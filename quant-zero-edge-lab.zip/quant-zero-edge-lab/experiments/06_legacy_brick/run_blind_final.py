"""
最终盲测：用生成的数据实盘交易 —— 不再找"正期望"，只看最后结果
==================================================================
引擎已通过铁律检验（随机游走里胜率=0.50, 无脑全做必亏）

设置:
  - tick级执行(无bar内路径歧义)
  - 市价成交 + 不利滑点 + 手续费
  - 头寸: 每笔风险1%本金, 名义<=5倍
  - 初始 10000 元
  - 四个市场, 我"事前不知道"哪个有edge, 用完全相同流程
  - 每市场 25 条路径 = 25 个"可能的我"
"""
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from ticktrade import (gen_ticks, run_brick_ticks, INIT_CAP,
                       TICKS_PER_HOUR, HOURS_PER_YEAR)

plt.rcParams['font.sans-serif'] = ['WenQuanYi Micro Hei', 'DejaVu Sans']
plt.rcParams['axes.unicode_minus'] = False

N = 150000
ANN = 0.20
SIG = ANN / np.sqrt(TICKS_PER_HOUR * HOURS_PER_YEAR)
NPATH = 25
A_MULT = 20
YEARS = N / (TICKS_PER_HOUR * HOURS_PER_YEAR)

MK = ['rw', 'trendvol', 'regime', 'strong']
MK_NAME = {'rw': '随机游走', 'trendvol': '趋势+波动', 'regime': '体制切换', 'strong': '强趋势'}

print("=" * 98)
print(f"最终盲测: {YEARS:.1f}年tick数据  初始{INIT_CAP:.0f}元  每笔风险1%  区间A={A_MULT*SIG*1e4:.0f}bp")
print("  我'事前不知道'哪个市场有edge —— 四个市场用完全相同的流程")
print("=" * 98)

results = {}
for mk in MK:
    results[mk] = {}
    for mode, uf in [("在线判定", True), ("无脑全做", False)]:
        fs, dds, bks, nts, wins, curves = [], [], [], [], [], []
        for s in range(NPATH):
            px = gen_ticks(mk, N, SIG, seed=5000 + s)
            r = run_brick_ticks(px, A_mult=A_MULT, W=100, use_filter=uf,
                                sigma_tick=SIG)
            fs.append(r['final']); dds.append(r['maxdd'])
            bks.append(r['bankrupt']); nts.append(r['n_trades'])
            wins.append(r['win']); curves.append(r['equity'])
        f = np.array(fs)
        results[mk][mode] = dict(f=f, dd=np.array(dds), bk=np.array(bks),
                                 nt=np.mean(nts), win=np.nanmean(wins),
                                 curves=curves, med=np.median(f))
        print(f"  {MK_NAME[mk]:<10} {mode:<8} 中位={np.median(f):>8.0f} 均值={f.mean():>9.0f} "
              f"最差={f.min():>7.0f} 最好={f.max():>9.0f} 亏损={(f<INIT_CAP).mean()*100:>3.0f}% "
              f"破产={np.mean(bks)*100:>3.0f}% 回撤={np.median(dds)*100:>5.1f}% 交易={np.mean(nts):>6.0f} 胜率={np.nanmean(wins):.4f}")

print("\n" + "=" * 98)
print("结论1: 在线判定(用统计决定下不下注) vs 无脑全做")
print("=" * 98)
print(f"  {'市场':<12} {'在线判定中位':>13} {'无脑中位':>11} {'差异':>10} {'判定胜率':>10} {'无脑胜率':>10}")
for mk in MK:
    a = results[mk]['在线判定']; b = results[mk]['无脑全做']
    print(f"  {MK_NAME[mk]:<12} {a['med']:>13.0f} {b['med']:>11.0f} {a['med']-b['med']:>+10.0f} "
          f"{a['win']:>10.4f} {b['win']:>10.4f}")

print("\n" + "=" * 98)
print("结论2: 最终答案 —— 10000元最后变成多少? (在线判定)")
print("=" * 98)
print(f"  {'市场':<12} {'中位终值':>10} {'收益率':>11} {'亏损率':>8} {'回撤':>8} {'评价':>10}")
for mk in MK:
    r = results[mk]['在线判定']
    ret = (r['med'] / INIT_CAP - 1) * 100
    loss = (r['f'] < INIT_CAP).mean() * 100
    ev = "赚钱" if ret > 20 else ("打平" if ret > -20 else "亏钱")
    print(f"  {MK_NAME[mk]:<12} {r['med']:>10.0f} {ret:>+10.1f}% {loss:>7.0f}% "
          f"{np.median(r['dd'])*100:>7.1f}% {ev:>10}")

print("\n" + "=" * 98)
print("关键: 我【事前不知道】自己在哪个市场 -> 真实预期 = 四市场混合")
print("=" * 98)
allf = np.concatenate([results[mk]['在线判定']['f'] for mk in MK])
allbk = np.concatenate([results[mk]['在线判定']['bk'] for mk in MK])
alldd = np.concatenate([results[mk]['在线判定']['dd'] for mk in MK])
print(f"  混合后({len(allf)}条路径):")
print(f"    中位终值 : {np.median(allf):>9.0f} 元   收益率 {(np.median(allf)/INIT_CAP-1)*100:+.1f}%")
print(f"    均值终值 : {allf.mean():>9.0f} 元   <- 被右尾拉高, 不是你的预期")
print(f"    最好/最差: {allf.max():>9.0f} / {allf.min():.0f} 元")
print(f"    亏损概率 : {(allf<INIT_CAP).mean()*100:>9.0f}%")
print(f"    破产概率 : {allbk.mean()*100:>9.0f}%")
print(f"    中位回撤 : {np.median(alldd)*100:>9.1f}%")

# ============================================================
# 图
# ============================================================
fig = plt.figure(figsize=(17.5, 11))
gs = fig.add_gridspec(2, 2, hspace=0.32, wspace=0.2)
fig.suptitle(f"最终盲测：10000元，{YEARS:.1f}年，tick级实盘（引擎已过铁律检验）",
             fontsize=14.5, fontweight='bold')

ax = fig.add_subplot(gs[0, :])
x = np.arange(len(MK))
w = 0.36
on = [results[mk]['在线判定']['med'] for mk in MK]
off = [results[mk]['无脑全做']['med'] for mk in MK]
ax.bar(x - w / 2, on, w, label='在线判定（用统计决定下不下注）', color='green', alpha=.85)
ax.bar(x + w / 2, off, w, label='无脑全做（每笔都做）', color='salmon', alpha=.85)
ax.axhline(INIT_CAP, color='k', ls='--', lw=2, label=f'本金 {INIT_CAP:.0f}')
ax.set_xticks(x)
ax.set_xticklabels([MK_NAME[m] for m in MK], fontsize=11)
ax.set_ylabel("最终权益中位数 (元)")
ax.set_title("① 最终权益：在线判定 vs 无脑全做\n（我事前不知道自己在哪个市场）", fontsize=11.5)
ax.legend(fontsize=9.5)
ax.grid(alpha=.3, axis='y')
for i, v in enumerate(on):
    ax.text(i - w / 2, v * 1.05, f"{v:.0f}", ha='center', fontsize=9.5, fontweight='bold')
for i, v in enumerate(off):
    ax.text(i + w / 2, v * 1.05, f"{v:.0f}", ha='center', fontsize=9.5, fontweight='bold')

ax = fig.add_subplot(gs[1, 0])
for mk in MK:
    cs = results[mk]['在线判定']['curves']
    ml = min(len(c) for c in cs)
    ax.plot(np.median(np.array([c[:ml] for c in cs]), axis=0), lw=2.2, label=MK_NAME[mk])
ax.axhline(INIT_CAP, color='k', ls='--', lw=1.5, label='本金')
ax.set_xlabel(f"tick (共{N})")
ax.set_ylabel("权益中位数 (元)")
ax.set_title("② 资金曲线中位数", fontsize=11.5)
ax.legend(fontsize=9)
ax.grid(alpha=.3)

ax = fig.add_subplot(gs[1, 1])
cols = ['salmon', 'steelblue', 'orange', 'green']
for i, mk in enumerate(MK):
    ax.hist(results[mk]['在线判定']['f'], bins=14, alpha=.66,
            label=f"{MK_NAME[mk]} 中位{results[mk]['在线判定']['med']:.0f}",
            color=cols[i], edgecolor='white')
ax.axvline(INIT_CAP, color='k', ls='--', lw=2, label=f'本金{INIT_CAP:.0f}')
ax.set_xlabel("最终权益 (元)")
ax.set_ylabel("路径数")
ax.set_title("③ 终值分布：每条都是\"一个我\"\n分布越宽 = 运气占比越大", fontsize=11.5)
ax.legend(fontsize=8.5)
ax.grid(alpha=.3)

plt.savefig("/data/workspace/brick/fig_blind_final.png", dpi=130)
print("\n[已保存] fig_blind_final.png")
