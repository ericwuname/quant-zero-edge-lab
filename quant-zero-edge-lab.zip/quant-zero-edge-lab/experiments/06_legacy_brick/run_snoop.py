"""
实验C: 数据窥探陷阱 —— 你的"正期望"有多少是搜索出来的运气?
================================================================
设计(对你怀疑的直接检验):
  1. 取【纯随机游走】市场 —— 数学上保证零结构、绝无 edge
  2. 暴力搜索 225 个均线参数组合
  3. 挑出样本内【最漂亮】的那个: 报告它的年化收益 / Sharpe / t值
  4. 把它放到【样本外】(全新独立路径) —— 看还剩多少
  5. 对照组: 在【有真实趋势结构】的市场里重复同样流程

关键对比:
  - 无结构市场: 样本内惊艳 -> 样本外塌(这就是幸存者偏差的定量形态)
  - 有结构市场: 样本内惊艳 -> 样本外【仍然为正】(这才是真 edge)

结论: 区分"运气"和"真edge"的唯一方法 = 样本外。别无他法。
"""
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from zoo import gen_market, eval_bar, sma

plt.rcParams['font.sans-serif'] = ['WenQuanYi Micro Hei', 'DejaVu Sans']
plt.rcParams['axes.unicode_minus'] = False

N = 12000
NSEED = 20
FAST = [2, 3, 4, 5, 6, 8, 10, 13, 16, 20, 25, 30, 38, 47, 58]
SLOW = [35, 44, 55, 68, 85, 106, 132, 165, 200]
SPLIT = int(N * 0.6)          # 样本内 60%


def ma_pos(px, f, s):
    a, b = sma(px, f), sma(px, s)
    raw = np.zeros(len(px))
    raw[(a > b) & ~np.isnan(a) & ~np.isnan(b)] = 1.0
    raw[(a < b) & ~np.isnan(a) & ~np.isnan(b)] = -1.0
    return raw


def scan(px, fgrid=FAST, sgrid=SLOW):
    """返回所有参数组合的 (样本内年化%, 样本外年化%, 样本内Sharpe)"""
    out = []
    for f in fgrid:
        for s in sgrid:
            if s <= f * 1.5:
                continue
            raw = ma_pos(px, f, s)
            e_in = eval_bar(px[:SPLIT], raw[:SPLIT])
            e_out = eval_bar(px[SPLIT:], raw[SPLIT:])
            out.append((f, s, e_in["ret_ann"] * 100, e_out["ret_ann"] * 100, e_in["sharpe"]))
    return out


print("=" * 94)
print("实验C: 数据窥探 —— 在【零结构】市场里能'搜出'多漂亮的正期望?")
print("=" * 94)

for mk in ["RW", "TRENDVOL"]:
    print(f"\n### 市场: {mk} " + "(纯随机游走, 数学上绝无edge)" if mk == "RW"
          else f"\n### 市场: {mk} (含真实缓慢漂移趋势)")
    best_ins, best_outs, best_shps = [], [], []
    all_ins, all_outs = [], []
    for s_ in range(NSEED):
        px, _ = gen_market(mk, N, seed=3000 + s_)
        res = scan(px)
        arr = np.array([(r[2], r[3], r[4]) for r in res])
        ins, outs, shps = arr[:, 0], arr[:, 1], arr[:, 2]
        all_ins.extend(ins); all_outs.extend(outs)
        bi = int(np.argmax(ins))                 # 样本内挑最好的
        best_ins.append(ins[bi]); best_outs.append(outs[bi]); best_shps.append(shps[bi])
    bi = np.array(best_ins); bo = np.array(best_outs); bs = np.array(best_shps)
    ai = np.array(all_ins); ao = np.array(all_outs)

    t_in = bi.mean() / (bi.std() / np.sqrt(len(bi))) if bi.std() > 0 else 0
    t_out = bo.mean() / (bo.std() / np.sqrt(len(bo))) if bo.std() > 0 else 0

    print(f"  参数组合总数: {len(res)} (每一个都被'试'过)")
    print(f"  ── 全部参数的平均表现 ──")
    print(f"     样本内平均年化: {ai.mean():>7.2f}%   样本外平均年化: {ao.mean():>7.2f}%")
    print(f"  ── 挑出样本内【最好的那一个】 ──")
    print(f"     样本内年化: {bi.mean():>7.2f}%  (t={t_in:>5.1f} <- 看起来极显著!)")
    print(f"     样本内Sharpe: {bs.mean():>7.2f}")
    print(f"     样本外年化: {bo.mean():>7.2f}%  (t={t_out:>5.1f})")
    decay = (1 - bo.mean() / bi.mean()) * 100 if abs(bi.mean()) > 1e-9 else 0
    print(f"     过拟合衰减: {decay:>7.1f}%   <- 样本内的成绩, 样本外还剩多少")
    pct_neg = (bo < 0).mean() * 100
    print(f"     样本外变负的比例: {pct_neg:>5.1f}%")
    if mk == "RW":
        rw = (bi, bo, bs)
    else:
        tv = (bi, bo, bs)

print("\n" + "=" * 94)
print("决定性对比")
print("=" * 94)
print(f"  {'':<18} {'样本内(挑最优)':>15} {'样本外(真相)':>15} {'判定':>14}")
print(f"  {'随机游走(无edge)':<18} {rw[0].mean():>13.2f}% {rw[1].mean():>13.2f}% {'假象,塌了':>14}")
print(f"  {'趋势市场(有edge)':<18} {tv[0].mean():>13.2f}% {tv[1].mean():>13.2f}% {'样本外仍正=真':>14}")

# ============================================================
# 图
# ============================================================
fig, axes = plt.subplots(1, 3, figsize=(17.5, 5.2))
fig.suptitle("数据窥探陷阱：回测里的'正期望'，有多少是搜索出来的运气？",
             fontsize=14, fontweight='bold')

ax = axes[0]
w = 0.36
labels = ['随机游走\n(零结构)', '趋势市场\n(有真结构)']
xb = np.arange(2)
ax.bar(xb - w / 2, [rw[0].mean(), tv[0].mean()], w, label='样本内 (挑最优参数)', color='gold')
ax.bar(xb + w / 2, [rw[1].mean(), tv[1].mean()], w, label='样本外 (全新数据)', color='steelblue')
ax.axhline(0, color='k', lw=1.3)
ax.set_xticks(xb); ax.set_xticklabels(labels, fontsize=10)
ax.set_ylabel("年化收益 %")
ax.set_title("① 样本内 vs 样本外\n无edge: 样本内惊艳→样本外塌\n有edge: 样本外仍站得住", fontsize=10.5)
ax.legend(fontsize=9); ax.grid(alpha=.3, axis='y')
for i, v in enumerate([rw[0].mean(), tv[0].mean()]):
    ax.text(i - w / 2, v + 0.4, f"{v:.1f}%", ha='center', fontsize=9)
for i, v in enumerate([rw[1].mean(), tv[1].mean()]):
    ax.text(i + w / 2, v + (0.4 if v > 0 else -1.2), f"{v:.1f}%", ha='center', fontsize=9)

ax = axes[1]
ax.hist(rw[1], bins=14, alpha=.75, label='随机游走(无edge)', color='salmon')
ax.hist(tv[1], bins=14, alpha=.75, label='趋势市场(有edge)', color='steelblue')
ax.axvline(0, color='k', lw=1.3)
ax.set_xlabel("样本外年化收益 %"); ax.set_ylabel("频次")
ax.set_title("② 样本外收益分布\n无edge: 分布在0附近/偏负\n有edge: 整体右移", fontsize=10.5)
ax.legend(fontsize=9); ax.grid(alpha=.3)

ax = axes[2]
# 搜索次数 vs 样本内"最优"的虚高程度
ns = [5, 20, 50, 100, 225]
ins_means = []
for k in ns:
    vals = []
    for s_ in range(10):
        px, _ = gen_market("RW", N, seed=7000 + s_)
        res = scan(px)[:k]
        vals.append(max(r[2] for r in res))
    ins_means.append(np.mean(vals))
ax.plot(ns, ins_means, 'o-', color='darkred', lw=2.2, ms=8)
ax.axhline(0, color='k', ls='--', lw=1.2)
ax.set_xlabel("搜索了多少个参数组合")
ax.set_ylabel("样本内'最优'年化收益 %")
ax.set_title("③ 试得越多，'最优'越漂亮\n纯随机市场里也能'搜出'正期望 —— 全是运气",
             fontsize=10.5)
ax.grid(alpha=.3)
for i, v in enumerate(ins_means):
    ax.text(ns[i], v + 0.3, f"{v:.1f}", ha='center', fontsize=8.5)

plt.tight_layout(rect=[0, 0, 1, 0.93])
plt.savefig("/data/workspace/brick/fig_snoop.png", dpi=130)
print("\n[已保存] fig_snoop.png")
