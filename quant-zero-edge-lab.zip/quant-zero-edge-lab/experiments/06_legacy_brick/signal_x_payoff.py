"""
【终极组合】信号入场 × 宽目标出场 —— 乘法效应
====================================================
【逻辑】
  前面分离测试了:
    - 信号(动量 mom_60 最强)     -> 样本外夏普 0.097, 弱但为正
    - 宽目标(R=3~5)            -> E单调改善, 但随机入场时不显著
  两者是【乘法】关系吗?
    E_total = 信号带来的胜率提升 × 宽目标带来的盈亏比提升

【实验设计】
  入场信号: 动量(只用过去信息, 无前视)
  出场规则:
    A. 固定止损 + 固定止盈 (R = 1/2/3/5)
    B. 固定止损 + 追踪止盈
    C. 对照: 随机入场 + 同样出场  (分离出场规则的贡献)
  对照: 买入持有

【关键检验】
  1. 信号入场是否优于随机入场? (配对检验)
  2. 最优组合的 E 与 t 值
  3. 样本内/样本外切分 (样本内选最优R, 样本外验证)
  4. 成本敏感性

【严格性】
  必须无前视: 信号用t及之前, 出场从t+1开始
"""
import numpy as np
import pandas as pd
from scipy import stats

HOURLY = {'DOGE': '/data/inputs/DOGEUSDT_1h.csv',
          'DOT':  '/data/inputs/DOTUSDT_1h.csv',
          'CRV':  '/data/inputs/CRVUSDT_1h.csv',
          'DASH': '/data/inputs/DASHUSDT_1h.csv'}


def load():
    out = {}
    for k, p in HOURLY.items():
        d = pd.read_csv(p)
        out[k] = d['close'].values.astype(float)
    return out


def momentum_signal(px, w):
    """动量信号: 用 t 及之前 -> 信号[t] 用于 t+1 之后入场
    长度 = len(px), signal[t] 在 t 时刻可知
    """
    n = len(px)
    sig = np.zeros(n)
    sig[w:] = np.sign(px[w:] / np.maximum(px[:-w], 1e-9) - 1)
    return sig


def run_trades(px, signal, risk, R=None, trail=None,
               cost_bp=2, max_hold=1000, seed=42):
    """
    signal: 长度n, signal[t]表示t时刻的方向建议(+-1) 或 0(不入场)
    R:   固定止盈倍数 (None则用trail)
    trail: 追踪止盈回撤比例
    """
    n = len(px)
    rng = np.random.default_rng(seed)
    rets = []
    i = max(60, 0)
    while i < n - 2:
        s = signal[i]
        if s == 0:
            # 随机方向入场(对照组)
            s = rng.choice([-1, 1])
        direction = 1 if s > 0 else -1
        entry = px[i]

        if trail is not None:
            # 追踪止盈
            sl = entry * (1 - risk) if direction == 1 else entry * (1 + risk)
            peak = entry
            exit_i = None
            for j in range(i + 1, min(i + max_hold, n)):
                p = px[j]
                if direction == 1:
                    peak = max(peak, p)
                    if p <= sl:
                        exit_i = j; break
                    if p <= peak * (1 - trail):
                        exit_i = j; break
                else:
                    peak = min(peak, p)
                    if p >= sl:
                        exit_i = j; break
                    if p >= peak * (1 + trail):
                        exit_i = j; break
        else:
            sl = entry * (1 - risk) if direction == 1 else entry * (1 + risk)
            tp = entry * (1 + risk * R) if direction == 1 else entry * (1 - risk * R)
            exit_i = None
            for j in range(i + 1, min(i + max_hold, n)):
                p = px[j]
                if direction == 1:
                    if p <= sl: exit_i = j; break
                    if p >= tp: exit_i = j; break
                else:
                    if p >= sl: exit_i = j; break
                    if p <= tp: exit_i = j; break
        if exit_i is None:
            exit_i = min(i + max_hold, n - 1)
        ret = (px[exit_i] / entry - 1) * direction
        ret -= 2 * cost_bp / 1e4
        rets.append(ret)
        i = exit_i + 1
    return np.array(rets)


def stats_of(rets):
    if len(rets) < 30:
        return None
    pw = (rets > 0).mean()
    aw = rets[rets > 0].mean() if (rets > 0).any() else 0
    al = -rets[rets < 0].mean() if (rets < 0).any() else 0
    E = rets.mean()
    t = E / (rets.std() / np.sqrt(len(rets))) if rets.std() > 0 else 0
    return dict(n=len(rets), win=pw, aw=aw, al=al, E_bp=E * 1e4, t=t,
                R=aw / al if al > 0 else 0)


print("=" * 100)
print("【终极组合】信号入场 × 宽目标出场 —— 乘法效应测试")
print("=" * 100)
print("  入场: 动量信号(mom) vs 随机(对照)")
print("  出场: 固定止盈(R) / 追踪止盈(trail)")
print("  止损: 2%,  成本: 2bp单边(maker)")

data = load()
RISK = 0.02
W_MOM = 60           # 动量窗口(小时)

print(f"\n  【A】动量信号 + 固定止盈 (扫描R)")
print(f"  {'品种':<7}{'R':>5}{'笔数':>7}{'胜率':>8}{'均盈':>8}{'均亏':>8}"
      f"{'实际R':>8}{'E(bp)':>9}{'t值':>8}{'vs随机':>9}")
print("  " + "-" * 80)

summary = []
for sym in ['DOGE', 'CRV', 'DOT', 'DASH']:
    px = data[sym]
    sig = momentum_signal(px, W_MOM)
    for R in [1, 2, 3, 5]:
        r_sig = run_trades(px, sig, RISK, R=R, cost_bp=2)
        r_rnd = run_trades(px, np.zeros(len(px)), RISK, R=R, cost_bp=2)
        s1 = stats_of(r_sig); s2 = stats_of(r_rnd)
        if s1 is None or s2 is None:
            continue
        diff = s1['E_bp'] - s2['E_bp']
        print(f"  {sym:<7}{R:>5}{s1['n']:>7}{s1['win']*100:>7.1f}%"
              f"{s1['aw']*100:>7.2f}%{s1['al']*100:>7.2f}%{s1['R']:>8.2f}"
              f"{s1['E_bp']:>+9.1f}{s1['t']:>+8.2f}{diff:>+9.1f}")
        summary.append((sym, 'fixed', R, s1['E_bp'], s1['t'], diff))

print(f"\n  【B】动量信号 + 追踪止盈(宽目标=让盈利奔跑)")
print(f"  {'品种':<7}{'trail':>7}{'笔数':>7}{'胜率':>8}{'均盈':>8}{'均亏':>8}"
      f"{'实际R':>8}{'E(bp)':>9}{'t值':>8}{'vs随机':>9}")
print("  " + "-" * 80)

for sym in ['DOGE', 'CRV', 'DOT', 'DASH']:
    px = data[sym]
    sig = momentum_signal(px, W_MOM)
    for tr in [0.02, 0.05, 0.10]:
        r_sig = run_trades(px, sig, RISK, trail=tr, cost_bp=2)
        r_rnd = run_trades(px, np.zeros(len(px)), RISK, trail=tr, cost_bp=2)
        s1 = stats_of(r_sig); s2 = stats_of(r_rnd)
        if s1 is None or s2 is None:
            continue
        diff = s1['E_bp'] - s2['E_bp']
        print(f"  {sym:<7}{tr*100:>6.0f}%{s1['n']:>7}{s1['win']*100:>7.1f}%"
              f"{s1['aw']*100:>7.2f}%{s1['al']*100:>7.2f}%{s1['R']:>8.2f}"
              f"{s1['E_bp']:>+9.1f}{s1['t']:>+8.2f}{diff:>+9.1f}")
        summary.append((sym, 'trail', tr, s1['E_bp'], s1['t'], diff))

# ---------- 汇总 ----------
print(f"\n" + "=" * 100)
print(f"  【汇总】信号入场 vs 随机入场 (所有品种/参数)")
print(f"  {'出场方式':<12}{'信号E均值':>12}{'随机E均值':>12}{'差值':>10}"
      f"{'信号胜出数':>12}{'最大t值':>10}")
print("  " + "-" * 68)

for mode in ['fixed', 'trail']:
    sub = [x for x in summary if x[1] == mode]
    if not sub:
        continue
    es = np.array([x[3] for x in sub])
    ds = np.array([x[5] for x in sub])
    ts = np.array([x[4] for x in sub])
    wins = int((ds > 0).sum())
    print(f"  {mode:<12}{es.mean():>+11.1f}bp{(es-ds).mean():>+11.1f}bp"
          f"{ds.mean():>+10.1f}bp{wins:>8}/{len(sub)}{ts.max():>10.2f}")

# ---------- 最好的组合 ----------
print(f"\n  【最佳组合】(按t值排序, 前5)")
print(f"  {'品种':<7}{'方式':<10}{'参数':>8}{'E(bp)':>10}{'t值':>8}{'判定':>10}")
best = sorted(summary, key=lambda x: -abs(x[4]))[:5]
for sym, mode, param, E, t, diff in best:
    pv = '显著' if abs(t) > 1.96 else '不显著'
    print(f"  {sym:<7}{mode:<10}{param:>8}{E:>+10.1f}{t:>+8.2f}{pv:>10}")

print("\n" + "=" * 100)
print("完成")
print("=" * 100)
