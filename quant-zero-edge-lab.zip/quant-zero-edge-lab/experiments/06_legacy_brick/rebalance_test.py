"""
新路检验: 再平衡溢价 (Volatility Harvesting)
=============================================
【为什么这是"新路"】
  之前所有测试都在【预测方向】-> 全部失败
  再平衡【不预测任何方向】: 定期调回目标权重 = 机械低买高卖
  收益来源: 资产间的相对波动 (不是别人的错误)
  -> 不会被反身性消灭 (没有"被利用即消失"的问题)

【数学】
  两个低相关高波动资产, 50/50 定期再平衡
  溢价 ≈ 波动率的函数, 相关性越低、波动越大 -> 溢价越高
  与方向无关!

【检验】
  1. 相关性矩阵 (crypto内部相关性有多高?)
  2. 等权组合: 定期再平衡 vs 买入持有(不rebalance)
  3. 多频率: 日/周/月/季/年
  4. 扣真实换手成本 (按调仓量, 不是全额)
  5. 配对bootstrap显著性 + 样本外
  6. 随机对照: 打乱日期 (破坏相对波动结构)
  7. 匹配暴露: 再平衡 vs 同等平均仓位的固定组合

【关键判据】
  扣成本后再平衡溢价是否显著为正?
"""
import numpy as np
import pandas as pd
from scipy import stats

DAILY = {'BTC': '/data/inputs/BTCUSDT_1d.csv',
         'BNB': '/data/inputs/BNBUSDT_1d.csv',
         'BCH': '/data/inputs/BCHUSDT_1d.csv'}
HOURLY = {'DOGE': '/data/inputs/DOGEUSDT_1h.csv',
          'DOT':  '/data/inputs/DOTUSDT_1h.csv',
          'CRV':  '/data/inputs/CRVUSDT_1h.csv',
          'DASH': '/data/inputs/DASHUSDT_1h.csv'}
DAYS_YR = 365
COST_BP = 20       # 单边成本 bp
BLK = 20


def load():
    px = {}
    for k, p in DAILY.items():
        d = pd.read_csv(p)
        s = pd.Series(d['close'].values,
                      index=pd.to_datetime(d['timestamp'], unit='ms').dt.normalize())
        px[k] = s[~s.index.duplicated()]
    for k, p in HOURLY.items():
        d = pd.read_csv(p)
        s = pd.Series(d['close'].values,
                      index=pd.to_datetime(d['timestamp'], unit='ms'))
        px[k] = s.resample('1D').last().dropna()
    return pd.DataFrame(px).dropna()


def boot_idx(rng, T, L):
    nb = int(np.ceil(T / L))
    st = rng.integers(0, T - L, size=nb)
    return (st[:, None] + np.arange(L)[None, :]).ravel()[:T] % T


def metrics(net):
    n = len(net)
    mu, sd = net.mean(), net.std()
    if sd < 1e-12 or n < 10:
        return 0.0, 0.0, 0.0
    nav = np.cumprod(1.0 + np.clip(net, -0.99, None))
    ann = float(np.clip((nav[-1] ** (DAYS_YR / n) - 1) * 100 if nav[-1] > 0 else -100.0, -100, 1e6))
    sh = mu / sd * np.sqrt(DAYS_YR)
    pk = np.maximum.accumulate(nav)
    dd = (nav - pk) / np.maximum(pk, 1e-12)
    return ann, sh, float(-dd.min() * 100)


def paired_test(a, b, kind='sharpe', B=1000, seed=0):
    def sh(x):
        s = x.std()
        return x.mean() / s * np.sqrt(DAYS_YR) if s > 1e-12 else 0.0
    def mdd(x):
        nav = np.cumprod(1.0 + np.clip(x, -0.99, None))
        pk = np.maximum.accumulate(nav)
        return float(-((nav - pk) / np.maximum(pk, 1e-12)).min() * 100)
    f = sh if kind == 'sharpe' else mdd
    T = len(a)
    rng = np.random.default_rng(seed)
    obs = f(a) - f(b)
    d = np.zeros(B)
    for i in range(B):
        d[i] = f(a[boot_idx(rng, T, BLK)]) - f(b[boot_idx(rng, T, BLK)])
    return obs, min(2 * min((d <= 0).mean(), (d >= 0).mean()), 1.0)


def rebalance_backtest(px, freq_days, cost_bp):
    """
    px: DataFrame of prices
    freq_days: 再平衡间隔(交易日)
    返回: (再平衡组合的日收益序列, 买入持有的日收益序列, 平均换手率)
    """
    r = px.pct_change().fillna(0)
    T, N = r.shape
    R = r.values

    # 买入持有: 初始等权, 之后不动
    w_bh = np.ones(N) / N
    bh_val = np.zeros(T)
    bh_val[0] = 1.0
    for t in range(1, T):
        # 各资产按自身收益增长
        holdings = w_bh * np.cumprod(1 + R[:t], axis=0)[-1]
        bh_val[t] = holdings.sum()
    bh_ret = np.zeros(T)
    bh_ret[1:] = bh_val[1:] / np.maximum(bh_val[:-1], 1e-12) - 1

    # 再平衡: 每 freq_days 调回等权
    val = np.zeros(T)
    val[0] = 1.0
    holdings = np.ones(N) / N      # 初始等权
    turnover = np.zeros(T)
    for t in range(1, T):
        holdings = holdings * (1 + R[t])
        tv = holdings.sum()
        if t % freq_days == 0:
            target = tv / N
            turn_amt = np.abs(holdings - target).sum()
            # 成本: 调仓量 * 双边成本
            cost = turn_amt * (2 * cost_bp / 1e4)
            tv = tv - cost
            holdings = np.ones(N) * (tv / N)
            turnover[t] = turn_amt / 2.0   # 单边换手率
        val[t] = tv
    rb_ret = np.zeros(T)
    rb_ret[1:] = val[1:] / np.maximum(val[:-1], 1e-12) - 1
    avg_turn = turnover[turnover > 0].mean() if (turnover > 0).any() else 0
    return rb_ret, bh_ret, avg_turn


# ============ 主流程 ============
print("=" * 100)
print("新路检验: 再平衡溢价 (Volatility Harvesting) —— 不预测方向的收益")
print("=" * 100)

df = load()
T, N = df.shape
sp = T // 2
print(f"面板: {N}品种 x {T}天 ({df.index[0].date()} -> {df.index[-1].date()})")
print(f"品种: {list(df.columns)}")
print(f"样本外: [{sp}, {T})")

# ---------- 1. 相关性矩阵 ----------
print("\n" + "=" * 100)
print("【1】相关性矩阵 —— crypto内部相关性有多高?")
print("=" * 100)
print("  再平衡溢价需要【低相关】+【高波动】")
ret = df.pct_change().fillna(0)
corr = ret.corr()
print(f"\n  {'':<7}" + "".join(f"{c:>8}" for c in corr.columns))
for i in corr.index:
    print(f"  {i:<7}" + "".join(f"{corr.loc[i,c]:>8.3f}" for c in corr.columns))
off_diag = corr.values[~np.eye(N, dtype=bool)]
print(f"\n  非对角相关: 均值 {off_diag.mean():.3f}  最小 {off_diag.min():.3f}  "
      f"最大 {off_diag.max():.3f}")
print(f"  日波动率均值: {ret.std().mean()*100:.2f}%  (年化 {ret.std().mean()*np.sqrt(365)*100:.1f}%)")
print("\n  判读: 相关性越接近1, 再平衡溢价越小")
print("        crypto 通常高度相关(0.7-0.9), 溢价会很有限")

# ---------- 2. 再平衡 vs 买入持有 ----------
print("\n" + "=" * 100)
print("【2】再平衡 vs 买入持有 (等权组合, 扣真实换手成本)")
print("=" * 100)
print(f"  {'频率':<10}{'年化(再平衡)':>14}{'年化(持有)':>13}{'溢价':>10}"
      f"{'夏普RB':>9}{'夏普BH':>9}{'Δ夏普':>9}{'p':>8}{'回撤RB':>9}{'回撤BH':>9}")

results = []
for freq, label in [(1, '每日'), (5, '每周'), (21, '每月'), (63, '每季'), (250, '每年')]:
    rb, bh, avg_turn = rebalance_backtest(df, freq, COST_BP)
    a1, s1, d1 = metrics(rb[sp:])
    a2, s2, d2 = metrics(bh[sp:])
    dsh, psh = paired_test(rb[sp:], bh[sp:], 'sharpe', seed=101)
    print(f"  {label:<10}{a1:>13.2f}%{a2:>12.2f}%{a1-a2:>+9.2f}%"
          f"{s1:>9.3f}{s2:>9.3f}{dsh:>+9.3f}{min(psh,1.0):>8.3f}"
          f"{d1:>8.2f}%{d2:>8.2f}%")
    results.append((label, freq, a1 - a2, dsh, min(psh, 1.0), avg_turn))

print(f"\n  判读: '溢价'>0 且 p<0.05 = 再平衡溢价成立且可交易")
print(f"        溢价 = 再平衡年化 - 买入持有年化 (扣成本后)")

# ---------- 3. 零成本上界 ----------
print("\n" + "=" * 100)
print("【3】零成本上界 —— 溢价的理论最大值 (成本吃掉多少?)")
print("=" * 100)
print(f"  {'频率':<10}{'溢价(0bp)':>13}{'溢价(20bp)':>13}{'成本吃掉':>12}")
for freq, label in [(1, '每日'), (5, '每周'), (21, '每月'), (63, '每季')]:
    rb0, bh0, _ = rebalance_backtest(df, freq, 0)
    rb2, bh2, _ = rebalance_backtest(df, freq, COST_BP)
    a0 = metrics(rb0[sp:])[0] - metrics(bh0[sp:])[0]
    a2 = metrics(rb2[sp:])[0] - metrics(bh2[sp:])[0]
    print(f"  {label:<10}{a0:>+12.2f}%{a2:>+12.2f}%{a0-a2:>+11.2f}%")

# ---------- 4. 随机对照 ----------
print("\n" + "=" * 100)
print("【4】随机对照 —— 溢价是真结构, 还是样本噪声?")
print("=" * 100)
rb_real, bh_real, _ = rebalance_backtest(df, 21, COST_BP)
prem_real = metrics(rb_real[sp:])[0] - metrics(bh_real[sp:])[0]
rng = np.random.default_rng(7)
prem_rand = []
for b in range(200):
    # 打乱每日收益的顺序 (破坏时间序列结构, 保留横截面)
    perm = rng.permutation(T)
    r_perm = ret.values[perm]
    px_perm = pd.DataFrame(np.cumprod(1 + r_perm, axis=0), columns=df.columns)
    rb_p, bh_p, _ = rebalance_backtest(px_perm, 21, COST_BP)
    prem_rand.append(metrics(rb_p[sp:])[0] - metrics(bh_p[sp:])[0])
prem_rand = np.array(prem_rand)
p_rand = (prem_rand >= prem_real).mean()
print(f"  真实再平衡溢价: {prem_real:+.2f}%/年")
print(f"  随机打乱后    : {prem_rand.mean():+.2f}% ± {prem_rand.std():.2f}%")
print(f"  置换 p 值     : {p_rand:.3f} ({'显著' if p_rand<0.05 else '不显著'})")

# ---------- 5. 分年度稳健性 ----------
print("\n" + "=" * 100)
print("【5】分年度稳健性 (每月再平衡, 扣成本)")
print("=" * 100)
rb_r, bh_r, _ = rebalance_backtest(df, 21, COST_BP)
years = df.index.year.values[sp:]
rb_oos, bh_oos = rb_r[sp:], bh_r[sp:]
print(f"  {'年份':<8}{'再平衡':>11}{'买入持有':>11}{'溢价':>10}{'判定':>10}")
wins = 0
yrs_tot = 0
for y in sorted(set(years)):
    m = years == y
    if m.sum() < 30:
        continue
    a_r = (np.cumprod(1 + np.clip(rb_oos[m], -0.99, None))[-1] - 1) * 100
    a_b = (np.cumprod(1 + np.clip(bh_oos[m], -0.99, None))[-1] - 1) * 100
    yrs_tot += 1
    if a_r > a_b:
        wins += 1
    print(f"  {y:<8}{a_r:>10.2f}%{a_b:>10.2f}%{a_r-a_b:>+9.2f}%"
          f"{('再平衡优' if a_r>a_b else '持有优'):>10}")
print(f"\n  再平衡占优年份: {wins}/{yrs_tot}")

print("\n" + "=" * 100)
print("完成")
print("=" * 100)
