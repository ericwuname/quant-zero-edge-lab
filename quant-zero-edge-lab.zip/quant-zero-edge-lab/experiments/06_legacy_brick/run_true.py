import numpy as np, matplotlib
matplotlib.use('Agg'); import matplotlib.pyplot as plt
from brick_engine import to_bricks, cont_prob

N=60000; L=2000; S=0.000707; COST_REL=0.0005
def gen_trend(n, snr, seed, L=L, s=S):
    rng=np.random.default_rng(seed)
    nseg=int(np.ceil(n/L)); signs=rng.choice([-1,1],size=nseg)
    d=snr*np.sqrt(L)*s/L
    drift=np.repeat(signs*d,L)[:n]
    r=drift+rng.normal(0,s,n)
    return 100.0*np.exp(np.cumsum(r))
def meas(px,A):
    b=to_bricks(px,A)
    return (cont_prob(b),len(b)) if len(b)>=30 else (np.nan,0)

print("="*78)
print("扣除伪影后的【真实可行域】(伪影基线 = 同A下 无动量snr=0 测得的p)")
print("="*78)
As=[0.3,0.5,1.0,2.0,3.0,5.0]
print(f"  {'A%':>5} {'伪影基线p0':>10} {'伪影偏移':>8} | {'snr=2实测p':>10} {'扣伪影p真':>10} {'p*':>7} {'真实净E':>9} {'N':>6} {'判定':>8}")
rows=[]
for A in As:
    # 伪影基线 (无动量)
    b0=[];n0=[]
    for s_ in range(20):
        p,n=meas(gen_trend(N,0.0,500+s_),A)
        if n>0: b0.append(p); n0.append(n)
    p0=np.mean(b0)
    # snr=2
    p2=[];n2=[]
    for s_ in range(20):
        p,n=meas(gen_trend(N,2.0,300+s_),A)
        if n>0: p2.append(p); n2.append(n)
    p2m=np.mean(p2); n2m=np.mean(n2)
    bias=p0-0.5
    p_true=p2m-bias
    c=COST_REL/(A/100.0); pstar=(1+c)/2
    net=(2*p_true-1)-c
    ok="可行" if (net>0 and n2m>=150) else ("砖太少" if n2m<150 else "期望负")
    rows.append((A,p0,bias,p2m,p_true,pstar,net,n2m))
    print(f"  {A:>5.1f} {p0:>10.4f} {bias:>+8.4f} | {p2m:>10.4f} {p_true:>10.4f} {pstar:>7.3f} {net:>+9.4f} {n2m:>6.0f} {ok:>8}")

# 弱动量 snr=1 情形
print("\n若真实市场动量很弱 (snr=1):")
print(f"  {'A%':>5} {'扣伪影p真':>10} {'p*':>7} {'真实净E':>9} {'N':>6} {'判定':>8}")
for A in As:
    b0=[]
    for s_ in range(20):
        p,n=meas(gen_trend(N,0.0,500+s_),A)
        if n>0: b0.append(p)
    p0=np.mean(b0); bias=p0-0.5
    p1=[]
    for s_ in range(20):
        p,n=meas(gen_trend(N,1.0,700+s_),A)
        if n>0: p1.append(p)
    p1m=np.mean(p1); p_true=p1m-bias
    c=COST_REL/(A/100.0); pstar=(1+c)/2; net=(2*p_true-1)-c
    n1=len(p1)
    ok="可行" if net>0 else "期望负"
    print(f"  {A:>5.1f} {p_true:>10.4f} {pstar:>7.3f} {net:>+9.4f} {n1:>6} {ok:>8}")

fig,ax=plt.subplots(1,2,figsize=(13,4.6))
ax[0].bar([str(r[0]) for r in rows],[r[6] for r in rows],
          color=['green' if r[6]>0 else 'salmon' for r in rows])
ax[0].axhline(0,color='k',lw=1.2)
ax[0].set_xlabel("砖块A (%)"); ax[0].set_ylabel("真实净期望(扣伪影+扣成本)")
ax[0].set_title("真实可行域 (动量snr=2)\n绿=正 红=负"); ax[0].grid(alpha=.3,axis='y')
ax[1].plot([r[0] for r in rows],[r[1] for r in rows],'o-',color='darkred',lw=2,label='伪影基线 p0 (无动量)')
ax[1].plot([r[0] for r in rows],[r[2] for r in rows],'s-',color='purple',lw=2,label='伪影偏移量')
ax[1].axhline(0.5,color='k',ls='--',lw=1.2)
ax[1].set_xlabel("砖块A (%)"); ax[1].set_ylabel("概率")
ax[1].set_title("伪影大小：A越小(采样相对越粗)→假趋势越强"); ax[1].legend(fontsize=8); ax[1].grid(alpha=.3)
plt.tight_layout(); plt.savefig("/data/workspace/brick/fig_true.png",dpi=130)
print("\n[已保存] fig_true.png")
