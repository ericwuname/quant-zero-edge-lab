"""
丰年/灾年 检验: 短期角度, 收益的时间分布不均匀性
====================================================
【核心问题】
  长期平均可能为零/负, 但如果收益是【集中的】:
    - 少数"丰年/丰日"贡献大部分收益
    - 多数"灾年/平日"在磨损
  那么: 能否在丰年多种(加仓)、灾年少种(减仓)?

【四层检验】
  A. 收益集中度   : 多少天贡献了全部收益? (验证"丰年灾年"是否真实存在)
  B. 极端日可预测 : 能否提前知道明天是"最好/最坏"的日子?
                    (上行捕获 vs 下行保护, 哪个更可行?)
  C. 条件仓位     : 按预测状态调整耕作强度 -> walk-forward + 配对检验
  D. 状态持续性   : 丰年后更可能丰年? 灾年后更可能灾年? (列联表+卡方)

【严谨性】
  - 无前视: 特征用 t 及之前, 预测 t+1
  - 随机对照: 打乱状态标签 -> 零假设基线 (吸取波动率目标的教训)
  - 匹配暴露: 条件仓位若长期降仓, 必须和"同等平均仓位的固定仓位"比
  - walk-forward + 配对bootstrap + 多重检验校正
"""
import numpy as np
import pandas as pd
from scipy import stats

DAILY = {'BTC': '/data/inputs/BTCUSDT_1d.csv',
         'BNB': '/data/inputs/BNBUSDT_1d.csv',
         'BCH': '/data/inputs/BCHUSDT_1d.csv'}
HOURLY = {'DOGE': '/data/inputs/DOGEUSDT_1h.csv',
          'DOT':  '/data/inputs/DOTUSDT_1h.csv',
          'CRV':  '/data/inputs/CRVUSDT_1h.csv',
          'DASH': '/data/inputs/DASHUSDT_1h.csv'}
DAYS_YR = 365
B_BOOT = 500
BLK = 20


def load():
    px = {}
    for k, p in DAILY.items():
        d = pd.read_csv(p)
        s = pd.Series(d['close'].values,
                      index=pd.to_datetime(d['timestamp'], unit='ms').dt.normalize())
        px[k] = s[~s.index.duplicated()]
    for k, p in HOURLY.items():
        d = pd.read_csv(p)
        s = pd.Series(d['close'].values,
                      index=pd.to_datetime(d['timestamp'], unit='ms'))
        px[k] = s.resample('1D').last().dropna()
    return pd.DataFrame(px).dropna()


def metrics(net):
    n = len(net)
    mu, sd = net.mean(), net.std()
    if sd < 1e-12 or n < 10:
        return 0.0, 0.0, 0.0
    nav = np.cumprod(1.0 + np.clip(net, -0.99, None))
    ann = float(np.clip((nav[-1] ** (DAYS_YR / n) - 1) * 100 if nav[-1] > 0 else -100.0, -100, 1e6))
    sh = mu / sd * np.sqrt(DAYS_YR)
    pk = np.maximum.accumulate(nav)
    dd = (nav - pk) / np.maximum(pk, 1e-12)
    return ann, sh, float(-dd.min() * 100)


def boot_idx(rng, T, L):
    nb = int(np.ceil(T / L))
    st = rng.integers(0, T - L, size=nb)
    return (st[:, None] + np.arange(L)[None, :]).ravel()[:T] % T


def paired_test(a, b, kind='sharpe', B=B_BOOT, blk=BLK, seed=0):
    def sh(x):
        s = x.std()
        return x.mean() / s * np.sqrt(DAYS_YR) if s > 1e-12 else 0.0
    def mdd(x):
        nav = np.cumprod(1.0 + np.clip(x, -0.99, None))
        pk = np.maximum.accumulate(nav)
        return float(-((nav - pk) / np.maximum(pk, 1e-12)).min() * 100)
    f = sh if kind == 'sharpe' else mdd
    T = len(a)
    rng = np.random.default_rng(seed)
    obs = f(a) - f(b)
    d = np.zeros(B)
    for i in range(B):
        d[i] = f(a[boot_idx(rng, T, blk)]) - f(b[boot_idx(rng, T, blk)])
    return obs, min(2 * min((d <= 0).mean(), (d >= 0).mean()), 1.0)


# ==================================================================
# A. 收益集中度: 丰年灾年是否真实存在?
# ==================================================================
def concentration(df):
    print("\n" + "=" * 100)
    print("【A】收益的时间集中度 —— '丰年灾年'是否真实存在?")
    print("=" * 100)
    print(f"  {'品种':<7}{'总收益':>10}{'最好1%天贡献':>14}{'最好5%天贡献':>14}"
          f"{'去掉最好10天':>14}{'最好10天占比':>13}")
    for c in df.columns:
        r = df[c].pct_change().dropna().values
        lr = np.log1p(np.clip(r, -0.99, None))
        n = len(lr)
        total = lr.sum()
        s = np.sort(lr)[::-1]
        cum = np.cumsum(s)
        k1 = max(1, int(n * 0.01))
        k5 = max(1, int(n * 0.05))
        c1 = s[:k1].sum()
        c5 = s[:k5].sum()
        # 去掉最好的10天后的总收益(复利)
        idx_best = np.argsort(lr)[::-1][:10]
        mask = np.ones(n, bool)
        mask[idx_best] = False
        ret_wo = lr[mask].sum()
        ann_full = (np.exp(total) ** (DAYS_YR / n) - 1) * 100
        ann_wo = (np.exp(ret_wo) ** (DAYS_YR / (n - 10)) - 1) * 100
        contrib1 = c1 / total * 100 if total > 0 else np.nan
        contrib5 = c5 / total * 100 if total > 0 else np.nan
        print(f"  {c:<7}{total*100:>9.0f}%{contrib1:>13.0f}%{contrib5:>13.0f}%"
              f"{ann_wo:>13.1f}%{10/n*100:>12.1f}%")
    print("\n  判读: 若'最好1%天'贡献远超1%, 且去掉最好10天收益暴跌")
    print("        -> 收益高度集中 = '丰年灾年'确实存在, 值得继续测B/C/D")
    print("        -> 但也意味着: 抓不住那几天, 就一定跑输")


# ==================================================================
# B. 极端日可预测性: 上行捕获 vs 下行保护
# ==================================================================
def extreme_predictability(df):
    print("\n" + "=" * 100)
    print("【B】极端日可预测性 —— '抓住丰日' vs '避开灾日', 哪个更可行?")
    print("=" * 100)
    print("  目标: 用 t 及之前的信息, 预测 t+1 是否落入最好/最坏的 10%")
    print("  特征: EWMA波动率分位 (最自然的'天气预报')")
    print(f"\n  {'品种':<7}{'高波→最坏10%':>16}{'低波→最坏10%':>16}{'差':>9}"
          f"{'高波→最好10%':>16}{'低波→最好10%':>16}{'差':>9}")

    res = []
    for c in df.columns:
        r = df[c].pct_change().fillna(0).values
        T = len(r)
        # EWMA 波动率 (无前视)
        lam = 0.94
        var = np.zeros(T)
        var[0] = r[:20].var() if T > 20 else max(r.var(), 1e-12)
        for t in range(1, T):
            var[t] = lam * var[t - 1] + (1 - lam) * r[t - 1] ** 2
        vol = np.sqrt(var)
        # 波动率的历史分位 (滚动500天, 无前视)
        vq = pd.Series(vol).rolling(500, min_periods=100).rank(pct=True).values

        fwd = np.full(T, np.nan)
        fwd[:-1] = r[1:]
        q90 = np.nanpercentile(fwd, 90)
        q10 = np.nanpercentile(fwd, 10)
        is_best = (fwd >= q90).astype(float)
        is_worst = (fwd <= q10).astype(float)

        ok = ~np.isnan(vq) & ~np.isnan(fwd)
        hi = ok & (vq >= 0.8)
        lo = ok & (vq <= 0.2)
        if hi.sum() < 30 or lo.sum() < 30:
            continue
        pw_hi = is_worst[hi].mean() * 100
        pw_lo = is_worst[lo].mean() * 100
        pb_hi = is_best[hi].mean() * 100
        pb_lo = is_best[lo].mean() * 100
        print(f"  {c:<7}{pw_hi:>15.1f}%{pw_lo:>15.1f}%{pw_hi-pw_lo:>+8.1f}pp"
              f"{pb_hi:>15.1f}%{pb_lo:>15.1f}%{pb_hi-pb_lo:>+8.1f}pp")
        res.append((c, pw_hi - pw_lo, pb_hi - pb_lo))

    print("\n  判读: '差'列 >0 且幅度大 = 该方向可预测")
    print("        若【下行差】远大于【上行差】 -> '避开灾日'比'抓住丰日'更可行")
    if res:
        dw = np.array([x[1] for x in res])
        du = np.array([x[2] for x in res])
        print(f"\n  汇总: 下行差 均值{dw.mean():+.1f}pp (正值{(dw>0).sum()}/{len(dw)}个)")
        print(f"        上行差 均值{du.mean():+.1f}pp (正值{(du>0).sum()}/{len(du)}个)")
    return res


# ==================================================================
# C. 条件仓位: 丰年多种, 灾年少种
# ==================================================================
def conditional_position(df, cost_bp=20):
    print("\n" + "=" * 100)
    print("【C】条件仓位 (耕作强度) —— 按预测状态加减仓")
    print("=" * 100)
    print("  关键对照: 若条件策略长期降仓, 必须与【同等平均仓位的固定仓位】比")
    print("            (吸取波动率目标的教训: 降仓本身就能改善回撤)")

    port = df.pct_change().fillna(0).mean(axis=1).values
    T = len(port)
    sp = T // 2

    def ewma_vol(x, lam=0.94):
        v = np.zeros(len(x))
        v[0] = x[:20].var() if len(x) > 20 else max(x.var(), 1e-12)
        for t in range(1, len(x)):
            v[t] = lam * v[t - 1] + (1 - lam) * x[t - 1] ** 2
        return np.sqrt(v)

    def mom(x, w):
        m = np.zeros(len(x))
        m[w:] = np.cumsum(x)[w:] - np.cumsum(x)[:-w]
        return m

    print(f"\n  {'策略':<22}{'平均仓位':>9}{'年化':>9}{'夏普':>8}{'回撤':>8}"
          f"{'Δ夏普vs固定':>13}{'p':>8}")
    results = []
    for name, sig_fn in [('动量择时(w=60)', lambda x: (mom(x, 60) > 0).astype(float)),
                         ('动量择时(w=120)', lambda x: (mom(x, 120) > 0).astype(float)),
                         ('低波加仓', lambda x: (ewma_vol(x) < np.nanmedian(ewma_vol(x))).astype(float)),
                         ('高波减仓', lambda x: (ewma_vol(x) <= np.nanpercentile(ewma_vol(x), 70)).astype(float))]:
        sig = sig_fn(port)
        pnl = np.zeros(T)
        pnl[1:] = sig[:-1] * port[1:]
        turn = np.concatenate([[abs(sig[0])], np.abs(np.diff(sig))])
        pnl = pnl - turn * (2 * cost_bp / 1e4)
        # 同等平均仓位的固定仓位
        avg_lev = sig[sp:].mean()
        fix = np.zeros(T)
        fix[1:] = avg_lev * port[1:]
        fix[1] -= avg_lev * (2 * cost_bp / 1e4)
        a, s_, d_ = metrics(pnl[sp:])
        dsh, psh = paired_test(pnl[sp:], fix[sp:], 'sharpe', seed=201)
        print(f"  {name:<22}{avg_lev:>9.2f}{a:>8.2f}%{s_:>8.3f}{d_:>7.2f}%"
              f"{dsh:>+13.3f}{psh:>8.3f}")
        results.append((name, dsh, psh))

    # 随机对照: 打乱信号
    print(f"\n  【随机对照】打乱信号日期 -> 零假设基线(扣伪影):")
    rng = np.random.default_rng(9)
    sig_real = (mom(port, 60) > 0).astype(float)
    pnl_real = np.zeros(T)
    pnl_real[1:] = sig_real[:-1] * port[1:]
    turn = np.concatenate([[abs(sig_real[0])], np.abs(np.diff(sig_real))])
    pnl_real = pnl_real - turn * (2 * cost_bp / 1e4)
    sh_real = metrics(pnl_real[sp:])[1]
    sh_rand = []
    for b in range(300):
        perm = rng.permutation(T)
        sr = sig_real[perm]
        p = np.zeros(T)
        p[1:] = sr[:-1] * port[1:]
        tn = np.concatenate([[abs(sr[0])], np.abs(np.diff(sr))])
        p = p - tn * (2 * cost_bp / 1e4)
        sh_rand.append(metrics(p[sp:])[1])
    sh_rand = np.array(sh_rand)
    p_rand = (sh_rand >= sh_real).mean()
    print(f"    真实信号夏普: {sh_real:.3f}")
    print(f"    随机信号夏普: {sh_rand.mean():.3f} ± {sh_rand.std():.3f}   p={p_rand:.3f} "
          f"({'显著' if p_rand<0.05 else '不显著'})")
    return results


# ==================================================================
# D. 状态持续性: 丰年后更可能丰年?
# ==================================================================
def state_persistence(df):
    print("\n" + "=" * 100)
    print("【D】状态持续性 —— 丰年后更可能丰年? (用滞后状态预测未来状态)")
    print("=" * 100)
    print(f"  {'尺度':<10}{'丰→丰':>9}{'丰→灾':>9}{'灾→丰':>9}{'灾→灾':>9}"
          f"{'卡方p':>9}{'判定':>14}")
    port = df.pct_change().fillna(0).mean(axis=1)
    for scale, label in [(21, '月(21d)'), (63, '季(63d)'), (250, '年(250d)')]:
        # 滚动 scale 天收益, 丰 = 正
        roll = port.rolling(scale).sum().dropna()
        if len(roll) < scale * 2:
            continue
        cur = roll.values[:-scale]
        nxt = roll.values[scale:]
        good_c = cur > 0
        good_n = nxt > 0
        if len(good_c) < 30:
            continue
        gg = (good_c & good_n).sum()
        gb = (good_c & ~good_n).sum()
        bg = (~good_c & good_n).sum()
        bb = (~good_c & ~good_n).sum()
        table = np.array([[gg, gb], [bg, bb]])
        try:
            chi2, p, _, _ = stats.chi2_contingency(table)
        except Exception:
            p = np.nan
        n = table.sum()
        print(f"  {label:<10}{gg/n*100:>8.1f}%{gb/n*100:>8.1f}%{bg/n*100:>8.1f}%{bb/n*100:>8.1f}%"
              f"{p:>9.3f}{('有持续性' if p<0.05 else '无持续性'):>14}")
    print("\n  判读: 若卡方p<0.05 -> 状态有持续性(可预测), 否则丰灾是随机的")


# ============ 主流程 ============
print("=" * 100)
print("丰年/灾年 检验 —— 短期角度: 收益的时间分布不均匀性")
print("=" * 100)
df = load()
print(f"面板: {df.shape[1]} 品种 x {df.shape[0]} 天 "
      f"({df.index[0].date()} -> {df.index[-1].date()})")
print(f"品种: {list(df.columns)}")

concentration(df)
extreme_predictability(df)
conditional_position(df)
state_persistence(df)

print("\n" + "=" * 100)
print("完成")
print("=" * 100)
