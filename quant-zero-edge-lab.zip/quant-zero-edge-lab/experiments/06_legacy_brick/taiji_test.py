"""
太极四原理 -> 可证伪统计假设 -> 真实数据检验
================================================
【方法纪律】(吸取前面所有轮次的教训)
  1. 极端用【波动率归一化 z-score】定义, 不用分位数(机械效应)
  2. 收益用【对数收益】度量(复利), 不只算术收益
  3. 每个检验都有【置换对照/block bootstrap】零假设
  4. 多重检验校正 (Benjamini-Hochberg FDR)
  5. 真实成本 20bp 往返
  6. 匹配暴露对照 (排除降仓效应)

【四原理 -> 假设】
  A. 物极必反  : 偏离越大 -> 反向修正越强 (剂量-反应, 非简单50%反转)
  B. 鱼眼      : 最强趋势内部已含反转种子
  C. 阴阳消长  : 涨跌贡献长期对称, 但局部失衡 (失衡是否可利用?)
  D. 循环往复  : 存在超越随机的周期性
"""
import numpy as np
import pandas as pd
from scipy import stats

DAILY = {'BTC': '/data/inputs/BTCUSDT_1d.csv',
         'BNB': '/data/inputs/BNBUSDT_1d.csv',
         'BCH': '/data/inputs/BCHUSDT_1d.csv'}
HOURLY = {'DOGE': '/data/inputs/DOGEUSDT_1h.csv',
          'DOT':  '/data/inputs/DOTUSDT_1h.csv',
          'CRV':  '/data/inputs/CRVUSDT_1h.csv',
          'DASH': '/data/inputs/DASHUSDT_1h.csv'}
DAYS_YR = 365
COST_BP = 20          # 往返成本
BLK = 20              # block bootstrap 块长
NBOOT = 1000


def load():
    px = {}
    for k, p in DAILY.items():
        d = pd.read_csv(p)
        s = pd.Series(d['close'].values,
                      index=pd.to_datetime(d['timestamp'], unit='ms').dt.normalize())
        px[k] = s[~s.index.duplicated()]
    for k, p in HOURLY.items():
        d = pd.read_csv(p)
        s = pd.Series(d['close'].values,
                      index=pd.to_datetime(d['timestamp'], unit='ms'))
        px[k] = s.resample('1D').last().dropna()
    return pd.DataFrame(px).dropna()


def logret(r):
    return np.log1p(np.clip(r, -0.99, None))


def block_boot_stat(x, stat_fn, nboot=NBOOT, blk=BLK, seed=0):
    """block bootstrap: 返回 (观测值, 中心化的bootstrap分布)"""
    rng = np.random.default_rng(seed)
    T = len(x)
    obs = stat_fn(x)
    d = np.zeros(nboot)
    for i in range(nboot):
        d[i] = stat_fn(x[boot_idx(rng, T, blk)])
    return obs, d


def boot_idx(rng, T, L):
    nb = int(np.ceil(T / L))
    st = rng.integers(0, T - L, size=nb)
    return (st[:, None] + np.arange(L)[None, :]).ravel()[:T] % T


def bh_fdr(pvals, alpha=0.05):
    """Benjamini-Hochberg FDR 校正"""
    p = np.asarray(pvals)
    n = len(p)
    order = np.argsort(p)
    ranked = p[order]
    thresh = alpha * (np.arange(1, n + 1)) / n
    passed = ranked <= thresh
    if passed.any():
        k = np.max(np.where(passed)[0])
        crit = thresh[k]
    else:
        crit = -1
    return p <= crit, crit


def metrics(net):
    n = len(net)
    mu, sd = net.mean(), net.std()
    if sd < 1e-12 or n < 10:
        return 0.0, 0.0, 0.0
    nav = np.cumprod(1.0 + np.clip(net, -0.99, None))
    ann = float(np.clip((nav[-1] ** (DAYS_YR / n) - 1) * 100 if nav[-1] > 0 else -100.0, -100, 1e6))
    sh = mu / sd * np.sqrt(DAYS_YR)
    pk = np.maximum.accumulate(nav)
    dd = (nav - pk) / np.maximum(pk, 1e-12)
    return ann, sh, float(-dd.min() * 100)


# ==================================================================
# A. 物极必反: 剂量-反应关系
# ==================================================================
def test_A_reversal(df):
    print("\n" + "=" * 100)
    print("【A】物极必反 —— 偏离越大, 反向修正越强? (剂量-反应)")
    print("=" * 100)
    print("  信号: z = 过去N日累计收益 / (sqrt(N)*日波动)   [波动率归一化, 无前视]")
    print("  假设: 若'物极必反'成立 -> z 与未来收益【负相关】, 且越极端越强")
    print("  证伪: 若相关性≈0 或分桶无单调 -> 只是随机, 不是'极'")

    port = df.pct_change().fillna(0).mean(axis=1)
    r = port.values
    lr = logret(r)
    T = len(r)

    print(f"\n  {'回看N':>6}{'持有H':>6}{'Spearman rho':>14}{'p(block)':>10}"
          f"{'最极端桶收益':>14}{'中立桶收益':>12}{'差值(bp)':>11}{'单调?':>8}")

    all_p, all_rho = [], []
    for N in [5, 10, 20, 60]:
        for H in [1, 5, 10]:
            # z-score: 过去N日累计对数收益 / 波动率
            cum = pd.Series(lr).rolling(N).sum().values
            vol = pd.Series(r).rolling(60).std().values      # 用60日估计波动
            sig_vol = vol * np.sqrt(N)
            z = np.where(sig_vol > 1e-12, cum / sig_vol, 0.0)
            z = np.where(np.isnan(z), 0.0, z)

            # 未来H日对数收益
            fwd = np.full(T, np.nan)
            for t in range(T - H):
                fwd[t] = lr[t + 1:t + 1 + H].sum()

            ok = ~np.isnan(fwd) & (np.abs(z) > 0)
            if ok.sum() < 200:
                continue
            zz, ff = z[ok], fwd[ok]

            # Spearman 相关 (block bootstrap p值)
            rho, _ = stats.spearmanr(zz, ff)

            def stat_pair(idx):
                return stats.spearmanr(zz[idx], ff[idx])[0]

            rng = np.random.default_rng(11)
            d = np.zeros(500)
            for i in range(500):
                idx = boot_idx(rng, len(zz), BLK)
                d[i] = stat_pair(idx)
            p = 2 * min((d <= 0).mean(), (d >= 0).mean())

            # 分桶: 极端负 / 中立 / 极端正
            lo_thr = np.percentile(zz, 10)
            hi_thr = np.percentile(zz, 90)
            b_lo = ff[zz <= lo_thr].mean() * 1e4
            b_hi = ff[zz >= hi_thr].mean() * 1e4
            b_mid = ff[(zz > lo_thr) & (zz < hi_thr)].mean() * 1e4
            # 极端桶(两侧合并, 取反向) vs 中立桶
            extreme = np.concatenate([ff[zz <= lo_thr], ff[zz >= hi_thr]])
            diff = extreme.mean() - ff[(zz > lo_thr) & (zz < hi_thr)].mean()
            # 单调性: 5个桶的收益是否单调递减
            qs = np.percentile(zz, [20, 40, 60, 80])
            buckets = [ff[zz <= qs[0]], ff[(zz > qs[0]) & (zz <= qs[1])],
                       ff[(zz > qs[1]) & (zz <= qs[2])],
                       ff[(zz > qs[2]) & (zz <= qs[3])], ff[zz > qs[3]]]
            bm = np.array([b.mean() for b in buckets])
            mono = np.all(np.diff(bm) < 0) or np.all(np.diff(bm) > 0)
            print(f"  {N:>6}{H:>6}{rho:>+14.4f}{min(p,1.0):>10.3f}"
                  f"{extreme.mean()*1e4:>13.1f}bp{b_mid:>11.1f}bp"
                  f"{diff*1e4:>+10.1f}bp{('是' if mono else '否'):>8}")
            all_p.append(min(p, 1.0))
            all_rho.append(rho)

    print(f"\n  汇总: {len(all_rho)} 组检验")
    print(f"    rho 均值: {np.mean(all_rho):+.4f}  (负{(np.array(all_rho)<0).sum()}/{len(all_rho)}组)")
    rej, crit = bh_fdr(all_p, 0.05)
    print(f"    BH-FDR 校正(α=0.05) 后显著组数: {rej.sum()}/{len(all_p)}  (阈值 p<{crit:.4f})")
    print("\n  判读: 若 rho 显著为负 且 分桶单调 -> '物极必反'成立, 是剂量-反应")
    print("        若 rho≈0 -> '极端后反弹'只是50%随机, 不是太极的'极'")
    return all_rho, all_p


# ==================================================================
# B. 鱼眼: 最强趋势内部已含反转种子?
# ==================================================================
def test_B_fisheye(df):
    print("\n" + "=" * 100)
    print("【B】鱼眼(阳中有阴) —— 最强趋势内部, 是否已含反转种子?")
    print("=" * 100)
    print("  定义: 上涨趋势中【已出现的回调幅度】= '阳中之阴'的种子大小")
    print("  假设: 趋势越强, 内含的阴越大 -> 回调幅度与后续反转【正相关】")
    print("  证伪: 若无相关 -> '鱼眼'是修辞, 不是结构")

    port = df.pct_change().fillna(0).mean(axis=1)
    r = port.values
    lr = logret(r)
    T = len(r)

    print(f"\n  {'趋势窗口':>9}{'回调窗口':>9}{'相关系数':>12}{'p(block)':>10}"
          f"{'强趋势+大回调→未来收益':>24}")

    all_p, all_r = [], []
    for Nt in [20, 40, 60]:
        for Nb in [3, 5, 10]:
            # 趋势强度: 过去Nt日累计对数收益
            trend = pd.Series(lr).rolling(Nt).sum().values
            # 种子: 过去Nb日的回调幅度 (若趋势为正, 回调=最近Nb日跌幅)
            recent = pd.Series(lr).rolling(Nb).sum().values
            # 只看上涨趋势
            up = trend > 0
            seed = np.where(up, -recent, np.nan)   # 上涨趋势中, 最近跌幅=阴的种子
            fwd = np.full(T, np.nan)
            H = 10
            for t in range(T - H):
                fwd[t] = lr[t + 1:t + 1 + H].sum()
            ok = ~np.isnan(seed) & ~np.isnan(fwd)
            if ok.sum() < 200:
                continue
            s_, f_ = seed[ok], fwd[ok]
            rho, _ = stats.spearmanr(s_, f_)

            def stat_p(idx):
                return stats.spearmanr(s_[idx], f_[idx])[0]

            rng = np.random.default_rng(21)
            d = np.zeros(500)
            for i in range(500):
                d[i] = stat_p(boot_idx(rng, len(s_), BLK))
            p = 2 * min((d <= 0).mean(), (d >= 0).mean())
            # 强趋势 + 大回调 的子样本
            big_seed = s_ >= np.percentile(s_, 80)
            sub = f_[big_seed].mean() * 1e4
            print(f"  {Nt:>9}{Nb:>9}{rho:>+12.4f}{min(p,1.0):>10.3f}{sub:>23.1f}bp")
            all_p.append(min(p, 1.0))
            all_r.append(rho)

    print(f"\n  汇总: rho 均值 {np.mean(all_r):+.4f}  "
          f"(正{(np.array(all_r)>0).sum()}/{len(all_r)}组)")
    if all_p:
        rej, crit = bh_fdr(all_p, 0.05)
        print(f"    BH-FDR 校正后显著: {rej.sum()}/{len(all_p)} (阈值 p<{crit:.4f})")
    print("\n  判读: 正相关 = 回调越大后续反转越强 = '阳中之阴'确实在生长")
    print("        无相关 = 回调只是噪音, 鱼眼不成立")


# ==================================================================
# C. 阴阳消长: 对称性是否稳定? 失衡是否可利用?
# ==================================================================
def test_C_balance(df):
    print("\n" + "=" * 100)
    print("【C】阴阳消长 —— 涨跌贡献长期对称, 但局部是否失衡? (失衡=机会?)")
    print("=" * 100)
    print("  上一轮发现: 好日子 +646.4%  vs  坏日子 -654.9%  (近乎完美对称)")
    print("  本检验: 这个平衡是【恒定】还是【波动】? 失衡期有先行信号吗?")

    port = df.pct_change().fillna(0).mean(axis=1)
    r = port.values
    T = len(r)
    W = 250

    print(f"\n  滚动{W}日窗口内: 正收益日总贡献 '阳' vs 负收益日总贡献 '阴'")
    print(f"\n  {'指标':<26}{'数值':>14}")
    ratios = []
    for i in range(0, T - W):
        w = r[i:i + W]
        pos = w[w > 0].sum()
        neg = -w[w < 0].sum()
        if neg > 1e-12:
            ratios.append(pos / neg)
    ratios = np.array(ratios)
    print(f"  {'阳/阴 比值 均值':<26}{ratios.mean():>14.3f}")
    print(f"  {'阳/阴 比值 标准差':<26}{ratios.std():>14.3f}")
    print(f"  {'阳/阴 比值 中位数':<26}{np.median(ratios):>14.3f}")
    print(f"  {'失衡期(比值>1.5)占比':<26}{(ratios>1.5).mean()*100:>13.1f}%")
    print(f"  {'失衡期(比值<0.67)占比':<26}{(ratios<0.67).mean()*100:>13.1f}%")

    # 失衡是否有先行信号? 用当前比值预测下一段比值
    print(f"\n  【关键】失衡是否可预测? (当前窗口失衡 -> 下一段继续失衡?)")
    if len(ratios) > W:
        cur = ratios[:-W]
        nxt = ratios[W:]
        rho, p_s = stats.spearmanr(cur, nxt)
        print(f"    自相关(Spearman): {rho:+.4f}  p={p_s:.4f}")
        print(f"    ({'有持续性' if p_s<0.05 and abs(rho)>0.1 else '无持续性'}"
              f" -> 失衡不可预测)")
    else:
        print("    样本不足")

    print("\n  判读: 若比值标准差大 且 无自相关 -> 平衡在动态波动但不可预测")
    print("        这正是'阴阳消长': 消长是真实的, 但【何时消长】不可知")


# ==================================================================
# D. 循环往复: 是否存在超越随机的周期?
# ==================================================================
def test_D_cycle(df):
    print("\n" + "=" * 100)
    print("【D】循环往复 —— 是否存在超越随机的周期性结构?")
    print("=" * 100)
    print("  方法: 周期图 + 【block permutation】零假设 (保持局部自相关, 破坏长周期)")
    print("  证伪: 若真实峰高 不超过 置换分布 -> 无周期性, 只是红噪声")

    port = df.pct_change().fillna(0).mean(axis=1)
    x = port.values
    x = x - x.mean()
    T = len(x)

    # 周期图
    fft = np.fft.rfft(x)
    power = np.abs(fft) ** 2
    freqs = np.fft.rfftfreq(T, d=1.0)
    # 排除 0 频与极低频(趋势)
    mask = (freqs > 1 / 500) & (freqs < 0.5)
    if mask.sum() == 0:
        print("  频率范围不足")
        return
    pk_idx = np.argmax(np.where(mask, power, -1))
    pk_power = power[pk_idx]
    pk_period = 1 / freqs[pk_idx]

    # block permutation 零假设
    rng = np.random.default_rng(31)
    null_max = []
    for b in range(300):
        xp = x[block_perm(rng, T, BLK)]
        xp = xp - xp.mean()
        p_ = np.abs(np.fft.rfft(xp)) ** 2
        null_max.append(np.max(np.where(mask, p_, -1)))
    null_max = np.array(null_max)
    p_val = (null_max >= pk_power).mean()

    print(f"\n  最强周期: {pk_period:.1f} 天")
    print(f"  真实峰功率: {pk_power:.4e}")
    print(f"  置换零假设: {null_max.mean():.4e} ± {null_max.std():.4e}")
    print(f"  置换 p 值 : {p_val:.3f}  ({'显著' if p_val<0.05 else '不显著'})")

    # 多品种
    print(f"\n  分品种检验:")
    print(f"  {'品种':<7}{'最强周期(天)':>14}{'置换p':>10}{'判定':>14}")
    ps = []
    for c in df.columns:
        xc = df[c].pct_change().fillna(0).values
        xc = xc - xc.mean()
        if len(xc) < 100:
            continue
        f_ = np.fft.rfft(xc)
        pw = np.abs(f_) ** 2
        fr = np.fft.rfftfreq(len(xc), d=1.0)
        m = (fr > 1 / 500) & (fr < 0.5)
        if m.sum() == 0:
            continue
        pi_ = np.argmax(np.where(m, pw, -1))
        pp = pw[pi_]
        per = 1 / fr[pi_]
        nm = []
        for b in range(200):
            xp = xc[block_perm(rng, len(xc), BLK)]
            xp = xp - xp.mean()
            nm.append(np.max(np.where(m, np.abs(np.fft.rfft(xp)) ** 2, -1)))
        pv = (np.array(nm) >= pp).mean()
        ps.append(pv)
        print(f"  {c:<7}{per:>14.1f}{pv:>10.3f}"
              f"{('有周期' if pv<0.05 else '无周期'):>14}")
    if ps:
        rej, crit = bh_fdr(ps, 0.05)
        print(f"\n  BH-FDR 校正后: {rej.sum()}/{len(ps)} 个品种有显著周期")
    print("\n  判读: 若不显著 -> 市场是红噪声, '循环往复'不可用于预测")


def block_perm(rng, T, L):
    """打乱块的顺序, 保持块内结构"""
    nb = int(np.ceil(T / L))
    starts = np.arange(0, T, L)
    perm = rng.permutation(len(starts))
    idx = []
    for s in starts[perm]:
        idx.extend(range(s, min(s + L, T)))
    return np.array(idx[:T]) % T


# ============ 主流程 ============
print("=" * 100)
print("太极四原理 -> 可证伪假设 -> 真实数据检验")
print("=" * 100)
df = load()
print(f"面板: {df.shape[1]}品种 x {df.shape[0]}天 ({df.index[0].date()} -> {df.index[-1].date()})")
print(f"品种: {list(df.columns)}")

test_A_reversal(df)
test_B_fisheye(df)
test_C_balance(df)
test_D_cycle(df)

print("\n" + "=" * 100)
print("完成")
print("=" * 100)
