"""
【以损定量 × 1:2盈亏比】成本与风险解耦 —— 找止损的"度"
============================================================
【用户两个洞察】
  1. 不要极端(追踪10%/胜率20%), 用 1:2 温和盈亏比
  2. 以损定量: 固定每笔风险金额 -> 止损越宽, 张数越少, 手续费越少
     成本占风险比 = 2*cost_bp / s   (与止损宽度成反比!)

【之前模型的错误】
  固定"2*cost_bp往返"应用在固定仓位上
  = 隐含假设止损宽度不影响成本 -> 高估了宽止损的成本

【本轮正确建模: R-multiple 框架】
  每笔以"风险倍数R"计量:
    止损 s, 止盈 R*s
    触及止损 -> -1R
    触及止盈 -> +R*R
    成本(以R计) = 2*cost_bp / s     <- 关键! s越大成本越低
    net_R = 毛R - 成本R
  账户: NAV *= (1 + f * net_R)   f=每笔风险占净值比例

【扫描】
  s: 0.5% ~ 12%   (找"度": 太窄成本高, 太宽N少)
  R: 1, 1.5, 2, 3 (重点1:2)
  cost: 2bp(maker), 10bp(taker)
  验证理论胜率 1/(1+R) vs 实测
"""
import numpy as np
import pandas as pd
from scipy import stats

HOURLY = {'DOGE': '/data/inputs/DOGEUSDT_1h.csv',
          'DOT':  '/data/inputs/DOTUSDT_1h.csv',
          'CRV':  '/data/inputs/CRVUSDT_1h.csv',
          'DASH': '/data/inputs/DASHUSDT_1h.csv'}


def load():
    out = {}
    for k, p in HOURLY.items():
        d = pd.read_csv(p)
        out[k] = d['close'].values.astype(float)
    return out


def momentum_signal(px, w=60):
    n = len(px)
    sig = np.zeros(n)
    sig[w:] = np.sign(px[w:] / np.maximum(px[:-w], 1e-9) - 1)
    return sig


def run_trades_R(px, signal, s, R, cost_bp=2, max_hold=1000,
                 seed=42, start=0, end=None):
    """R-multiple 框架
    返回 net_R 数组 (每笔净收益, 以风险为单位)
    """
    n = len(px) if end is None else min(end, len(px))
    rng = np.random.default_rng(seed)
    cost_R = 2 * cost_bp / 1e4 / s      # 成本(以R计)
    net = []
    i = max(start, 60)
    while i < n - 2:
        sg = signal[i]
        if sg == 0:
            sg = rng.choice([-1, 1])
        direction = 1 if sg > 0 else -1
        entry = px[i]
        exit_R = None
        for j in range(i + 1, min(i + max_hold, n)):
            move = (px[j] / entry - 1) * direction
            if move <= -s:
                exit_R = -1.0; break
            if move >= R * s:
                exit_R = R; break
        if exit_R is None:
            je = min(i + max_hold, n - 1)
            move = (px[je] / entry - 1) * direction
            exit_R = move / s            # 超时按实际(以R计)
        net.append(exit_R - cost_R)
        i = (j if exit_R in (-1.0, R) else min(i + max_hold, n - 1)) + 1
    return np.array(net)


def stats_of(net):
    if len(net) < 30:
        return None
    win = (net > 0).mean()
    E = net.mean()                        # 以R为单位
    t = E / (net.std() / np.sqrt(len(net))) if net.std() > 0 else 0
    return dict(n=len(net), win=win, E_R=E, t=t)


def path_risk(net, f=0.01, init=10000.0):
    nav = np.empty(len(net) + 1)
    nav[0] = init
    for i, r in enumerate(net):
        nav[i + 1] = nav[i] * (1.0 + f * r)
        if nav[i + 1] <= 0:
            nav[i + 1:] = 0
            break
    mc, cur = 0, 0
    for r in net:
        if r < 0:
            cur += 1; mc = max(mc, cur)
        else:
            cur = 0
    pk = np.maximum.accumulate(nav)
    dd = -((nav - pk) / np.maximum(pk, 1e-12)).min() * 100
    return dict(final=nav[-1], mdd=dd, max_consec=mc,
                below50=bool((nav < init * .5).any()))


data = load()
print("=" * 100)
print("【以损定量 × 盈亏比】成本与风险解耦 —— 找止损的'度'")
print("=" * 100)

# ---------- 0. 成本洞察表(纯数学) ----------
print(f"\n  【0】验证洞察: 成本占风险比 = 2*cost_bp / s")
print(f"  {'止损s':>8}{'maker 2bp':>14}{'taker 10bp':>14}{'判定':>16}")
print("  " + "-" * 54)
for s in [0.005, 0.01, 0.02, 0.03, 0.05, 0.08, 0.12]:
    c2 = 2 * 0.0002 / s * 100
    c10 = 2 * 0.0010 / s * 100
    tag = '致命' if c10 > 15 else ('可控' if c10 < 8 else '偏高')
    print(f"  {s*100:>7.1f}%{c2:>13.1f}%{c10:>13.1f}%{tag:>16}")

# ---------- 1. 网格扫描 (DOGE, 样本外) ----------
sym = 'DOGE'
px = data[sym]
n = len(px); sp = n // 2
sig = momentum_signal(px, 60)
S_LIST = [0.005, 0.01, 0.02, 0.03, 0.05, 0.08, 0.12]
R_LIST = [1, 1.5, 2, 3]

for cost in [2, 10]:
    tag = 'maker' if cost == 2 else 'taker'
    print(f"\n  【1】网格扫描 (DOGE样本外, {tag} {cost}bp) —— 每笔净收益 E(R倍数)")
    print("  s\\R      " + "".join(f"{f'1:{r}':>20}" for r in R_LIST))
    print("  " + "-" * 90)
    for s in S_LIST:
        row = f"  {s*100:>6.1f}%  "
        for R in R_LIST:
            net = run_trades_R(px, sig, s, R, cost_bp=cost, start=sp, end=n,
                               max_hold=800)
            st = stats_of(net)
            if st:
                row += f"{st['E_R']:>+8.3f}R(t{st['t']:>+5.2f})"
            else:
                row += f"{'—':>20}"
        print(row)

# ---------- 2. 聚焦 1:2 ----------
print(f"\n  【2】聚焦 1:2 (理论胜率 1/(1+2)=33.3%)")
print(f"  {'品种':<7}{'cost':>6}{'s':>7}{'笔数':>7}{'胜率':>8}"
      f"{'E(R)':>9}{'t':>8}{'终值':>10}{'回撤':>8}{'连亏':>7}")
print("  " + "-" * 72)
for cost in [2, 10]:
    for s in [0.02, 0.03, 0.05, 0.08]:
        for sym2 in ['DOGE', 'DASH']:
            px2 = data[sym2]
            n2 = len(px2); sp2 = n2 // 2
            sg2 = momentum_signal(px2, 60)
            net = run_trades_R(px2, sg2, s, 2, cost_bp=cost,
                               start=sp2, end=n2, max_hold=800)
            st = stats_of(net)
            if st is None:
                continue
            pr = path_risk(net, f=0.01)
            print(f"  {sym2:<7}{cost:>5}bp{s*100:>6.1f}%{st['n']:>7}"
                  f"{st['win']*100:>7.1f}%{st['E_R']:>+9.3f}{st['t']:>+8.2f}"
                  f"{pr['final']:>10.0f}{pr['mdd']:>7.1f}%{pr['max_consec']:>7}")

# ---------- 3. 找"度": E(R) 随 s 变化 ----------
print(f"\n  【3】止损的'度' (DASH, taker 10bp, R=2) —— E(R)随止损宽度")
print(f"  {'s':>8}{'笔数':>8}{'胜率':>9}{'E(R)':>10}{'t':>8}{'成本占R':>10}{'判定':>10}")
print("  " + "-" * 64)
pxd = data['DASH']
nd = len(pxd); spd = nd // 2
sgd = momentum_signal(pxd, 60)
best = None
for s in [0.005, 0.01, 0.02, 0.03, 0.05, 0.08, 0.12, 0.20]:
    net = run_trades_R(pxd, sgd, s, 2, cost_bp=10, start=spd, end=nd,
                       max_hold=800)
    st = stats_of(net)
    if st is None:
        continue
    cr = 2 * 0.001 / s * 100
    ok = '★' if (st['E_R'] > 0 and st['t'] > 1.96) else ''
    print(f"  {s*100:>7.1f}%{st['n']:>8}{st['win']*100:>8.1f}%"
          f"{st['E_R']:>+10.3f}{st['t']:>+8.2f}{cr:>9.1f}%{ok:>10}")
    if best is None or st['E_R'] > best[1]['E_R']:
        best = (s, st)

if best:
    print(f"\n    最优止损宽度: s={best[0]*100:.1f}% (E={best[1]['E_R']:+.3f}R, "
          f"t={best[1]['t']:+.2f})")

print("\n" + "=" * 100)
print("完成")
print("=" * 100)
