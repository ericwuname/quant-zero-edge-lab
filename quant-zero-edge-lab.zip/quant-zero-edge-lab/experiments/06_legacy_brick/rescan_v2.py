"""
【修复框架·全面重扫】用修复后的逻辑重新评估所有入场信号
修复: F1 入场open[t+1]  F2 信号翻转即平仓  F3 止损含滑点
关键: 信号与出场联动, 不再脱节
"""
import numpy as np, pandas as pd

FILES={'DOGE':'/data/inputs/DOGEUSDT_1h.csv','DOT':'/data/inputs/DOTUSDT_1h.csv',
       'CRV':'/data/inputs/CRVUSDT_1h.csv','DASH':'/data/inputs/DASHUSDT_1h.csv',
       'ETH':'/data/inputs/ETHUSDT_1h.csv','FIL':'/data/inputs/FILUSDT_1h.csv',
       'HBAR':'/data/inputs/HBARUSDT_1h.csv'}

def load():
    o={}
    for k,p in FILES.items():
        d=pd.read_csv(p);c={x.lower():x for x in d.columns}
        o[k]=dict(open=d[c['open']].values.astype(float),high=d[c['high']].values.astype(float),
                  low=d[c['low']].values.astype(float),close=d[c['close']].values.astype(float))
    return o

# ---------- 信号库 ----------
def s_mom(cl,w):
    n=len(cl);s=np.zeros(n);s[w:]=np.sign(cl[w:]/np.maximum(cl[:-w],1e-9)-1);return s
def s_rev(cl,w):
    return -s_mom(cl,w)
def s_brk(cl,w):
    n=len(cl);s=np.zeros(n)
    for i in range(w,n):
        hi=cl[i-w:i].max();lo=cl[i-w:i].min()
        if cl[i]>hi: s[i]=1
        elif cl[i]<lo: s[i]=-1
    return s
def s_ma(cl,w):
    n=len(cl);s=np.zeros(n)
    if len(cl)<w: return s
    ma=pd.Series(cl).rolling(w).mean().values
    s[w:]=np.sign(cl[w:]-ma[w:]);return s
def s_pull(cl,w,thr):
    """回撤: 距w期高点下跌>thr 做多"""
    n=len(cl);s=np.zeros(n)
    for i in range(w,n):
        hh=cl[i-w:i+1].max();ll=cl[i-w:i+1].min()
        if hh>0 and (cl[i]/hh-1)<-thr: s[i]=1
        elif ll>0 and (cl[i]/ll-1)>thr: s[i]=-1
    return s

SIGS={
 'mom_5':   lambda cl:s_mom(cl,5),
 'mom_10':  lambda cl:s_mom(cl,10),
 'mom_20':  lambda cl:s_mom(cl,20),
 'mom_60':  lambda cl:s_mom(cl,60),
 'rev_5':   lambda cl:s_rev(cl,5),
 'rev_10':  lambda cl:s_rev(cl,10),
 'rev_20':  lambda cl:s_rev(cl,20),
 'brk_20':  lambda cl:s_brk(cl,20),
 'ma_50':   lambda cl:s_ma(cl,50),
 'pull_240_10': lambda cl:s_pull(cl,240,0.10),
}

def run(D,sg,s=0.05,R=2.0,cost_bp=2,slip_bp=5,max_hold=800,start=0,end=None):
    """修复框架: open[t+1]入场, 信号翻转即平, 止损含滑点"""
    op,hi,lo,cl=D['open'],D['high'],D['low'],D['close']
    n=len(cl) if end is None else min(end,len(cl))
    cR=2*cost_bp/1e4/s
    slipR=slip_bp/1e4/s
    stop_dist=s+slip_bp/1e4
    net=[];holds=[]
    i=max(start,120)
    while i<n-3:
        if sg[i]==0: i+=1; continue
        d=1 if sg[i]>0 else -1
        e=op[i+1]; i0=i+1
        out=None;j=i0
        for jj in range(i0,min(i0+max_hold,n)):
            if d==1:
                adv=lo[jj]/e-1; fav=hi[jj]/e-1
            else:
                adv=1-hi[jj]/e; fav=1-lo[jj]/e
            if adv<=-stop_dist: out=-1.0-slipR; j=jj; break
            if fav>=R*s: out=R; j=jj; break
            # F2: 信号翻转即平
            if sg[jj]*d<0:
                out=((cl[jj]/e-1)*d)/s; j=jj; break
        if out is None:
            j=min(i0+max_hold,n-1)
            out=((cl[j]/e-1)*d)/s
        net.append(out-cR); holds.append(j-i0)
        i=j+1
    return np.array(net),np.array(holds)

def st(net):
    if len(net)<30: return None
    E=net.mean();sd=net.std()
    return dict(n=len(net),win=(net>0).mean(),E=E,t=E/(sd/np.sqrt(len(net))) if sd>0 else 0)

def path_risk(net,f=0.01,init=10000.0):
    nav=np.empty(len(net)+1);nav[0]=init
    for i,r in enumerate(net):
        nav[i+1]=nav[i]*(1+f*r)
        if nav[i+1]<=0: nav[i+1:]=0;break
    mc,cur=0,0
    for r in net:
        if r<0: cur+=1;mc=max(mc,cur)
        else: cur=0
    pk=np.maximum.accumulate(nav)
    return dict(final=nav[-1],mdd=-((nav-pk)/np.maximum(pk,1e-12)).min()*100,max_consec=mc)

data=load()
COST=2; SLIP=5
print("="*104)
print("【修复框架·全面重扫】7品种池化, 样本外50%, maker2bp, 止损5%+5bp滑点, R=2")
print("   修复: open[t+1]入场 | 信号翻转即平仓 | 止损含滑点")
print("="*104)
print(f"\n  {'信号':<14}{'笔数':>7}{'胜率':>8}{'E(R)':>9}{'t':>8}{'终值':>9}{'回撤':>7}{'连亏':>6}")
print("  "+"-"*72)
res={}
for name,fn in SIGS.items():
    alln=[]
    for k,D in data.items():
        n=len(D['close']);sp=n//2
        try: sg=fn(D['close'])
        except Exception: continue
        nt,_=run(D,sg,cost_bp=COST,slip_bp=SLIP,start=sp,end=n)
        if len(nt)>=30: alln.append(nt)
    if not alln: continue
    cat=np.concatenate(alln); s_=st(cat); pr=path_risk(cat)
    res[name]=s_
    print(f"  {name:<14}{s_['n']:>7}{s_['win']*100:>7.1f}%{s_['E']:>+9.4f}{s_['t']:>+8.2f}"
          f"{pr['final']:>9.0f}{pr['mdd']:>6.1f}%{pr['max_consec']:>6}")

best=max(res.items(),key=lambda x:x[1]['E'])
print(f"\n  最优: {best[0]}  E={best[1]['E']:+.4f}R  t={best[1]['t']:+.2f}")
print(f"  盈亏平衡需要 E>0, 显著需要 |t|>1.96")
print(f"  -> 修复框架下{'有' if best[1]['t']>1.96 and best[1]['E']>0 else '无'}统计显著的正期望信号")

# 成本敏感性: 最优信号在零成本下
print(f"\n  【零成本对照】若成本→0, 修复框架下E是多少?")
for nm in [best[0],'mom_5','rev_5']:
    alln=[]
    for k,D in data.items():
        n=len(D['close']);sp=n//2
        sg=SIGS[nm](D['close'])
        nt,_=run(D,sg,cost_bp=0,slip_bp=0,start=sp,end=n)
        if len(nt)>=30: alln.append(nt)
    if not alln: continue
    s_=st(np.concatenate(alln))
    print(f"    {nm:<14} 零成本 E={s_['E']:+.4f}R t={s_['t']:+.2f}")
print("\n"+"="*104)
