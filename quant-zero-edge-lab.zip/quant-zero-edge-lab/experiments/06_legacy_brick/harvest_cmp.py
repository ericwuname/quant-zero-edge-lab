import numpy as np
D=np.load('seq2.npz')
C0=10000.0; BUST=0.20; NCOIN=7
YEARS=3.0; BUDGET=YEARS*8760.0

def simulate(Rarr,Harr,f,T,NSIM,seed,mode='target',period=100):
    rng=np.random.default_rng(seed)
    N=len(Rarr); mh=np.median(Harr)
    max_steps=int(BUDGET/(mh/NCOIN)*1.6)+200
    max_steps=min(max_steps,200000)
    W=np.full(NSIM,C0); G=np.zeros(NSIM); tu=np.zeros(NSIM)
    dead=np.zeros(NSIM,bool); reached=np.zeros(NSIM,bool)
    t_reach=np.full(NSIM,np.nan); ntr=np.zeros(NSIM)
    for step in range(max_steps):
        act=(~dead)&(tu<BUDGET)
        if not act.any(): break
        ia=np.where(act)[0]
        idx=rng.integers(0,N,size=len(ia))
        r=Rarr[idx]; h=Harr[idx]/NCOIN
        eff=np.minimum(f*C0,W[ia])
        W[ia]=W[ia]+eff*r; tu[ia]+=h; ntr[ia]+=1
        bd=W[ia]<=BUST*C0
        if bd.any():
            bi=ia[bd]; G[bi]+=W[bi]; can=G[bi]>=C0; re=bi[can]
            G[re]-=C0; W[re]=C0
            dead[bi[~can]]=True; ia=ia[~bd]
            if len(ia)==0: continue
        if mode=='target':
            hv=W[ia]-C0>=T
            if hv.any(): hi=ia[hv]; G[hi]+=W[hi]-C0; W[hi]=C0
        elif mode=='periodic':
            pv=(ntr[ia]%period==0)&(W[ia]>C0)
            if pv.any(): pi=ia[pv]; G[pi]+=W[pi]-C0; W[pi]=C0
        nw=(~reached[ia])&(G[ia]>=C0)
        if nw.any(): reached[ia[nw]]=True; t_reach[ia[nw]]=tu[ia[nw]]
    G+=W*(~dead)
    return dict(P=reached.mean(), medG=np.median(G), bust=dead.mean(),
                medT=np.nanmedian(t_reach) if np.isfinite(t_reach).any() else np.nan,
                trades=np.median(ntr))

STRATS=['brk20_flip','brk20_flip_R3','brk20_tgt_R2','brk20_tgt_R5','mom20_flip',
        'brk20_s2_R2','mom5_flip','ma50_flip','brk20_tgt_R3','mom20_tgt_R2']
NS=500
print("="*104)
print(f"【跨策略对比·新目标】每个策略在(f,T)上寻优, 目标=最大化P(累计提取>=本金)")
print(f"  本金{C0:.0f} 爆仓线{int(BUST*100)}% 时间预算{YEARS}年 7币种并行  NSIM={NS}")
print("="*104)
print(f"\n  {'策略':<15}{'E[R]':>8}{'sig':>6}{'最佳f':>7}{'最佳T':>7}{'P(赚回)':>9}{'落袋中位':>9}{'爆仓%':>7}{'用时(年)':>9}")
print("  "+"-"*80)
results={}
for nm in STRATS:
    R=D[nm+'_R']; H=D[nm+'_H']; mu=R.mean(); sd=R.std()
    best=None
    for f in [0.005,0.01,0.02,0.03,0.05]:
        for T in [0.10,0.20,0.50,1.00]:
            r=simulate(R,H,f,T*C0,NS,seed=5)
            if best is None or r['P']>best[2]['P']: best=(f,T,r)
    f,T,r=best
    yr=r['medT']/8760 if np.isfinite(r['medT']) else np.nan
    results[nm]=(f,T,r,mu,sd)
    print(f"  {nm:<15}{mu:>+8.4f}{sd:>6.3f}{f*100:>6.1f}%{T*100:>6.0f}%{r['P']*100:>8.1f}%{r['medG']:>9.0f}"
          f"{r['bust']*100:>6.1f}%{yr:>9.2f}")

print("\n"+"="*104)
print("【E衰减敏感性】基准序列来自回测(有选择偏差/幸存者偏差), 若真实E衰减:")
print("="*104)
R=D['brk20_flip_R']; H=D['brk20_flip_H']; mu0=R.mean()
print(f"\n  {'衰减':<8}{'真实E[R]':>10}{'f*':>7}{'最佳f':>7}{'P(赚回)':>9}{'落袋中位':>9}{'爆仓%':>7}{'用时(年)':>9}")
print("  "+"-"*68)
for shrink in [1.0,0.7,0.5,0.3,0.0]:
    E=mu0*shrink
    Rs=R-(mu0-E)
    fs=2*E/R.std()**2 if E>0 else 0
    best=None
    for f in [0.005,0.01,0.02,0.03,0.05]:
        for T in [0.20,0.50,1.00]:
            r=simulate(Rs,H,f,T*C0,NS,seed=5)
            if best is None or r['P']>best[1]['P']: best=(f,r)
    f,r=best
    yr=r['medT']/8760 if np.isfinite(r['medT']) else np.nan
    print(f"  {shrink*100:<7.0f}%{E:>+10.4f}{fs*100:>6.2f}%{f*100:>6.1f}%{r['P']*100:>8.1f}%{r['medG']:>9.0f}"
          f"{r['bust']*100:>6.1f}%{yr:>9.2f}")
print("\n"+"="*104)
