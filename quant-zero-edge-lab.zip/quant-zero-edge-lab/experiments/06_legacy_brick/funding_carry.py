"""
资金费率 carry 统计 (非方向预测, 属于风险溢价/期限结构类)
逻辑: 永续合约 funding>0 = 多头付空头 -> 收取方有正carry
      (真正的delta中性需要 现货多 + 永续空, 此处只测费率本身是否稳定为正)
"""
import numpy as np, pandas as pd
F = {'BTCUSDT':'/data/inputs/BTCUSDT_funding.csv',
     'BNBUSDT':'/data/inputs/BNBUSDT_funding.csv',
     'BOMEUSDT':'/data/inputs/BOMEUSDT_funding.csv',
     'BRUSDT':'/data/inputs/BRUSDT_funding.csv'}
PER_YEAR = 3*365   # 8小时一次 -> 一天3次

print("="*94)
print("资金费率 funding rate 统计 (每8小时结算)")
print("="*94)
print(f"  {'品种':<11}{'样本':>7}{'均值':>11}{'中位数':>10}{'为正比例':>10}"
      f"{'年化carry':>11}{'标准差':>10}{'t值':>8}")
for s,p in F.items():
    df = pd.read_csv(p).dropna()
    r = df['fundingRate'].values
    n=len(r); mu=r.mean(); sd=r.std()
    t = mu/(sd/np.sqrt(n)) if sd>0 else 0
    pos=(r>0).mean()
    print(f"  {s:<11}{n:>7}{mu:>11.6f}{np.median(r):>10.6f}{pos*100:>9.1f}%"
          f"{mu*PER_YEAR*100:>10.1f}%{sd:>10.6f}{t:>8.2f}")

print("\n  注: 年化carry = 平均funding × 1095 (未扣交易成本/借贷/执行滑点)")
print("      为正比例 >50% 且 t值显著 -> 存在稳定的资金费溢价(做空永续方收carry)")
