"""
真实数据检验器 —— 拿真实数据验证/推翻我的所有结论
========================================================
用法:
    python3 real_data_test.py <你的CSV文件> [选项]

支持的 CSV 格式(自动识别):
    A. Date,Open,High,Low,Close,Volume      (标准OHLCV)
    B. timestamp,price                       (单列价格/tick)
    C. Date,Close                            (日期+收盘)

输出:
    1. 真实市场的【矛盾强度】rho 实测值
    2. 临界值 rho_crit(成本决定)
    3. 直接判定: 矛盾是否强到可抓
    4. 稳健性: 分时间段/分尺度看 rho 是否稳定(防止偶然)
    5. 与随机化对照比较(扣掉伪影)

关键: 这个脚本【不假设市场有edge】, 它只测量。
"""
import numpy as np
import sys
import os

PRICE0_DEFAULT = None       # 用数据自身的价格
COST_RATE = 0.0001          # 单边手续费(按名义), 根据你的实际调整
SLIP_REL = 0.00001          # 滑点(相对价格)


# ============================================================
# 一、读数据
# ============================================================
def load_csv(path, price_col=None, date_col=None):
    """自动识别格式, 返回 (价格数组, 标签)"""
    import csv
    rows = []
    with open(path, 'r', encoding='utf-8-sig', errors='ignore') as f:
        rdr = csv.reader(f)
        for row in rdr:
            if row:
                rows.append(row)
    if not rows:
        raise ValueError("空文件")

    header = rows[0]
    hlow = [h.strip().lower() for h in header]
    data = rows[1:]

    def col_of(names):
        for n in names:
            if n in hlow:
                return hlow.index(n)
        return None

    c_close = col_of(['close', 'price', 'adj close', 'adj_close', 'last'])
    c_open = col_of(['open'])
    c_high = col_of(['high'])
    c_low = col_of(['low'])

    # 判断是否有表头
    def is_num(s):
        try:
            float(s)
            return True
        except Exception:
            return False

    has_header = not all(is_num(x) for x in header if x)
    if not has_header:
        data = rows
        c_close = price_col if price_col is not None else (len(header) - 1)
        c_open = c_high = c_low = None

    if c_close is None:
        # 没找到, 用最后一列
        c_close = len(header) - 1

    px = []
    for r in data:
        if len(r) <= c_close:
            continue
        try:
            v = float(r[c_close])
            if v > 0:
                px.append(v)
        except Exception:
            continue
    px = np.array(px)
    if len(px) < 100:
        raise ValueError(f"有效数据太少: {len(px)}")
    return px, dict(close=px, has_ohlc=(c_high is not None and c_low is not None))


# ============================================================
# 二、测量矛盾强度 rho (自相关)
# ============================================================
def measure_rho(px, lags=(1, 2, 5, 10, 20, 50, 100)):
    """多尺度自相关 —— 这才是'矛盾强度'的直接测量"""
    r = np.diff(np.log(px))
    r = r - r.mean()
    n = len(r)
    out = {}
    for L in lags:
        if n <= L + 10:
            continue
        ac = np.corrcoef(r[:-L], r[L:])[0, 1]
        # 标准误 (Bartlett)
        se = 1.0 / np.sqrt(n)
        out[L] = dict(rho=float(ac), se=float(se), z=float(ac / se))
    return out, r


def rho_rolling(px, W=2000, lag=1):
    """滚动自相关 —— 看矛盾是否稳定(会不会转化)"""
    r = np.diff(np.log(px))
    n = len(r)
    acf = np.full(n, np.nan)
    for i in range(W + lag, n):
        seg = r[i - W:i]
        a = seg[:-lag]
        b = seg[lag:]
        sa, sb = a.std(), b.std()
        if sa > 0 and sb > 0:
            acf[i] = np.corrcoef(a, b)[0, 1]
    return acf


# ============================================================
# 三、临界值 (成本决定)
# ============================================================
def rho_crit_of(A, sigma_step, cost_rate=COST_RATE):
    """
    解出: 使 胜率(rho) = 盈亏平衡胜率 p* 的临界 rho
    A          : 砖块大小(对数幅度)
    sigma_step : 单步波动(对数)
    """
    from scipy.stats import norm

    def win(rho):
        if abs(rho) < 1e-12:
            return 0.5
        T = (A / max(sigma_step, 1e-12)) ** 2
        mu = rho * A
        noise = sigma_step * np.sqrt(max(T, 1.0))
        return float(norm.cdf(mu / max(noise, 1e-12)))

    c = 2.0 * cost_rate / A
    pstar = (1.0 + c) / 2.0
    if win(0.0) >= pstar:
        return 0.0, pstar
    lo, hi = 0.0, 1.0
    for _ in range(80):
        mid = (lo + hi) / 2
        if win(mid) < pstar:
            lo = mid
        else:
            hi = mid
    return (lo + hi) / 2, pstar


# ============================================================
# 四、随机对照 (扣伪影)
# ============================================================
def shuffle_null(px, n_boot=20, lag=1, seed=0):
    """打乱收益 -> 破坏时间结构, 得到'无矛盾'基线"""
    rng = np.random.default_rng(seed)
    r = np.diff(np.log(px))
    vals = []
    for _ in range(n_boot):
        rb = rng.permutation(r)
        if len(rb) > lag + 10:
            vals.append(np.corrcoef(rb[:-lag], rb[lag:])[0, 1])
    return float(np.mean(vals)), float(np.std(vals))


# ============================================================
# 五、主流程
# ============================================================
def analyze(path, cost_rate=COST_RATE, A_mult_list=(3, 8, 20, 50)):
    px, meta = load_csv(path)
    n = len(px)
    print("=" * 92)
    print(f"真实数据检验: {os.path.basename(path)}")
    print("=" * 92)
    print(f"  样本数: {n}")
    print(f"  价格范围: {px.min():.4f} ~ {px.max():.4f}")
    print(f"  总收益: {(px[-1]/px[0]-1)*100:+.2f}%")

    # 1. 测矛盾强度
    print("\n" + "-" * 92)
    print("【1】矛盾强度 rho 实测 (自相关)")
    print("-" * 92)
    print(f"  {'lag':>6}{'rho':>12}{'标准误':>10}{'z值':>9}{'含义':>16}")
    rho_res, r = measure_rho(px)
    for L in sorted(rho_res.keys()):
        v = rho_res[L]
        if abs(v['z']) < 1.96:
            mean = "不显著(未分化)"
        elif v['rho'] > 0:
            mean = "趋势主导"
        else:
            mean = "反转主导"
        print(f"  {L:>6}{v['rho']:>12.5f}{v['se']:>10.5f}{v['z']:>9.2f}{mean:>16}")

    # 随机对照
    null_m, null_s = shuffle_null(px)
    rho1 = rho_res.get(1, {}).get('rho', np.nan)
    print(f"\n  随机对照(打乱后)基线: {null_m:+.5f} ± {null_s:.5f}")
    print(f"  实测 lag-1 rho      : {rho1:+.5f}")
    print(f"  扣除伪影后          : {rho1 - null_m:+.5f}  <- 这是真实的矛盾强度")

    # 2. 临界值
    print("\n" + "-" * 92)
    print("【2】临界值 rho_crit (由成本决定) —— 矛盾必须强过它才可抓")
    print("-" * 92)
    sigma_step = float(np.std(r))
    print(f"  单步波动 sigma = {sigma_step:.6f} ({sigma_step*1e4:.2f} bp)")
    print(f"\n  {'砖块A(bp)':>11}{'成本占比':>10}{'p*':>9}{'临界rho':>11}"
          f"{'实测|rho|':>11}{'跨过?':>8}{'需样本':>10}{'可得?':>8}")
    best = None
    for am in A_mult_list:
        A = am * sigma_step
        rc, pstar = rho_crit_of(A, sigma_step, cost_rate)
        nd = ((1.96 + 0.84) / max(abs(rc), 1e-9)) ** 2
        n_bricks = n * sigma_step / A
        ok = abs(rho1) > rc and nd < n_bricks
        flag = "YES" if abs(rho1) > rc else "no"
        avail = "OK" if nd < n_bricks else "不够"
        print(f"  {A*1e4:>11.1f}{2*cost_rate/A:>10.4f}{pstar:>9.4f}{rc:>11.5f}"
              f"{abs(rho1):>11.5f}{flag:>8}{nd:>10.0f}{avail:>8}")
        if ok and best is None:
            best = (A, rc)

    # 3. 稳定性: 矛盾会转化吗?
    print("\n" + "-" * 92)
    print("【3】矛盾稳定性 —— 主要矛盾会不会转化?")
    print("-" * 92)
    acf = rho_rolling(px, W=min(2000, n // 5))
    valid = acf[~np.isnan(acf)]
    if len(valid) > 10:
        print(f"  滚动 rho 均值  : {np.nanmean(valid):+.5f}")
        print(f"  滚动 rho 标准差: {np.nanstd(valid):.5f}")
        pos = (valid > 0).mean()
        print(f"  为正的比例    : {pos*100:.1f}%  "
              f"{'矛盾方向会翻转(不稳定)' if 0.2<pos<0.8 else '方向较稳定'}")

    # 4. 最终判定
    print("\n" + "=" * 92)
    print("【最终判定】")
    print("=" * 92)
    if best is None:
        print(f"  ✗ 未找到可行的砖块大小: 实测矛盾强度 |rho|={abs(rho1):.5f}")
        print(f"    低于所有砖块下的临界值")
        print(f"  -> 在这份真实数据下, 【无可抓的矛盾】(与我的模拟结论一致)")
    else:
        print(f"  ✓ 反例成立! 砖块 A={best[0]*1e4:.1f}bp, 实测 |rho|={abs(rho1):.5f}"
              f" > 临界 {best[1]:.5f}")
        print(f"  -> 在这份真实数据下, 【存在可抓的矛盾】(推翻我的结论)")
    return dict(rho1=rho1, null=null_m, sigma=sigma_step, n=n,
                rho_res=rho_res, best=best)


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print(__doc__)
        print("\n用法: python3 real_data_test.py <CSV文件>")
        print("\n示例数据源(需你自己下载后传入):")
        print("  - Binance klines: https://api.binance.com/api/v3/klines")
        print("  - Yahoo Finance:  AAPL, SPY, BTC-USD")
        print("  - Stooq:          https://stooq.com/q/d/l/?s=btcusd&i=d")
        sys.exit(1)
    analyze(sys.argv[1])
