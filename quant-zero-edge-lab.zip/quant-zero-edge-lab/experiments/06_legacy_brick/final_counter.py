import numpy as np
from solve_counterexample import gen_mkt_rho, rho_crit, pstar_of_A, gen_mkt_strong
from zoo_tick import brick_events, cont_returns, INIT_CAP, PRICE0, COST_RATE, TICKS_PER_HOUR, HOURS_PER_YEAR
N=60000; ANN=0.20; SIG=ANN/np.sqrt(TICKS_PER_HOUR*HOURS_PER_YEAR)
A=8*SIG; rc=rho_crit(A,SIG)

def strategy(px,A,mode='cont'):
    e=brick_events(px,A)
    if e is None: return INIT_CAP,0,0.5
    b,lp=e
    if len(b)<100: return INIT_CAP,0,0.5
    cr=cont_returns(b,lp)
    s=1.0 if mode=='cont' else -1.0
    cap=INIT_CAP
    for i in range(len(cr)):
        lots=cap*0.01/(PRICE0*A)
        if lots*PRICE0>cap*5: lots=cap*5/PRICE0
        cap+=s*cr[i]*lots*PRICE0-2*lots*PRICE0*COST_RATE
        if cap<=0: cap=0;break
    return cap,len(cr),float((s*cr>0).mean())

print("="*96)
print("★ 反例确认: 矛盾论解方程 -> 构造市场 -> 实盘验证")
print("="*96)
print(f"  砖块 A={A*1e4:.1f}bp  临界矛盾强度 rho_crit={rc:.5f}  p*={pstar_of_A(A):.4f}")
print(f"\n  {'强度/临界':>10}{'rho':>9}{'实测胜率':>10}{'p*':>9}{'终值中位':>10}{'收益':>10}{'反例':>8}")
ok_list=[]
for mult in [0.5,1.0,2.0,3.0,5.0,8.0,12.0]:
    rho=rc*mult
    fs=[];ws=[]
    for s in range(10):
        px=gen_mkt_rho('trend',N,SIG,seed=800+s,rho_target=rho)
        c,n,w=strategy(px,A)
        fs.append(c);ws.append(w)
    med=np.median(fs);ret=(med/INIT_CAP-1)*100
    ok=ret>20
    if ok: ok_list.append((mult,rho,med,ret))
    print(f"  {mult:>9.1f}x{rho:>9.4f}{np.mean(ws):>10.4f}{pstar_of_A(A):>9.4f}"
          f"{med:>10.0f}{ret:>+9.0f}%{'成立' if ok else '-':>8}")

print("\n" + "="*96)
print("★ 反例的另一半: 震荡(反转主导)也要能成立")
print("="*96)
print(f"  {'强度/临界':>10}{'rho':>9}{'实测胜率':>10}{'终值中位':>10}{'收益':>10}{'反例':>8}")
for mult in [1.0,3.0,5.0,8.0,12.0]:
    rho=-rc*mult
    fs=[];ws=[]
    for s in range(10):
        px=gen_mkt_rho('rev',N,SIG,seed=900+s,rho_target=rho)
        c,n,w=strategy(px,A,'rev')
        fs.append(c);ws.append(w)
    med=np.median(fs);ret=(med/INIT_CAP-1)*100
    print(f"  {mult:>9.1f}x{rho:>9.4f}{np.mean(ws):>10.4f}{med:>10.0f}{ret:>+9.0f}%"
          f"{'成立' if ret>20 else '-':>8}")

print("\n" + "="*96)
print("★ 结论: 反例成立的条件")
print("="*96)
if ok_list:
    m=ok_list[0]
    print(f"  最小成立强度: {m[0]:.1f}x 临界值 (rho={m[1]:.4f}) -> 收益 {m[3]:+.0f}%")
print(f"\n  矛盾论给出的反例判据:")
print(f"    1. 矛盾强度 rho 必须 > rho_crit(A) = {rc:.5f}")
print(f"    2. 砖块 A 必须落在可行域 (A={A*1e4:.0f}bp 满足: 需样本<可得砖数)")
print(f"    3. 检测: N_req(rho) = ((1.96+0.84)/rho)^2 必须 < 可得样本")
for r in [0.0315,0.094,0.188,0.314]:
    nd=((1.96+0.84)/r)**2
    print(f"       rho={r:.3f}: 需 {nd:.0f} 笔样本 {'✓可检测' if nd<1200 else '✗不可检测'}")
print(f"\n  ⚠ 关键: 真实市场的 rho 通常在 0.001~0.01 (弱动量实测0.0093)")
print(f"     远低于临界 {rc:.4f} -> 这解释了为何实盘难赚")
