# -*- coding: utf-8 -*-
import sys, numpy as np, pandas as pd, warnings
sys.path.insert(0,'/data/workspace/brick')
warnings.filterwarnings('ignore')
from entry_lib import *
def sig_brk20(c):
    s=np.zeros(len(c)); hh=pd.Series(c).rolling(20).max().values; ll=pd.Series(c).rolling(20).min().values
    s[20:]=np.where(c[20:]>hh[:-20],1,np.where(c[20:]<ll[:-20],-1,0)); return np.where(np.isnan(s),0,s)

print('诊断: brk20 单品种 —— 持仓比例 / 累积收益 / 与买入持有对比')
print(f'{"品种":<6}{"多头%":>8}{"空头%":>8}{"空仓%":>8}{"策略累积":>12}{"BH累积":>10}{"比值":>8}')
for sym in ALL13[:6]:
    df=load(sym); o=df['open'].values; c=df['close'].values
    n=len(o); cut=n//2; sig=sig_brk20(c)
    r=np.zeros(n); r[1:]=o[1:]/o[:-1]-1
    pos=sig[:-1]; ret=r[1:]
    a=cut
    p=pos[a:]; rr=ret[a:]
    chg=np.zeros(len(pos)); chg[1:]=(np.abs(np.diff(pos))>0).astype(float)
    pnl=pos*ret-chg*2*0.0002
    pnl=pnl[a:]
    # 累积(复利)
    strat=np.exp(np.log1p(pnl).sum())-1
    bh=np.exp(np.log1p(rr).sum())-1
    print(f'{sym:<6}{(p>0).mean():>8.1%}{(p<0).mean():>8.1%}{(p==0).mean():>8.1%}{strat:>12.1%}{bh:>10.1%}{strat/max(bh,1e-9):>8.1f}')

print()
print('检查: 信号是否"卡住不动"(长期不翻转) -> 平均持仓段长度')
for sym in ['DOGE','XRP']:
    df=load(sym); c=df['close'].values
    s=sig_brk20(c)
    ch=np.abs(np.diff(s))>0
    print(f'  {sym}: 翻转次数={ch.sum()}, 总bar={len(s)}, 平均每段={len(s)/max(ch.sum(),1):.1f} bar')
    print(f'     信号值分布: +1={np.mean(s>0):.1%}  -1={np.mean(s<0):.1%}  0={np.mean(s==0):.1%}')
