"""
tick 级盲测交易 —— 彻底绕开"bar内路径不可知"
================================================
之前所有基于 OHLC 的回测都有病:
  一根 bar 内 high/low 都被触及时, 真实路径未知
  -> 任何顺序假设都会系统性造假利润
  -> 这就是随机游走里也能测出 0.537 胜率的原因

本版本:
  直接生成【高频 tick 序列】, 逐 tick 判断触及边界。
  单 tick 波动 << 区间 A  -> 不存在"一个tick跨多个区间"
  -> 无路径歧义, 无伪影来源

这就是"用我生成的数据, 按你的砖块规则实盘交易"。
"""
import numpy as np

PRICE0 = 100000.0
COST_RATE = 0.0001      # 单边手续费(按名义)
SLIP_REL = 0.00001      # 滑点 1个基点
INIT_CAP = 10000.0
RISK = 0.01
LEV_CAP = 5.0
TICKS_PER_HOUR = 20
HOURS_PER_YEAR = 252 * 8


def gen_ticks(kind, n, sigma_tick, seed, price0=PRICE0):
    """生成高频 tick 价格(对数收益累加)"""
    rng = np.random.default_rng(seed)
    r = np.zeros(n)
    if kind == 'rw':
        r = rng.normal(0, sigma_tick, n)
    elif kind == 'trendvol':
        h, d = sigma_tick ** 2, np.zeros(n)
        for t in range(1, n):
            h = 0.9 * h + 0.1 * r[t - 1] ** 2 + 1e-16
            d[t] = 0.95 * d[t - 1] + rng.normal(0, sigma_tick * 0.10)
            r[t] = d[t] + np.sqrt(h) * rng.normal()
        sd = r.std()
        if sd > 0:
            r = r / sd * sigma_tick
    elif kind == 'regime':
        state = 0
        for t in range(1, n):
            if rng.random() < 0.0005:
                state = 1 - state
            r[t] = (0.10 if state == 1 else -0.10) * r[t - 1] + rng.normal(0, sigma_tick)
    elif kind == 'strong':
        L = max(50, n // 8)
        signs = rng.choice([-1, 1], int(np.ceil(n / L)))
        r = signs.repeat(L)[:n] * sigma_tick * 0.30 + rng.normal(0, sigma_tick, n)
    return price0 * np.exp(np.cumsum(r))


def run_brick_ticks(px, A_mult=20.0, W=100, z_crit=1.645, use_filter=True,
                    n_warm=60, cap0=INIT_CAP, risk=RISK, cost_rate=COST_RATE,
                    slip_rel=SLIP_REL, lev_cap=LEV_CAP, sigma_tick=None):
    """
    砖块系统, tick 级执行。
    A = A_mult * sigma_tick   (区间 = 20倍单tick波动 -> 单tick跨区概率≈0)
    """
    A = A_mult * sigma_tick              # 对数幅度
    lp = np.log(px)
    n = len(lp)
    cap = cap0
    equity = np.empty(n)
    peak = cap0
    maxdd = 0.0
    pos = 0
    entry = 0.0
    lots = 0.0
    a_hi = lp[0] + A
    a_lo = lp[0] - A
    outcomes = []
    bankrupt = False
    n_sig = 0
    n_taken = 0

    def size_for(capv):
        # 每笔风险 = cap*risk; 区间收益 = A (对数) -> 名义 = cap*risk/A
        # 关键单位修正: 名义 = lots*PRICE0; 每笔盈亏(货币)=lots*PRICE0*A
        # 令其 = cap*risk  ->  lots = cap*risk/(PRICE0*A)
        lots_ = capv * risk / (PRICE0 * A)
        if lots_ * PRICE0 > capv * lev_cap:
            lots_ = capv * lev_cap / PRICE0
        return max(lots_, 0.0)

    for i in range(n):
        p = lp[i]
        if pos == 0:
            n_sig += 1
            take = True
            if use_filter and len(outcomes) >= n_warm and len(outcomes) >= W:
                wr = np.mean(outcomes[-W:]) * 0.5 + 0.5
                se = np.sqrt(0.25 / W)
                take = (wr - 0.5) / se > z_crit
            if take and p >= a_hi:
                n_taken += 1
                entry = p + slip_rel          # 真实: 市价成交 + 不利滑点
                pos = 1
                lots = size_for(cap)
                cap -= lots * PRICE0 * cost_rate
                a_hi = entry + A
                a_lo = entry - A
            elif take and p <= a_lo:
                n_taken += 1
                entry = p - slip_rel          # 真实: 市价成交 - 不利滑点
                pos = -1
                lots = size_for(cap)
                cap -= lots * PRICE0 * cost_rate
                a_hi = entry + A
                a_lo = entry - A

        if pos != 0:
            if pos == 1:
                if p <= entry - A:
                    exitp = p - slip_rel
                    pnl = (exitp - entry) * lots * PRICE0
                    cap += pnl - lots * PRICE0 * cost_rate
                    outcomes.append(-1.0); pos = 0
                    a_hi, a_lo = exitp + A, exitp - A
                elif p >= entry + A:
                    exitp = p + slip_rel
                    pnl = (exitp - entry) * lots * PRICE0
                    cap += pnl - lots * PRICE0 * cost_rate
                    outcomes.append(1.0); pos = 0
                    a_hi, a_lo = exitp + A, exitp - A
            else:
                if p >= entry + A:
                    exitp = p + slip_rel
                    pnl = (entry - exitp) * lots * PRICE0
                    cap += pnl - lots * PRICE0 * cost_rate
                    outcomes.append(-1.0); pos = 0
                    a_hi, a_lo = exitp + A, exitp - A
                elif p <= entry - A:
                    exitp = p - slip_rel
                    pnl = (entry - exitp) * lots * PRICE0
                    cap += pnl - lots * PRICE0 * cost_rate
                    outcomes.append(1.0); pos = 0
                    a_hi, a_lo = exitp + A, exitp - A

        eq = cap
        if pos != 0:
            eq += ((p - entry) if pos == 1 else (entry - p)) * lots * PRICE0
        equity[i] = max(eq, 0.0)
        peak = max(peak, equity[i])
        maxdd = max(maxdd, (peak - equity[i]) / peak if peak > 0 else 0)
        if equity[i] <= 0:
            bankrupt = True
            equity[i:] = 0.0
            break

    oc = np.array(outcomes) if outcomes else np.array([])
    return dict(final=equity[-1] if not bankrupt else 0.0,
                equity=equity, maxdd=maxdd, bankrupt=bankrupt,
                n_trades=len(outcomes), n_sig=n_sig, n_taken=n_taken,
                win=float((oc > 0).mean()) if len(oc) else np.nan,
                A=A)
