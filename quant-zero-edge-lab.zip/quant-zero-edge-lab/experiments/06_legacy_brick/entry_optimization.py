"""
【入场优化】—— 用户指出: 核心在入场
==================================================
【精确判据】
  R=2, cost_R(maker,s=5%) ≈ 0.008
  盈亏平衡胜率 p* = (1+cost_R)/(1+R) = 1.008/3 = 33.6%
  随机(无edge)理论胜率 = 1/(1+R) = 33.3%

  => 入场信号只需把胜率从 33.3% 推到 >33.6% 即可盈利
  => 这是【可精确搜索】的目标!

【本实验】
  1. 先测 bar内触及顺序的三种假设 (乐观/中间/保守)
     -> 给出真实E(R)的区间, 而非单点
  2. 扫描入场信号族, 看谁能把胜率推过 p*
  3. 样本内选 -> 样本外验

【入场信号族】(全部只用t及之前信息)
  A. 动量窗口扫描: 5/10/20/40/60/120
  B. 突破(唐奇安): 20/60
  C. 均线: 10/30/60
  D. 回撤入场: 趋势(60日向上) + 短期回调N日
  E. 波动率条件: 低波时入场 / 高波时入场
  F. 时段: UTC小时
  G. 组合: 动量 + 波动率过滤
"""
import numpy as np
import pandas as pd
from scipy import stats

HOURLY = {'DOGE': '/data/inputs/DOGEUSDT_1h.csv',
          'DOT':  '/data/inputs/DOTUSDT_1h.csv',
          'CRV':  '/data/inputs/CRVUSDT_1h.csv',
          'DASH': '/data/inputs/DASHUSDT_1h.csv'}


def load():
    out = {}
    for k, p in HOURLY.items():
        d = pd.read_csv(p)
        ts = pd.to_datetime(d['timestamp'], unit='ms')
        out[k] = dict(open=d['open'].values, high=d['high'].values,
                      low=d['low'].values, close=d['close'].values,
                      hour=np.asarray(pd.to_datetime(ts).dt.hour))
    return out


def run_trades_ohlc(D, signal, s, R, mode='maker', max_hold=800,
                    tie='conservative', seed=42, start=0, end=None):
    """tie: conservative(止损先) / optimistic(止盈先) / mid(50-50)"""
    hi, lo, cl = D['high'], D['low'], D['close']
    n = len(cl) if end is None else min(end, len(cl))
    if mode == 'maker':
        c_win = c_loss = 2 * 2e-4 / s
    elif mode == 'mixed':
        c_win = 2 * 2e-4 / s; c_loss = (2e-4 + 10e-4) / s
    else:
        c_win = c_loss = 2 * 10e-4 / s

    rng = np.random.default_rng(seed)
    net = []
    i = max(start, 120)
    while i < n - 2:
        sg = signal[i]
        if sg == 0:
            i += 1
            continue          # 关键: 无信号就不入场(不再随机)
        direction = 1 if sg > 0 else -1
        entry = cl[i]
        out_R = None
        j = i
        for jj in range(i + 1, min(i + max_hold, n)):
            if direction == 1:
                hs = lo[jj] <= entry * (1 - s)
                ht = hi[jj] >= entry * (1 + R * s)
            else:
                hs = hi[jj] >= entry * (1 + s)
                ht = lo[jj] <= entry * (1 - R * s)
            if hs and ht:
                if tie == 'conservative':
                    out_R = -1.0
                elif tie == 'optimistic':
                    out_R = R
                else:
                    out_R = -1.0 if rng.random() < 0.5 else R
                j = jj; break
            if hs: out_R = -1.0; j = jj; break
            if ht: out_R = R; j = jj; break
        if out_R is None:
            j = min(i + max_hold, n - 1)
            out_R = (cl[j] / entry - 1) * direction / s
        net.append(out_R - (c_win if out_R > 0 else c_loss))
        i = j + 1
    return np.array(net)


def stats_of(net):
    if len(net) < 30: return None
    E = net.mean()
    t = E / (net.std() / np.sqrt(len(net))) if net.std() > 0 else 0
    return dict(n=len(net), win=(net > 0).mean(), E_R=E, t=t)


def path_risk(net, f=0.01, init=10000.0):
    nav = np.empty(len(net) + 1); nav[0] = init
    for i, r in enumerate(net):
        nav[i + 1] = nav[i] * (1.0 + f * r)
        if nav[i + 1] <= 0: nav[i + 1:] = 0; break
    mc, cur = 0, 0
    for r in net:
        if r < 0: cur += 1; mc = max(mc, cur)
        else: cur = 0
    pk = np.maximum.accumulate(nav)
    return dict(final=nav[-1],
                mdd=-((nav - pk) / np.maximum(pk, 1e-12)).min() * 100,
                max_consec=mc)


# ---------- 入场信号族 ----------
def build_entries(D):
    cl = D['close']; hi = D['high']; lo = D['low']
    n = len(cl)
    S = {}

    # A. 动量窗口
    for w in [5, 10, 20, 40, 60, 120, 240]:
        sig = np.zeros(n)
        sig[w:] = np.sign(cl[w:] / np.maximum(cl[:-w], 1e-9) - 1)
        S[f'mom_{w}'] = sig

    # B. 突破
    for w in [20, 60, 120]:
        hh = pd.Series(hi).rolling(w).max().values
        ll = pd.Series(lo).rolling(w).min().values
        sig = np.zeros(n)
        sig[w:] = np.where(cl[w:] > hh[:-w], 1.0,
                           np.where(cl[w:] < ll[:-w], -1.0, 0.0))
        S[f'brk_{w}'] = sig

    # C. 均线
    ma = pd.Series(cl)
    for w in [10, 30, 60, 120]:
        m = ma.rolling(w).mean().values
        sig = np.where(cl > m, 1.0, -1.0)
        sig[:w] = 0
        S[f'ma_{w}'] = sig

    # D. 回撤入场: 大趋势向上 + 短期回调
    for wL, wS in [(240, 10), (120, 5), (240, 20)]:
        trend = np.zeros(n)
        trend[wL:] = np.sign(cl[wL:] / np.maximum(cl[:-wL], 1e-9) - 1)
        pull = np.zeros(n)
        pull[wS:] = cl[wS:] / np.maximum(cl[:-wS], 1e-9) - 1
        sig = np.zeros(n)
        # 上升趋势中回调(跌) -> 做多; 下降趋势中反弹 -> 做空
        sig = np.where((trend > 0) & (pull < 0), 1.0,
                       np.where((trend < 0) & (pull > 0), -1.0, 0.0))
        sig[:max(wL, wS)] = 0
        S[f'pull_{wL}_{wS}'] = sig

    # E. 波动率条件入场 (低波/高波 用动量方向)
    ret = np.zeros(n); ret[1:] = cl[1:] / np.maximum(cl[:-1], 1e-9) - 1
    vol = pd.Series(np.abs(ret)).rolling(48).mean().values
    vq = np.nanpercentile(vol[~np.isnan(vol)], [33, 67])
    mom60 = np.zeros(n)
    mom60[60:] = np.sign(cl[60:] / np.maximum(cl[:-60], 1e-9) - 1)
    S['vol_low'] = np.where(vol <= vq[0], mom60, 0.0)
    S['vol_high'] = np.where(vol >= vq[1], mom60, 0.0)
    S['vol_mid'] = np.where((vol > vq[0]) & (vol < vq[1]), mom60, 0.0)

    # F. 时段
    hr = D['hour']
    for h0, h1 in [(0, 8), (8, 16), (16, 24)]:
        S[f'hour_{h0}_{h1}'] = np.where((hr >= h0) & (hr < h1), mom60, 0.0)

    # G. 组合: 动量60 + 突破确认
    brk60 = S['brk_60']
    S['mom60_brk'] = np.where((mom60 != 0) & (brk60 == mom60), mom60, 0.0)

    return S


data = load()
print("=" * 100)
print("【入场优化】把胜率推过盈亏平衡线")
print("=" * 100)

S_R, R_MULT = 0.05, 2.0
cost_R = 2 * 2e-4 / S_R
p_star = (1 + cost_R) / (1 + R_MULT)
print(f"\n  R=1:{R_MULT}, s={S_R*100:.0f}%, cost_R={cost_R:.4f}")
print(f"  盈亏平衡胜率 p* = (1+cost_R)/(1+R) = {p_star*100:.2f}%")
print(f"  随机理论胜率 1/(1+R) = {100/(1+R_MULT):.2f}%")
print(f"  => 入场只需把胜率从 {100/(1+R_MULT):.1f}% 推到 >{p_star*100:.1f}%")

# ---------- 1. 触及顺序三假设 ----------
print(f"\n  【1】bar内触及顺序: 三假设 (DOGE, mom_60, maker)")
print(f"  {'假设':<14}{'笔数':>7}{'胜率':>9}{'E(R)':>10}{'t':>8}")
print("  " + "-" * 50)
D = data['DOGE']; cl = D['close']; n = len(cl); sp = n // 2
S = build_entries(D)
for tie in ['optimistic', 'mid', 'conservative']:
    net = run_trades_ohlc(D, S['mom_60'], S_R, R_MULT, mode='maker',
                          tie=tie, start=sp, end=n)
    st = stats_of(net)
    if st:
        print(f"  {tie:<14}{st['n']:>7}{st['win']*100:>8.1f}%"
              f"{st['E_R']:>+10.3f}{st['t']:>+8.2f}")
print(f"  -> 真实值应在乐观与保守之间")

# ---------- 2. 入场信号族扫描 ----------
print(f"\n  【2】入场信号扫描 (DOGE样本外, tie=mid, maker)")
print(f"  {'信号':<16}{'笔数':>7}{'胜率':>9}{'vs p*':>9}{'E(R)':>10}{'t':>8}{'判定':>8}")
print("  " + "-" * 70)

results = []
for nm, sg in S.items():
    net = run_trades_ohlc(D, sg, S_R, R_MULT, mode='maker',
                          tie='mid', start=sp, end=n)
    st = stats_of(net)
    if st is None: continue
    diff = (st['win'] - p_star) * 100
    ok = '★' if (st['E_R'] > 0 and st['t'] > 1.96) else ''
    print(f"  {nm:<16}{st['n']:>7}{st['win']*100:>8.1f}%{diff:>+8.1f}pp"
          f"{st['E_R']:>+10.3f}{st['t']:>+8.2f}{ok:>8}")
    results.append((nm, st['win'], st['E_R'], st['t']))

# ---------- 3. 样本内选 -> 样本外验 ----------
print(f"\n  【3】样本内(前50%)选最优入场 -> 样本外验证")
best_in = None
for nm, sg in S.items():
    net = run_trades_ohlc(D, sg, S_R, R_MULT, mode='maker',
                          tie='mid', start=0, end=sp)
    st = stats_of(net)
    if st and (best_in is None or st['t'] > best_in[1]['t']):
        best_in = (nm, st)
if best_in:
    nm_b, s_in = best_in
    print(f"    样本内最优: {nm_b} (胜率{s_in['win']*100:.1f}%, "
          f"E={s_in['E_R']:+.3f}R, t={s_in['t']:+.2f})")
    net_oos = run_trades_ohlc(D, S[nm_b], S_R, R_MULT, mode='maker',
                              tie='mid', start=sp, end=n)
    s_oos = stats_of(net_oos)
    if s_oos:
        pr = path_risk(net_oos)
        print(f"    样本外验证: 胜率{s_oos['win']*100:.1f}%, "
              f"E={s_oos['E_R']:+.3f}R, t={s_oos['t']:+.2f}, N={s_oos['n']}")
        print(f"    账户: 终值{pr['final']:.0f}, 回撤{pr['mdd']:.1f}%, "
              f"最大连亏{pr['max_consec']}")

# ---------- 4. 多品种验证最优入场 ----------
print(f"\n  【4】多品种验证 (用样本内选出的 {best_in[0] if best_in else 'mom_60'})")
nm_use = best_in[0] if best_in else 'mom_60'
print(f"  {'品种':<7}{'笔数':>7}{'胜率':>9}{'E(R)':>10}{'t':>8}"
      f"{'终值':>10}{'回撤':>8}{'连亏':>7}")
print("  " + "-" * 68)
for sym in ['DOGE', 'CRV', 'DOT', 'DASH']:
    D2 = data[sym]
    S2 = build_entries(D2)
    n2 = len(D2['close']); sp2 = n2 // 2
    if nm_use not in S2: continue
    net = run_trades_ohlc(D2, S2[nm_use], S_R, R_MULT, mode='maker',
                          tie='mid', start=sp2, end=n2)
    st = stats_of(net)
    if st is None: continue
    pr = path_risk(net)
    print(f"  {sym:<7}{st['n']:>7}{st['win']*100:>8.1f}%{st['E_R']:>+10.3f}"
          f"{st['t']:>+8.2f}{pr['final']:>10.0f}{pr['mdd']:>7.1f}%"
          f"{pr['max_consec']:>7}")

print("\n" + "=" * 100)
print("完成")
print("=" * 100)
