"""
用矛盾论找反例 —— 不靠猜, 靠解方程
==============================================
流程:
  1. 解出【临界矛盾强度】rho_crit(A) 的理论曲线
  2. 加上【检测门槛】: 需要多少样本才能确认这个矛盾
  3. 求【可行域】
  4. 在可行域内构造市场, 实盘跑, 验证反例成立
  5. 在可行域【外】构造市场, 验证反例不成立(对照组)
"""
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from solve_counterexample import (win_rate_from_rho, pstar_of_A, rho_crit,
                                  n_detect, solve_feasible,
                                  gen_mkt_rho, gen_mkt_strong)
from contradiction3 import run_contra3, roll_acf1
from zoo_tick import (INIT_CAP, COST_RATE, TICKS_PER_HOUR, HOURS_PER_YEAR)

plt.rcParams['font.sans-serif'] = ['WenQuanYi Micro Hei', 'DejaVu Sans']
plt.rcParams['axes.unicode_minus'] = False

N = 60000
ANN = 0.20
SIG = ANN / np.sqrt(TICKS_PER_HOUR * HOURS_PER_YEAR)
NPATH = 8

print("=" * 100)
print("用矛盾论找反例: 把'能赚钱'翻译成可解的方程")
print("=" * 100)
print(f"  单步波动 sigma = {SIG:.6f} ({SIG*1e4:.2f} bp)")
print(f"  样本长度 N = {N} ticks = {N/(TICKS_PER_HOUR*HOURS_PER_YEAR):.1f} 年")

# ============================================================
# Step1: 理论可行域
# ============================================================
print("\n" + "=" * 100)
print("Step1: 理论可行域 —— 矛盾强度必须跨过什么门槛?")
print("=" * 100)
rows = solve_feasible(SIG, N, verbose=True)

feas = [r for r in rows if r['feasible']]
print(f"\n  可行砖块大小: ", end="")
if feas:
    print(", ".join(f"A={r['A_bp']:.0f}bp(需ρ>{r['rho_crit']:.4f})" for r in feas[:5]))
    best = min(feas, key=lambda r: r['rho_crit'])
    print(f"  >>> 最容易的入口: A={best['A_bp']:.0f}bp, 只需矛盾强度 rho > {best['rho_crit']:.4f}")
else:
    best = min(rows, key=lambda r: r['rho_crit'])
    print(f"  无完全可行点; 最接近: A={best['A_bp']:.0f}bp, rho_crit={best['rho_crit']:.4f}")

# ============================================================
# Step2: 在可行域【内】构造反例
# ============================================================
print("\n" + "=" * 100)
print("Step2: 构造反例 —— 让矛盾强度【刚好跨过】门槛")
print("=" * 100)

A_TEST = best['A'] if best else 5 * SIG
rc = rho_crit(A_TEST, SIG)
print(f"  选定砖块 A = {A_TEST*1e4:.1f} bp")
print(f"  临界矛盾强度 rho_crit = {rc:.5f}")
print(f"\n  构造强度为 1.5x / 3x / 6x 临界值的市场, 看是否真能赚钱")
print(f"\n  {'强度倍数':>9}{'rho':>10}{'理论胜率':>10}{'p*':>9}"
      f"{'理论正期望?':>13}{'实盘终值':>11}{'判定':>9}")

counterexamples = []
for mult in [0.5, 1.0, 1.5, 3.0, 6.0, 10.0]:
    rho = rc * mult
    p_theory = win_rate_from_rho(rho, A_TEST, SIG)
    pstar = pstar_of_A(A_TEST)
    pos_theory = p_theory > pstar

    # 实盘跑
    fs = []
    for s in range(NPATH):
        px = gen_mkt_rho('trend', N, SIG, seed=400 + s, rho_target=rho)
        r = run_contra3(px, A_TEST, W=min(2000, N // 10),
                        theta=max(rc * 0.5, 0.002))
        fs.append(r['final'])
    med = float(np.median(fs))
    ok = med > INIT_CAP * 1.1
    counterexamples.append((mult, rho, p_theory, pstar, med))
    print(f"  {mult:>9.1f}x{rho:>10.5f}{p_theory:>10.4f}{pstar:>9.4f}"
          f"{'是' if pos_theory else '否':>13}{med:>11.0f}"
          f"{'反例成立' if ok else '—':>9}")

print("\n" + "=" * 100)
print("Step3: 反例的【另一半】—— 矛盾的两个方面都要能抓")
print("=" * 100)
print("  震荡(反转主导)能否也构成反例? 用负 rho")
print(f"\n  {'强度倍数':>9}{'rho':>10}{'理论胜率':>10}{'p*':>9}{'实盘终值':>11}{'判定':>9}")
for mult in [1.0, 3.0, 6.0, 10.0]:
    rho = -rc * mult
    p_theory_rev = win_rate_from_rho(-rho, A_TEST, SIG)   # 反向做
    pstar = pstar_of_A(A_TEST)
    fs = []
    for s in range(NPATH):
        px = gen_mkt_rho('rev', N, SIG, seed=500 + s, rho_target=rho)
        r = run_contra3(px, A_TEST, W=min(2000, N // 10),
                        theta=max(rc * 0.5, 0.002))
        fs.append(r['final'])
    med = float(np.median(fs))
    ok = med > INIT_CAP * 1.1
    print(f"  {mult:>9.1f}x{rho:>10.5f}{p_theory_rev:>10.4f}{pstar:>9.4f}"
          f"{med:>11.0f}{'反例成立' if ok else '—':>9}")

# ============================================================
# Step4: 可行域外(对照组)
# ============================================================
print("\n" + "=" * 100)
print("Step4: 对照组 —— 矛盾强度【低于】门槛时, 必须失败")
print("=" * 100)
print(f"  {'rho/rho_crit':>14}{'实盘终值':>11}{'判定':>14}")
for ratio in [0.1, 0.25, 0.5, 0.8]:
    rho = rc * ratio
    fs = []
    for s in range(NPATH):
        px = gen_mkt_rho('trend', N, SIG, seed=600 + s, rho_target=rho)
        r = run_contra3(px, A_TEST, W=min(2000, N // 10),
                        theta=max(rc * 0.3, 0.001))
        fs.append(r['final'])
    med = float(np.median(fs))
    print(f"  {ratio:>14.2f}{med:>11.0f}{'失败(符合预期)' if med<=INIT_CAP*1.05 else '意外成功':>14}")

# ============================================================
# Step5: 强结构市场(更现实的"真edge")
# ============================================================
print("\n" + "=" * 100)
print("Step5: 强结构市场(分段趋势) —— 现实中的'真edge'长什么样")
print("=" * 100)
print(f"  {'结构强度':>9}{'实测ACF':>10}{'实盘终值':>11}{'判定':>12}")
for st in [0.1, 0.3, 0.6, 0.9, 1.5]:
    acfs, fs = [], []
    for s in range(NPATH):
        px = gen_mkt_strong('trend', N, SIG, seed=700 + s, strength=st)
        a = roll_acf1(px, W=min(2000, N // 10))
        acfs.append(np.nanmean(a))
        r = run_contra3(px, A_TEST, W=min(2000, N // 10),
                        theta=max(rc * 0.5, 0.002))
        fs.append(r['final'])
    med = float(np.median(fs))
    ok = med > INIT_CAP * 1.1
    print(f"  {st:>9.1f}{np.nanmean(acfs):>10.4f}{med:>11.0f}"
          f"{'反例成立' if ok else '—':>12}")

# ============================================================
# 图
# ============================================================
fig = plt.figure(figsize=(18, 10.5))
gs = fig.add_gridspec(2, 2, hspace=0.33, wspace=0.2)
fig.suptitle("用矛盾论找反例：把“能赚钱”翻译成可解的方程", fontsize=15, fontweight='bold')

ax = fig.add_subplot(gs[0, 0])
Ag = [r['A_bp'] for r in rows]
ax.plot(Ag, [r['rho_crit'] for r in rows], 'o-', lw=2.4, ms=8, label='临界矛盾强度 ρ_crit')
ax2 = ax.twinx()
ax2.plot(Ag, [r['pstar'] for r in rows], 's--', color='red', lw=2, ms=7, label='盈亏平衡胜率 p*')
ax.set_xscale('log')
ax.set_xlabel("砖块大小 A (bp, 对数)")
ax.set_ylabel("需要的矛盾强度 ρ_crit", color='blue')
ax2.set_ylabel("盈亏平衡胜率 p*", color='red')
ax.set_title("① 矛盾的“度”：砖块越大，成本占比越低\n→ 需要的矛盾强度越小（但样本也越少）", fontsize=11)
ax.grid(alpha=.3)
ax.legend(loc='upper right', fontsize=9)
ax2.legend(loc='center right', fontsize=9)

ax = fig.add_subplot(gs[0, 1])
mult_v = [c[0] for c in counterexamples]
ax.plot(mult_v, [c[4] for c in counterexamples], 'o-', lw=2.6, ms=9, color='darkblue')
ax.axhline(INIT_CAP, color='k', ls='--', lw=2, label='本金10000')
ax.axvline(1.0, color='red', ls=':', lw=2, label='临界 ρ_crit (1.0x)')
ax.set_xscale('log')
ax.set_xlabel("矛盾强度 / 临界值")
ax.set_ylabel("实盘终值 (元)")
ax.set_title("② 反例求解：跨过临界 → 赚钱\n低于临界 → 必亏（矛盾论给出精确分界）", fontsize=11)
ax.legend(fontsize=9)
ax.grid(alpha=.3)

ax = fig.add_subplot(gs[1, 0])
ax.plot(Ag, [min(r['n_detect'], 1e8) for r in rows], 'o-', lw=2.2,
        ms=7, color='green', label='检测所需样本 N_req')
ax.plot(Ag, [r['n_bricks'] for r in rows], 's-', lw=2.2, ms=7,
        color='orange', label='实际可得砖数')
ax.set_yscale('log')
ax.set_xscale('log')
ax.set_xlabel("砖块大小 A (bp)")
ax.set_ylabel("样本量（对数）")
ax.set_title("③ 第二道门：即使有矛盾，也要能【检测】\n绿线必须在橙线下方才可行", fontsize=11)
ax.legend(fontsize=9)
ax.grid(alpha=.3, which='both')

ax = fig.add_subplot(gs[1, 1])
sts, meds_s = [], []
for st in [0.1, 0.3, 0.6, 0.9, 1.5]:
    fs = []
    for s in range(NPATH):
        px = gen_mkt_strong('trend', N, SIG, seed=700 + s, strength=st)
        r = run_contra3(px, A_TEST, W=min(2000, N // 10), theta=max(rc * 0.5, 0.002))
        fs.append(r['final'])
    sts.append(st); meds_s.append(np.median(fs))
ax.bar(range(len(sts)), meds_s,
       color=['green' if m > INIT_CAP * 1.1 else 'salmon' for m in meds_s])
ax.axhline(INIT_CAP, color='k', ls='--', lw=1.8)
ax.set_xticks(range(len(sts)))
ax.set_xticklabels([f"{s}" for s in sts])
ax.set_xlabel("结构强度（分段趋势的漂移/噪声比）")
ax.set_ylabel("实盘终值 (元)")
ax.set_title("④ 现实市场的真edge：需要多强的结构？\n（强度是人为设定，真实市场未知）", fontsize=11)
ax.grid(alpha=.3, axis='y')

plt.savefig("/data/workspace/brick/fig_counterexample.png", dpi=130)
print("\n[已保存] fig_counterexample.png")
