"""
【严格重算·不复利方案】
用户要求: 不考虑复利增长, 算最终结果, 避免逻辑漏洞

核心定义澄清:
  复利(compound): 每笔押注 = f × 当前净值   -> 净值增长则自动加注
  固定注(fixed)  : 每笔押注 = f × 初始本金   -> 永远押固定金额, 赚了不加注

"不做复利"的严格含义 = 固定注 + 定期结算提取(把净值重置回本金)

逻辑漏洞检查清单(逐条在代码中落实):
  V1 时间一致性     : 所有模式跑相同总笔数, 爆仓后不补时
  V2 提取后基准     : 提取基准恒为初始本金C0(不是提取后的净值), 避免基准漂移
  V3 固定注爆仓风险 : 净值下跌时bet不变=相对风险上升, 必须靠爆仓线保护(不能无保护)
  V4 多店时间分摊   : 总笔数在多店间分配(不是每店都跑满)
  V5 爆仓后处理     : 剩余净值归入公积金(不是清零), 公积金>=C0才开新店
  V6 抽样一致性     : 同一bootstrap池, 但每次路径独立抽样
  V7 基准乐观性     : 基准序列E[R]来自回测(存在过拟合/幸存者偏差), 需做E衰减敏感性
"""
import numpy as np, pandas as pd
FILES={'DOGE':'/data/inputs/DOGEUSDT_1h.csv','DOT':'/data/inputs/DOTUSDT_1h.csv',
       'CRV':'/data/inputs/CRVUSDT_1h.csv','DASH':'/data/inputs/DASHUSDT_1h.csv',
       'ETH':'/data/inputs/ETHUSDT_1h.csv','FIL':'/data/inputs/FILUSDT_1h.csv',
       'HBAR':'/data/inputs/HBARUSDT_1h.csv'}
def load():
    o={}
    for k,p in FILES.items():
        d=pd.read_csv(p);c={x.lower():x for x in d.columns}
        o[k]=dict(open=d[c['open']].values.astype(float),high=d[c['high']].values.astype(float),
                  low=d[c['low']].values.astype(float),close=d[c['close']].values.astype(float))
    return o
def s_brk(cl,w):
    n=len(cl);s=np.zeros(n)
    for i in range(w,n):
        h=cl[i-w:i].max();l=cl[i-w:i].min()
        if cl[i]>h:s[i]=1
        elif cl[i]<l:s[i]=-1
    return s
def run(D,sg,s,R,cost_bp,slip_bp,max_hold,start,end,mode='flip'):
    op,hi,lo,cl=D['open'],D['high'],D['low'],D['close']
    n=len(cl) if end is None else min(end,len(cl))
    cR=2*cost_bp/1e4/s; slipR=slip_bp/1e4/s; stopd=s+slip_bp/1e4
    net=[];i=max(start,120)
    while i<n-3:
        d=1 if sg[i]>0 else (-1 if sg[i]<0 else 0)
        if d==0:i+=1;continue
        e=op[i+1];i0=i+1;out=None;j=i0
        for jj in range(i0,min(i0+max_hold,n)):
            adv=(lo[jj]/e-1) if d==1 else (1-hi[jj]/e)
            fav=(hi[jj]/e-1) if d==1 else (1-lo[jj]/e)
            if adv<=-stopd: out=-1.0-slipR;j=jj;break
            if fav>=R*s: out=R;j=jj;break
            if mode=='flip' and sg[jj]*d<0: out=((cl[jj]/e-1)*d)/s;j=jj;break
        if out is None:
            j=min(i0+max_hold,n-1);out=((cl[j]/e-1)*d)/s
        net.append(out-cR);i=j+1
    return np.array(net)

data=load()
alln=[]
for k,D in data.items():
    n=len(D['close'])
    nt=run(D,s_brk(D['close'],20),0.05,2.0,2,5,800,n//2,n,'flip')
    if len(nt)>=30: alln.append(nt)
R_full=np.concatenate(alln)
mu0,sd0=R_full.mean(),R_full.std()

C0=10000.0      # 单店投入本金
BUST=0.20       # 爆仓线: 净值<=20%本金即关店
NSIM=2000
HORIZON=3000    # 总笔数(时间基准)

def sim(rng, f, q, period, sizing, nshop=1, R=None):
    """
    sizing: 'compound'(bet=f*W) | 'fixed'(bet=f*C0)
    q     : 提取率(0=不提取)
    nshop : 店数(1=单店)
    返回: 落袋G, 剩余W, 总资产, 爆仓, 真赚到(G>C0)
    V1: 总笔数固定= HORIZON, 分摊到nshop
    """
    R = R if R is not None else R_full
    per = HORIZON//nshop
    G=0.0; bk_any=False; alive_left=0.0; used=0
    for sh in range(nshop):
        # V5: 第一店用初始本金, 后续店需公积金>=C0
        if sh==0: cap=C0
        else:
            if G>=C0: cap=C0; G-=C0
            else: break
        Rs=rng.choice(R, per, replace=True)
        W=cap; bet0=f*cap
        for i,r in enumerate(Rs):
            # 押注额
            bet = f*W if sizing=='compound' else bet0
            # V3: 押注不能超过当前净值(否则负债), 但爆仓线先触发
            if bet>W: bet=W
            W += bet*r
            # 爆仓
            if W<=cap*BUST:
                bk_any=True; break
            # V2: 定期结算, 提取基准恒为cap(初始本金), 不漂移
            if (i+1)%period==0 and W>cap:
                draw=(W-cap)*q
                W-=draw; G+=draw
        G+=W; alive_left=W; used+=len(Rs)
    total=G
    return dict(total=total, G=G, left=alive_left, bk=bk_any, win=(G>C0))

def summarize(res,label,R=None):
    tot=np.array([x['total'] for x in res])
    g=np.array([x['G'] for x in res])
    bk=np.array([x['bk'] for x in res])
    win=np.array([x['win'] for x in res])
    print(f"  {label:<34}{np.median(tot):>11.0f}{np.percentile(g,25):>10.0f}{np.percentile(g,75):>10.0f}"
          f"{bk.mean()*100:>8.1f}%{win.mean()*100:>9.1f}%")
    return dict(med=np.median(tot),p_win=win.mean(),p_bk=bk.mean(),g25=np.percentile(g,25),g75=np.percentile(g,75))

rng=np.random.default_rng(2024)
print("="*104)
print("【严格重算·不复利】基准序列 brk20_flip")
print(f"  E[R]={mu0:+.4f}  σ={sd0:.3f}  Kelly={mu0/sd0**2*100:.2f}%  临界f*=2E/σ²={2*mu0/sd0**2*100:.2f}%")
print(f"  本金C0={C0:.0f}  爆仓线={int(BUST*100)}%本金  总笔数={HORIZON}  模拟{NSIM}次")
print("="*104)
print(f"\n  {'模式':<34}{'总资产中位':>11}{'落袋P25':>10}{'落袋P75':>10}{'爆仓%':>8}{'真赚到%':>9}")
print("  "+"-"*86)

print(f"\n  ### 仓位 f=1% (安全区, 低于f*={2*mu0/sd0**2*100:.1f}%)")
res={}
res['A 复利 不提取']      =[sim(rng,0.01,0.0,100,'compound') for _ in range(NSIM)]
res['B 复利 提取100%']    =[sim(rng,0.01,1.0,100,'compound') for _ in range(NSIM)]
res['C 固定注 不提取']    =[sim(rng,0.01,0.0,100,'fixed') for _ in range(NSIM)]
res['D 固定注 提取100%']  =[sim(rng,0.01,1.0,100,'fixed') for _ in range(NSIM)]
res['E 固定注 提取 四店'] =[sim(rng,0.01,1.0,100,'fixed',nshop=4) for _ in range(NSIM)]
for k,v in res.items(): summarize(v,k)

print(f"\n  ### 仓位 f=3% (接近Kelly={mu0/sd0**2*100:.1f}%)")
res={}
res['A 复利 不提取']      =[sim(rng,0.03,0.0,100,'compound') for _ in range(NSIM)]
res['B 复利 提取100%']    =[sim(rng,0.03,1.0,100,'compound') for _ in range(NSIM)]
res['C 固定注 不提取']    =[sim(rng,0.03,0.0,100,'fixed') for _ in range(NSIM)]
res['D 固定注 提取100%']  =[sim(rng,0.03,1.0,100,'fixed') for _ in range(NSIM)]
res['E 固定注 提取 四店'] =[sim(rng,0.03,1.0,100,'fixed',nshop=4) for _ in range(NSIM)]
for k,v in res.items(): summarize(v,k)

print(f"\n  ### 仓位 f=5% (超临界, 复利必归零)")
res={}
res['A 复利 不提取']      =[sim(rng,0.05,0.0,100,'compound') for _ in range(NSIM)]
res['B 复利 提取100%']    =[sim(rng,0.05,1.0,100,'compound') for _ in range(NSIM)]
res['C 固定注 不提取']    =[sim(rng,0.05,0.0,100,'fixed') for _ in range(NSIM)]
res['D 固定注 提取100%']  =[sim(rng,0.05,1.0,100,'fixed') for _ in range(NSIM)]
res['E 固定注 提取 四店'] =[sim(rng,0.05,1.0,100,'fixed',nshop=4) for _ in range(NSIM)]
for k,v in res.items(): summarize(v,k)

print("\n"+"="*104)
print("【V7 敏感性】若真实E衰减(回测过拟合/幸存者偏差), 固定注方案还成立吗?")
print("="*104)
print(f"  {'E[R]':<10}{'f*':>8}{'模式':<26}{'总资产中位':>11}{'落袋P25':>10}{'真赚到%':>9}{'爆仓%':>8}")
print("  "+"-"*82)
for shrink in [1.0,0.5,0.3,0.0]:
    E=mu0*shrink
    # 构造衰减序列: 平移使均值=E (保持σ)
    Rs=R_full - (mu0-E)
    fs=2*E/sd0**2 if E>0 else 0
    for lab,mode,ns in [('D 固定注 提取100%','fixed',1),('E 四店','fixed',4),('A 复利 不提取','compound',1)]:
        rr=[sim(rng,0.03,1.0 if 'fixed' in lab else 0.0,100,mode,nshop=ns,R=Rs) for _ in range(800)]
        t=np.array([x['total'] for x in rr]); g=np.array([x['G'] for x in rr])
        bk=np.array([x['bk'] for x in rr]); wn=np.array([x['win'] for x in rr])
        print(f"  {E:<+10.4f}{fs*100:>7.2f}%{lab:<26}{np.median(t):>11.0f}{np.percentile(g,25):>10.0f}"
              f"{wn.mean()*100:>8.1f}%{bk.mean()*100:>7.1f}%")
print("\n"+"="*104)
