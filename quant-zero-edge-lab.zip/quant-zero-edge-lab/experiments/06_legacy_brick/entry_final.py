# -*- coding: utf-8 -*-
"""最终判决: (1)62信号Reality Check (2)vs买入持有完整对比"""
import sys, numpy as np, pandas as pd, warnings
sys.path.insert(0,'/data/workspace/brick')
warnings.filterwarnings('ignore')
from entry_lib import *

def pos_series(sig, n):
    s=np.asarray(sig,float); nz=np.where(s!=0)[0]
    if len(nz)<100: return None
    s=s.copy(); s[:nz[0]]=0
    eff=np.where(s==0,0,s); prev=np.roll(eff,1); prev[0]=0
    chg=(eff!=prev)&(eff!=0); st=np.where(chg)[0]; st=st[st+1<n]
    if len(st)<5: return None
    ei=st+1; xi=np.roll(ei,-1); xi[-1]=n-1
    v=xi>ei; ei,xi=ei[v],xi[v]
    # position[i] = 该bar持仓方向 (ei生效到xi之前)
    p=np.zeros(n); d=eff[st][v]
    cnt=xi-ei; bseg=np.repeat(np.arange(len(ei)),cnt)
    st0=ei[0]; idx=np.arange(st0,st0+cnt.sum())
    p[idx]=d[bseg]
    return p

def equity_cmp(sig, df, cost=0.0002, stop=STOP, f=1.0):
    o=df['open'].values; n=len(o)
    p=pos_series(sig,n)
    if p is None: return None
    # 止损: 逐段检查(用之前引擎一致的保守规则)
    h=df['high'].values; l=df['low'].values
    ei=np.where((p!=0)&(np.roll(p,1)!=p))[0]
    if len(ei)==0: return None
    xi=np.roll(ei,-1); xi[-1]=n
    ei=ei[:-1]; xi=xi[:-1]
    if len(ei)<10: return None
    d=p[ei]; ep=o[ei]
    cnt=np.maximum(xi-ei,1); bseg=np.repeat(np.arange(len(ei)),cnt)
    st0=ei[0]; idx=np.arange(st0,st0+cnt.sum())
    lmin=np.full(len(ei),np.inf); np.minimum.at(lmin,bseg,l[idx])
    hmax=np.full(len(ei),-np.inf); np.maximum.at(hmax,bseg,h[idx])
    sp=np.where(d>0,ep*(1-stop),ep*(1+stop))
    hs=np.where(d>0,lmin<=sp,hmax>=sp)
    xp=o[xi]
    raw=(xp-ep)/ep*d
    ret=np.where(hs,-stop,raw)-2*cost
    # 逐笔 -> 时间加权近似: 策略总收益(固定注, 每笔风险f*stop)
    # BH 同期
    bh_ret=(xp-ep)/ep
    yrs=(df['timestamp'].values[xi]-df['timestamp'].values[ei]).mean()/ (365.25*24*3600*1000) * len(ei)
    return dict(ret=ret/stop, bh=bh_ret, hold_yrs=yrs, ntrade=len(ei), d=d)

def agg(sig_name, syms, cost, f=1.0):
    E=[]; BH=[]; SH=[]; NH=[]; YRS=[]
    for sym in syms:
        df=load(sym); S=build_signals(df)
        if sig_name not in S: continue
        r=equity_cmp(S[sig_name],df,cost=cost)
        if r is None: continue
        E.append(r['ret'].mean()); BH.append(r['bh'].mean())
        SH.append(r['ret'].std(ddof=1)); NH.append(r['ntrade']); YRS.append(r['hold_yrs'])
    E=np.array(E); BH=np.array(BH); SH=np.array(SH); NH=np.array(NH); YRS=np.array(YRS)
    # 年化: 固定注 -> 总R * stop * f / 年数
    ann_s = E*NH*STOP*f/YRS
    ann_bh = BH*NH/YRS    # BH在每笔持仓窗口的平均收益*笔数/年数 ≈ 全程持有
    sharpe_s = E/SH*np.sqrt(NH/YRS)
    t = E.mean()/(E.std(ddof=1)/np.sqrt(len(E)))
    return dict(sig=sig_name, nsym=len(E), E=E.mean(), t=t, pos=(E>0).mean(),
                ann_strat=np.median(ann_s), ann_bh=np.median(ann_bh),
                alpha=np.median(ann_s-ann_bh), sharpe=np.median(sharpe_s), ntr=np.median(NH))

TOPS=['xab50_200','xab20_100','mom240','ma200','pos240','mom120','ma100','brk240','mom60']
print('='*92)
print('判决二: 完整 vs 买入持有 对比 (maker 2bp, 固定注 f=1, 止损5%)')
print('='*92)
rows=[agg(s,ALL13,0.0002) for s in TOPS]
d=pd.DataFrame(rows)
print(d[['sig','nsym','E','t','pos','ann_strat','ann_bh','alpha','sharpe','ntr']].to_string(index=False,float_format=lambda x:f'{x:9.4f}'))

print()
print('='*92)
print('判决一: Reality Check — 62信号多重挑选校正 (跨品种符号随机化, 2000次)')
print('='*92)
# 构建 per-symbol E 矩阵
SIGS=[]; MAT=[]
for sym in ALL13:
    df=load(sym); S=build_signals(df)
    o,h,l=df['open'].values,df['high'].values,df['low'].values
    for nm,sg in S.items():
        if nm.startswith('_'): continue
        r=backtest(sg,o,h,l,cost=0.0002)
        if len(r)>=50:
            if nm not in SIGS: SIGS.append(nm); MAT.append({})
            MAT[SIGS.index(nm)][sym]=r.mean()
keep=[i for i,m in enumerate(MAT) if len(m)>=10]
SIGS=[SIGS[i] for i in keep]; MAT=[MAT[i] for i in keep]
syms=[s for s in ALL13 if all(s in m for m in MAT)]
M=np.array([[m[s] for s in syms] for m in MAT])
print(f'信号数={len(SIGS)}, 品种数={len(syms)}')
def tcols(M):
    mu=M.mean(1); sd=M.std(1,ddof=1)
    return mu/(sd/np.sqrt(M.shape[1]))
obs=tcols(M); mx=obs.max(); mi=obs.min()
rng=np.random.default_rng(7)
maxs=[];mins=[]
for _ in range(2000):
    b=rng.choice([-1.0,1.0],size=M.shape[1])
    t=tcols(M*b); maxs.append(t.max()); mins.append(t.min())
maxs=np.array(maxs); mins=np.array(mins)
p_max=(maxs>=mx).mean(); p_min=(mins<=mi).mean()
print(f'实际最强正信号: {SIGS[int(obs.argmax())]}  t={mx:.3f}   RC p={p_max:.4f}')
print(f'实际最强负信号: {SIGS[int(obs.argmin())]}  t={mi:.3f}   RC p={p_min:.4f}')
print(f'零分布 max t 的 95%分位 = {np.quantile(maxs,0.95):.3f}')
print(f'零分布 min t 的  5%分位 = {np.quantile(mins,0.05):.3f}')
