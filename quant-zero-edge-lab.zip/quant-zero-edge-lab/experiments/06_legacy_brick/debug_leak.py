# -*- coding: utf-8 -*-
"""定位异常收益: 随机化/平移信号对照 —— 若打乱后仍赚钱, 则是代码bug而非信号"""
import sys, numpy as np, pandas as pd, warnings
sys.path.insert(0,'/data/workspace/brick')
warnings.filterwarnings('ignore')
from entry_lib import *

def sig_brk20(c):
    s=np.zeros(len(c)); hh=pd.Series(c).rolling(20).max().values; ll=pd.Series(c).rolling(20).min().values
    s[20:]=np.where(c[20:]>hh[:-20],1,np.where(c[20:]<ll[:-20],-1,0)); return np.where(np.isnan(s),0,s)

rng=np.random.default_rng(3)
print('='*96)
print('Debug  同一套引擎, 换不同信号 -> 若"随机信号"也赚钱, 则是引擎bug')
print('='*96)
print(f'{"信号":<22}{"前半bp/bar":>14}{"后半bp/bar":>14}{"判定":>10}')

def run(sigfn, half):
    out=[]
    for sym in ALL13:
        df=load(sym); o=df['open'].values; c=df['close'].values
        n=len(o); cut=n//2
        sig=sigfn(c)
        r=np.zeros(n); r[1:]=o[1:]/o[:-1]-1
        pos=sig[:-1]; ret=r[1:]
        chg=np.zeros(len(pos)); chg[1:]=(np.abs(np.diff(pos))>0).astype(float)
        pnl=pos*ret-chg*2*0.0002
        a,b=(0,cut) if half=='first' else (cut,len(pos))
        out.append(pnl[a:b].mean())
    return np.mean(out)*1e4

def sig_rand(c):
    s=rng.choice([-1,0,1],size=len(c)); return s
def sig_shift(c):     # 真实信号整体后移1根(制造"无效但结构相同")
    s=sig_brk20(c); return np.roll(s,1)
def sig_long(c):      # 始终做多
    return np.ones(len(c))
def sig_zero(c):
    return np.zeros(len(c))

for nm,fn in [('始终做多(基准)',sig_long),('brk20(真实)',sig_brk20),
              ('brk20整体后移1根',sig_shift),('随机信号',sig_rand),('空仓',sig_zero)]:
    f1=run(fn,'first'); f2=run(fn,'second')
    tag='✓合理' if nm.startswith('始终') or nm.startswith('空仓') else ('可疑' if abs(f2)>abs(f1)*0.8 and nm!='brk20(真实)' else '-')
    print(f'{nm:<22}{f1:>14.3f}{f2:>14.3f}{tag:>10}')
