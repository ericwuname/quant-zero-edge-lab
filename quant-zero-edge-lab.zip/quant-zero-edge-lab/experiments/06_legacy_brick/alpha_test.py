"""
关键补充: 策略 vs 买入持有 —— 择时到底有没有增加值?
在【真实成本】下, 检验 alpha = 策略收益 - 买入持有 是否显著 > 0
"""
import numpy as np, pandas as pd
from real_crypto_edge import load, build_signals, strat_returns, FILES

REAL_COST = 10   # 币安现货 taker 0.1% = 10bp 单边

print("="*100)
print(f"★ 真实成本 {REAL_COST}bp 单边下: 择时策略 vs 买入持有 (样本外)")
print("="*100)
print(f"  {'品种':<10}{'最优策略':>12}{'策略bp/日':>12}{'买入持有':>12}"
      f"{'差值(alpha)':>14}{'t值':>9}{'显著?':>9}{'判定':>16}")

for sym, path in FILES.items():
    df = load(path); n=len(df); split=n//2
    sigs = build_signals(df)
    rets = strat_returns(df, sigs, REAL_COST)
    # 样本内选最优
    inm = {k: v[:split].mean() for k,v in rets.items()}
    best = max(inm, key=inm.get)
    # 样本外
    oos_s = rets[best][split:]
    bh = df['ret'].values[split:]          # 买入持有(始终满仓)
    diff = oos_s - bh
    t = diff.mean()/(diff.std()/np.sqrt(len(diff))) if diff.std()>0 else 0
    sig = "显著" if t>1.96 else "不显著"
    verdict = "择时有增加值" if t>1.96 else "择时无增加值"
    print(f"  {sym:<10}{best:>12}{oos_s.mean()*1e4:>12.2f}{bh.mean()*1e4:>12.2f}"
          f"{diff.mean()*1e4:>14.2f}{t:>9.2f}{sig:>9}{verdict:>16}")

print("\n" + "="*100)
print("★ 成本临界点: 策略在多少成本下, 收益降到与买入持有持平?")
print("="*100)
print(f"  {'品种':<10}{'零成本策略':>12}{'买入持有':>12}{'持平成本':>12}{'备注':>26}")
for sym, path in FILES.items():
    df = load(path); n=len(df); split=n//2
    sigs = build_signals(df)
    bh = df['ret'].values[split:].mean()*1e4
    # 扫成本找持平点
    crit=None
    for cb in [0,2,4,6,8,10,12,15,20,25,30]:
        rets = strat_returns(df, sigs, cb)
        inm={k:v[:split].mean() for k,v in rets.items()}
        b=max(inm,key=inm.get)
        o=rets[b][split:].mean()*1e4
        if o < bh:
            crit=cb; break
    r0 = strat_returns(df, sigs, 0)
    inm0={k:v[:split].mean() for k,v in r0.items()}
    b0=max(inm0,key=inm0.get)
    o0=r0[b0][split:].mean()*1e4
    note = f"币安taker=10bp {'→ 已低于' if crit and crit<=10 else '→ 仍高于'}" 
    print(f"  {sym:<10}{o0:>12.2f}{bh:>12.2f}"
          f"{(f'{crit}bp' if crit else '>30bp'):>12}{note:>26}")

print("\n" + "="*100)
print("★ 样本内→样本外 衰减 (过拟合程度)")
print("="*100)
print(f"  {'品种':<10}{'样本内bp/日':>14}{'样本外bp/日':>14}{'衰减':>10}{'保留比例':>12}")
for sym, path in FILES.items():
    df = load(path); n=len(df); split=n//2
    sigs = build_signals(df)
    r0 = strat_returns(df, sigs, 0)
    inm={k:v[:split].mean()*1e4 for k,v in r0.items()}
    b=max(inm,key=inm.get)
    o=r0[b][split:].mean()*1e4
    keep = o/inm[b]*100 if inm[b]!=0 else 0
    print(f"  {sym:<10}{inm[b]:>14.2f}{o:>14.2f}{(inm[b]-o):>10.2f}{keep:>11.1f}%")
