"""
矛盾论主实验
================================
四组实验:
  A. 铁律检验: 随机游走(矛盾未分化)里, 扣成本后所有策略必须 <= 本金
  B. 四市场对比: 矛盾论(双向) vs 只抓延续 vs 只抓反转 vs 纯策略
  C. 度的扫描: z_crit 过小/过大都会失败 —— 过犹不及(量变到质变有临界)
  D. 矛盾转化: 时变市场里, 能否跟上主要矛盾的切换
"""
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from zoo_tick import (brick_events, cont_returns, run_single, sig_const,
                      sig_rev, sig_stat_mom, INIT_CAP, PRICE0,
                      TICKS_PER_HOUR, HOURS_PER_YEAR)
from contradiction import gen_mkt, run_contra, run_half

plt.rcParams['font.sans-serif'] = ['WenQuanYi Micro Hei', 'DejaVu Sans']
plt.rcParams['axes.unicode_minus'] = False

N = 120000
ANN = 0.20
SIG = ANN / np.sqrt(TICKS_PER_HOUR * HOURS_PER_YEAR)
NPATH = 12
A_MULT = 5
A = A_MULT * SIG
YEARS = N / (TICKS_PER_HOUR * HOURS_PER_YEAR)

MK = ['rw', 'weakmom', 'oscill', 'regime']
MK_NAME = {'rw': '随机游走\n(矛盾未分化)', 'weakmom': '弱动量\n(矛盾=趋势)',
           'oscill': '震荡\n(矛盾=反转)', 'regime': '体制切换\n(矛盾会转化)'}

print("=" * 100)
print(f"矛盾论实验: {YEARS:.1f}年tick  A={A_MULT}σ={A*1e4:.0f}bp  本金{INIT_CAP:.0f}  "
      f"每笔风险1%  {NPATH}路径")
print("=" * 100)


def evaluate(mk, seed):
    px = gen_mkt(mk, N, SIG, seed)
    e = brick_events(px, A)
    if e is None:
        return None
    b, lp = e
    if len(b) < 400:
        return None
    cr = cont_returns(b, lp)
    o = {
        '纯延续(无脑)': run_single(cr, sig_const, A, b=b),
        '纯反转(无脑)': run_single(cr, sig_rev, A, b=b),
        '只抓延续': run_half(cr, A, 'mom'),
        '只抓反转': run_half(cr, A, 'rev'),
        '统计只多': run_single(cr, sig_stat_mom, A, b=b),
        '矛盾论(双向)': run_contra(cr, A),
    }
    o['_n'] = len(cr)
    o['_cr'] = cr
    return o


NAMES = ['纯延续(无脑)', '纯反转(无脑)', '只抓延续', '只抓反转', '统计只多', '矛盾论(双向)']

# ============================================================
# A. 铁律检验
# ============================================================
print("\n### A. 铁律检验: 随机游走(矛盾未分化) —— 所有策略扣成本后必须 <= 10000")
print(f"  {'策略':<16}{'中位':>10}{'均值':>10}{'最大':>10}  判定")
iron_ok = True
for name in NAMES:
    fs = []
    for s in range(NPATH):
        o = evaluate('rw', 3000 + s)
        if o:
            fs.append(o[name]['final'])
    f = np.array(fs)
    ok = f.max() <= INIT_CAP * 1.03
    if not ok:
        iron_ok = False
    print(f"  {name:<16}{np.median(f):>10.0f}{f.mean():>10.0f}{f.max():>10.0f}  "
          f"{'OK' if ok else '!!!违反'}")

print(f"\n  => 铁律{'通过, 引擎可信' if iron_ok else '未通过'}")

# ============================================================
# B. 四市场对比
# ============================================================
print("\n" + "=" * 100)
print("### B. 四市场 × 六策略 —— 中位终值 (本金 10000)")
print("=" * 100)
res = {}
for mk in MK:
    res[mk] = {}
    for name in NAMES:
        fs, dds = [], []
        for s in range(NPATH):
            o = evaluate(mk, 5000 + s)
            if o:
                fs.append(o[name]['final'])
                dds.append(o[name]['maxdd'])
        res[mk][name] = dict(f=np.array(fs), med=float(np.median(fs)),
                             dd=float(np.median(dds)))

print(f"\n  {'策略':<16}" + "".join(f"{MK_NAME[m].split(chr(10))[0]:>12}" for m in MK)
      + f"{'最差':>10}{'回撤':>8}")
for name in NAMES:
    meds = [res[mk][name]['med'] for mk in MK]
    dd = np.mean([res[mk][name]['dd'] for mk in MK])
    print(f"  {name:<16}" + "".join(f"{v:>12.0f}" for v in meds) +
          f"{min(meds):>10.0f}{dd*100:>7.1f}%")

print("\n  >>> 关键观察:")
print("      纯延续 在弱动量市场赚, 在震荡市场崩 —— 只看到矛盾的一个方面")
print("      矛盾论 双向自适应, 看能否在两个市场都站住")

print("\n" + "-" * 100)
print("稳健性排名 (按【最差市场】—— 你事前不知道在哪个市场)")
print("-" * 100)
rank = sorted(NAMES, key=lambda n: -min(res[mk][n]['med'] for mk in MK))
print(f"  {'排名':<5}{'策略':<16}{'最差中位':>10}{'收益':>10}{'平均回撤':>10}{'评价':>10}")
for i, n in enumerate(rank, 1):
    meds = [res[mk][n]['med'] for mk in MK]
    dd = np.mean([res[mk][n]['dd'] for mk in MK])
    worst = min(meds)
    ev = "打平" if worst > 9500 else ("小亏" if worst > 8000 else "亏")
    print(f"  {i:<5}{n:<16}{worst:>10.0f}{(worst/INIT_CAP-1)*100:>+9.1f}%"
          f"{dd*100:>9.1f}%{ev:>10}")

# 矛盾论的方向分布(证明它真的在抓两个矛盾)
print("\n" + "-" * 100)
print("矛盾论策略: 它真的在抓'两个方向'的矛盾吗? (下注方向分布)")
print("-" * 100)
print(f"  {'市场':<14}{'总下注':>9}{'赌延续':>9}{'赌反转':>9}{'占比':>12}")
for mk in MK:
    o = evaluate(mk, 5000)
    if o:
        r = o['矛盾论(双向)']
        tot = r['n_mom'] + r['n_rev']
        ratio = r['n_mom'] / tot * 100 if tot > 0 else 0
        print(f"  {MK_NAME[mk].split(chr(10))[0]:<14}{tot:>9}{r['n_mom']:>9}"
              f"{r['n_rev']:>9}{ratio:>10.0f}%延续")

# ============================================================
# C. 度的扫描
# ============================================================
print("\n" + "=" * 100)
print("### C. 度的扫描: z_crit (出手门槛) —— 过犹不及?")
print("=" * 100)
print(f"  {'z_crit':>8}{'弱动量':>11}{'震荡':>11}{'体制切换':>11}{'随机游走':>11}"
      f"{'最差':>10}{'下注率':>9}")

zs_grid = [0.5, 1.0, 1.645, 2.0, 2.5, 3.0, 4.0]
deg_rows = []
for zc in zs_grid:
    meds = {}
    bets = []
    for mk in MK:
        fs = []
        for s in range(NPATH):
            px = gen_mkt(mk, N, SIG, 5000 + s)
            e = brick_events(px, A)
            if e is None:
                continue
            b, lp = e
            if len(b) < 400:
                continue
            cr = cont_returns(b, lp)
            r = run_contra(cr, A, z_crit=zc)
            fs.append(r['final'])
            bets.append(r['n_bet'] / len(cr))
        meds[mk] = np.median(fs) if fs else np.nan
    worst = min([v for v in meds.values() if not np.isnan(v)])
    deg_rows.append((zc, meds, worst, np.mean(bets)))
    print(f"  {zc:>8.2f}{meds['weakmom']:>11.0f}{meds['oscill']:>11.0f}"
          f"{meds['regime']:>11.0f}{meds['rw']:>11.0f}{worst:>10.0f}"
          f"{np.mean(bets)*100:>8.0f}%")

best_z = max(deg_rows, key=lambda r: r[2])
print(f"\n  >>> 最优'度': z_crit ≈ {best_z[0]:.2f} (最差市场表现最好 {best_z[2]:.0f})")
print(f"  >>> z太小(0.5): 频繁误判, 成本吃光 -> 过")
print(f"  >>> z太大(4.0): 几乎不出手, 错过矛盾 -> 不及")
print(f"  >>> 中间存在最优区间 = '适度'")

# ============================================================
# D. 矛盾转化: 时变市场
# ============================================================
print("\n" + "=" * 100)
print("### D. 矛盾转化: 市场前半=趋势, 后半=震荡 —— 能否跟上切换?")
print("=" * 100)


def gen_switch(n, sigma, seed):
    rng = np.random.default_rng(seed)
    # 前半: 弱动量(趋势是主要矛盾)
    d = np.zeros(n // 2)
    r1 = np.zeros(n // 2)
    for t in range(1, n // 2):
        d[t] = 0.98 * d[t - 1] + rng.normal(0, sigma * 0.020)
        r1[t] = d[t] + rng.normal(0, sigma)
    # 后半: 震荡(反转是主要矛盾)
    n2 = n - n // 2
    phi = -0.08
    e = rng.normal(0, sigma * np.sqrt(1 - phi ** 2), n2)
    r2 = np.zeros(n2)
    for t in range(1, n2):
        r2[t] = phi * r2[t - 1] + e[t]
    return PRICE0 * np.exp(np.cumsum(np.concatenate([r1, r2])))


NB = 20
switch_ratio = []
for s in range(NB):
    px = gen_switch(N, SIG, 6000 + s)
    e = brick_events(px, A)
    if e is None:
        continue
    b, lp = e
    if len(b) < 400:
        continue
    cr = cont_returns(b, lp)
    r = run_contra(cr, A)
    tot = r['n_mom'] + r['n_rev']
    # 看方向随时间的变化
    switch_ratio.append(r)

print(f"  时变市场(前趋势/后震荡), {len(switch_ratio)}条路径")
print(f"  {'路径':<6}{'终值':>10}{'赌延续':>9}{'赌反转':>9}{'延续占比':>10}")
for i, r in enumerate(switch_ratio[:8]):
    tot = r['n_mom'] + r['n_rev']
    ratio = r['n_mom'] / tot * 100 if tot > 0 else 0
    print(f"  {i+1:<6}{r['final']:>10.0f}{r['n_mom']:>9}{r['n_rev']:>9}{ratio:>9.0f}%")

if switch_ratio:
    fs = [r['final'] for r in switch_ratio]
    moms = [r['n_mom'] for r in switch_ratio]
    revs = [r['n_rev'] for r in switch_ratio]
    print(f"\n  中位终值: {np.median(fs):.0f}")
    print(f"  平均赌延续 {np.mean(moms):.0f} 次, 赌反转 {np.mean(revs):.0f} 次")
    print(f"  -> 两个方向都用了 = 矛盾论在跟随主要矛盾的转化")

# ============================================================
# 图
# ============================================================
fig = plt.figure(figsize=(18, 11))
gs = fig.add_gridspec(2, 2, hspace=0.34, wspace=0.2)
fig.suptitle("矛盾论实验：抓主要矛盾 → 看矛盾转化 → 守“度”", fontsize=15, fontweight='bold')

ax = fig.add_subplot(gs[0, :])
x = np.arange(len(NAMES))
w = 0.19
cols = ['salmon', 'steelblue', 'orange', 'green']
for i, mk in enumerate(MK):
    ax.bar(x + i * w - 0.285, [res[mk][n]['med'] for n in NAMES], w,
           label=MK_NAME[mk].replace("\n", ""), color=cols[i], alpha=.85)
ax.axhline(INIT_CAP, color='k', ls='--', lw=2, label='本金10000')
ax.set_xticks(x)
ax.set_xticklabels(NAMES, fontsize=10)
ax.set_ylabel("中位终值 (元)")
ax.set_title("① 各策略 × 各市场：只抓一个矛盾方向的策略，换个市场就崩\n"
             "（矛盾论双向自适应，看能否在所有市场都站住）", fontsize=11.5)
ax.legend(fontsize=9.5)
ax.grid(alpha=.3, axis='y')

ax = fig.add_subplot(gs[1, 0])
xs = np.arange(len(rank))
worst = [min(res[mk][n]['med'] for mk in MK) for n in rank]
ax.bar(xs, worst, color=['green' if v > 9500 else 'salmon' for v in worst])
ax.axhline(INIT_CAP, color='k', ls='--', lw=1.8)
ax.set_xticks(xs)
ax.set_xticklabels(rank, fontsize=9, rotation=22)
ax.set_ylabel("最差市场终值 (元)")
ax.set_title("② 稳健性排名：看最差市场（你不知自己在哪）", fontsize=11)
ax.grid(alpha=.3, axis='y')
for i, v in enumerate(worst):
    ax.text(i, v * 1.03, f"{v:.0f}", ha='center', fontsize=9)

ax = fig.add_subplot(gs[1, 1])
zc = [r[0] for r in deg_rows]
ax.plot(zc, [r[1]['weakmom'] for r in deg_rows], 'o-', label='弱动量(趋势)', lw=2.2)
ax.plot(zc, [r[1]['oscill'] for r in deg_rows], 's-', label='震荡(反转)', lw=2.2)
ax.plot(zc, [r[2] for r in deg_rows], '^-', color='red', lw=2.6, label='最差市场')
ax.axhline(INIT_CAP, color='k', ls='--', lw=1.5, label='本金')
ax.axvline(best_z[0], color='green', ls=':', lw=2, label=f'最优度 z={best_z[0]:.2f}')
ax.set_xlabel("度: z_crit (出手门槛)")
ax.set_ylabel("终值 (元)")
ax.set_title("③ 度的扫描：过犹不及\nz太小=频繁误判 / z太大=错过矛盾", fontsize=11)
ax.legend(fontsize=8.5)
ax.grid(alpha=.3)

plt.savefig("/data/workspace/brick/fig_contradiction.png", dpi=130)
print("\n[已保存] fig_contradiction.png")
