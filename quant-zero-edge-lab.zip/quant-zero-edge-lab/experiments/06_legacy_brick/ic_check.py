"""
【决定性】绕开所有持仓结构, 直接测信号预测力 (IC)
若 IC≈0 => 之前所有"信号"测试都是在噪声上做文章
同时重验两个关键动量结论
"""
import numpy as np, pandas as pd
from scipy import stats

FILES={'DOGE':'/data/inputs/DOGEUSDT_1h.csv','DOT':'/data/inputs/DOTUSDT_1h.csv',
       'CRV':'/data/inputs/CRVUSDT_1h.csv','DASH':'/data/inputs/DASHUSDT_1h.csv',
       'ETH':'/data/inputs/ETHUSDT_1h.csv','FIL':'/data/inputs/FILUSDT_1h.csv',
       'HBAR':'/data/inputs/HBARUSDT_1h.csv'}

def load():
    o={}
    for k,p in FILES.items():
        d=pd.read_csv(p);c={x.lower():x for x in d.columns}
        o[k]=dict(open=d[c['open']].values.astype(float),high=d[c['high']].values.astype(float),
                  low=d[c['low']].values.astype(float),close=d[c['close']].values.astype(float))
    return o

data=load()

print("="*100)
print("【决定性检验 A】信号的信息系数 IC = corr(signal[t], 未来h根bar收益)")
print("="*100)
print("  若 IC≈0 且 t<1.96 => 信号无预测力, 与持仓结构无关")
print(f"\n  {'品种':<7}", end="")
for h in [1,5,10,20,60]: print(f"{'h='+str(h):>10}", end="")
print()
print("  "+"-"*60)
all_ic={h:[] for h in [1,5,10,20,60]}
for k,D in data.items():
    cl=D['close'];n=len(cl)
    sig_now=cl[5:]/np.maximum(cl[:-5],1e-9)-1   # 过去5bar收益(连续值, 非sign)
    print(f"  {k:<7}", end="")
    for h in [1,5,10,20,60]:
        fut=np.full(n,np.nan)
        fut[:n-h]=cl[h:]/np.maximum(cl[:n-h],1e-9)-1
        s_=sig_now[:n-h]; f_=fut[:n-h]
        m=~(np.isnan(s_)|np.isnan(f_)|(s_==0))
        if m.sum()<1000: print(f"{'NA':>10}",end="");continue
        ic=np.corrcoef(s_[m],f_[m])[0,1]
        all_ic[h].append(ic)
        print(f"{ic:>+10.4f}", end="")
    print()
print(f"\n  {'均值':<7}",end="")
for h in [1,5,10,20,60]:
    if all_ic[h]: print(f"{np.mean(all_ic[h]):>+10.4f}",end="")
print()
print(f"\n  -> 若|均值|<0.01 且各品种符号不一致 => 无预测力")

print("\n"+"="*100)
print("【重验 B】'R越大E越好' —— 随机入场+固定R, 测触及概率 vs 随机理论")
print("="*100)
print("  旧结论: R=5时实测胜率22.9% vs 理论16.7% (超出6pp, 称'真实动量')")
print("  新检验: 用'随机方向'基线对比, 排除漂移(牛市)造成的假象")

def touch_test(D,R,s=0.05,max_hold=800,n_trial=None,seed=0):
    """随机入场(随机方向), 测先触及+Rs还是-s"""
    op,hi,lo,cl=D['open'],D['high'],D['low'],D['close']
    n=len(cl); rng=np.random.default_rng(seed)
    res=[]
    idx=np.arange(120,n-2)
    if n_trial and n_trial<len(idx): idx=rng.choice(idx,n_trial,replace=False)
    for i in idx:
        d=rng.choice([-1,1]); e=op[i+1]; out=None
        for jj in range(i+1,min(i+max_hold,n)):
            adv=(lo[jj]/e-1) if d==1 else (1-hi[jj]/e)
            fav=(hi[jj]/e-1) if d==1 else (1-lo[jj]/e)
            if adv<=-s: out=-1.0;break
            if fav>=R*s: out=R;break
        if out is None: out=0.0
        res.append(out)
    return np.array(res)

for R in [1,2,3,5]:
    print(f"\n  R=1:{R}")
    print(f"  {'品种':<7}{'实测胜率':>10}{'理论1/(1+R)':>13}{'差值':>10}{'t':>8}")
    for k,D in data.items():
        r=touch_test(D,R,n_trial=3000,seed=1)
        w=(r>0).mean(); th=1/(1+R)
        se=np.sqrt(w*(1-w)/len(r)); t=(w-th)/se if se>0 else 0
        print(f"  {k:<7}{w*100:>9.1f}%{th*100:>12.1f}%{(w-th)*100:>+9.1f}pp{t:>+8.2f}")

print("\n"+"="*100)
