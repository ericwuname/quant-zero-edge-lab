# -*- coding: utf-8 -*-
"""决定性检验: beta中性 / vs买入持有 / 成本敏感性 / 分年度 / 离群稳健性"""
import sys, numpy as np, pandas as pd, warnings
sys.path.insert(0,'/data/workspace/brick')
warnings.filterwarnings('ignore')
from entry_lib import *
from scipy import stats

def backtest_full(sig, df, stop=STOP, cost=0.0002):
    o,h,l,c = (df[k].values for k in ['open','high','low','close'])
    n=len(o); s=np.asarray(sig,float)
    nz=np.where(s!=0)[0]
    if len(nz)<100: return None
    s=s.copy(); s[:nz[0]]=0
    eff=np.where(s==0,0,s); prev=np.roll(eff,1); prev[0]=0
    chg=(eff!=prev)&(eff!=0); starts=np.where(chg)[0]
    starts=starts[starts+1<n]
    if len(starts)<5: return None
    ei=starts+1; xi=np.roll(ei,-1); xi[-1]=n-1
    v=xi>ei; ei,xi=ei[v],xi[v]
    if len(ei)<5: return None
    d=eff[starts][v]; ep=o[ei]; xp=o[xi]
    raw=(xp-ep)/ep*d
    cnt=xi-ei; bseg=np.repeat(np.arange(len(ei)),cnt)
    st=ei[0]; idx=np.arange(st,st+cnt.sum())
    lmin=np.full(len(ei),np.inf); np.minimum.at(lmin,bseg,l[idx])
    hmax=np.full(len(ei),-np.inf); np.maximum.at(hmax,bseg,h[idx])
    sp=np.where(d>0,ep*(1-stop),ep*(1+stop))
    hs=np.where(d>0,lmin<=sp,hmax>=sp)
    ret=np.where(hs,-stop,raw)-2*cost
    # 同期买入持有收益(同一持仓窗口, 纯多头)
    bh=(xp-ep)/ep
    return dict(ret=ret/stop, d=d, ei=ei, xi=xi, bh=bh, n=len(ei))

TOPS = ['xab20_100','xab50_200','mom240','ma200','pos240','brk240','mom120','ma100']

def analyze(sig_name, syms, cost=0.0002):
    per_sym=[]; longs=[]; shorts=[]; bh_all=[]; stra_all=[]; yrs={}
    for sym in syms:
        df=load(sym); S=build_signals(df)
        if sig_name not in S: continue
        r=backtest_full(S[sig_name], df, cost=cost)
        if r is None: continue
        m=r['d']>0; 
        if m.sum()>20: longs.append(r['ret'][m].mean())
        if (~m).sum()>20: shorts.append(r['ret'][~m].mean())
        per_sym.append(r['ret'].mean())
        bh_all.append(r['bh'].mean()*(r['xi']-r['ei']).mean())   # 近似
        stra_all.append(r['ret'].mean()*STOP)
        # 分年度
        yr=pd.to_datetime(df['timestamp'].values,unit='ms').year
        y0=yr[r['ei']]
        for y in np.unique(y0):
            sel=y0==y
            if sel.sum()>=15: yrs.setdefault(y,[]).append(r['ret'][sel].mean())
    per=np.array(per_sym)
    t=per.mean()/(per.std(ddof=1)/np.sqrt(len(per))) if len(per)>1 else np.nan
    L=np.array(longs); Sh=np.array(shorts)
    dl = L.mean()-Sh.mean() if len(L)>1 and len(Sh)>1 else np.nan
    # 配对多空差
    tl = np.nan
    if len(L)>1 and len(Sh)>1 and len(L)==len(Sh):
        dd=L-Sh; tl=dd.mean()/(dd.std(ddof=1)/np.sqrt(len(dd)))
    return dict(sig=sig_name, nsym=len(per), E=per.mean(), t=t, pos=(per>0).mean(),
                longE=L.mean() if len(L) else np.nan, shortE=Sh.mean() if len(Sh) else np.nan,
                longshort=dl, t_ls=tl,
                years={y:np.mean(v) for y,v in sorted(yrs.items())})

print('='*84)
print('决定性检验 (maker 2bp): 13品种')
print('='*84)
rows=[analyze(s, ALL13) for s in TOPS]
d=pd.DataFrame(rows)
print(d[['sig','nsym','E','t','pos','longE','shortE','longshort','t_ls']].to_string(index=False, float_format=lambda x:f'{x:8.4f}'))

print()
print('='*84)
print('成本敏感性: taker 10bp (现实市价单)')
print('='*84)
rows2=[analyze(s, ALL13, cost=0.0010) for s in TOPS]
d2=pd.DataFrame(rows2)
print(d2[['sig','nsym','E','t','pos','longE','shortE','longshort','t_ls']].to_string(index=False, float_format=lambda x:f'{x:8.4f}'))

print()
print('='*84)
print('分年度 E (maker): 检验时间稳定性')
print('='*84)
for r in rows:
    ys=r['years']; print(f"{r['sig']:>12}: " + '  '.join(f'{y}:{v:+.4f}' for y,v in ys.items()))
