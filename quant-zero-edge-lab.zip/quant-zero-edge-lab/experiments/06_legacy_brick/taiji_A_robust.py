"""
太极 A 的显著动量效应 —— 是真结构, 还是少数极端日拉动?
============================================================
v2 发现: 极阳桶(超涨)未来10日收益 483.3bp vs 极阴桶 54.2bp
         bootstrap p = 0.000 (显著)

但前面反复教训: 收益高度集中在少数天(+646% vs -655% 抵消)
  -> 483bp 的均值可能被【少数几天】拉动
  -> 若中位数很低, 则"大多数时候不涨, 偶尔暴涨"
  -> 这种结构在实践中极难捕捉(必须在那几天在场)

本检验:
  1. 极阳桶收益的【分布形状】 (中位数/分位数/偏度)
  2. 扣成本后的【净收益】与【典型路径】
  3. 与"始终在场"对比 (匹配暴露)
  4. 样本外稳定性
"""
import numpy as np
import pandas as pd
from scipy import stats

DAILY = {'BTC': '/data/inputs/BTCUSDT_1d.csv',
         'BNB': '/data/inputs/BNBUSDT_1d.csv',
         'BCH': '/data/inputs/BCHUSDT_1d.csv'}
HOURLY = {'DOGE': '/data/inputs/DOGEUSDT_1h.csv',
          'DOT':  '/data/inputs/DOTUSDT_1h.csv',
          'CRV':  '/data/inputs/CRVUSDT_1h.csv',
          'DASH': '/data/inputs/DASHUSDT_1h.csv'}
DAYS_YR = 365
COST_BP = 20


def load():
    px = {}
    for k, p in DAILY.items():
        d = pd.read_csv(p)
        s = pd.Series(d['close'].values,
                      index=pd.to_datetime(d['timestamp'], unit='ms').dt.normalize())
        px[k] = s[~s.index.duplicated()]
    for k, p in HOURLY.items():
        d = pd.read_csv(p)
        s = pd.Series(d['close'].values,
                      index=pd.to_datetime(d['timestamp'], unit='ms'))
        px[k] = s.resample('1D').last().dropna()
    return pd.DataFrame(px).dropna()


def logret(r):
    return np.log1p(np.clip(r, -0.99, None))


def metrics(net):
    n = len(net)
    mu, sd = net.mean(), net.std()
    if sd < 1e-12 or n < 10:
        return 0.0, 0.0, 0.0
    nav = np.cumprod(1.0 + np.clip(net, -0.99, None))
    ann = float(np.clip((nav[-1] ** (DAYS_YR / n) - 1) * 100 if nav[-1] > 0 else -100.0, -100, 1e6))
    sh = mu / sd * np.sqrt(DAYS_YR)
    pk = np.maximum.accumulate(nav)
    dd = (nav - pk) / np.maximum(pk, 1e-12)
    return ann, sh, float(-dd.min() * 100)


print("=" * 100)
print("太极 A 的显著动量效应: 真结构 还是 少数极端日拉动?")
print("=" * 100)

df = load()
port = df.pct_change().fillna(0).mean(axis=1)
r = port.values
lr = logret(r)
T = len(r)
N, H = 20, 10

# 重构 z 信号
cum = pd.Series(lr).rolling(N).sum().values
vol = pd.Series(r).rolling(60).std().values
z = np.where(vol * np.sqrt(N) > 1e-12, cum / (vol * np.sqrt(N)), 0.0)
z = np.where(np.isnan(z), 0.0, z)

fwd = np.full(T, np.nan)
for t in range(T - H):
    fwd[t] = lr[t + 1:t + 1 + H].sum()

ok = ~np.isnan(fwd) & (np.abs(z) > 0)
zz, ff = z[ok], fwd[ok]
hi_thr = np.percentile(zz, 80)
extreme_up = zz > hi_thr
fu = ff[extreme_up]

print(f"\n【1】极阳桶(超涨, z>{hi_thr:.2f}) 未来{H}日收益分布:")
print(f"  样本数        : {len(fu)}")
print(f"  均值          : {fu.mean()*1e4:>8.1f} bp")
print(f"  【中位数】    : {np.median(fu)*1e4:>8.1f} bp   <- 关键!")
print(f"  25%分位       : {np.percentile(fu,25)*1e4:>8.1f} bp")
print(f"  75%分位       : {np.percentile(fu,75)*1e4:>8.1f} bp")
print(f"  标准差        : {fu.std()*1e4:>8.1f} bp")
print(f"  偏度          : {stats.skew(fu):>8.2f}  (>1 表示强烈右偏)")
print(f"  最大值        : {fu.max()*1e4:>8.1f} bp")
print(f"  最小值        : {fu.min()*1e4:>8.1f} bp")
print(f"  正收益占比    : {(fu>0).mean()*100:>7.1f}%")

# 少数天贡献分析
srt = np.sort(fu)[::-1]
tot = fu.sum()
for k in [1, 3, 5, 10]:
    if len(srt) >= k:
        print(f"  最好{k:>2}天贡献    : {srt[:k].sum()/tot*100:>7.1f}%")

print(f"\n  对照: 全样本中位数 {np.median(ff)*1e4:.1f}bp, 正收益占比 {(ff>0).mean()*100:.1f}%")

# ---------- 2. 可交易性 ----------
print("\n" + "=" * 100)
print("【2】可交易性: 极阳时买入, 扣成本后如何?")
print("=" * 100)

# 策略: z > 阈值时持仓H天 (不重叠持仓简化)
sig = np.zeros(T)
sig[z > hi_thr] = 1.0

# 持仓H天 (简化: 信号触发后持有H天)
pos = np.zeros(T)
i = 0
while i < T:
    if sig[i] == 1.0:
        pos[i:min(i + H, T)] = 1.0
        i += H
    else:
        i += 1

pnl = np.zeros(T)
for t in range(T):
    if pos[t] > 0:
        pnl[t] = r[t] if t < T else 0
# 成本: 每次建仓/平仓
turn = np.abs(np.diff(np.concatenate([[0], pos])))
pnl = pnl - turn * (2 * COST_BP / 1e4)

# 始终在场
always = r.copy()

sp = T // 2
a1, s1, d1 = metrics(pnl[sp:])
a2, s2, d2 = metrics(always[sp:])
print(f"\n  样本外 [{sp}, {T}):")
print(f"  {'策略':<20}{'年化':>10}{'夏普':>9}{'回撤':>9}{'在场时间':>10}")
print(f"  {'极阳买入(扣成本)':<20}{a1:>9.2f}%{s1:>9.3f}{d1:>8.2f}%{pos[sp:].mean()*100:>9.1f}%")
print(f"  {'始终在场':<20}{a2:>9.2f}%{s2:>9.3f}{d2:>8.2f}%{100.0:>9.1f}%")

# 匹配暴露对照
avg_pos = pos[sp:].mean()
matched = always * avg_pos
a3, s3, d3 = metrics(matched[sp:])
print(f"  {'同等仓位固定持有':<20}{a3:>9.2f}%{s3:>9.3f}{d3:>8.2f}%{avg_pos*100:>9.1f}%")

print(f"\n  判定: 极阳买入 vs 同等仓位固定持有")
print(f"    年化差: {a1-a3:+.2f}%   夏普差: {s1-s3:+.3f}   回撤差: {d1-d3:+.2f}%")
if s1 > s3:
    print(f"    -> 极阳买入【优于】同等仓位持有")
else:
    print(f"    -> 极阳买入【不如】同等仓位持有 (动量效应被成本/择时损耗吃掉)")

# ---------- 3. 样本外稳定性 ----------
print("\n" + "=" * 100)
print("【3】样本外稳定性: 分年度看极阳桶收益")
print("=" * 100)
df_idx = df.index[ok]
years = pd.Series(df_idx).dt.year.values
print(f"\n  {'年份':<8}{'极阳桶收益':>13}{'全样本收益':>13}{'差值':>12}{'样本数':>8}")
yrs = sorted(set(years))
pos_years = 0
for y in yrs:
    m_y = years == y
    m_e = m_y & extreme_up
    if m_e.sum() < 5:
        continue
    ve = ff[m_e].mean() * 1e4
    va = ff[m_y].mean() * 1e4
    if ve > va:
        pos_years += 1
    print(f"  {y:<8}{ve:>12.1f}bp{va:>12.1f}bp{ve-va:>+11.1f}bp{m_e.sum():>8}")
print(f"\n  极阳桶优于全样本的年份: {pos_years}/{len([y for y in yrs if (years==y).sum()>0 and ((years==y)&extreme_up).sum()>=5])}")
print("  判读: 若只在一两年有效 -> 是特定行情(牛市)的产物, 不是稳定结构")

print("\n" + "=" * 100)
print("完成")
print("=" * 100)
