"""
实例化交易世界 v5 (最终版) —— 加入GARCH波动率 + 平衡校准
=============================================================
【v4 诊断】
  纯生态: AC(1)=+0.61  (生态选择让趋势者胜出 -> 自发强趋势)
  加均值回归: AC(1)=-0.016 ✓ 但 |r|AC(1)=-0.007 ✗ (无波动聚集)

【v5 修正】
  波动聚集在真实市场来自【波动率持续性】(GARCH), 不是主体行为
  加入 GARCH(1,1) 生成外生波动率 -> 直接产生 |r| 的自相关

【最终设计】
  价格 = 主体行为(方向结构) + GARCH噪声(波动聚集) + 锚定(长期约束)
  参数标定目标:
    |AC(1)| < 0.10   : 无强方向自相关
    峰度 > 3         : 肥尾 (由GARCH自然产生)
    |r| AC(1) > 0.05 : 波动聚集 (由GARCH自然产生)
    无类型垄断       : 容量约束

【这个世界的用途】
  1. 校准检测工具 (植入已知edge, 看能否测出)
  2. 测试策略生态 (谁在什么世界活下来)
"""
import numpy as np
from scipy import stats


class World:
    """最终版市场世界"""

    DEFAULTS = dict(
        p0=100.0, n_agents=300, init_wealth=1.0,
        frac_fund=0.20, frac_trend=0.20, frac_contra=0.20,
        frac_mm=0.15, frac_noise=0.25,
        fund_speed=0.20, fund_value_vol=0.005,
        trend_lbs=(5, 20, 60), trend_scale=0.05,
        contra_lb=10, contra_scale=0.035, contra_thresh=0.015,
        mm_inv_k=0.5,
        noise_vol=1.0,
        beta=0.0008,             # 主体行为对价格的影响
        # --- GARCH(1,1) 波动率 ---
        garch_omega=0.10, garch_alpha=0.08, garch_beta=0.90,
        base_vol=0.010,
        evol_speed=0.05,
        gamma=0.6, crowd_penalty=1.5, anchor=0.002,
    )

    def __init__(self, seed=0, **overrides):
        self.p = dict(self.DEFAULTS)
        self.p.update(overrides)
        self.rng = np.random.default_rng(seed)
        self.value = self.p['p0']

    def setup(self):
        p = self.p; n = p['n_agents']
        nf=int(n*p['frac_fund']); nt=int(n*p['frac_trend'])
        nc=int(n*p['frac_contra']); nm=int(n*p['frac_mm'])
        nn=n-nf-nt-nc-nm
        self.kinds=np.array(['fund']*nf+['trend']*nt+['contra']*nc
                            +['mm']*nm+['noise']*nn)
        self.wealth=np.ones(n)*p['init_wealth']
        self.inventory=np.zeros(n)
        self.var = p['base_vol']**2

    def demand(self, price, hist):
        p=self.p; rng=self.rng; k=self.kinds
        n=len(k); d=np.zeros(n)

        m=k=='fund'
        if m.sum():
            d[m]=np.tanh(((self.value-price)/max(price,1e-9))/p['fund_speed'])

        m=k=='trend'
        if m.sum() and len(hist)>=max(p['trend_lbs']):
            s=np.zeros(m.sum())
            for lb in p['trend_lbs']:
                if len(hist)>=lb:
                    s+=np.tanh((price/max(hist[-lb],1e-9)-1)/p['trend_scale'])
            d[m]=s/len(p['trend_lbs'])

        m=k=='contra'
        if m.sum() and len(hist)>=p['contra_lb']:
            mom=price/max(hist[-p['contra_lb']],1e-9)-1
            if abs(mom)>p['contra_thresh']:
                d[m]=-np.tanh(mom/p['contra_scale'])

        m=k=='mm'
        if m.sum():
            d[m]=-np.tanh(self.inventory[m]*p['mm_inv_k'])

        m=k=='noise'
        if m.sum():
            d[m]=rng.normal(0,p['noise_vol'],m.sum())
        return d

    def run(self, n_steps=12000, trend_strength=0.0,
            mean_revert_strength=0.0, true_drift=0.0,
            record_every=100, evolve=True):
        p=self.p; rng=self.rng
        self.setup()
        k=self.kinds; n=len(k)
        price=p['p0']; hist=[price]; prices=[price]
        prev_d=np.zeros(n); wh=[]; tc=0.0
        om,al,be=p['garch_omega'],p['garch_alpha'],p['garch_beta']
        base2=p['base_vol']**2

        for t in range(n_steps):
            self.value*=(1+rng.normal(0,p['fund_value_vol']))
            tc = 0.98*tc+0.02*rng.normal(0,1) if trend_strength>0 else 0.0

            d=self.demand(price,np.array(hist))

            we=np.power(np.maximum(self.wealth,1e-6),p['gamma'])
            sh={kk: we[k==kk].sum()/max(we.sum(),1e-9)
                for kk in ['fund','trend','contra','mm','noise']}
            cr=np.zeros(n)
            for kk in ['fund','trend','contra','mm']:
                cr[k==kk]=1.0/(1.0+p['crowd_penalty']*max(sh[kk]-0.2,0))
            cr[k=='noise']=1.0
            wf=we*cr
            net_d=(d*wf).sum()/max(wf.sum(),1e-9)

            # --- GARCH 波动率 ---
            self.var = om*base2 + al*(self.var) + be*self.var
            # 用上一期收益更新 (标准GARCH)
            if t>0:
                pr2 = prev_r**2 if 'prev_r' in dir() else base2
                self.var = om*base2 + al*pr2 + be*self.var
            vol=np.sqrt(max(self.var,1e-12))
            shock=rng.normal(0,vol)

            anchor_r=-p['anchor']*np.log(price/max(self.value,1e-9))
            struct=trend_strength*tc
            if mean_revert_strength>0 and len(hist)>=50:
                struct+=mean_revert_strength*(-(price/np.mean(hist[-50:])-1))

            r=p['beta']*net_d*50+true_drift+struct+anchor_r+shock
            price=max(price*(1+r),1e-6)
            prices.append(price); hist.append(price)
            if len(hist)>300: hist.pop(0)
            prev_r=r

            self.inventory=self.inventory*0.95+d*0.1

            if evolve:
                self.wealth=self.wealth+p['evol_speed']*(prev_d*r*n)
                self.wealth=np.maximum(self.wealth,0.2*p['init_wealth'])
                tw=self.wealth.sum()
                if tw>0: self.wealth=self.wealth/tw*(n*p['init_wealth'])
            prev_d=d

            if t%record_every==0:
                wh.append([self.wealth[k==kk].sum()
                           for kk in ['fund','trend','contra','mm','noise']])
        return np.array(prices),np.array(wh),k


def facts(prices):
    r=np.diff(prices)/prices[:-1]; r=r[np.isfinite(r)]
    if len(r)<500: return None
    ar=np.abs(r)
    def ac(x,kk): return np.corrcoef(x[:-kk],x[kk:])[0,1] if len(x)>kk+10 else np.nan
    def vr(kk):
        v1=r.var()
        if v1<=0 or len(r)<kk*20: return np.nan
        return np.array([r[i:i+kk].sum() for i in range(0,len(r)-kk,kk)]).var()/(kk*v1)
    return dict(n=len(r),mean=r.mean()*1e4,vol=r.std()*1e4,
                kurt=stats.kurtosis(r)+3.0,
                ac1=ac(r,1),ac5=ac(r,5),ac20=ac(r,20),
                aac1=ac(ar,1),aac5=ac(ar,5),aac20=ac(ar,20),
                vr5=vr(5),vr20=vr(20))


def check(res, wh):
    ok_ac  = abs(res['ac1'])<0.10
    ok_kurt= res['kurt']>3.0
    ok_vol = res['aac1']>0.05
    mx = max(wh[-1])/sum(wh[-1]) if len(wh)>0 else 0
    ok_mono= mx<0.50
    return ok_ac, ok_kurt, ok_vol, ok_mono, mx


# ================= 标定搜索 =================
if __name__ == "__main__":
    print("="*100)
    print("实例化交易世界 v5 —— GARCH波动率 + 参数标定")
    print("="*100)

    print("\n  标定搜索 (寻找 AC(1)≈0 且 波动聚集 的参数):")
    print(f"  {'mrs':>6}{'beta':>8}{'AC(1)':>9}{'峰度':>8}{'|r|AC(1)':>10}{'方差比5':>9}{'判定':>10}")

    best=None
    for mrs in [0.0, 0.02, 0.05, 0.10]:
        for beta in [0.0005, 0.0008]:
            w=World(seed=42, beta=beta)
            prices,wh,k=w.run(n_steps=10000, mean_revert_strength=mrs)
            res=facts(prices)
            if res is None: continue
            oa,ok,ov,om,mx=check(res,wh)
            good=oa and ok and ov and om
            print(f"  {mrs:>6.2f}{beta:>8.4f}{res['ac1']:>+9.4f}{res['kurt']:>8.2f}"
                  f"{res['aac1']:>+10.4f}{res['vr5']:>9.3f}{'✓合格' if good else '✗':>10}")
            if good and best is None:
                best=(mrs,beta)

    print(f"\n  最佳参数: mrs={best[0] if best else None}, beta={best[1] if best else None}")

    if best:
        mrs,beta=best
        print("\n"+"="*100)
        print(f"  最终世界验证 (mrs={mrs}, beta={beta})")
        print("="*100)
        for label,cfg in [("① 基准(无结构)",dict()),
                          ("② 植入趋势",dict(trend_strength=0.006)),
                          ("③ 植入回归",dict(mean_revert_strength=mrs+0.05))]:
            w=World(seed=42,beta=beta)
            cfg2=dict(cfg); cfg2.setdefault('mean_revert_strength', mrs)
            prices,wh,k=w.run(n_steps=12000, **cfg2)
            res=facts(prices)
            oa,ok,ov,om,mx=check(res,wh)
            print(f"\n  【{label}】")
            print(f"    均值{res['mean']:>7.2f}bp 波动{res['vol']:>7.1f}bp "
                  f"峰度{res['kurt']:>6.2f}{'✓' if ok else '✗'} "
                  f"AC(1){res['ac1']:>+7.4f}{'✓' if oa else '✗'} "
                  f"|r|AC(1){res['aac1']:>+7.4f}{'✓' if ov else '✗'}")
            print(f"    AC(5/20) {res['ac5']:>+7.4f}/{res['ac20']:>+7.4f}   "
                  f"方差比(5/20) {res['vr5']:>6.3f}/{res['vr20']:>6.3f}")
            last=wh[-1]
            print(f"    终局: 基本面{last[0]:.1f} 趋势{last[1]:.1f} 反转{last[2]:.1f} "
                  f"做市{last[3]:.1f} 噪声{last[4]:.1f}  最大{mx*100:.1f}%")

    print("\n"+"="*100)
    print("阶段1完成")
    print("="*100)
