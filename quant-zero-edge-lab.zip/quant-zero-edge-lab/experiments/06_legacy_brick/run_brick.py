"""
实验B (修正版): 砖块策略的正期望到底从哪来
=============================================
公平对照: 所有市场标准化到同一波动率 -> 伪影基线一致, 可比
砖块基于对数价格: 每块砖 = 固定对数幅度, 收益精确 = ±A_log

核心三问:
  Q1. 随机游走里, 砖块策略有正期望吗? (应无 -> 扣成本后必负)
  Q2. 什么市场结构能让它变正? (动量? 反转? regime? 波动聚集?)
  Q3. 扣掉伪影+成本后, 还剩多少? 需要多少砖才验证得了?
"""
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from zoo import gen_market, eval_brick

plt.rcParams['font.sans-serif'] = ['WenQuanYi Micro Hei', 'DejaVu Sans']
plt.rcParams['axes.unicode_minus'] = False

N = 30000
NSEED = 30
MARKETS = ["RW", "MOM", "MR", "REGIME", "VOL", "TRENDVOL", "JUMP"]
MK_LABEL = {
    "RW": "随机游走\n(零结构)", "MOM": "动量\n(正自相关)", "MR": "均值回归\n(负自相关)",
    "REGIME": "体制切换\n(趋势/震荡)", "VOL": "波动聚集\n(无方向)",
    "TRENDVOL": "趋势+波动\n(最像真实)", "JUMP": "跳跃\n(肥尾)",
}
COST = 0.0005          # 每笔往返成本(对数) 0.05%

# 扫描砖块大小: 看伪影 vs 统计 的权衡
print("=" * 96)
print("Step1: 伪影基线 —— 纯随机游走(绝无结构)里, 砖块策略测出的'延续概率'")
print("       理论值应 = 0.500。超出部分 = 采样伪影(虚假趋势)")
print("=" * 96)
print(f"  {'砖块A(对数)':>12} {'σ_bar/A':>9} {'砖数N':>7} {'伪影基线p0':>11} {'伪影(bias)':>11} {'p*(成本)':>9}")

A_LIST = [0.02, 0.05, 0.10, 0.20]
SIGMA = 0.010
bias_map = {}
for A in A_LIST:
    ps, ns = [], []
    for s in range(NSEED):
        px, _ = gen_market("RW", N, seed=5000 + s)
        e = eval_brick(px, A, COST)
        if e:
            ps.append(e["p_cont"]); ns.append(e["n"])
    p0 = np.mean(ps); n = np.mean(ns)
    se = np.std(ps) / np.sqrt(len(ps))
    c = COST / A
    pstar = (1 + c) / 2
    bias_map[A] = (p0, se, c, pstar, n)
    print(f"  {A:>12.3f} {SIGMA/A:>9.2f} {n:>7.0f} {p0:>11.4f} {p0-0.5:>+11.4f} {pstar:>9.4f}")

print("\n  注: 伪影 bias = p0 - 0.5。砖块越小(相对σ), 伪影越强 -> 凭空造出'趋势'")

# 选定砖块: 伪影与统计的折中
A_SEL = 0.05
p0, p0_se, c_sel, pstar, n_sel = bias_map[A_SEL]
print(f"\n  选定砖块 A={A_SEL} (5%): 伪影bias={p0-0.5:+.4f}, 砖数≈{n_sel:.0f}, p*={pstar:.4f}")

print("\n" + "=" * 96)
print("Step2: 各市场里 砖块·延续 策略的真实表现 (已扣伪影 + 已扣成本)")
print("=" * 96)
print(f"  {'市场':<11} {'实测p':>8} {'真p(扣伪影)':>12} {'p*':>7} {'每笔净期望':>11} {'年化':>8} {'判定':>10}")

rows = []
for mk in MARKETS:
    ps, exps, ns = [], [], []
    for s in range(NSEED):
        px, _ = gen_market(mk, N, seed=1000 * (MARKETS.index(mk) + 1) + s)
        e = eval_brick(px, A_SEL, COST)
        if e:
            ps.append(e["p_cont"]); exps.append(e["exp_per"]); ns.append(e["n"])
    p_obs = np.mean(ps)
    p_true = p_obs - (p0 - 0.5)
    net = (2 * p_true - 1) * A_SEL - COST
    ann = net * np.mean(ns) / (N / 252)
    verdict = "正期望" if net > 0 else "负期望"
    rows.append((mk, p_obs, p_true, pstar, net, ann, np.mean(ns)))
    print(f"  {mk:<11} {p_obs:>8.4f} {p_true:>12.4f} {pstar:>7.4f} {net:>+11.6f} {ann*100:>7.2f}% {verdict:>10}")

print("\n" + "=" * 96)
print("Step3: 砖块·反转 (赌折返) —— 与延续严格镜像")
print("=" * 96)
print(f"  {'市场':<11} {'反转胜率':>9} {'真p(扣伪影)':>12} {'每笔净期望':>11} {'判定':>10}")
rev_rows = []
for mk in MARKETS:
    ps, exps = [], []
    for s in range(NSEED):
        px, _ = gen_market(mk, N, seed=1000 * (MARKETS.index(mk) + 1) + s)
        e = eval_brick(px, A_SEL, COST, reverse=True)
        if e:
            ps.append(e["p_cont"]); exps.append(e["exp_per"])
    p_obs = np.mean(ps)
    p_true = p_obs + (p0 - 0.5)          # 反转的伪影是镜像的
    net = (2 * p_true - 1) * A_SEL - COST
    verdict = "正期望" if net > 0 else "负期望"
    rev_rows.append((mk, p_obs, p_true, net))
    print(f"  {mk:<11} {p_obs:>9.4f} {p_true:>12.4f} {net:>+11.6f} {verdict:>10}")

# ============================================================
# 图
# ============================================================
fig = plt.figure(figsize=(17, 9.5))
gs = fig.add_gridspec(2, 2, hspace=0.35, wspace=0.2)
fig.suptitle("砖块策略的正期望从哪来？—— 市场结构 × 策略方向 的匹配（已扣伪影与成本）",
             fontsize=14.5, fontweight='bold')

ax = fig.add_subplot(gs[0, 0])
xs = [str(a) for a in A_LIST]
ax.bar(xs, [bias_map[a][0] - 0.5 for a in A_LIST], color='darkred', alpha=.8)
ax.axhline(0, color='k', lw=1.3)
ax.set_xlabel("砖块大小 A（对数）")
ax.set_ylabel("伪影 bias = p₀ − 0.5")
ax.set_title("① 伪影：随机游走里凭空测出的'趋势'\n砖块越小→伪影越强→回测越骗人")
ax.grid(alpha=.3, axis='y')
for i, a in enumerate(A_LIST):
    ax.text(i, bias_map[a][0] - 0.5 + 0.004, f"{bias_map[a][0]-0.5:+.3f}",
            ha='center', fontsize=9)

ax = fig.add_subplot(gs[0, 1])
mkx = [MK_LABEL[r[0]] for r in rows]
ax.bar(range(len(rows)), [r[4] for r in rows],
       color=['green' if r[4] > 0 else 'salmon' for r in rows])
ax.axhline(0, color='k', lw=1.3)
ax.axhline(0, color='k', lw=1.3)
ax.set_xticks(range(len(rows)))
ax.set_xticklabels(mkx, rotation=25, fontsize=8.5)
ax.set_ylabel("每笔净期望（扣伪影+成本）")
ax.set_title("② 砖块·延续：只在【有真实动量】的市场正期望\n随机游走/反转市里必负")
ax.grid(alpha=.3, axis='y')

ax = fig.add_subplot(gs[1, :])
w = 0.36
x = np.arange(len(rows))
ax.bar(x - w / 2, [r[4] for r in rows], w, label='砖块·延续（赌同向）', color='steelblue')
ax.bar(x + w / 2, [r[3] for r in rev_rows], w, label='砖块·反转（赌折返）', color='darkorange')
ax.axhline(0, color='k', lw=1.3)
ax.set_xticks(x)
ax.set_xticklabels([MK_LABEL[r[0]] for r in rows], rotation=25, fontsize=9)
ax.set_ylabel("每笔净期望（扣伪影+成本）")
ax.set_title("③ 镜像对照：同一市场里两个策略严格相反 —— 证明期望来自【市场结构】，不来自策略本身",
             fontsize=11)
ax.legend(fontsize=10)
ax.grid(alpha=.3, axis='y')

plt.savefig("/data/workspace/brick/fig_brick.png", dpi=130)
print("\n[已保存] fig_brick.png")
