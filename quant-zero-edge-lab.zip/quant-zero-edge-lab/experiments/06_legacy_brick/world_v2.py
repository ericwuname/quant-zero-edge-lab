"""
实例化交易世界 v2 —— 修正版
================================
【v1 的三个致命错误】
  1. AC(1)=-0.75 -> 基本面/做市商过强, 价格被钉死在价值附近, 是"假市场"
  2. 主体演化代码错误: last_d 恒为0 -> pnl恒为0 -> 权重从未演化 (生态是死的)
  3. 植入的 trend_strength 未生效 (被淹没/实现有误)

【v2 修正】
  1. 重新标定: 噪声交易者权重提高, 基本面/做市商减弱 -> 让价格真的能走
  2. 正确实现主体演化: 先记录需求, 用下期收益更新pnl, 再调整权重(财富)
  3. 分离"真实结构"与"主体行为", 确保植入的edge真实进入价格
  4. 用财富而非任意权重做演化 (更真实的生态选择)

【验证标准】必须通过:
  1. |AC(1)| < 0.10   (不能是强反转或强趋势的假市场)
  2. 峰度 > 3          (肥尾)
  3. |r| AC(1) > 0.05 (波动聚集)
  4. 主体权重有演化   (生态是活的)
"""
import numpy as np
import pandas as pd
from scipy import stats


class World:
    def __init__(self, seed=0, params=None):
        if params is None:
            params = self.default_params()
        self.p = params
        self.rng = np.random.default_rng(seed)
        self.n_agents = params['n_agents']
        # 财富 (生态选择的基础)
        self.wealth = np.ones(self.n_agents) * params['init_wealth']
        self.value = params['p0']           # 基本面价值

    @staticmethod
    def default_params():
        return dict(
            p0=100.0,
            n_agents=200,
            init_wealth=1.0,
            # 各类型占比
            frac_fund=0.15,
            frac_trend=0.30,
            frac_contra=0.15,
            frac_mm=0.15,
            frac_noise=0.25,
            # 行为参数
            fund_speed=0.30,       # 基本面: 偏离多快才反应 (大=慢)
            fund_value_vol=0.004,  # 价值本身的波动
            trend_lbs=(5, 20, 60),
            trend_scale=0.08,      # 动量敏感度 (大=迟钝)
            contra_lb=10,
            contra_scale=0.05,
            contra_thresh=0.02,    # 反转者只在偏离够大时出手
            mm_scale=0.03,
            noise_vol=1.0,
            # 价格形成
            beta=0.0006,           # 需求->收益的敏感度 (关键标定)
            shock_vol=0.008,
            # 演化
            evol_speed=0.10,       # 财富再分配速度
            bankrupt_thresh=0.2,   # 破产线(相对初始)
        )

    def agent_types(self):
        p = self.p
        n = p['n_agents']
        nf = int(n * p['frac_fund'])
        nt = int(n * p['frac_trend'])
        nc = int(n * p['frac_contra'])
        nm = int(n * p['frac_mm'])
        nn = n - nf - nt - nc - nm
        kinds = (['fund'] * nf + ['trend'] * nt + ['contra'] * nc
                 + ['mm'] * nm + ['noise'] * nn)
        return np.array(kinds)

    def demand(self, kinds, price, hist, state):
        """每个主体的需求 (向量化)"""
        p = self.p
        rng = self.rng
        n = len(kinds)
        d = np.zeros(n)

        # 基本面者
        m = kinds == 'fund'
        if m.sum():
            dev = (self.value - price) / max(price, 1e-9)
            d[m] = np.tanh(dev / p['fund_speed'])

        # 趋势者
        m = kinds == 'trend'
        if m.sum() and len(hist) >= max(p['trend_lbs']):
            sig = np.zeros(m.sum())
            for lb in p['trend_lbs']:
                if len(hist) >= lb:
                    mom = price / max(hist[-lb], 1e-9) - 1.0
                    sig += np.tanh(mom / p['trend_scale'])
            d[m] = sig / len(p['trend_lbs'])

        # 反转者 (只在偏离够大时出手)
        m = kinds == 'contra'
        if m.sum() and len(hist) >= p['contra_lb']:
            mom = price / max(hist[-p['contra_lb']], 1e-9) - 1.0
            if abs(mom) > p['contra_thresh']:
                d[m] = -np.tanh(mom / p['contra_scale'])

        # 做市商
        m = kinds == 'mm'
        if m.sum() and len(hist) >= 5:
            dev = (hist[-5:].mean() - price) / max(price, 1e-9)
            d[m] = np.tanh(dev / p['mm_scale'])

        # 噪声
        m = kinds == 'noise'
        if m.sum():
            d[m] = rng.normal(0, p['noise_vol'], m.sum())

        return d

    def run(self, n_steps=10000, true_drift=0.0, trend_strength=0.0,
            mean_revert_strength=0.0, record_every=50):
        """
        true_drift          : 外生漂移
        trend_strength      : 植入趋势成分 (可被动量策略利用)
        mean_revert_strength: 植入均值回归 (可被反转策略利用)
        """
        p = self.p
        rng = self.rng
        kinds = self.agent_types()
        n = len(kinds)

        price = p['p0']
        hist = [price]
        prices = [price]
        # 需求记录 (用于下期pnl)
        prev_d = np.zeros(n)
        wealth_hist = []
        trend_comp = 0.0
        mr_comp = 0.0

        for t in range(n_steps):
            # --- 基本面价值随机游走 ---
            self.value *= (1 + rng.normal(0, p['fund_value_vol']))

            # --- 植入的真实结构 ---
            if trend_strength > 0:
                trend_comp = 0.985 * trend_comp + 0.015 * rng.normal(0, 1)
            else:
                trend_comp = 0.0
            if mean_revert_strength > 0:
                mr_comp = -(price / max(np.mean(hist[-50:]), 1e-9) - 1.0)
            else:
                mr_comp = 0.0

            # --- 需求 ---
            d = self.demand(kinds, price, np.array(hist), None)
            # 按财富加权 (有钱的人影响大)
            w = np.maximum(self.wealth, 0.0)
            w = w / w.sum() * n if w.sum() > 0 else np.ones(n)
            net_d = np.sum(d * w) / n

            # --- 价格更新 ---
            shock = rng.normal(0, p['shock_vol'])
            struct = trend_strength * trend_comp + mean_revert_strength * mr_comp
            r = p['beta'] * net_d * 100 + true_drift + struct + shock
            price = price * (1 + r)
            prices.append(price)
            hist.append(price)
            if len(hist) > 300:
                hist.pop(0)

            # --- 主体演化: 用上期需求 * 本期收益 ---
            gains = prev_d * r * n
            self.wealth = self.wealth + p['evol_speed'] * gains
            self.wealth = np.maximum(self.wealth, p['bankrupt_thresh'] * p['init_wealth'])
            # 归一化 (保持总财富恒定, 纯再分配)
            tw = self.wealth.sum()
            if tw > 0:
                self.wealth = self.wealth / tw * (n * p['init_wealth'])

            prev_d = d

            if t % record_every == 0:
                wealth_hist.append([
                    self.wealth[kinds == 'fund'].sum(),
                    self.wealth[kinds == 'trend'].sum(),
                    self.wealth[kinds == 'contra'].sum(),
                    self.wealth[kinds == 'mm'].sum(),
                    self.wealth[kinds == 'noise'].sum(),
                ])

        return np.array(prices), np.array(wealth_hist), kinds


def stylized_facts(prices):
    r = np.diff(prices) / prices[:-1]
    r = r[np.isfinite(r)]
    if len(r) < 500:
        return None
    ar = np.abs(r)

    def ac(x, k):
        return np.corrcoef(x[:-k], x[k:])[0, 1] if len(x) > k + 10 else np.nan

    def var_ratio(k):
        var1 = r.var()
        if var1 <= 0 or len(r) < k * 20:
            return np.nan
        agg = np.array([r[i:i + k].sum() for i in range(0, len(r) - k, k)])
        return agg.var() / (k * var1)

    return dict(
        n=len(r),
        mean=r.mean() * 1e4,
        vol=r.std() * 1e4,
        kurt=stats.kurtosis(r) + 3.0,
        ac1=ac(r, 1), ac5=ac(r, 5), ac20=ac(r, 20),
        aac1=ac(ar, 1), aac5=ac(ar, 5), aac20=ac(ar, 20),
        vr5=var_ratio(5), vr20=var_ratio(20),
    )


def show(res, label, passes):
    ok1 = abs(res['ac1']) < 0.10
    ok2 = res['kurt'] > 3.0
    ok3 = res['aac1'] > 0.05
    print(f"\n  【{label}】")
    print(f"    样本 {res['n']}  均值 {res['mean']:>7.2f}bp  波动 {res['vol']:>7.1f}bp")
    print(f"    峰度(正态=3)   : {res['kurt']:>7.2f}   {'✓肥尾' if ok2 else '✗'}")
    print(f"    收益 AC(1)     : {res['ac1']:>+7.4f}   {'✓无自相关' if ok1 else '✗偏离过大'}")
    print(f"    收益 AC(5/20)  : {res['ac5']:>+7.4f} / {res['ac20']:>+7.4f}")
    print(f"    |r| AC(1)      : {res['aac1']:>+7.4f}   {'✓波动聚集' if ok3 else '✗'}")
    print(f"    |r| AC(5/20)   : {res['aac5']:>+7.4f} / {res['aac20']:>+7.4f}")
    print(f"    方差比(5/20)   : {res['vr5']:>7.3f} / {res['vr20']:>7.3f}")
    passes.append((label, ok1 and ok2 and ok3))


# ============ 主流程 ============
print("=" * 100)
print("实例化交易世界 v2 —— 修正版: 标定 / 演化 / 结构植入")
print("=" * 100)

passes = []
configs = [
    ("① 纯生态 (无外生结构)", dict()),
    ("② 植入趋势成分", dict(trend_strength=0.004)),
    ("③ 植入均值回归", dict(mean_revert_strength=0.02)),
    ("④ 强趋势", dict(trend_strength=0.012)),
]

for label, cfg in configs:
    w = World(seed=42)
    prices, wh, kinds = w.run(n_steps=10000, **cfg)
    res = stylized_facts(prices)
    if res:
        show(res, label, passes)
    # 生态是否活着
    if len(wh) > 10:
        first, last = wh[0], wh[-1]
        change = np.abs(last / (first + 1e-9) - 1).max()
        print(f"    主体财富演化  : {change*100:>7.1f}%  "
              f"{'✓生态活着' if change > 0.05 else '✗生态僵死'}")
        print(f"      终局占比 基本面{last[0]:.2f} 趋势{last[1]:.2f} "
              f"反转{last[2]:.2f} 做市{last[3]:.2f} 噪声{last[4]:.2f}")

print("\n" + "=" * 100)
print("阶段1 结论:")
allpass = all(p for _, p in passes)
for label, p in passes:
    print(f"  {label}: {'✓ 像真实市场' if p else '✗ 不合格'}")
print(f"\n  世界是否可用: {'✓ 可用于校准' if allpass else '✗ 需继续标定'}")
print("=" * 100)
