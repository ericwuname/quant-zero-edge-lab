"""
【新目标函数下的策略设计】
目标: 最大化 P(累计提取 G >= 投入本金 C0)  —— 在爆仓前"赚回本金"
(而非最大化终值期望 / Kelly增长率)

关键设计: 收割制 harvest-and-reset
  单店本金C0, 固定注 bet=f*C0
  当单店浮盈 W-C0 >= T (收割阈值) -> 提取全部浮盈, 净值重置回C0
  当净值 W <= BUST*C0 -> 店爆仓, 公积金>=C0则开新店
时间口径: 墙钟bar, 7币种并行, 每笔消耗 hold/7 bar  (保证跨策略公平)
"""
import numpy as np
D=np.load('seq2.npz')
C0=10000.0; BUST=0.20; NCOIN=7
YEARS=3.0; BUDGET=YEARS*8760.0   # 墙钟bar预算

def simulate(Rarr,Harr,f,T,NSIM,seed,mode='target',period=100,maxshop=8):
    """mode: 'target'=达阈值收割  'periodic'=每period笔结算  'compound'=不提取"""
    rng=np.random.default_rng(seed)
    N=len(Rarr)
    mh=np.median(Harr)
    max_steps=int(BUDGET/(mh/NCOIN)*1.6)+200
    max_steps=min(max_steps,200000)
    W=np.full(NSIM,C0); G=np.zeros(NSIM); tu=np.zeros(NSIM)
    dead=np.zeros(NSIM,bool); shops=np.ones(NSIM)
    reached=np.zeros(NSIM,bool); t_reach=np.full(NSIM,np.nan)
    ntr=np.zeros(NSIM)
    for step in range(max_steps):
        act=(~dead)&(tu<BUDGET)
        if not act.any(): break
        ia=np.where(act)[0]
        idx=rng.integers(0,N,size=len(ia))
        r=Rarr[idx]; h=Harr[idx]/NCOIN
        bet=f*C0
        eff=np.minimum(bet,W[ia])
        W[ia]=W[ia]+eff*r
        tu[ia]+=h; ntr[ia]+=1
        # 爆仓判定
        bd=W[ia]<=BUST*C0
        if bd.any():
            bi=ia[bd]
            G[bi]+=W[bi]
            can=G[bi]>=C0
            re=bi[can]
            G[re]-=C0; W[re]=C0; shops[re]+=1
            fin=bi[~can]
            dead[fin]=True
            ia=ia[~bd]; 
            if len(ia)==0: continue
        # 收割判定
        if mode=='target':
            hv=W[ia]-C0>=T
            if hv.any():
                hi=ia[hv]
                G[hi]+=W[hi]-C0; W[hi]=C0
        elif mode=='periodic':
            pv=(ntr[ia]%period==0)&(W[ia]>C0)
            if pv.any():
                pi=ia[pv]
                G[pi]+=W[pi]-C0; W[pi]=C0
        # 达成判定
        nw=(~reached[ia])&(G[ia]>=C0)
        if nw.any():
            reached[ia[nw]]=True; t_reach[ia[nw]]=tu[ia[nw]]
    G+=W*(~dead)
    return dict(P=reached.mean(), medG=np.median(G), p25=np.percentile(G,25),
                bust=dead.mean(), medT=np.nanmedian(t_reach) if np.isfinite(t_reach).any() else np.nan,
                shops=np.median(shops), trades=np.median(ntr))

NS=600
print("="*100)
print(f"【新目标: P(累计提取>=本金)】本金{C0:.0f} 爆仓线{int(BUST*100)}% 时间预算{YEARS}年({BUDGET:.0f}bar) 7币种并行")
print("="*100)
R=D['brk20_flip_R']; H=D['brk20_flip_H']
mu,sd=R.mean(),R.std()
print(f"\n基准序列 brk20_flip: E[R]={mu:+.4f} sig={sd:.3f} Kelly={mu/sd**2*100:.2f}%")
print(f"\n### 网格扫描 (f=仓位, T=收割阈值占本金比例)  NSIM={NS}")
print(f"  {'f':>5} {'T':>6} | {'P(赚回本金)':>11}{'落袋中位':>10}{'落袋P25':>9}{'爆仓%':>8}{'达成用时(年)':>13}{'交易数':>8}")
print("  "+"-"*78)
grid=[]
for f in [0.005,0.01,0.02,0.03,0.05]:
    for T in [0.05,0.10,0.20,0.50,1.00]:
        r=simulate(R,H,f,T*C0,NS,seed=11)
        grid.append((f,T,r))
        yr=r['medT']/8760 if np.isfinite(r['medT']) else np.nan
        print(f"  {f*100:>4.1f}% {T*100:>5.0f}% | {r['P']*100:>10.1f}%{r['medG']:>10.0f}{r['p25']:>9.0f}"
              f"{r['bust']*100:>7.1f}%{yr:>13.2f}{r['trades']:>8.0f}")
best=max(grid,key=lambda x:x[2]['P'])
print(f"\n  >>> 最优: f={best[0]*100:.1f}%  T={best[1]*100:.0f}%  P={best[2]['P']*100:.1f}%  落袋中位={best[2]['medG']:.0f}")

print(f"\n### 对照: 不提取(纯复利) / 定期结算")
print(f"  {'模式':<28}{'P(赚回本金)':>11}{'落袋中位':>10}{'爆仓%':>8}")
print("  "+"-"*60)
for f in [0.01,0.02,0.03]:
    r1=simulate(R,H,f,0.2*C0,NS,seed=11,mode='compound')
    print(f"  {'复利 不提取 f=%.0f%%'%(f*100):<28}{r1['P']*100:>10.1f}%{r1['medG']:>10.0f}{r1['bust']*100:>7.1f}%")
for f in [0.01,0.02,0.03]:
    for per in [50,200]:
        r2=simulate(R,H,f,0,NS,seed=11,mode='periodic',period=per)
        print(f"  {'定期结算 f=%.0f%% 每%d笔'%(f*100,per):<28}{r2['P']*100:>10.1f}%{r2['medG']:>10.0f}{r2['bust']*100:>7.1f}%")
print("\n"+"="*100)
