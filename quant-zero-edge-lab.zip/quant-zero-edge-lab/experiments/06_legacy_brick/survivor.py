import numpy as np, pandas as pd
FILES={'DOGE':'/data/inputs/DOGEUSDT_1h.csv','DOT':'/data/inputs/DOTUSDT_1h.csv',
       'CRV':'/data/inputs/CRVUSDT_1h.csv','DASH':'/data/inputs/DASHUSDT_1h.csv',
       'ETH':'/data/inputs/ETHUSDT_1h.csv','FIL':'/data/inputs/FILUSDT_1h.csv',
       'HBAR':'/data/inputs/HBARUSDT_1h.csv'}
print("="*104)
print("【幸存者偏差量化】我这7个样本品种 = 已经活下来的那批")
print("="*104)
print(f"  {'品种':<7}{'起始':>12}{'结束':>12}{'首价':>10}{'末价':>10}{'总涨跌':>12}{'年化':>10}{'样本年数':>9}")
print("  "+"-"*84)
rows=[]
for k,p in FILES.items():
    d=pd.read_csv(p);c={x.lower():x for x in d.columns}
    ts=d[c['timestamp']].values if 'timestamp' in c else d[c.get('timestamp',d.columns[0])].values
    cl=d[c['close']].values.astype(float)
    t0=pd.to_datetime(ts[0],unit='ms');t1=pd.to_datetime(ts[-1],unit='ms')
    yrs=(ts[-1]-ts[0])/(1000*3600*24*365.25)
    tot=cl[-1]/cl[0]-1
    ann=(cl[-1]/cl[0])**(1/yrs)-1 if yrs>0 and cl[0]>0 else np.nan
    rows.append((k,t0.date(),t1.date(),cl[0],cl[-1],tot,ann,yrs))
    print(f"  {k:<7}{str(t0.date()):>12}{str(t1.date()):>12}{cl[0]:>10.2f}{cl[-1]:>10.2f}{tot*100:>11.0f}%{ann*100:>9.1f}%{yrs:>9.2f}")
print(f"\n  观察:")
print(f"   7个品种全部: 数据连续到今天, 仍在交易所挂牌, 有完整历史")
print(f"   => 它们都是'活到样本结束'的个体")
print(f"   已下架/归零的币种: 数据不可得, 从未进入样本")

# 等权组合BH
print(f"\n  【等权组合买入持有】(假设7个都从各自起点持有到终点)")
anns=[r[6] for r in rows if np.isfinite(r[6])]
print(f"   各品种年化: {[f'{a*100:.0f}%' for a in anns]}")
print(f"   均值 {np.mean(anns)*100:.1f}%  中位数 {np.median(anns)*100:.1f}%")

print("\n"+"="*104)
print("【关键】如果样本里混入'死掉的'币种会怎样?")
print("="*104)
print("  设: 真实上市币种中, 比例 q 最终归零(-100%), 其余存活")
print("  存活者平均年化 = 上面实测值")
print("  则全体(含死亡者)的真实年化 = ?")
print(f"\n  {'归零比例q':<12}{'存活者年化':>12}{'全体真实年化':>14}{'差异':>10}")
print("  "+"-"*50)
for q in [0.0,0.1,0.3,0.5,0.7,0.9]:
    surv=np.mean(anns)
    # 简化: 全体 = (1-q)*存活者收益 + q*(-100%)
    # 用几何近似: 年化上, 归零者贡献 -100%
    allr=(1-q)*surv + q*(-1.0)
    print(f"  {q*100:<11.0f}%{surv*100:>11.1f}%{allr*100:>13.1f}%{(allr-surv)*100:>9.1f}pp")
print(f"\n  => q=50%时, 存活者看起来年化{np.mean(anns)*100:.0f}%, 全体真实仅{((0.5)*np.mean(anns)+0.5*(-1))*100:.0f}%")
print(f"     这就是幸存者偏差的量级")
print("\n"+"="*104)
