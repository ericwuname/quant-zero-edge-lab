# -*- coding: utf-8 -*-
"""最终判决: 策略收益对市场收益回归 —— alpha 与 beta 分离 (时间外推后半段)"""
import sys, numpy as np, pandas as pd, warnings
sys.path.insert(0,'/data/workspace/brick')
warnings.filterwarnings('ignore')
from entry_lib import *

def bars_of(sym, sigfn, cost=0.0002):
    df=load(sym)
    o=df['open'].values; c=df['close'].values
    ts=df['timestamp'].values
    n=len(o); cut=n//2
    sig=sigfn(c)
    r=np.zeros(n); r[1:]=o[1:]/o[:-1]-1
    # 持仓 = sig(信号由close[t]决定, 收益从open[t+1]起算 -> 用sig[t]配 r[t+1])
    pos=sig[:-1]; ret=r[1:]
    chg=np.zeros(len(pos)); chg[1:]=(np.abs(np.diff(pos))>0).astype(float)
    pnl=pos*ret - chg*2*cost
    a=cut
    return pnl[a:], ret[a:], ts[1:][a:]

def sig_brk20(c):
    s=np.zeros(len(c)); hh=pd.Series(c).rolling(20).max().values; ll=pd.Series(c).rolling(20).min().values
    s[20:]=np.where(c[20:]>hh[:-20],1,np.where(c[20:]<ll[:-20],-1,0)); return np.where(np.isnan(s),0,s)
def sig_mom240(c):
    s=np.zeros(len(c)); s[240:]=np.sign(c[240:]/c[:-240]-1); return s
def sig_ma200(c):
    ma=pd.Series(c).rolling(200).mean().values; s=np.where(c>ma,1,-1); s[:200]=0
    return np.where(np.isnan(s),0,s)

print('='*104)
print('最终判决  pnl_strategy = alpha + beta * market_return   (后半段时间, 日度聚合)')
print('='*104)
print(f'{"策略":<10}{"日均bp":>10}{"年化%":>10}{"beta":>10}{"alpha日bp":>12}{"alpha t":>10}{"IR(年化)":>10}{"判定":>12}')
for name,fn in [('brk20',sig_brk20),('mom240',sig_mom240),('ma200',sig_ma200)]:
    P=[];M=[];T=None
    for sym in ALL13:
        p,m,t=bars_of(sym,fn)
        P.append(p);M.append(m);T=t if T is None else T
    L=min(len(x) for x in P)
    P=np.array([x[:L] for x in P]); M=np.array([x[:L] for x in M]); T=T[:L]
    port=P.mean(axis=0); mkt=M.mean(axis=0)
    # 日度聚合
    d=pd.to_datetime(T,unit='ms').date
    dfp=pd.DataFrame({'p':port,'m':mkt,'d':d}).groupby('d').sum()
    p=dfp['p'].values; m=dfp['m'].values
    beta=np.cov(p,m,ddof=1)[0,1]/np.var(m,ddof=1)
    alpha=p.mean()-beta*m.mean()
    resid=p-(alpha+beta*m)
    se=resid.std(ddof=1)/np.sqrt(len(p))
    t=alpha/se
    ir=alpha/p.std(ddof=1)*np.sqrt(365) if p.std()>0 else 0
    ann=p.mean()*365*1e4/1e4*100
    judgment='显著' if abs(t)>1.96 else '不显著'
    print(f'{name:<10}{p.mean()*1e4:>10.3f}{ann:>10.1f}{beta:>10.3f}{alpha*1e4:>12.3f}{t:>10.2f}{ir:>10.2f}{judgment:>12}')

print()
print('='*104)
print('参照  纯买入持有 (beta=1): 日均 / 年化  —— 策略是否跑赢"什么都不做"')
print('='*104)
bh=[]
for sym in ALL13:
    p,m,t=bars_of(sym,sig_ma200)
    bh.append(m)
L=min(len(x) for x in bh)
bhm=np.array([x[:L] for x in bh]).mean(axis=0)
print(f'  买入持有: 日均 {bhm.mean()*1e4:+.3f} bp   年化 {bhm.mean()*365*100:+.1f}%')

print()
print('='*104)
print('时间稳定性  前半时间 vs 后半时间 的日均收益 (未做选择的策略)')
print('='*104)
def bars_half(sym,fn,half,cost=0.0002):
    df=load(sym); o=df['open'].values; c=df['close'].values
    n=len(o); cut=n//2; sig=fn(c)
    r=np.zeros(n); r[1:]=o[1:]/o[:-1]-1
    pos=sig[:-1]; ret=r[1:]
    chg=np.zeros(len(pos)); chg[1:]=(np.abs(np.diff(pos))>0).astype(float)
    pnl=pos*ret-chg*2*cost
    a,b=(0,cut) if half=='first' else (cut,len(pos))
    return pnl[a:b]
print(f'{"策略":<10}{"前半(日均bp)":>16}{"后半(日均bp)":>16}{"一致性":>12}')
for name,fn in [('brk20',sig_brk20),('mom240',sig_mom240),('ma200',sig_ma200)]:
    f1=np.mean([bars_half(s,fn,'first').mean() for s in ALL13])*1e4
    f2=np.mean([bars_half(s,fn,'second').mean() for s in ALL13])*1e4
    print(f'{name:<10}{f1:>16.3f}{f2:>16.3f}{"同号✓" if f1*f2>0 else "反号✗":>12}')
