"""
【当下可实现】成本工程化 —— 唯一100%可控的杠杆
====================================================
【核心命题】
  之前所有"必败"结论都建立在【假设成本】上
  成本是唯一不需要预测、100%可控的变量
  -> 若能把成本压到临界值以下, 结论会变

【现实成本对照】
  币安 taker(市价):  10bp 单边 -> 20bp 往返
  币安 maker(限价):   2bp 单边 ->  4bp 往返
  有返佣/VIP:        0bp 或负  ->  0bp 往返
  DEX:               gas + 滑点, 通常更贵

【实验】
  1. 真实crypto日线, 策略族扫描
  2. 成本从 0 -> 50bp 逐步加压
  3. 每个成本: 样本内选最优 -> 样本外验证 -> 对比买入持有(BH)
  4. 找出【临界成本】: 策略还能跑赢BH的最大成本
  5. 对照现实可达成本 -> 判断可行性

【关键】
  如果临界成本 > 4bp (maker可达), 则这条路通
  如果临界成本 < 1bp, 则无解
"""
import numpy as np
import pandas as pd
from scipy import stats

DAILY = {'BTC': '/data/inputs/BTCUSDT_1d.csv',
         'BNB': '/data/inputs/BNBUSDT_1d.csv',
         'BCH': '/data/inputs/BCHUSDT_1d.csv'}
HOURLY = {'DOGE': '/data/inputs/DOGEUSDT_1h.csv',
          'DOT':  '/data/inputs/DOTUSDT_1h.csv',
          'CRV':  '/data/inputs/CRVUSDT_1h.csv',
          'DASH': '/data/inputs/DASHUSDT_1h.csv'}
DAYS_YR = 365


def load():
    px = {}
    for k, p in DAILY.items():
        d = pd.read_csv(p)
        s = pd.Series(d['close'].values,
                      index=pd.to_datetime(d['timestamp'], unit='ms').dt.normalize())
        px[k] = s[~s.index.duplicated()]
    for k, p in HOURLY.items():
        d = pd.read_csv(p)
        s = pd.Series(d['close'].values,
                      index=pd.to_datetime(d['timestamp'], unit='ms'))
        px[k] = s.resample('1D').last().dropna()
    return pd.DataFrame(px).dropna()


def build_signals(P):
    """P = 价格数组(长度T+1), 信号长度T, 只用t及之前信息"""
    T = len(P) - 1
    Pp = P[:T]
    S = {}
    for w in [5, 10, 20, 40, 60, 120]:
        if T > w + 1:
            mom = np.zeros(T)
            mom[w:] = Pp[w:] / np.maximum(Pp[:-w], 1e-9) - 1
            S[f'mom_{w}'] = np.sign(mom)
            S[f'rev_{w}'] = -np.sign(mom)
    for w in [10, 30, 60]:
        if T > w + 1:
            ma = pd.Series(Pp).rolling(w).mean().values
            sig = np.where(Pp > ma, 1.0, -1.0)
            sig[:w] = 0.0
            S[f'ma_{w}'] = sig
    # 突破 (唐奇安)
    for w in [20, 60]:
        if T > w + 1:
            hi = pd.Series(Pp).rolling(w).max().values
            lo = pd.Series(Pp).rolling(w).min().values
            sig = np.zeros(T)
            sig[w:] = np.where(Pp[w:] > hi[:-w], 1.0,
                               np.where(Pp[w:] < lo[:-w], -1.0, 0.0))
            S[f'brk_{w}'] = sig
    return S


def backtest(sig, r, cost_bp):
    T = len(r)
    pnl = np.zeros(T)
    pnl[:-1] = sig[:-1] * r[1:]
    turn = np.abs(np.diff(np.concatenate([[0.0], sig])))
    return pnl - turn * (2 * cost_bp / 1e4)


def sharpe(x):
    s = x.std()
    return x.mean() / s * np.sqrt(DAYS_YR) if s > 1e-12 else 0.0


def ann_nav(x):
    nav = np.cumprod(1.0 + np.clip(x, -0.99, None))
    if len(nav) == 0 or nav[-1] <= 0:
        return -100.0
    return (nav[-1] ** (DAYS_YR / len(x)) - 1) * 100


print("=" * 100)
print("【当下可实现】成本临界点扫描 —— 唯一100%可控的杠杆")
print("=" * 100)
print("  命题: 若成本能压到临界值以下, 策略可活")
print("  现实: taker 10bp单边 / maker 2bp单边 / VIP返佣 0或负")

df = load()
print(f"\n  数据: {df.shape[1]}品种 x {df.shape[0]}天 "
      f"({df.index[0].date()} -> {df.index[-1].date()})")

port = df.pct_change().fillna(0).mean(axis=1).values
r = port
T = len(r)
sp = T // 2
prices = np.empty(T + 1)
prices[0] = 100.0
prices[1:] = 100.0 * np.cumprod(1.0 + r)

S = build_signals(prices)
names = list(S.keys())
print(f"  策略族: {len(names)} 个")

COSTS = [0, 1, 2, 3, 5, 10, 20, 30, 50]

print(f"\n  【扫描】成本 -> 样本外最优策略 vs 买入持有")
print(f"  {'成本bp':>7}{'最优策略':>12}{'策略年化':>11}{'策略夏普':>10}"
      f"{'BH年化':>10}{'BH夏普':>9}{'差值':>9}{'策略胜?':>9}")
print("  " + "-" * 78)

results = []
for c in COSTS:
    best_sh = -9
    best_nm = None
    best_pnl = None
    for nm in names:
        pnl = backtest(S[nm], r, c)
        sh = sharpe(pnl[sp:])
        if sh > best_sh:
            best_sh, best_nm, best_pnl = sh, nm, pnl
    bh_pnl = r.copy()
    a_s, s_s = ann_nav(best_pnl[sp:]), best_sh
    a_b, s_b = ann_nav(bh_pnl[sp:]), sharpe(bh_pnl[sp:])
    win = '★是' if s_s > s_b else '否'
    print(f"  {c:>7}{best_nm:>12}{a_s:>10.2f}%{s_s:>10.3f}"
          f"{a_b:>9.2f}%{s_b:>9.3f}{s_s-s_b:>+9.3f}{win:>9}")
    results.append((c, best_nm, s_s, s_b, a_s, a_b))

# ---------- 临界成本 ----------
print(f"\n  【临界成本】策略还能跑赢买入持有的最大成本")
cs = [r[0] for r in results]
diffs = [r[2] - r[3] for r in results]
crit = None
for i in range(len(diffs)):
    if diffs[i] > 0:
        crit = cs[i]
if crit is not None:
    print(f"    策略跑赢BH的成本区间: 0 ~ {crit} bp")
else:
    print(f"    即使零成本, 最优策略也未跑赢BH (差 {diffs[0]:+.3f})")

print(f"\n  差值随成本变化:")
for c, nm, ss, sb, a1, a2 in results:
    d = ss - sb
    bar = ("+" * int(max(d, 0) * 20)) if d > 0 else ("-" * int(min(-d, 1) * 20))
    print(f"    {c:>3}bp | {nm:>10} | Δ夏普 {d:>+6.3f} {bar}")

# ---------- 现实对照 ----------
print(f"\n" + "=" * 100)
print(f"  【现实成本对照】")
print(f"  {'执行方式':<24}{'单边bp':>9}{'往返bp':>9}{'是否可行':>12}")
print(f"  " + "-" * 56)
real_costs = [
    ("市价单 taker (币安)", 10, 20),
    ("限价单 maker (币安)", 2, 4),
    ("限价 maker + 返佣", 1, 2),
    ("VIP/做市商返佣", 0, 0),
    ("负费率(做市返佣)", -1, -2),
]
for nm, one, rt in real_costs:
    # 查找该往返成本对应的单边
    feasible = '?'
    for c, _, ss, sb, _, _ in results:
        if c == one:
            feasible = '★可行' if ss > sb else '不可行'
            break
    print(f"  {nm:<24}{one:>9}{rt:>9}{feasible:>12}")

print(f"\n  结论:")
if crit is not None and crit >= 2:
    print(f"    ★ 临界成本 {crit}bp -> maker单(2bp)即可达到 -> 这条路【可行】")
    print(f"    ★ 关键: 用限价单替代市价单, 就能把策略从'必败'变为'可战'")
elif crit is not None and crit >= 1:
    print(f"    临界成本 {crit}bp -> 需要极低费率(返佣), 普通maker勉强")
else:
    print(f"    临界成本 {crit}bp -> 现实中极难达到 -> 单纯降成本救不活")

print("\n" + "=" * 100)
print("完成")
print("=" * 100)
