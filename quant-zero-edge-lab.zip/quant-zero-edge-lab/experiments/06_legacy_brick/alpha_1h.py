"""
补充检验: 主动策略 vs 买入持有 的配对 alpha 检验 + 成本临界点
"""
import numpy as np, pandas as pd
from ohlc_1h_price_action import (load, build_signals, backtest, MOM_W,
                                   BARS_YR, calc_er, reality_check)
FILES = {'DOGEUSDT':'/data/inputs/DOGEUSDT_1h.csv','DOTUSDT':'/data/inputs/DOTUSDT_1h.csv',
         'CRVUSDT':'/data/inputs/CRVUSDT_1h.csv','DASHUSDT':'/data/inputs/DASHUSDT_1h.csv'}

print("="*102)
print("★ 配对 alpha 检验: 样本外 (策略 - 买入持有), 逐bar配对")
print("="*102)
print(f"  {'品种':<10}{'成本':>6}{'样本内最优':>16}{'策略bp':>9}{'BH bp':>9}"
      f"{'alpha':>9}{'t值':>8}{'显著?':>8}")
for sym,p in FILES.items():
    df = load(p); close=df['close'].values.astype(float)
    high=df['high'].values.astype(float); low=df['low'].values.astype(float)
    ret = pd.Series(close).pct_change().fillna(0).values
    L=len(close); sp=L//2
    sigs,meta,mom = build_signals(close,high,low); names=list(sigs.keys())
    for cost in [0,10,20]:
        nets = {nm: backtest(sigs[nm],ret,cost) for nm in names}
        is_m = {nm: nets[nm][:sp].mean() for nm in names}
        best = max(is_m,key=is_m.get)
        if best=='BH':
            print(f"  {sym:<10}{cost:>5}bp{'BH(无主动策略胜出)':>16}"
                  f"{nets['BH'][sp:].mean()*1e4:>9.3f}{nets['BH'][sp:].mean()*1e4:>9.3f}"
                  f"{0.0:>9.3f}{0.0:>8.2f}{'—':>8}")
            continue
        s_oos = nets[best][sp:]; bh_oos = nets['BH'][sp:]
        d = s_oos - bh_oos
        t = d.mean()/(d.std()/np.sqrt(len(d))) if d.std()>0 else 0
        sig = "显著" if abs(t)>1.96 else "不显著"
        print(f"  {sym:<10}{cost:>5}bp{best:>16}{s_oos.mean()*1e4:>9.3f}"
              f"{bh_oos.mean()*1e4:>9.3f}{d.mean()*1e4:>9.3f}{t:>8.2f}{sig:>8}")

print("\n"+"="*102)
print("★ 成本临界点: 主动策略需要多低的成本才能跑赢BH? (样本外)")
print("="*102)
print(f"  {'品种':<10}{'0bp策略':>10}{'BH':>9}{'临界成本':>10}{'备注':>34}")
for sym,p in FILES.items():
    df = load(p); close=df['close'].values.astype(float)
    high=df['high'].values.astype(float); low=df['low'].values.astype(float)
    ret = pd.Series(close).pct_change().fillna(0).values
    L=len(close); sp=L//2
    sigs,meta,mom = build_signals(close,high,low); names=list(sigs.keys())
    bh = backtest(sigs['BH'],ret,0)[sp:].mean()*1e4
    crit=None
    for cost in [0,1,2,3,5,8,10,15,20,30,50]:
        nets={nm:backtest(sigs[nm],ret,cost) for nm in names}
        is_m={nm:nets[nm][:sp].mean() for nm in names}
        b=max(is_m,key=is_m.get)
        o=nets[b][sp:].mean()*1e4
        if o<bh: crit=cost; break
    nets0={nm:backtest(sigs[nm],ret,0) for nm in names}
    is0={nm:nets0[nm][:sp].mean() for nm in names}
    b0=max(is0,key=is0.get); o0=nets0[b0][sp:].mean()*1e4
    note = "币安山寨币往返约20-50bp → 远超临界" if crit is not None and crit<=20 else "需极低成本"
    print(f"  {sym:<10}{o0:>10.3f}{bh:>9.3f}{(f'{crit}bp' if crit else '<1bp'):>10}{note:>34}")
