# -*- coding: utf-8 -*-
"""
入场信号库 + 向量化分段回测引擎
严格无前视: 信号只用 close[t]及以前 -> open[t+1]成交
flip设计: 信号翻转即平仓(同价反向开仓); 段内触发止损则截断该段
保守假设: 段内同时触及止损与止盈时, 一律记为止损
"""
import numpy as np, pandas as pd, os, warnings
warnings.filterwarnings('ignore')

DATA = '/data/inputs'
OLD7 = ['DOGE','DOT','CRV','DASH','ETH','FIL','HBAR']   # 曾参与过选择(部分污染)
NEW6 = ['TRX','UNI','XLM','XMR','XRP','ZEC']            # 从未参与任何选择(完全干净)
ALL13 = OLD7 + NEW6

STOP = 0.05          # 止损 5%
SLIP = 0.0000        # 止损滑点(单独加)
COST = {'maker':0.0002, 'taker':0.0010}   # 单边成本


def load(sym):
    df = pd.read_csv(f'{DATA}/{sym}USDT_1h.csv')
    df = df[['timestamp','open','high','low','close','volume']].copy()
    df = df.dropna()
    for c in ['open','high','low','close','volume']:
        df[c] = pd.to_numeric(df[c], errors='coerce')
    df = df.dropna()
    df = df[(df[['open','high','low','close']] > 0).all(axis=1)]
    # 剔除上市初期前10%
    n = len(df)
    df = df.iloc[int(n*0.10):].reset_index(drop=True)
    return df


def rsi(close, n):
    d = np.diff(close, prepend=close[0])
    up = np.where(d > 0, d, 0.0); dn = np.where(d < 0, -d, 0.0)
    au = pd.Series(up).ewm(alpha=1/n, adjust=False).mean().values
    ad = pd.Series(dn).ewm(alpha=1/n, adjust=False).mean().values
    rs = au / np.maximum(ad, 1e-12)
    return 100 - 100/(1+rs)


def roll_max(x, n):
    s = pd.Series(x); return s.rolling(n, min_periods=n).max().values
def roll_min(x, n):
    s = pd.Series(x); return s.rolling(n, min_periods=n).min().values
def roll_mean(x, n):
    s = pd.Series(x); return s.rolling(n, min_periods=n).mean().values
def roll_std(x, n):
    s = pd.Series(x); return s.rolling(n, min_periods=n).std().values


def zscore(x, n):
    m = roll_mean(x, n); s = roll_std(x, n)
    return (x - m) / np.maximum(s, 1e-12)


def build_signals(df):
    """返回 dict: name -> signal array (值域{-1,0,+1}), 全部无前视"""
    o, h, l, c, v = (df[k].values for k in ['open','high','low','close','volume'])
    n = len(c)
    S = {}
    r1 = np.zeros(n); r1[1:] = c[1:]/c[:-1] - 1     # 单bar收益(用close, 无前视)

    # ---- A. 动量 / 反转 (多窗口) ----
    for k in [2,3,5,10,20,40,60,120,240]:
        m = np.full(n, np.nan); m[k:] = c[k:]/c[:-k] - 1
        S[f'mom{k}'] = np.nan_to_num(np.sign(m))
        S[f'rev{k}'] = -np.nan_to_num(np.sign(m))

    # ---- B. 突破 (前n根高/低点) ----
    for k in [10,20,40,60,120,240]:
        hh = roll_max(h, k); ll = roll_min(l, k)
        up = c - np.roll(hh, 1); dn = np.roll(ll, 1) - c
        s = np.where(np.isnan(up)|np.isnan(dn), 0, np.where(up > 0, 1, np.where(dn > 0, -1, 0)))
        S[f'brk{k}'] = s

    # ---- C. 均线 ----
    for k in [10,20,50,100,200]:
        ma = roll_mean(c, k)
        S[f'ma{k}'] = np.where(np.isnan(ma), 0, np.sign(c - ma))
    for a,b in [(5,20),(10,50),(20,100),(50,200)]:
        ma_a, ma_b = roll_mean(c,a), roll_mean(c,b)
        S[f'xab{a}_{b}'] = np.where(np.isnan(ma_a)|np.isnan(ma_b), 0, np.sign(ma_a - ma_b))

    # ---- D. 通道位置 ----
    for k in [20,60,240]:
        hh = roll_max(h,k); ll = roll_min(l,k)
        rng = np.maximum(hh - ll, 1e-12)
        posv = (c - ll)/rng - 0.5
        S[f'pos{k}'] = np.where(np.isnan(posv), 0, np.sign(posv))

    # ---- E. RSI ----
    for k in [7,14,28]:
        r = rsi(c, k)
        S[f'rsim{k}'] = np.where(r > 55, 1, np.where(r < 45, -1, 0))   # 动量式
        S[f'rsir{k}'] = np.where(r > 55, -1, np.where(r < 45, 1, 0))   # 反转式

    # ---- F. 波动率标准化动量 (AQR式, 新维度) ----
    for k in [20,60,120]:
        m = np.full(n, np.nan); m[k:] = c[k:]/c[:-k] - 1
        vol = roll_std(r1, k) * np.sqrt(k)
        z = m / np.maximum(vol, 1e-12)
        S[f'vsm{k}'] = np.nan_to_num(np.sign(z))
        S[f'vsr{k}'] = -np.nan_to_num(np.sign(z))

    # ---- G. 波动率过滤的动量 (新维度) ----
    for k in [20,60]:
        m = np.full(n, np.nan); m[k:] = c[k:]/c[:-k] - 1
        vol = roll_std(r1, k)
        vq = pd.Series(vol).rolling(k, min_periods=k).rank(pct=True).values
        mom = np.nan_to_num(np.sign(m))
        S[f'mom{k}_lq'] = np.where(vq < 0.30, mom, 0)   # 低波动才做
        S[f'mom{k}_hq'] = np.where(vq > 0.70, mom, 0)   # 高波动才做

    # ---- H. 成交量维度 (全新, 之前从未测) ----
    lv = np.log(np.maximum(v, 1e-9))
    for k in [20,60]:
        vz = zscore(lv, k)
        S[f'volz{k}'] = np.where(np.isnan(vz), 0, np.sign(vz))
        m = np.full(n, np.nan); m[k:] = c[k:]/c[:-k] - 1
        mom = np.nan_to_num(np.sign(m))
        # 量价背离: 价涨但量缩 -> 反转
        S[f'div{k}'] = np.where(np.isnan(vz), 0, np.where(mom*vz > 0, -mom, mom))

    # ---- I. 多时间框架确认 (新维度) ----
    m20 = np.full(n,np.nan); m20[20:] = c[20:]/c[:-20]-1
    m120 = np.full(n,np.nan); m120[120:] = c[120:]/c[:-120]-1
    s20, s120 = np.nan_to_num(np.sign(m20)), np.nan_to_num(np.sign(m120))
    S['mtf_agree'] = np.where(s20 == s120, s20, 0)
    S['mtf_conflict'] = np.where((s20 != s120) & (s20 != 0) & (s120 != 0), -s20, 0)
    ma200 = roll_mean(c, 200)
    S['mom20_trend'] = np.where(np.isnan(ma200), 0, np.where(c > ma200, s20, 0))
    S['rev20_trend'] = np.where(np.isnan(ma200), 0, np.where(c > ma200, -s20, 0))

    # ---- J. ATR通道突破 (新维度) ----
    tr = np.maximum(h - l, np.maximum(np.abs(h - np.roll(c,1)), np.abs(l - np.roll(c,1))))
    tr[0] = h[0]-l[0]
    atr = roll_mean(tr, 20)
    mid = roll_mean(c, 20)
    S['atrbrk'] = np.where(np.isnan(atr), 0, np.sign(c - (mid + 1.5*atr)))
    S['atrrev'] = np.where(np.isnan(atr), 0, -np.sign(c - (mid + 1.5*atr)))

    # ---- K. 时段效应 (新维度, 用UTC小时) ----
    hr = pd.to_datetime(df['timestamp'].values, unit='ms').hour
    S['hour_dummy'] = np.zeros(n)   # 占位, 后面用训练集统计填充

    # 清理: 去掉全零/常值信号
    out = {}
    for k, s in S.items():
        s = np.asarray(s, float)
        if np.nanstd(s) > 0 and np.nanmean(np.abs(s)) > 0.01:
            out[k] = s
    out['_hour'] = hr.astype(float)
    out['_r1'] = r1
    return out


def backtest(sig, o, h, l, stop=STOP, cost=0.0002, slip=0.0):
    """
    flip设计向量化回测
    sig[t]: 用 close[t] 及以前算出的信号; 在 open[t+1] 成交
    返回: 每笔 R-multiple 数组
    """
    n = len(o)
    s = np.asarray(sig, float)
    # 有效起点: 第一个非零点
    nz = np.where(s != 0)[0]
    if len(nz) < 100:
        return np.array([])
    s = s.copy(); s[:nz[0]] = 0

    # 段划分: 信号"有效变化"点
    prev = np.roll(s, 1); prev[0] = 0
    # 只在非零信号之间切换才算翻转(0视为空仓)
    eff = np.where(s == 0, 0, s)
    prev_eff = np.roll(eff, 1); prev_eff[0] = 0
    chg = (eff != prev_eff) & (eff != 0)
    starts = np.where(chg)[0]          # 信号变为非新的索引 t
    if len(starts) < 5:
        return np.array([])
    starts = starts[starts + 1 < n]
    if len(starts) < 5:
        return np.array([])

    entry_idx = starts + 1             # open 索引
    exit_idx = np.roll(entry_idx, -1)  # 下一段入场点=本段出场点
    exit_idx[-1] = n - 1
    valid = exit_idx > entry_idx
    entry_idx, exit_idx = entry_idx[valid], exit_idx[valid]
    K = len(entry_idx)
    if K < 5:
        return np.array([])

    direction = eff[starts][valid]
    entry_px = o[entry_idx]
    exit_px = o[exit_idx]
    with np.errstate(invalid='ignore', divide='ignore'):
        raw = (exit_px - entry_px)/entry_px * direction

    # 段内极值 (保守: 同时触及止损/止盈一律记止损)
    counts = exit_idx - entry_idx
    bar_seg = np.repeat(np.arange(K), counts)
    start = entry_idx[0]
    idx = np.arange(start, start + counts.sum())
    lo_min = np.full(K, np.inf);  np.minimum.at(lo_min, bar_seg, l[idx])
    hi_max = np.full(K, -np.inf); np.maximum.at(hi_max, bar_seg, h[idx])

    stop_px = np.where(direction > 0, entry_px*(1-stop), entry_px*(1+stop))
    hit_stop = np.where(direction > 0, lo_min <= stop_px, hi_max >= stop_px)

    ret = np.where(hit_stop, -stop - slip, raw)
    ret = ret - 2*cost          # 往返成本
    return ret/stop             # R-multiple
