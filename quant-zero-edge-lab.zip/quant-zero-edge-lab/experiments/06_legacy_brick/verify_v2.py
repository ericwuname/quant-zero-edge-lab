"""
【严格验证】brk_20 是否真实? + 重验极阳桶 + 短期反转可交易性
三组独立验证:
  A. 信号选择偏差: 前50%选信号 -> 后50%验证
  B. 品种外推:     旧4品种选 -> 新3品种验证
  C. 极阳桶重验
  D. 短期反转(IC<0)可交易性
"""
import numpy as np, pandas as pd

FILES={'DOGE':'/data/inputs/DOGEUSDT_1h.csv','DOT':'/data/inputs/DOTUSDT_1h.csv',
       'CRV':'/data/inputs/CRVUSDT_1h.csv','DASH':'/data/inputs/DASHUSDT_1h.csv',
       'ETH':'/data/inputs/ETHUSDT_1h.csv','FIL':'/data/inputs/FILUSDT_1h.csv',
       'HBAR':'/data/inputs/HBARUSDT_1h.csv'}
OLD=['DOGE','DOT','CRV','DASH']; NEW=['ETH','FIL','HBAR']

def load():
    o={}
    for k,p in FILES.items():
        d=pd.read_csv(p);c={x.lower():x for x in d.columns}
        o[k]=dict(open=d[c['open']].values.astype(float),high=d[c['high']].values.astype(float),
                  low=d[c['low']].values.astype(float),close=d[c['close']].values.astype(float))
    return o

def s_mom(cl,w):
    n=len(cl);s=np.zeros(n);s[w:]=np.sign(cl[w:]/np.maximum(cl[:-w],1e-9)-1);return s
def s_brk(cl,w):
    n=len(cl);s=np.zeros(n)
    for i in range(w,n):
        hi=cl[i-w:i].max();lo=cl[i-w:i].min()
        if cl[i]>hi: s[i]=1
        elif cl[i]<lo: s[i]=-1
    return s
def s_ma(cl,w):
    n=len(cl);s=np.zeros(n)
    ma=pd.Series(cl).rolling(w).mean().values
    s[w:]=np.sign(cl[w:]-ma[w:]);return s

SIGS={'mom_5':lambda c:s_mom(c,5),'mom_10':lambda c:s_mom(c,10),'mom_20':lambda c:s_mom(c,20),
      'mom_60':lambda c:s_mom(c,60),'rev_5':lambda c:-s_mom(c,5),'rev_10':lambda c:-s_mom(c,10),
      'rev_20':lambda c:-s_mom(c,20),'brk_20':lambda c:s_brk(c,20),'ma_50':lambda c:s_ma(c,50),
      'brk_60':lambda c:s_brk(c,60)}

def run(D,sg,s=0.05,R=2.0,cost_bp=2,slip_bp=5,max_hold=800,start=0,end=None,invert=False):
    op,hi,lo,cl=D['open'],D['high'],D['low'],D['close']
    n=len(cl) if end is None else min(end,len(cl))
    cR=2*cost_bp/1e4/s; slipR=slip_bp/1e4/s; stopd=s+slip_bp/1e4
    net=[]
    i=max(start,120)
    while i<n-3:
        d=1 if sg[i]>0 else (-1 if sg[i]<0 else 0)
        if d==0: i+=1;continue
        if invert: d=-d
        e=op[i+1];i0=i+1;out=None;j=i0
        for jj in range(i0,min(i0+max_hold,n)):
            adv=(lo[jj]/e-1) if d==1 else (1-hi[jj]/e)
            fav=(hi[jj]/e-1) if d==1 else (1-lo[jj]/e)
            if adv<=-stopd: out=-1.0-slipR;j=jj;break
            if fav>=R*s: out=R;j=jj;break
            if sg[jj]*d<0: out=((cl[jj]/e-1)*d)/s;j=jj;break
        if out is None:
            j=min(i0+max_hold,n-1);out=((cl[j]/e-1)*d)/s
        net.append(out-cR);i=j+1
    return np.array(net)

def st(net):
    if len(net)<30: return None
    E=net.mean();sd=net.std()
    return dict(n=len(net),win=(net>0).mean(),E=E,t=E/(sd/np.sqrt(len(net))) if sd>0 else 0)

data=load()

print("="*100)
print("【A】信号选择偏差: 前50%选最优信号 -> 后50%验证 (7品种池化)")
print("="*100)
# 前50%选
print(f"\n  前50%(选):")
best_nm=None;best_E=-9
for nm,fn in SIGS.items():
    alln=[]
    for k,D in data.items():
        n=len(D['close']);half=n//2
        sg=fn(D['close'])
        nt=run(D,sg,start=0,end=half)
        if len(nt)>=30: alln.append(nt)
    if not alln: continue
    s_=st(np.concatenate(alln))
    flag=''
    if s_['E']>best_E: best_E=s_['E'];best_nm=nm
    print(f"    {nm:<10} N={s_['n']:>6} E={s_['E']:+.4f} t={s_['t']:+.2f}")
print(f"  -> 选中: {best_nm} (样本内 E={best_E:+.4f})")

print(f"\n  后50%(验) — 只用选中的 {best_nm}:")
alln=[]
for k,D in data.items():
    n=len(D['close'])
    sg=SIGS[best_nm](D['close'])
    nt=run(D,sg,start=n//2,end=n)
    if len(nt)>=30: alln.append(nt)
v=st(np.concatenate(alln))
print(f"    样本外: N={v['n']} 胜率={v['win']*100:.1f}% E={v['E']:+.4f}R t={v['t']:+.2f}")
print(f"    衰减: {(v['E']/best_E*100) if best_E!=0 else 0:.0f}%")

print("\n"+"="*100)
print("【B】品种外推: 旧4品种选 -> 新3品种验证")
print("="*100)
best_nm2=None;best_E2=-9
for nm,fn in SIGS.items():
    alln=[]
    for k in OLD:
        D=data[k];n=len(D['close'])
        sg=fn(D['close'])
        nt=run(D,sg,start=n//2,end=n)
        if len(nt)>=30: alln.append(nt)
    if not alln: continue
    s_=st(np.concatenate(alln))
    if s_['E']>best_E2: best_E2=s_['E'];best_nm2=nm
print(f"  旧4品种(选) 最优: {best_nm2} E={best_E2:+.4f}")
alln=[]
for k in NEW:
    D=data[k];n=len(D['close'])
    sg=SIGS[best_nm2](D['close'])
    nt=run(D,sg,start=n//2,end=n)
    if len(nt)>=30: alln.append(nt)
v2=st(np.concatenate(alln))
print(f"  新3品种(验): N={v2['n']} 胜率={v2['win']*100:.1f}% E={v2['E']:+.4f}R t={v2['t']:+.2f}")

print("\n"+"="*100)
print("【C】极阳桶重验 (修复框架: 无前视, 信号联动)")
print("="*100)
print("  旧结论: 极阳(z>2)后10日收益+483bp, p=0.000 (用日线, 收盘价)")
print("  新检验: 1h数据, 用open[t+1]入场, 持有固定bar数, 测分桶收益")
print(f"\n  {'分桶':<12}{'N':>7}{'未来10bar收益(bp)':>20}{'t':>8}")
print("  "+"-"*50)
allb={}
for k,D in data.items():
    cl=D['close'];op=D['open'];n=len(cl)
    # z-score of 240bar 收益
    w=240
    r240=np.full(n,np.nan)
    r240[w:]=cl[w:]/np.maximum(cl[:-w],1e-9)-1
    sig=np.full(n,np.nan)
    sig[:n-1]=np.diff(np.log(np.maximum(cl,1e-9)))
    # 滚动std
    df=pd.Series(sig)
    mu=df.rolling(w).mean().values; sd=df.rolling(w).std().values
    z=np.full(n,np.nan)
    m=(sd>0)&np.isfinite(mu)
    z[m]=(r240[m]-mu[m])/sd[m]
    fut=np.full(n,np.nan)
    fut[:n-10]=op[11:n+1]/np.maximum(op[1:n-9],1e-9)-1  # 未来10bar用open
    valid=np.isfinite(z)&np.isfinite(fut)
    zv=z[valid];fv=fut[valid]
    q=np.nanpercentile(np.abs(zv),100) if False else None
    edges=[-np.inf,-1,-0.5,0.5,1,np.inf]
    labs=['极阴','阴','中','阳','极阳']
    for i in range(5):
        mk=(zv>=edges[i])&(zv<edges[i+1])
        if mk.sum()<100: continue
        allb.setdefault(labs[i],[]).append(fv[mk]*1e4)
for lab in ['极阴','阴','中','阳','极阳']:
    if lab not in allb: continue
    arr=np.concatenate(allb[lab]);N=len(arr)
    t=arr.mean()/(arr.std()/np.sqrt(N)) if arr.std()>0 else 0
    print(f"  {lab:<12}{N:>7}{arr.mean():>20.1f}{t:>8.2f}")

print("\n"+"="*100)
print("【D】短期反转 (IC h=1 为负) 可交易性 — 修复框架")
print("="*100)
print("  策略: 过去5bar跌->做多(反转), 信号翻转即平, 各种止损宽度")
print(f"\n  {'止损':<8}{'R':>5}{'N':>8}{'胜率':>8}{'E(R)':>9}{'t':>8}{'毛(bp/bar)':>12}")
print("  "+"-"*58)
for s in [0.02,0.05]:
    for R in [1,2]:
        alln=[]
        for k,D in data.items():
            n=len(D['close'])
            sg=-s_mom(D['close'],5)   # 反转方向
            nt=run(D,sg,s=s,R=R,cost_bp=2,slip_bp=5,start=n//2,end=n)
            if len(nt)>=30: alln.append(nt)
        if not alln: continue
        cat=np.concatenate(alln);s_=st(cat)
        gross=(s_['E']+2*2e-4/s)*s*1e4
        print(f"  {s*100:<8.0f}%{R:>5}{s_['n']:>8}{s_['win']*100:>7.1f}%{s_['E']:>+9.4f}{s_['t']:>+8.2f}{gross:>12.2f}")
print("\n"+"="*100)
