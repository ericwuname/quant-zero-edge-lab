"""
在线交易引擎 v2 —— 修掉两个致命 bug
========================================
Bug1(死锁): 在线判定的 warmup 死锁
    不下注 -> 没有交易记录 -> 无法估计胜率 -> 永远不下注
  修正: 前 N_WARM 笔【无条件下注】积累样本, 之后才用统计判定

Bug2(虚假利润): bar 内顺序假设
    同一根 bar 里 high 和 low 都被触及时, 我原来假设了"有利顺序"
    -> 系统性造出假利润 (强趋势市场跑出 98 亿, 荒谬)
  修正: 【最保守假设】只要该 bar 的区间同时覆盖止损和止盈, 一律先算止损
        且每根 bar 最多完成 1 笔完整的开->平, 禁止 bar 内反复刷单

头寸约束: 名义价值 <= LEV_CAP x 本金 (防止无限加杠杆)
"""
import numpy as np

PRICE0 = 100000.0
TICK = 1.0
COST_RATE = 0.0001      # 单边手续费 万1
INIT_CAP = 10000.0
RISK = 0.01
LEV_CAP = 5.0           # 名义价值上限 = 5倍本金


def make_market(kind, n, sigma, seed, price0=PRICE0):
    rng = np.random.default_rng(seed)
    r = np.zeros(n)
    if kind == 'rw':
        r = rng.normal(0, sigma, n)
    elif kind == 'trendvol':
        h, d = sigma ** 2, np.zeros(n)
        for t in range(1, n):
            h = 0.9 * h + 0.1 * r[t - 1] ** 2 + 1e-12
            d[t] = 0.95 * d[t - 1] + rng.normal(0, sigma * 0.06)
            r[t] = d[t] + np.sqrt(h) * rng.normal()
        sd = r.std()
        if sd > 0:
            r = r / sd * sigma
    elif kind == 'regime':
        state = 0
        for t in range(1, n):
            if rng.random() < 0.002:
                state = 1 - state
            r[t] = (0.08 if state == 1 else -0.08) * r[t - 1] + rng.normal(0, sigma)
    elif kind == 'strong':
        L = max(20, n // 10)
        signs = rng.choice([-1, 1], int(np.ceil(n / L)))
        r = signs.repeat(L)[:n] * sigma * 0.5 + rng.normal(0, sigma, n)
    close = price0 * np.exp(np.cumsum(r))
    op = np.concatenate([[price0], close[:-1]])
    body = np.abs(close - op)
    span = body + rng.uniform(0.3, 1.5, n) * sigma * price0
    up = rng.uniform(0, 1, n)
    high = np.maximum(op, close) + span * up * 0.5
    low = np.minimum(op, close) - span * (1 - up) * 0.5
    return dict(open=op,
                high=np.maximum(high, np.maximum(op, close)),
                low=np.minimum(low, np.minimum(op, close)),
                close=close)


def atr(o, w=14):
    h, l, c = o['high'], o['low'], o['close']
    pc = np.concatenate([[c[0]], c[:-1]])
    tr = np.maximum(h - l, np.maximum(np.abs(h - pc), np.abs(l - pc)))
    a = np.full(len(c), np.nan)
    if len(c) >= w:
        a[w - 1] = tr[:w].mean()
        for i in range(w, len(c)):
            a[i] = (a[i - 1] * (w - 1) + tr[i]) / w
    return a


def trade(o, A_arr, W=100, z_crit=1.645, use_filter=True, n_warm=60,
          slip=1.0, cost_rate=COST_RATE, cap0=INIT_CAP, risk=RISK,
          lev_cap=LEV_CAP):
    h, l, c = o['high'], o['low'], o['close']
    n = len(c)
    cap = cap0
    equity = np.zeros(n)
    peak = cap0
    maxdd = 0.0
    pos = 0
    entry = 0.0
    lots = 0.0
    a0 = A_arr[0] if not np.isnan(A_arr[0]) else 200.0
    a_hi, a_lo = c[0] + a0, c[0] - a0
    outcomes = []            # 每笔 +1 / -1
    bankrupt = False
    n_sig = 0
    n_taken = 0

    def size_for(capv, Ai):
        lots_ = np.floor((capv * risk / Ai) * 100) / 100
        if lots_ < 0.01:
            return 0.0
        if lots_ * PRICE0 > capv * lev_cap:
            lots_ = np.floor((capv * lev_cap / PRICE0) * 100) / 100
        return max(lots_, 0.0)

    for i in range(n):
        Ai = A_arr[i] if not np.isnan(A_arr[i]) else 200.0
        if Ai <= 0:
            equity[i] = cap
            continue

        if pos == 0:
            n_sig += 1
            take = True
            if use_filter and len(outcomes) >= n_warm:
                wr = np.mean(outcomes[-W:]) * 0.5 + 0.5    # outcomes是±1
                if len(outcomes) >= W:
                    se = np.sqrt(0.25 / W)
                    take = (wr - 0.5) / se > z_crit
                else:
                    take = True
            elif use_filter and len(outcomes) < n_warm:
                take = True      # warmup: 无条件下注积累样本

            if take:
                n_taken += 1
                # 保守: 该 bar 同时触及上下界 -> 不做(避免顺序赌博)
                both = (h[i] >= a_hi) and (l[i] <= a_lo)
                if not both:
                    if h[i] >= a_hi:
                        entry = a_hi + slip
                        pos = 1
                        lots = size_for(cap, Ai)
                        if lots > 0:
                            cap -= lots * entry * cost_rate
                        # bar 内是否已被打掉(保守: 先止损)
                        stop, targ = entry - Ai, entry + Ai
                        if l[i] <= stop:
                            cap += (-Ai - slip) * lots - lots * stop * cost_rate
                            outcomes.append(-1.0); pos = 0
                            a_hi, a_lo = stop, stop - Ai
                        elif h[i] >= targ:
                            cap += (Ai - slip) * lots - lots * targ * cost_rate
                            outcomes.append(1.0); pos = 0
                            a_hi, a_lo = targ, targ - Ai
                        else:
                            a_hi, a_lo = targ, stop
                    elif l[i] <= a_lo:
                        entry = a_lo - slip
                        pos = -1
                        lots = size_for(cap, Ai)
                        if lots > 0:
                            cap -= lots * entry * cost_rate
                        stop, targ = entry + Ai, entry - Ai
                        if h[i] >= stop:
                            cap += (-Ai - slip) * lots - lots * stop * cost_rate
                            outcomes.append(-1.0); pos = 0
                            a_lo, a_hi = stop, stop + Ai
                        elif l[i] <= targ:
                            cap += (Ai - slip) * lots - lots * targ * cost_rate
                            outcomes.append(1.0); pos = 0
                            a_lo, a_hi = targ, targ + Ai
                        else:
                            a_lo, a_hi = targ, stop

        if pos != 0:
            if pos == 1:
                stop, targ = entry - Ai, entry + Ai
                hit_stop, hit_targ = l[i] <= stop, h[i] >= targ
            else:
                stop, targ = entry + Ai, entry - Ai
                hit_stop, hit_targ = h[i] >= stop, l[i] <= targ
            if hit_stop or hit_targ:
                if hit_stop:          # 保守: 同时触及 -> 算止损
                    cap += (-Ai - slip) * lots - lots * stop * cost_rate
                    outcomes.append(-1.0)
                    a_hi = a_lo = stop
                else:
                    cap += (Ai - slip) * lots - lots * targ * cost_rate
                    outcomes.append(1.0)
                    a_hi = a_lo = targ
                pos = 0
                if pos == 0:
                    if hit_stop:
                        a_hi, a_lo = stop + Ai, stop - Ai
                    else:
                        a_hi, a_lo = targ + Ai, targ - Ai

        eq = cap
        if pos != 0:
            eq += ((c[i] - entry) if pos == 1 else (entry - c[i])) * lots
        equity[i] = max(eq, 0.0)
        peak = max(peak, equity[i])
        maxdd = max(maxdd, (peak - equity[i]) / peak if peak > 0 else 0)
        if equity[i] <= 0:
            bankrupt = True
            equity[i:] = 0.0
            break

    oc = np.array(outcomes) if outcomes else np.array([])
    return dict(final=equity[-1] if not bankrupt else 0.0,
                equity=equity, maxdd=maxdd, bankrupt=bankrupt,
                n_trades=len(outcomes), n_sig=n_sig, n_taken=n_taken,
                win=float((oc > 0).mean()) if len(oc) else np.nan)
