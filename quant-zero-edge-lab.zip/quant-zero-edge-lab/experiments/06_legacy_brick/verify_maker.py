"""
【验证】maker下 t=9.29 是否跨品种稳健?
=============================================
【背景】
  DOGE样本外 maker 2bp, s=0.5%, R=3 -> E=+0.242R, t=+9.29
  这是整轮最强统计证据, 但【单品种】可能是运气/过拟合

【必须验证】
  1. 4个品种是否都为正且显著? (一致性)
  2. 成本混合情形: 止损单通常是市价(taker), 止盈是限价(maker)
     -> 更真实的成本模型
  3. 与买入持有对比 (alpha 检验)
  4. 账户路径: 连亏/回撤/终值
  5. 参数平原检验 (孤立尖峰 or 一片正)

【成本模型】
  A. 理想: 全部 maker (2bp)
  B. 混合: 开仓maker + 止盈maker + 止损taker  <- 真实
  C. 保守: 全部 taker (10bp)
"""
import numpy as np
import pandas as pd
from scipy import stats

HOURLY = {'DOGE': '/data/inputs/DOGEUSDT_1h.csv',
          'DOT':  '/data/inputs/DOTUSDT_1h.csv',
          'CRV':  '/data/inputs/CRVUSDT_1h.csv',
          'DASH': '/data/inputs/DASHUSDT_1h.csv'}


def load():
    out = {}
    for k, p in HOURLY.items():
        d = pd.read_csv(p)
        out[k] = d['close'].values.astype(float)
    return out


def momentum_signal(px, w=60):
    n = len(px)
    sig = np.zeros(n)
    sig[w:] = np.sign(px[w:] / np.maximum(px[:-w], 1e-9) - 1)
    return sig


def run_trades_R(px, signal, s, R, mode='maker', max_hold=800,
                 seed=42, start=0, end=None):
    """mode: maker(全2bp) / mixed(止损taker) / taker(全10bp)
    返回 net_R 数组 + 是否为盈利单标记
    """
    if mode == 'maker':
        c_win = 2 * 2e-4 / s; c_loss = 2 * 2e-4 / s
    elif mode == 'mixed':
        c_win = 2 * 2e-4 / s              # 开maker + 止盈maker
        c_loss = (2e-4 + 10e-4) / s       # 开maker + 止损taker
    else:
        c_win = 2 * 10e-4 / s; c_loss = 2 * 10e-4 / s

    n = len(px) if end is None else min(end, len(px))
    rng = np.random.default_rng(seed)
    net = []
    i = max(start, 60)
    while i < n - 2:
        sg = signal[i]
        if sg == 0:
            sg = rng.choice([-1, 1])
        direction = 1 if sg > 0 else -1
        entry = px[i]
        out_R = None
        j = i
        for jj in range(i + 1, min(i + max_hold, n)):
            mv = (px[jj] / entry - 1) * direction
            if mv <= -s:
                out_R = -1.0; j = jj; break
            if mv >= R * s:
                out_R = R; j = jj; break
        if out_R is None:
            j = min(i + max_hold, n - 1)
            out_R = (px[j] / entry - 1) * direction / s
        c = c_win if out_R > 0 else c_loss
        net.append(out_R - c)
        i = j + 1
    return np.array(net)


def stats_of(net):
    if len(net) < 30:
        return None
    win = (net > 0).mean()
    E = net.mean()
    t = E / (net.std() / np.sqrt(len(net))) if net.std() > 0 else 0
    return dict(n=len(net), win=win, E_R=E, t=t)


def path_risk(net, f=0.01, init=10000.0):
    nav = np.empty(len(net) + 1); nav[0] = init
    for i, r in enumerate(net):
        nav[i + 1] = nav[i] * (1.0 + f * r)
        if nav[i + 1] <= 0:
            nav[i + 1:] = 0; break
    mc, cur = 0, 0
    for r in net:
        if r < 0: cur += 1; mc = max(mc, cur)
        else: cur = 0
    pk = np.maximum.accumulate(nav)
    dd = -((nav - pk) / np.maximum(pk, 1e-12)).min() * 100
    return dict(final=nav[-1], mdd=dd, max_consec=mc)


data = load()
print("=" * 100)
print("【验证】maker下强信号是否跨品种稳健 + 真实混合成本")
print("=" * 100)

# ---------- 1. 多品种一致性 ----------
print(f"\n  【1】多品种一致性 (样本外, s=1%, R=3)")
print(f"  {'品种':<7}{'模式':<9}{'笔数':>7}{'胜率':>8}{'E(R)':>9}{'t':>8}"
      f"{'终值':>10}{'回撤':>8}{'连亏':>7}{'显著':>7}")
print("  " + "-" * 76)

for mode in ['maker', 'mixed', 'taker']:
    for sym in ['DOGE', 'CRV', 'DOT', 'DASH']:
        px = data[sym]
        n = len(px); sp = n // 2
        sg = momentum_signal(px, 60)
        net = run_trades_R(px, sg, 0.01, 3, mode=mode, start=sp, end=n)
        st = stats_of(net)
        if st is None: continue
        pr = path_risk(net, f=0.01)
        sig_flag = '★' if abs(st['t']) > 1.96 and st['E_R'] > 0 else ''
        print(f"  {sym:<7}{mode:<9}{st['n']:>7}{st['win']*100:>7.1f}%"
              f"{st['E_R']:>+9.3f}{st['t']:>+8.2f}{pr['final']:>10.0f}"
              f"{pr['mdd']:>7.1f}%{pr['max_consec']:>7}{sig_flag:>7}")
    print()

# ---------- 2. 参数平原 ----------
print(f"  【2】参数平原 (DOGE, maker, 是否'一片正')")
print("  s\\R      " + "".join(f"{f'1:{r}':>18}" for r in [2, 2.5, 3, 4]))
print("  " + "-" * 82)
px = data['DOGE']; n = len(px); sp = n // 2
sg = momentum_signal(px, 60)
pos = 0; tot = 0
for s in [0.003, 0.005, 0.01, 0.02, 0.03]:
    row = f"  {s*100:>6.1f}%  "
    for R in [2, 2.5, 3, 4]:
        net = run_trades_R(px, sg, s, R, mode='maker', start=sp, end=n)
        st = stats_of(net)
        if st:
            row += f"{st['E_R']:>+7.3f}(t{st['t']:>+5.1f})"
            tot += 1
            if st['E_R'] > 0: pos += 1
        else:
            row += f"{'—':>18}"
    print(row)
print(f"\n    maker下: {pos}/{tot} 为正 -> "
      f"{'✓参数平原' if pos >= tot*0.7 else '⚠非平原'}")

# ---------- 3. 与买入持有对比 ----------
print(f"\n  【3】与买入持有对比 (maker, s=1%, R=3, f=1%仓位)")
print(f"  {'品种':<7}{'笔数/年':>9}{'策略年化':>11}{'BH年化':>11}{'差值':>10}")
print("  " + "-" * 50)
for sym in ['DOGE', 'CRV', 'DOT', 'DASH']:
    px2 = data[sym]
    n2 = len(px2); sp2 = n2 // 2
    sg2 = momentum_signal(px2, 60)
    net = run_trades_R(px2, sg2, 0.01, 3, mode='maker', start=sp2, end=n2)
    st = stats_of(net)
    if st is None: continue
    yrs = (n2 - sp2) / (365 * 24)
    n_per_yr = st['n'] / yrs
    strat_ann = st['E_R'] * 0.01 * n_per_yr * 100
    # BH
    c = px2[sp2:n2]
    bh_ann = ((c[-1] / c[0]) ** (1 / yrs) - 1) * 100
    print(f"  {sym:<7}{n_per_yr:>9.0f}{strat_ann:>10.1f}%{bh_ann:>10.1f}%"
          f"{strat_ann - bh_ann:>+9.1f}pp")

print("\n" + "=" * 100)
print("完成")
print("=" * 100)
