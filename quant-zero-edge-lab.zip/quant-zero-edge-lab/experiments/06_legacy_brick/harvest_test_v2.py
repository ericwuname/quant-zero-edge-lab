"""
丰年/灾年 修正检验 (修正 v1 的两个方法论错误)
================================================
【修正1】B检验改用【条件期望】而非分位频率
    错: 高波时期日收益分布天然更宽 -> 更容易落入最好/最坏10%分位
        这是机械恒等式, 不是预测能力
    对: 看高波/低波时期, 下一期的【平均收益】是多少?
        -> 这才是"天气影响收成"的真正检验

【修正2】D检验改用【不重叠样本 + 置换检验】
    错: 滚动250天窗口高度重叠, 独立样本仅约8个, 卡方严重高估显著性
    对: 不重叠年度/季度样本 + 置换检验(打乱顺序)建立零假设

【新增】E. 收益集中度的【因果含义】
    A证实了收益高度集中在少数天。
    关键问题: 那几天可预测吗? 若不可预测 -> 唯一对策是"始终在场"
"""
import numpy as np
import pandas as pd
from scipy import stats

DAILY = {'BTC': '/data/inputs/BTCUSDT_1d.csv',
         'BNB': '/data/inputs/BNBUSDT_1d.csv',
         'BCH': '/data/inputs/BCHUSDT_1d.csv'}
HOURLY = {'DOGE': '/data/inputs/DOGEUSDT_1h.csv',
          'DOT':  '/data/inputs/DOTUSDT_1h.csv',
          'CRV':  '/data/inputs/CRVUSDT_1h.csv',
          'DASH': '/data/inputs/DASHUSDT_1h.csv'}
DAYS_YR = 365
B_BOOT = 1000
BLK = 20


def load():
    px = {}
    for k, p in DAILY.items():
        d = pd.read_csv(p)
        s = pd.Series(d['close'].values,
                      index=pd.to_datetime(d['timestamp'], unit='ms').dt.normalize())
        px[k] = s[~s.index.duplicated()]
    for k, p in HOURLY.items():
        d = pd.read_csv(p)
        s = pd.Series(d['close'].values,
                      index=pd.to_datetime(d['timestamp'], unit='ms'))
        px[k] = s.resample('1D').last().dropna()
    return pd.DataFrame(px).dropna()


def metrics(net):
    n = len(net)
    mu, sd = net.mean(), net.std()
    if sd < 1e-12 or n < 10:
        return 0.0, 0.0, 0.0
    nav = np.cumprod(1.0 + np.clip(net, -0.99, None))
    ann = float(np.clip((nav[-1] ** (DAYS_YR / n) - 1) * 100 if nav[-1] > 0 else -100.0, -100, 1e6))
    sh = mu / sd * np.sqrt(DAYS_YR)
    pk = np.maximum.accumulate(nav)
    dd = (nav - pk) / np.maximum(pk, 1e-12)
    return ann, sh, float(-dd.min() * 100)


def ewma_vol(x, lam=0.94):
    v = np.zeros(len(x))
    v[0] = x[:20].var() if len(x) > 20 else max(x.var(), 1e-12)
    for t in range(1, len(x)):
        v[t] = lam * v[t - 1] + (1 - lam) * x[t - 1] ** 2
    return np.sqrt(v)


def boot_idx(rng, T, L):
    nb = int(np.ceil(T / L))
    st = rng.integers(0, T - L, size=nb)
    return (st[:, None] + np.arange(L)[None, :]).ravel()[:T] % T


def paired_test(a, b, kind='sharpe', B=B_BOOT, blk=BLK, seed=0):
    def sh(x):
        s = x.std()
        return x.mean() / s * np.sqrt(DAYS_YR) if s > 1e-12 else 0.0
    f = sh if kind == 'sharpe' else (lambda x: x.mean())
    T = len(a)
    rng = np.random.default_rng(seed)
    obs = f(a) - f(b)
    d = np.zeros(B)
    for i in range(B):
        d[i] = f(a[boot_idx(rng, T, blk)]) - f(b[boot_idx(rng, T, blk)])
    return obs, min(2 * min((d <= 0).mean(), (d >= 0).mean()), 1.0)


# ==================================================================
# B修正: 条件期望 (高波/低波时期, 下一期平均收益)
# ==================================================================
def conditional_expectation(df):
    print("\n" + "=" * 100)
    print("【B修正】条件期望 —— 高波/低波'天气'下, 下一期收成如何?")
    print("=" * 100)
    print("  (修正: 不看落入极端分位的频率[机械效应], 而看条件平均收益)")
    print(f"\n  {'品种':<7}{'高波期收益':>13}{'低波期收益':>13}{'差值(bp/日)':>14}"
          f"{'t值':>8}{'判定':>14}")

    agg = []
    for c in df.columns:
        r = df[c].pct_change().fillna(0).values
        T = len(r)
        vol = ewma_vol(r)
        vq = pd.Series(vol).rolling(500, min_periods=100).rank(pct=True).values
        fwd = np.full(T, np.nan)
        fwd[:-1] = r[1:]
        ok = ~np.isnan(vq) & ~np.isnan(fwd)
        hi = ok & (vq >= 0.7)
        lo = ok & (vq <= 0.3)
        if hi.sum() < 50 or lo.sum() < 50:
            continue
        rh, rl = fwd[hi], fwd[lo]
        diff = rh.mean() - rl.mean()
        se = np.sqrt(rh.var() / len(rh) + rl.var() / len(rl))
        t = diff / se if se > 0 else 0
        print(f"  {c:<7}{rh.mean()*1e4:>12.1f}bp{rl.mean()*1e4:>12.1f}bp"
              f"{diff*1e4:>13.1f}bp{t:>8.2f}{('高波更好' if diff>0 else '低波更好'):>14}")
        agg.append(diff * 1e4)

    if agg:
        agg = np.array(agg)
        print(f"\n  汇总: 差值均值 {agg.mean():+.1f} bp/日  "
              f"(正值{(agg>0).sum()}/{len(agg)}个品种)")
        print("  判读: 若高波期收益显著更高 -> '风险有回报'(可加仓)")
        print("        若低波期收益更高     -> '高波是灾年'(应减仓)")
        print("        若两者无显著差异     -> 天气不影响收成, 无法择时")


# ==================================================================
# D修正: 不重叠样本 + 置换检验
# ==================================================================
def persistence_rigorous(df):
    print("\n" + "=" * 100)
    print("【D修正】状态持续性 —— 不重叠样本 + 置换检验")
    print("=" * 100)
    print("  (修正: v1用重叠滚动窗口, 独立样本极少, 卡方高估显著性)")
    port = df.pct_change().fillna(0).mean(axis=1)
    T = len(port)

    print(f"\n  {'尺度':<12}{'独立样本数':>11}{'丰→丰':>9}{'灾→灾':>9}"
          f"{'观测一致性':>12}{'置换p':>9}{'判定':>12}")
    for scale, label in [(63, '季(63d)'), (125, '半年(125d)'), (250, '年(250d)')]:
        # 不重叠分块
        nb = T // scale
        if nb < 6:
            print(f"  {label:<12}{nb:>11}  样本太少, 跳过")
            continue
        blocks = [port.values[i * scale:(i + 1) * scale].sum() for i in range(nb)]
        blocks = np.array(blocks)
        good = blocks > 0
        cur, nxt = good[:-1], good[1:]
        if len(cur) < 5:
            print(f"  {label:<12}{len(cur):>11}  样本太少, 跳过")
            continue
        agree = (cur == nxt).mean()
        # 置换检验: 打乱块顺序
        rng = np.random.default_rng(5)
        nperm = 5000
        cnt = 0
        g = good.copy()
        for _ in range(nperm):
            p = rng.permutation(len(g))
            a = (g[p][:-1] == g[p][1:]).mean()
            if a >= agree:
                cnt += 1
        pval = (cnt + 1) / (nperm + 1)
        gg = (cur & nxt).sum()
        bb = (~cur & ~nxt).sum()
        n = len(cur)
        print(f"  {label:<12}{len(cur):>11}{gg/n*100:>8.1f}%{bb/n*100:>8.1f}%"
              f"{agree*100:>11.1f}%{pval:>9.3f}"
              f"{('有持续性' if pval<0.05 else '无持续性'):>12}")

    print("\n  判读: 置换p<0.05 才说明状态有真实持续性")
    print("        注意: 年尺度独立样本极少(约8个), 结论极不可靠")


# ==================================================================
# E. 收益集中度的因果含义: 最好的那些天可预测吗?
# ==================================================================
def best_days_predictability(df):
    print("\n" + "=" * 100)
    print("【E】关键: 贡献最大的那几天, 能提前知道吗?")
    print("=" * 100)
    print("  A证实了收益高度集中在少数天。若那几天不可预测 -> 唯一对策是始终在场")
    print("  检验: 用 t 及之前信息预测 t+1 是否落入【最好的5%天】")

    print(f"\n  {'品种':<7}{'最好5%天收益':>14}{'其余天收益':>13}{'集中度':>10}"
          f"{'预测AUC':>10}{'p':>8}")
    port = df.pct_change().fillna(0).mean(axis=1).values
    T = len(port)
    for c in list(df.columns)[:7]:
        r = df[c].pct_change().fillna(0).values
        fwd = np.full(T, np.nan)
        fwd[:-1] = r[1:]
        q95 = np.nanpercentile(fwd, 95)
        is_best = (fwd >= q95)
        ok = ~np.isnan(fwd)
        if is_best[ok].sum() < 20:
            continue
        rb = r[ok][is_best[ok]]
        ro = r[ok][~is_best[ok]]
        conc = rb.sum() / (rb.sum() + ro.sum()) * 100 if (rb.sum() + ro.sum()) != 0 else np.nan

        # 预测: 用波动率 + 动量
        vol = ewma_vol(r)
        vq = pd.Series(vol).rolling(500, min_periods=100).rank(pct=True).values
        mom60 = pd.Series(r).rolling(60).sum().values
        X = np.column_stack([vq, mom60])
        y = is_best.astype(float)
        okm = ~np.isnan(X).any(axis=1) & ~np.isnan(fwd)
        # 单变量 AUC: 用波动率
        x1 = vq[okm]
        y1 = y[okm]
        if y1.sum() < 10 or (~(y1.astype(bool))).sum() < 10:
            continue
        # Mann-Whitney U -> AUC
        try:
            u, p = stats.mannwhitneyu(x1[y1 == 1], x1[y1 == 0], alternative='two-sided')
            auc = u / (len(x1[y1 == 1]) * len(x1[y1 == 0]))
        except Exception:
            auc, p = np.nan, np.nan
        print(f"  {c:<7}{rb.sum()*100:>13.1f}%{ro.sum()*100:>12.1f}%{conc:>9.1f}%"
              f"{auc:>10.3f}{p:>8.3f}")

    print("\n  判读: AUC≈0.5 = 无法预测最好的那些天")
    print("        若确实无法预测 -> 收益再集中也与你无关, 只能始终在场")
    print("        (这也解释了为何所有择时策略都失败: 它们系统性错过了最好的天)")


# ============ 主流程 ============
print("=" * 100)
print("丰年/灾年 修正检验")
print("=" * 100)
df = load()
print(f"面板: {df.shape[1]}品种 x {df.shape[0]}天 "
      f"({df.index[0].date()} -> {df.index[-1].date()})")

conditional_expectation(df)
persistence_rigorous(df)
best_days_predictability(df)

print("\n" + "=" * 100)
print("完成")
print("=" * 100)
