"""
1小时 OHLC 价格行为检验 (DOGE/DOT/CRV/DASH)
==============================================
严谨框架:
  1. 无前视: signal[t] 只用 t 及之前信息, 赚 t+1 收益
  2. walk-forward: 前50%样本内选最优, 后50%样本外验证
  3. Reality Check: circular block bootstrap 校正多重挑选(55策略)
  4. 成本敏感性: 1小时高频, 扫 0/10/20/30/50 bp 单边
  5. 买入持有(BH)对照
  6. regime诊断: 样本外按ER状态分组, 验证"趋势态动量/震荡态反转"
"""
import numpy as np
import pandas as pd
import time

FILES = {
    'DOGEUSDT': '/data/inputs/DOGEUSDT_1h.csv',
}
_OLD = {
    'DOGEUSDT': '/data/inputs/DOGEUSDT_1h.csv',
    'DOTUSDT':  '/data/inputs/DOTUSDT_1h.csv',
    'CRVUSDT':  '/data/inputs/CRVUSDT_1h.csv',
    'DASHUSDT': '/data/inputs/DASHUSDT_1h.csv',
}
MOM_W   = [5, 10, 20, 50, 100, 200]
ER_N    = [10, 20, 50]
RS_W    = [5, 10, 20, 50, 100]
THR     = [0.3, 0.4]
COSTS   = [0, 10, 20, 30, 50]      # 单边成本 bp
BARS_YR = 24 * 365                  # 1小时年化因子
B_BOOT  = 300
BLK     = 100


def load(path):
    df = pd.read_csv(path)
    df = df.dropna(subset=['close']).reset_index(drop=True)
    return df


def calc_er(close, n):
    """Kaufman效率比率, 向量化, 无前视"""
    d = np.abs(np.diff(close))
    cs = np.concatenate([[0.0], np.cumsum(d)])
    L = len(close)
    er = np.full(L, np.nan)
    num = np.abs(close[n:] - close[:-n])
    den = cs[n:] - cs[:-n]
    er[n:] = np.where(den > 0, num / np.maximum(den, 1e-12), 0.0)
    return er


def build_signals(close, high, low):
    L = len(close)
    sigs, meta = {}, {}
    mom = {}
    for w in MOM_W:
        m = np.zeros(L)
        m[w:] = close[w:] / close[:-w] - 1.0
        mom[w] = m
        sigs[f'mom_{w}'] = np.sign(m)
        meta[f'mom_{w}'] = ('mom', w)
        sigs[f'rev_{w}'] = -np.sign(m)
        meta[f'rev_{w}'] = ('rev', w)
        hh = pd.Series(high).rolling(w).max().shift(1).values
        ll = pd.Series(low).rolling(w).min().shift(1).values
        brk = np.zeros(L)
        ok = ~np.isnan(hh) & ~np.isnan(ll)
        brk[ok & (close > hh)] = 1.0
        brk[ok & (close < ll)] = -1.0
        sigs[f'brk_{w}'] = brk
        meta[f'brk_{w}'] = ('brk', w)
        ma = pd.Series(close).rolling(w).mean().values
        sigs[f'ma_{w}'] = np.where(close > ma, 1.0, -1.0)
        meta[f'ma_{w}'] = ('ma', w)
    for n in ER_N:
        er = calc_er(close, n)
        valid = ~np.isnan(er)
        for w in RS_W:
            for thr in THR:
                s = np.zeros(L)
                m = mom[w]
                trend = valid & (er > thr)
                chop = valid & (er <= thr)
                s[trend] = np.sign(m[trend])
                s[chop] = -np.sign(m[chop])
                sigs[f'rs_n{n}_w{w}_t{thr}'] = s
                meta[f'rs_n{n}_w{w}_t{thr}'] = ('rs', (n, w, thr))
    sigs['BH'] = np.ones(L)
    meta['BH'] = ('bh', None)
    return sigs, meta, mom


def backtest(sig, ret, cost_bp):
    L = len(ret)
    gross = np.zeros(L)
    gross[:-1] = sig[:-1] * ret[1:]
    turn = np.zeros(L)
    turn[1:] = np.abs(np.diff(sig))
    turn[0] = np.abs(sig[0])
    return gross - turn * (2 * cost_bp / 1e4)


def boot_idx(rng, T, L):
    """Circular block bootstrap 索引 (向量化)"""
    nb = int(np.ceil(T / L))
    starts = rng.integers(0, T - L, size=nb)
    idx = (starts[:, None] + np.arange(L)[None, :]) % T
    return idx.ravel()[:T]


def reality_check(rets_oos, best_idx, B=B_BOOT, blk=BLK, seed=0):
    M, T = rets_oos.shape
    rng = np.random.default_rng(seed)
    obs_mean = rets_oos.mean(axis=1)
    obs_best = obs_mean[best_idx]
    bm = np.zeros(B)
    for b in range(B):
        idx = boot_idx(rng, T, blk)
        m = rets_oos[:, idx].mean(axis=1)
        bm[b] = (m - obs_mean).max()
    return obs_best, (bm >= obs_best).mean()


def analyze(sym, path):
    t0 = time.time()
    df = load(path)
    close = df['close'].values.astype(float)
    high = df['high'].values.astype(float)
    low = df['low'].values.astype(float)
    ret = pd.Series(close).pct_change().fillna(0).values
    L = len(close)
    split = L // 2
    sigs, meta, mom = build_signals(close, high, low)
    names = list(sigs.keys())
    M = len(names)

    bh_ret = close[-1] / close[0] - 1
    yrs = L / BARS_YR
    print("\n" + "=" * 104)
    print(f"{sym}  样本 {L} 根1小时 ({yrs:.1f}年)  样本内[0,{split}) 样本外[{split},{L})  策略族 {M}")
    print("=" * 104)
    print(f"  全期买入持有: {bh_ret*100:+.1f}%   (年化 {((1+bh_ret)**(1/yrs)-1)*100:+.2f}%)")

    store = {}
    for cost in COSTS:
        nets = {nm: backtest(sigs[nm], ret, cost) for nm in names}
        is_m = {nm: nets[nm][:split].mean() * 1e4 for nm in names}
        best = max(is_m, key=is_m.get)
        oos_best = nets[best][split:].mean() * 1e4
        oos_bh = nets['BH'][split:].mean() * 1e4
        bm_ = max([f'mom_{w}' for w in MOM_W], key=lambda x: is_m[x])
        br_ = max([f'rev_{w}' for w in MOM_W], key=lambda x: is_m[x])
        rs_names = [n for n in names if n.startswith('rs_')]
        brs = max(rs_names, key=lambda x: is_m[x])
        store[cost] = dict(nets=nets, best=best, is_m=is_m,
                           oos_best=oos_best, oos_bh=oos_bh,
                           best_rs=brs, oos_rs=nets[brs][split:].mean()*1e4,
                           bm=bm_, oos_mom=nets[bm_][split:].mean()*1e4,
                           br=br_, oos_rev=nets[br_][split:].mean()*1e4)
        print(f"\n  -- 单边成本 {cost}bp --")
        print(f"    样本内全族最优: {best:<20} 样本外 {oos_best:>8.3f} bp/bar  "
              f"(年化 {oos_best*BARS_YR/100:>7.2f}%)")
        print(f"    regime族最优  : {brs:<20} 样本外 {store[cost]['oos_rs']:>8.3f} bp/bar")
        print(f"    纯动量最优    : {bm_:<20} 样本外 {store[cost]['oos_mom']:>8.3f} bp/bar")
        print(f"    纯反转最优    : {br_:<20} 样本外 {store[cost]['oos_rev']:>8.3f} bp/bar")
        print(f"    买入持有 BH   : {'BH':<20} 样本外 {oos_bh:>8.3f} bp/bar  "
              f"(年化 {oos_bh*BARS_YR/100:>7.2f}%)")

    # Reality Check (0bp 与 20bp)
    print(f"\n  【Reality Check】circular block bootstrap, 校正{M}个策略的多重挑选:")
    for cost in [0, 20, 50]:
        d = store[cost]
        nets = d['nets']
        mat = np.array([nets[nm][split:] for nm in names])
        bi = names.index(d['best'])
        ob, p = reality_check(mat, bi, seed=11)
        rs_names = [n for n in names if n.startswith('rs_')]
        mat_rs = np.array([nets[nm][split:] for nm in rs_names])
        brs_i = rs_names.index(d['best_rs'])
        ob_rs, p_rs = reality_check(mat_rs, brs_i, seed=12)
        print(f"    成本{cost:>2}bp | 全族最优 p={p:.3f} ({'显著' if p<0.05 else '不显著'})"
              f"   | regime族最优 p={p_rs:.3f} ({'显著' if p_rs<0.05 else '不显著'})")

    # Regime 诊断 (样本外)
    print(f"\n  【诊断】样本外按ER状态分组 (用样本内最优regime参数):")
    d = store[20]
    brs = d['best_rs']
    _, prm = meta[brs]
    n_, w_, thr_ = prm
    er = calc_er(close, n_)
    m = mom[w_]
    er_o = er[split:]
    m_o = m[split:]
    fwd = np.roll(ret[split:], -1)
    fwd[-1] = np.nan
    ok = ~np.isnan(er_o) & ~np.isnan(fwd)
    tr = ok & (er_o > thr_)
    ch = ok & (er_o <= thr_)
    mom_sig = np.sign(m_o)
    mt = (mom_sig[tr] * fwd[tr]).mean() * 1e4
    rt = (-mom_sig[tr] * fwd[tr]).mean() * 1e4
    mc = (mom_sig[ch] * fwd[ch]).mean() * 1e4
    rc = (-mom_sig[ch] * fwd[ch]).mean() * 1e4
    print(f"    参数 ER(n={n_}) 动量(w={w_}) 阈值={thr_}")
    print(f"    趋势态 (n={tr.sum():>5}bar): 动量 {mt:+8.3f} | 反转 {rt:+8.3f} bp/bar")
    print(f"    震荡态 (n={ch.sum():>5}bar): 动量 {mc:+8.3f} | 反转 {rc:+8.3f} bp/bar")
    if mt > rt and rc > mc:
        print(f"    -> Claude假设成立: 趋势态动量优、震荡态反转优")
    else:
        print(f"    -> Claude假设【不成立】")
    print(f"    (用时 {time.time()-t0:.0f}s)")


print("=" * 104)
print("1小时 OHLC 价格行为检验 —— 向量化 + walk-forward + Reality Check")
print("=" * 104)
for s, p in FILES.items():
    try:
        analyze(s, p)
    except Exception as e:
        import traceback
        print(f"[!] {s}: {e}")
        traceback.print_exc()
