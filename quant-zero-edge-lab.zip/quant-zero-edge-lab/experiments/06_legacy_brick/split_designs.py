import numpy as np, pandas as pd
FILES={'DOGE':'/data/inputs/DOGEUSDT_1h.csv','DOT':'/data/inputs/DOTUSDT_1h.csv',
       'CRV':'/data/inputs/CRVUSDT_1h.csv','DASH':'/data/inputs/DASHUSDT_1h.csv',
       'ETH':'/data/inputs/ETHUSDT_1h.csv','FIL':'/data/inputs/FILUSDT_1h.csv',
       'HBAR':'/data/inputs/HBARUSDT_1h.csv'}
OLD=['DOGE','DOT','CRV','DASH']; NEW=['ETH','FIL','HBAR']
def load():
    o={}
    for k,p in FILES.items():
        d=pd.read_csv(p);c={x.lower():x for x in d.columns}
        o[k]=dict(open=d[c['open']].values.astype(float),high=d[c['high']].values.astype(float),
                  low=d[c['low']].values.astype(float),close=d[c['close']].values.astype(float))
    return o
def s_mom(cl,w):
    n=len(cl);s=np.zeros(n);s[w:]=np.sign(cl[w:]/np.maximum(cl[:-w],1e-9)-1);return s
def s_brk(cl,w):
    n=len(cl);s=np.zeros(n)
    for i in range(w,n):
        h=cl[i-w:i].max();l=cl[i-w:i].min()
        if cl[i]>h:s[i]=1
        elif cl[i]<l:s[i]=-1
    return s

def run(D,sg,s,R,cost_bp,slip_bp,max_hold,start,end,mode):
    """mode='flip' 信号驱动; mode='target' 目标驱动"""
    op,hi,lo,cl=D['open'],D['high'],D['low'],D['close']
    n=len(cl) if end is None else min(end,len(cl))
    cR=2*cost_bp/1e4/s; slipR=slip_bp/1e4/s; stopd=s+slip_bp/1e4
    recs=[];i=max(start,120)
    while i<n-3:
        d=1 if sg[i]>0 else (-1 if sg[i]<0 else 0)
        if d==0:i+=1;continue
        e=op[i+1];i0=i+1;out=None;j=i0;kind='timeout'
        for jj in range(i0,min(i0+max_hold,n)):
            adv=(lo[jj]/e-1) if d==1 else (1-hi[jj]/e)
            fav=(hi[jj]/e-1) if d==1 else (1-lo[jj]/e)
            if adv<=-stopd: out=-1.0-slipR;j=jj;kind='stop';break
            if fav>=R*s: out=R;j=jj;kind='target';break
            if mode=='flip' and sg[jj]*d<0:
                out=((cl[jj]/e-1)*d)/s;j=jj;kind='flip';break
        if out is None:
            j=min(i0+max_hold,n-1);out=((cl[j]/e-1)*d)/s;kind='timeout'
        recs.append((kind,out,out-cR,j-i0));i=j+1
    return pd.DataFrame(recs,columns=['kind','gross','net','hold'])

def agg(frames,R,s,cost_bp):
    df=pd.concat(frames,ignore_index=True)
    cR=2*cost_bp/1e4/s
    n=len(df)
    hit_t=(df.kind=='target').mean(); hit_s=(df.kind=='stop').mean()
    # 实际盈亏比
    win=df[df.net>0]; loss=df[df.net<=0]
    realR=win.gross.mean()/abs(loss.gross.mean()) if len(loss)>0 and loss.gross.mean()!=0 else np.nan
    # 理论p*
    pstar=(1+cR)/(R+1)
    return dict(n=n,
        hit_target=hit_t,
        win_rate_net=(df.net>0).mean(),
        E_net=df.net.mean(),
        E_gross=df.gross.mean(),
        t=df.net.mean()/(df.net.std()/np.sqrt(n)) if df.net.std()>0 else 0,
        realR=realR,
        pstar=pstar,
        avg_hold=df.hold.mean(),
        cost=cR)

data=load()
print("="*108)
print("【两套设计分离测试】各自用正确的指标, 7品种样本外")
print("="*108)
SIG={'mom_5':lambda c:s_mom(c,5),'rev_5':lambda c:-s_mom(c,5),'mom_20':lambda c:s_mom(c,20),
     'rev_20':lambda c:-s_mom(c,20),'brk_20':lambda c:s_brk(c,20)}

for mode,title in [('flip','设计1 信号驱动: 翻转即平 | 指标=平仓时为正% + 平均hold'),
                   ('target','设计2 目标驱动: 只认止损止盈 | 指标=触止盈% + 实际盈亏比')]:
    print("\n"+"="*108)
    print(f"### {title}")
    print("="*108)
    if mode=='flip':
        print(f"  {'信号':<9}{'N':>7}{'平仓为正%':>10}{'flip占比':>9}{'止盈占比':>9}{'平均hold':>9}{'毛E(R)':>9}{'净E(R)':>9}{'t':>8}")
    else:
        print(f"  {'信号':<9}{'N':>7}{'触止盈%':>9}{'触止损%':>9}{'p*':>8}{'实际R':>8}{'平均hold':>9}{'毛E(R)':>9}{'净E(R)':>9}{'t':>8}")
    print("  "+"-"*104)
    for nm,fn in SIG.items():
        frames=[]
        for k,D in data.items():
            n=len(D['close'])
            sg=fn(D['close'])
            f=run(D,sg,0.05,2.0,2,5,800,n//2,n,mode)
            if len(f)>=30: frames.append(f)
        if not frames: continue
        a=agg(frames,2.0,0.05,2)
        if mode=='flip':
            df=pd.concat(frames,ignore_index=True)
            fp=(df.kind=='flip').mean(); tg=(df.kind=='target').mean()
            print(f"  {nm:<9}{a['n']:>7}{a['win_rate_net']*100:>9.1f}%{fp*100:>8.1f}%{tg*100:>8.1f}%{a['avg_hold']:>9.1f}{a['E_gross']:>+9.4f}{a['E_net']:>+9.4f}{a['t']:>+8.2f}")
        else:
            print(f"  {nm:<9}{a['n']:>7}{a['hit_target']*100:>8.1f}%{(1-a['hit_target'])*100:>8.1f}%{a['pstar']*100:>7.1f}%{a['realR']:>8.2f}{a['avg_hold']:>9.1f}{a['E_gross']:>+9.4f}{a['E_net']:>+9.4f}{a['t']:>+8.2f}")
    print(f"  (p* = 盈亏平衡所需触止盈率 = (1+成本R)/(R+1))")

print("\n"+"="*108)
print("【设计2 成本敏感性】brk_20 在不同成本下")
print("="*108)
print(f"  {'成本(bp)':<10}{'N':>7}{'触止盈%':>9}{'p*':>8}{'毛E(R)':>10}{'净E(R)':>10}{'t':>8}")
print("  "+"-"*62)
for cb in [0,1,2,5,10,20]:
    frames=[]
    for k,D in data.items():
        n=len(D['close'])
        sg=s_brk(D['close'],20)
        f=run(D,sg,0.05,2.0,cb,5,800,n//2,n,'target')
        if len(f)>=30: frames.append(f)
    if not frames: continue
    a=agg(frames,2.0,0.05,cb)
    print(f"  {cb:<10}{a['n']:>7}{a['hit_target']*100:>8.1f}%{a['pstar']*100:>7.1f}%{a['E_gross']:>+10.4f}{a['E_net']:>+10.4f}{a['t']:>+8.2f}")

print("\n"+"="*108)
print("【品种外推】两套设计各自: 旧4选 -> 新3验")
print("="*108)
for mode in ['flip','target']:
    print(f"\n  --- {mode} ---")
    # 旧4选最优信号
    best=None;bE=-9
    for nm,fn in SIG.items():
        fr=[]
        for k in OLD:
            D=data[k];n=len(D['close'])
            f=run(D,fn(D['close']),0.05,2.0,2,5,800,n//2,n,mode)
            if len(f)>=30: fr.append(f)
        if not fr: continue
        a=agg(fr,2.0,0.05,2)
        if a['E_net']>bE: bE=a['E_net'];best=nm
    fr=[]
    for k in NEW:
        D=data[k];n=len(D['close'])
        f=run(D,SIG[best](D['close']),0.05,2.0,2,5,800,n//2,n,mode)
        if len(f)>=30: fr.append(f)
    v=agg(fr,2.0,0.05,2)
    print(f"  旧4选中: {best}  E={bE:+.4f}R")
    print(f"  新3验证: N={v['n']} 毛E={v['E_gross']:+.4f} 净E={v['E_net']:+.4f} t={v['t']:+.2f}")
print("\n"+"="*108)
