# -*- coding: utf-8 -*-
import sys, numpy as np, pandas as pd, warnings
sys.path.insert(0,'/data/workspace/brick')
warnings.filterwarnings('ignore')
from entry_lib import *
from scipy import stats

def full(sig, df, cost=0.0002):
    o,h,l=df['open'].values,df['high'].values,df['low'].values; n=len(o)
    s=np.asarray(sig,float); nz=np.where(s!=0)[0]
    if len(nz)<100: return None
    s=s.copy(); s[:nz[0]]=0
    eff=np.where(s==0,0,s); prev=np.roll(eff,1); prev[0]=0
    chg=(eff!=prev)&(eff!=0); st=np.where(chg)[0]; st=st[st+1<n]
    if len(st)<5: return None
    ei=st+1; xi=np.roll(ei,-1); xi[-1]=n-1
    v=xi>ei; ei,xi=ei[v],xi[v]
    if len(ei)<5: return None
    d=eff[st][v]; ep=o[ei]; xp=o[xi]
    raw=(xp-ep)/ep*d
    cnt=xi-ei; bseg=np.repeat(np.arange(len(ei)),cnt)
    st0=ei[0]; idx=np.arange(st0,st0+cnt.sum())
    lmin=np.full(len(ei),np.inf); np.minimum.at(lmin,bseg,l[idx])
    hmax=np.full(len(ei),-np.inf); np.maximum.at(hmax,bseg,h[idx])
    sp=np.where(d>0,ep*(1-0.05),ep*(1+0.05))
    hs=np.where(d>0,lmin<=sp,hmax>=sp)
    ret=np.where(hs,-0.05,raw)-2*cost
    bh=(xp-ep)/ep
    dur=(df['timestamp'].values[xi]-df['timestamp'].values[ei])/(3600*1000.)
    return dict(E=(ret/0.05).mean(), bh=bh, dur=dur, n=len(ei), d=d,
                yrs=(df['timestamp'].values[-1]-df['timestamp'].values[0])/(365.25*24*3600*1000))

print('='*90)
print('诊断A: 换手率 vs 期望  (13品种, maker 2bp)')
print('='*90)
recs=[]
for sym in ALL13[:5]:
    df=load(sym); S=build_signals(df)
    for nm,sg in S.items():
        if nm.startswith('_'): continue
        r=full(sg,df)
        if r and r['n']>50:
            recs.append(dict(sig=nm,sym=sym,E=r['E'],ntr=r['n'],
                             turn=r['n']/r['yrs'], yrs=r['yrs']))
R=pd.DataFrame(recs)
R['bin']=pd.qcut(R['turn'],5,labels=['Q1最低换手','Q2','Q3','Q4','Q5最高换手'])
g=R.groupby('bin',observed=True).agg(n=('E','size'),E_mean=('E','mean'),
    E_med=('E','median'),pos=('E',lambda x:(x>0).mean()),turn=('turn','median'))
print(g.to_string(float_format=lambda x:f'{x:9.4f}'))

print()
print('='*90)
print('诊断B: mom240 的 alpha (唯一为正) — 配对检验 vs 买入持有')
print('='*90)
diffs=[]
for sym in ALL13:
    df=load(sym); S=build_signals(df)
    r=full(S['mom240'],df)
    if r is None: continue
    ann_s = r['E']*0.05*r['n']/r['yrs']
    ann_b = (r['bh']*r['dur']).sum()/ (r['dur'].sum()) * (r['dur'].sum()/ (r['yrs']*24*365))
    # 简化: 同期BH年化 = 全程持有收益 / 年数
    o=df['open'].values
    bh_ann = (o[-1]/o[0])**(1/r['yrs'])-1
    diffs.append(ann_s - bh_ann)
diffs=np.array(diffs)
t=diffs.mean()/(diffs.std(ddof=1)/np.sqrt(len(diffs)))
print(f'13品种 alpha(策略年化-BH年化): 均值={diffs.mean():+.4f}  中位={np.median(diffs):+.4f}  t={t:.3f} 为正比例={(diffs>0).mean():.2f}')
w=stats.wilcoxon(diffs); print(f'Wilcoxon 符号秩 p={w.pvalue:.4f}')

print()
print('='*90)
print('诊断C: 时段效应 (UTC小时) — 训练集OLD7定方向, 干净集NEW6验证')
print('='*90)
hr_ret={}
for sym in OLD7:
    df=load(sym); o=df['open'].values
    hr=pd.to_datetime(df['timestamp'].values,unit='ms').hour
    r=np.zeros(len(o)); r[1:]=o[1:]/o[:-1]-1
    for hh in range(24):
        m=(hr==hh)&(np.arange(len(o))>0)
        hr_ret.setdefault(hh,[]).append(r[m].mean())
hb={h:np.mean(v) for h,v in hr_ret.items()}
print('OLD7 各UTC小时平均bar收益(bp):')
print(' '.join(f'{h}:{hb[h]*1e4:+.1f}' for h in range(24)))
# 用OLD7方向在NEW6验证
vals=[]
for sym in NEW6:
    df=load(sym); o=df['open'].values
    hr=pd.to_datetime(df['timestamp'].values,unit='ms').hour
    r=np.zeros(len(o)); r[1:]=o[1:]/o[:-1]-1
    sig=np.sign(np.array([hb[h] for h in hr]))
    rr=r*sig
    m=np.arange(len(o))>0
    vals.append(rr[m].mean())
vals=np.array(vals)
t=vals.mean()/(vals.std(ddof=1)/np.sqrt(len(vals)))
print(f'NEW6 验证: 均值={vals.mean()*1e4:+.3f}bp/bar  为正比例={(vals>0).mean():.2f}  t={t:.3f}')
