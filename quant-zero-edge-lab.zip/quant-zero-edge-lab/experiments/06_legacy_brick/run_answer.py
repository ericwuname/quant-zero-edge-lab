"""
主实验: 什么样的策略具有正期望?
==================================
分两部分:
  A. bar级策略 × 市场宇宙 (无前视, 对数收益, 已扣成本)
  B. 砖块策略: 精确评估 + 伪影基线对照 (关键!)

铁律检验: 在 RW(随机游走) 市场里, 任何策略扣成本后必须 <= 0。
          如果显著 > 0 -> 说明还有 bug 或伪影, 结论不可信。
"""
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import pandas as pd
from zoo import (gen_market, BAR_STRATS, eval_bar, trade_stats,
                 eval_brick, BARS_PER_YEAR)

plt.rcParams['font.sans-serif'] = ['WenQuanYi Micro Hei', 'DejaVu Sans']
plt.rcParams['axes.unicode_minus'] = False

N = 12000
NSEED = 12
MARKETS = ["RW", "MOM", "MR", "REGIME", "VOL", "TRENDVOL", "JUMP"]
MK_LABEL = {
    "RW": "随机游走\n零结构", "MOM": "动量\n正自相关", "MR": "均值回归\n负自相关",
    "REGIME": "体制切换\n趋势/震荡", "VOL": "波动聚集\n无方向",
    "TRENDVOL": "趋势+波动\n最像真实", "JUMP": "跳跃肥尾",
}

# ============================================================
# A. bar级策略矩阵
# ============================================================
print("=" * 92)
print("实验A: bar级策略 × 市场 —— 年化【几何】增长率 % (对数收益, 已扣成本, 无前视)")
print("=" * 92)

res = np.zeros((len(BAR_STRATS), len(MARKETS)))
shp = np.zeros_like(res)
ntr = np.zeros_like(res)
sig = np.zeros_like(res)

for mi, mk in enumerate(MARKETS):
    for si, (sname, fn) in enumerate(BAR_STRATS.items()):
        vals, shs, nts = [], [], []
        for s in range(NSEED):
            px, _ = gen_market(mk, N, seed=1000 * (mi + 1) + s)
            raw = fn(px)
            e = eval_bar(px, raw)
            vals.append(e["ret_ann"] * 100)
            shs.append(e["sharpe"])
            nts.append(e["n_trades"])
        v = np.array(vals)
        res[si, mi] = v.mean(); shp[si, mi] = np.mean(shs); ntr[si, mi] = np.mean(nts)
        sig[si, mi] = v.mean() / (v.std() / np.sqrt(len(v))) if v.std() > 0 else 0

df = pd.DataFrame(res, index=list(BAR_STRATS.keys()),
                  columns=[MK_LABEL[m].replace("\n", "") for m in MARKETS])
print("\n" + df.round(2).to_string())

print("\n" + "-" * 92)
print("判定: * 显著为正(t>2)   x 显著为负(t<-2)   空白 与零无异")
print("-" * 92)
print(f"{'策略':<10}" + "".join(f"{MK_LABEL[m].split(chr(10))[0]:>10}" for m in MARKETS))
for si, sname in enumerate(BAR_STRATS.keys()):
    line = f"{sname:<10}"
    for mi in range(len(MARKETS)):
        t = sig[si, mi]
        m = "*" if t > 2 else ("x" if t < -2 else " ")
        line += f"{res[si,mi]:>8.2f}{m} "
    print(line)

# 铁律检验
print("\n" + "=" * 92)
print("【铁律检验】随机游走(RW)市场里: 扣成本后所有策略必须 <= 0")
print("=" * 92)
rw_idx = MARKETS.index("RW")
ok = True
for si, sname in enumerate(BAR_STRATS.keys()):
    v, t = res[si, rw_idx], sig[si, rw_idx]
    flag = "OK" if v <= 0.5 else "!!! 违反(有bug或伪影)"
    if v > 0.5:
        ok = False
    print(f"  {sname:<10} {v:>8.2f}%  {flag}")
print(f"\n  => 铁律{'通过: 框架可信' if ok else '未通过'}")

# ============================================================
# B. 砖块策略 (精确评估 + 伪影基线)
# ============================================================
print("\n" + "=" * 92)
print("实验B: 砖块策略 —— 精确trade级评估 + 伪影基线对照")
print("  伪影基线 = 同A下【随机游走】测出的延续概率p0; 真edge = p - p0")
print("=" * 92)

# 用细采样压制伪影: sigma_bar 小
SIG_FINE = 0.002       # 0.2%/bar (细采样)
A_PCT = 1.0            # 砖块 = 1%
A_PRICE = A_PCT        # 价格从100起, A=1价格单位

print(f"\n  设置: σ_bar={SIG_FINE*100:.1f}%, 砖块A={A_PCT:.0f}%, σ_bar/A={SIG_FINE*100/A_PCT:.3f}")
print(f"  {'市场':<12} {'砖数N':>7} {'实测p':>8} {'伪影基线p0':>11} {'真实p':>8} {'p*成本':>7} {'每笔净期望':>11} {'判定':>10}")

brick_rows = []
# 先算伪影基线 (RW)
base_ps = []
for s in range(NSEED):
    px, _ = gen_market("RW", N, seed=9000 + s, sigma=SIG_FINE)
    e = eval_brick(px, A_PRICE)
    if e:
        base_ps.append(e["p_cont"])
p0 = np.mean(base_ps) if base_ps else np.nan

cost_rel = 0.0005
c = cost_rel / (A_PCT / 100.0)          # 成本占砖块幅度比例
pstar = (1 + c) / 2

for mk in MARKETS:
    ps, exps, ns, ws = [], [], [], []
    for s in range(NSEED):
        px, _ = gen_market(mk, N, seed=1000 * (MARKETS.index(mk) + 1) + s, sigma=SIG_FINE)
        e = eval_brick(px, A_PRICE)
        if e:
            ps.append(e["p_cont"]); exps.append(e["exp_per"]); ns.append(e["n"]); ws.append(e["win"])
    if not ps:
        continue
    p = np.mean(ps); exp_ = np.mean(exps); n = np.mean(ns)
    p_true = p - (p0 - 0.5)              # 扣伪影
    net_true = (2 * p_true - 1) * (A_PCT / 100.0) - cost_rel
    verdict = "正期望" if net_true > 0 else "负期望"
    brick_rows.append((mk, n, p, p0, p_true, pstar, net_true, exp_))
    print(f"  {mk:<12} {n:>7.0f} {p:>8.4f} {p0:>11.4f} {p_true:>8.4f} {pstar:>7.3f} {net_true:>+11.6f} {verdict:>10}")

print(f"\n  成本: 每笔往返 {cost_rel*100:.2f}%  占砖块 {c*100:.1f}%  -> 盈亏平衡胜率 p* = {pstar:.4f}")
print(f"  伪影: 随机游走基线 p0 = {p0:.4f} (偏离0.5达 {p0-0.5:+.4f})")

# 砖块·反转 (负自相关市场里应该有效)
print(f"\n  砖块·反转策略 (赌折返):")
print(f"  {'市场':<12} {'反转胜率':>9} {'扣伪影':>8} {'每笔净期望':>11} {'判定':>10}")
rev_rows = []
for mk in MARKETS:
    ps, exps = [], []
    for s in range(NSEED):
        px, _ = gen_market(mk, N, seed=1000 * (MARKETS.index(mk) + 1) + s, sigma=SIG_FINE)
        e = eval_brick(px, A_PRICE, reverse=True)
        if e:
            ps.append(e["p_cont"]); exps.append(e["exp_per"])
    if not ps:
        continue
    p = np.mean(ps)
    p_true = p - (0.5 - (p0 - 0.5))      # 反转的伪影是镜像的
    net_true = (2 * p_true - 1) * (A_PCT / 100.0) - cost_rel
    verdict = "正期望" if net_true > 0 else "负期望"
    rev_rows.append((mk, p, p_true, net_true))
    print(f"  {mk:<12} {p:>9.4f} {p_true:>8.4f} {net_true:>+11.6f} {verdict:>10}")

# ============================================================
# 图
# ============================================================
fig = plt.figure(figsize=(17, 10))
gs = fig.add_gridspec(2, 2, hspace=0.32, wspace=0.22)
fig.suptitle("什么样的策略具有正期望？—— 答案：取决于【市场结构 × 策略结构】是否匹配",
             fontsize=14.5, fontweight='bold')

ax = fig.add_subplot(gs[0, :])
im = ax.imshow(res, cmap='RdYlGn', vmin=-14, vmax=14, aspect='auto')
ax.set_xticks(range(len(MARKETS)))
ax.set_xticklabels([MK_LABEL[m] for m in MARKETS], fontsize=9.5)
ax.set_yticks(range(len(BAR_STRATS)))
ax.set_yticklabels(list(BAR_STRATS.keys()), fontsize=10)
for i in range(len(BAR_STRATS)):
    for j in range(len(MARKETS)):
        v, t = res[i, j], sig[i, j]
        m = "*" if t > 2 else ("x" if t < -2 else "")
        col = 'white' if abs(v) > 9 else 'black'
        ax.text(j, i, f"{v:.1f}{m}", ha='center', va='center', fontsize=9.5,
                color=col, fontweight='bold' if m else 'normal')
ax.set_title("① bar级策略 × 市场：年化几何增长 %（对数收益·已扣成本·无前视）\n"
             "绿=正期望  红=负期望  *=显著   关键：随机游走(RW)那一列必须全红 —— 否则就是伪影/bug",
             fontsize=11)
plt.colorbar(im, ax=ax, shrink=0.75)

ax = fig.add_subplot(gs[1, 0])
mk_names = [r[0] for r in brick_rows]
net_vals = [r[6] for r in brick_rows]
cols = ['green' if v > 0 else 'salmon' for v in net_vals]
ax.bar(range(len(mk_names)), net_vals, color=cols)
ax.axhline(0, color='k', lw=1.2)
ax.set_xticks(range(len(mk_names)))
ax.set_xticklabels(mk_names, rotation=30, fontsize=9)
ax.set_ylabel("每笔净期望（已扣伪影+成本）")
ax.set_title("② 砖块·延续策略：只在有真实动量的市场正期望", fontsize=11)
ax.grid(alpha=.3, axis='y')

ax = fig.add_subplot(gs[1, 1])
w = 0.38
xs = np.arange(len(brick_rows))
ax.bar(xs - w / 2, [r[6] for r in brick_rows], w, label='砖块·延续', color='steelblue')
ax.bar(xs + w / 2, [r[3] for r in rev_rows], w, label='砖块·反转', color='darkorange')
ax.axhline(0, color='k', lw=1.2)
ax.set_xticks(xs)
ax.set_xticklabels([r[0] for r in brick_rows], rotation=30, fontsize=9)
ax.set_ylabel("每笔净期望")
ax.set_title("③ 两个镜像策略：同一市场里正负严格相反\n(动量市→延续赢；震荡市→反转赢)", fontsize=11)
ax.legend(fontsize=9)
ax.grid(alpha=.3, axis='y')

plt.savefig("/data/workspace/brick/fig_answer.png", dpi=130)
print("\n[已保存] fig_answer.png")
