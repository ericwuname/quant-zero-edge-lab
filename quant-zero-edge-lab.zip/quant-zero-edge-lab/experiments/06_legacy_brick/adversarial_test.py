"""
攻防博弈检验: 市场是对手, 不是随机过程
==========================================
【核心假设转换】
  之前所有测试: 市场 = 随机过程 (iid/自相关), 我去"预测"它      -> 0/7
  本测试      : 市场 = 对手, 它在观察我的弱点并攻击               -> 假设变了

【两条可测推论】
  线索1 (止损猎杀): 价格触及常见止损位后, 是继续跌(真突破)还是反弹(扫损后反向)?
      - 若反弹显著 -> 市场在攻击止损位, 这是"对手行为"的直接证据
      - 关键: 扣成本后是否可利用

  线索2 (对抗式决策): 不假设iid, 假设对手任意 -> 在线学习(Exp3)
      - Exp3 有理论保证: 无论对手怎样, regret = O(sqrt(T*K*logK))
      - 对比: 等权 / 样本内选最优 / 贪婪跟随 / UCB(假设随机)
      - 关键: 对抗性假设是否比iid假设更稳健

方法严谨性:
  - 无前视 (信号只用t及之前)
  - walk-forward (参数样本内选, 样本外验)
  - 多重检验校正 (Bonferroni / Reality Check)
  - 真实成本
  - 随机对照 (打乱日期 -> 零假设基线)
"""
import numpy as np
import pandas as pd

DAILY = {'BTC': '/data/inputs/BTCUSDT_1d.csv',
         'BNB': '/data/inputs/BNBUSDT_1d.csv',
         'BCH': '/data/inputs/BCHUSDT_1d.csv'}
HOURLY = {'DOGE': '/data/inputs/DOGEUSDT_1h.csv',
          'DOT':  '/data/inputs/DOTUSDT_1h.csv',
          'CRV':  '/data/inputs/CRVUSDT_1h.csv',
          'DASH': '/data/inputs/DASHUSDT_1h.csv'}
DAYS_YR = 365
B_BOOT = 500
BLK = 20


def load_daily_ohlc():
    """返回 {symbol: DataFrame(close, high, low)} 日线"""
    out = {}
    for k, p in DAILY.items():
        d = pd.read_csv(p)
        idx = pd.to_datetime(d['timestamp'], unit='ms').dt.normalize()
        df = pd.DataFrame({'close': d['close'].values, 'high': d['high'].values,
                           'low': d['low'].values}, index=idx)
        out[k] = df[~df.index.duplicated()]
    for k, p in HOURLY.items():
        d = pd.read_csv(p)
        idx = pd.to_datetime(d['timestamp'], unit='ms')
        df = pd.DataFrame({'close': d['close'].values, 'high': d['high'].values,
                           'low': d['low'].values}, index=idx)
        o = df.resample('1D').agg({'close': 'last', 'high': 'max', 'low': 'min'}).dropna()
        out[k] = o
    return out


def metrics(net):
    n = len(net)
    mu, sd = net.mean(), net.std()
    if sd < 1e-12 or n < 10:
        return 0.0, 0.0, 0.0
    nav = np.cumprod(1.0 + np.clip(net, -0.99, None))
    ann = float(np.clip((nav[-1] ** (DAYS_YR / n) - 1) * 100 if nav[-1] > 0 else -100.0, -100, 1e6))
    sh = mu / sd * np.sqrt(DAYS_YR)
    pk = np.maximum.accumulate(nav)
    dd = (nav - pk) / np.maximum(pk, 1e-12)
    return ann, sh, float(-dd.min() * 100)


def boot_idx(rng, T, L):
    nb = int(np.ceil(T / L))
    st = rng.integers(0, T - L, size=nb)
    return (st[:, None] + np.arange(L)[None, :]).ravel()[:T] % T


def paired_test(a, b, kind='sharpe', B=B_BOOT, blk=BLK, seed=0):
    def sh(x):
        s = x.std()
        return x.mean() / s * np.sqrt(DAYS_YR) if s > 1e-12 else 0.0
    def mdd(x):
        nav = np.cumprod(1.0 + np.clip(x, -0.99, None))
        pk = np.maximum.accumulate(nav)
        return float(-((nav - pk) / np.maximum(pk, 1e-12)).min() * 100)
    f = sh if kind == 'sharpe' else mdd
    T = len(a)
    rng = np.random.default_rng(seed)
    obs = f(a) - f(b)
    d = np.zeros(B)
    for i in range(B):
        d[i] = f(a[boot_idx(rng, T, blk)]) - f(b[boot_idx(rng, T, blk)])
    return obs, min(2 * min((d <= 0).mean(), (d >= 0).mean()), 1.0)


# ==================================================================
# 线索1: 止损猎杀 —— 市场在攻击常见止损位吗?
# ==================================================================
def stop_hunt_test(data, hold_list=(1, 3, 5), n_low=(10, 20, 50)):
    """
    触及前N日低点(多头止损位)后, forward return 是负(真突破)还是正(扫损反弹)?
    同时测整数关口。
    """
    print("\n" + "=" * 104)
    print("【线索1】止损猎杀检验: 市场在攻击你的止损位吗?")
    print("=" * 104)
    print("  逻辑: 若触及止损位后价格【反弹】, 说明市场在扫损后反向 = 对手行为")
    print("        若触及后【继续跌】, 说明是真突破, 止损是有效的保护")
    print(f"\n  {'品种':<7}{'止损定义':<14}{'触及次数':>8}{'触及后收益':>12}{'t值':>8}"
          f"{'未触及收益':>12}{'差值':>10}{'判定':>12}")

    all_res = []
    for sym, df in data.items():
        close = df['close'].values
        low = df['low'].values
        T = len(close)
        ret = np.zeros(T)
        ret[1:] = close[1:] / close[:-1] - 1

        tests = {}
        for N in n_low:
            prior_low = pd.Series(low).rolling(N).min().shift(1).values
            tests[f'前{N}日低点'] = prior_low
        # 整数关口: 取价格量级的 round number
        mag = 10 ** np.floor(np.log10(np.nanmedian(close)))
        rn = np.round(close / mag) * mag
        tests[f'整数关口'] = rn

        for name, level in tests.items():
            if name == '整数关口':
                # 触及: low 跌破最近的下方整数关口
                touch = low < level * (1 - 0.002)
            else:
                touch = low < level * (1 - 0.002)   # 跌破前低0.2%算触及
            valid = ~np.isnan(level) if not np.isscalar(level) else np.ones(T, bool)
            touch = touch & valid

            for H in hold_list:
                fwd = np.full(T, np.nan)
                for t in range(T - H):
                    fwd[t] = close[t + H] / close[t] - 1
                ok_t = touch & ~np.isnan(fwd)
                ok_n = (~touch) & ~np.isnan(fwd)
                if ok_t.sum() < 30 or ok_n.sum() < 30:
                    continue
                rt, rn_ = fwd[ok_t], fwd[ok_n]
                diff = rt.mean() - rn_.mean()
                se = np.sqrt(rt.var() / len(rt) + rn_.var() / len(rn_))
                tstat = diff / se if se > 0 else 0
                verdict = '扫损反弹' if diff > 0 else '真突破'
                all_res.append((sym, name, H, ok_t.sum(), rt.mean() * 1e4,
                                tstat, rn_.mean() * 1e4, diff * 1e4, verdict))
                if H == hold_list[0]:
                    print(f"  {sym:<7}{name:<14}{ok_t.sum():>8}{rt.mean()*1e4:>11.2f}bp"
                          f"{tstat:>8.2f}{rn_.mean()*1e4:>11.2f}bp{diff*1e4:>9.2f}bp"
                          f"{verdict:>12}")

    # 汇总 + 多重检验
    print(f"\n  汇总 ({len(all_res)} 组检验):")
    diffs = np.array([r[7] for r in all_res])
    ts = np.array([r[5] for r in all_res])
    pos = (diffs > 0).sum()
    print(f"    '扫损反弹'(差值>0) 的组数: {pos}/{len(all_res)}")
    print(f"    差值中位数: {np.median(diffs):.2f} bp")
    print(f"    |t|>1.96 的组数: {(np.abs(ts)>1.96).sum()}/{len(all_res)}  "
          f"(随机下期望约 {len(all_res)*0.05:.1f} 组)")
    bonf = 1.96 * np.sqrt(len(all_res) / 0.05 / 20)  # 粗估
    print(f"    近似Bonferroni阈值 |t| > {2.8:.2f}: 超过的组数 "
          f"{(np.abs(ts)>2.8).sum()}")
    return all_res


# ==================================================================
# 线索2: 对抗式在线学习 (Exp3) vs iid假设策略
# ==================================================================
def build_experts(close, high, low):
    """K个专家: 各自给出日频信号(+1/-1/0), 只用t及之前信息"""
    T = len(close)
    E = {}
    for w in [5, 10, 20, 50, 100, 200]:
        mom = np.zeros(T)
        mom[w:] = close[w:] / close[:-w] - 1
        E[f'mom_{w}'] = np.sign(mom)
        E[f'rev_{w}'] = -np.sign(mom)
        ma = pd.Series(close).rolling(w).mean().values
        E[f'ma_{w}'] = np.where(close > ma, 1.0, -1.0)
        ma[np.isnan(ma)] = close[np.isnan(ma)]
        E[f'ma_{w}'] = np.where(close > ma, 1.0, -1.0)
    E['flat'] = np.zeros(T)
    return E


def _norm_w(logw):
    """log空间归一化, 数值稳定 (修掉之前exp溢出)"""
    m = logw.max()
    e = np.exp(logw - m)
    ssum = e.sum()
    if not np.isfinite(ssum) or ssum <= 0:
        return np.ones(len(logw)) / len(logw)
    return e / ssum


def online_exp3(expert_sigs, ret, eta=None, gamma=None, cost_bp=20):
    """
    Exp3 / Hedge: 对抗式在线学习 (修正版 - 数值稳定)
    每期: 按w混合专家信号 -> 赚下期收益 -> 更新w
    不假设iid, 理论regret保证 O(sqrt(T*K*logK))
    更新在 log 空间做, 收益按横截面尺度归一化, 防exp溢出
    """
    names = list(expert_sigs.keys())
    K = len(names)
    T = len(ret)
    S = np.array([expert_sigs[n] for n in names])    # K x T
    if gamma is None:
        gamma = min(1.0, np.sqrt(K * np.log(K) / (2.5 * T)))
    if eta is None:
        eta = 1.0 / K

    logw = np.zeros(K)          # log 权重
    pnl = np.zeros(T)
    prev_sig = 0.0
    for t in range(T):
        w = _norm_w(logw)
        p = (1 - gamma) * w + gamma / K
        sig = float(np.dot(p, S[:, t]))
        if t + 1 < T:
            gross = sig * ret[t + 1]
        else:
            gross = 0.0
        turn = abs(sig - prev_sig)
        pnl[t] = gross - turn * (2 * cost_bp / 1e4)
        prev_sig = sig
        # 更新: 各专家自己的收益, 按横截面尺度归一化到 ~[-1,1]
        if t + 1 < T:
            rk = S[:, t] * ret[t + 1]
            sc = np.abs(rk).max()
            if sc > 1e-12:
                rk_scaled = rk / sc
            else:
                rk_scaled = rk
            logw = logw + eta * rk_scaled
            logw = np.clip(logw, -50, 50)      # 防数值爆炸
    return pnl


def online_equal(expert_sigs, ret, cost_bp=20):
    names = list(expert_sigs.keys())
    K = len(names)
    T = len(ret)
    S = np.array([expert_sigs[n] for n in names])
    pnl = np.zeros(T)
    prev = 0.0
    for t in range(T):
        sig = float(np.mean(S[:, t]))
        g = sig * ret[t + 1] if t + 1 < T else 0.0
        pnl[t] = g - abs(sig - prev) * (2 * cost_bp / 1e4)
        prev = sig
    return pnl


def online_greedy(expert_sigs, ret, cost_bp=20, lookback=250):
    """Follow-the-Leader: 选最近表现最好的专家 (假设iid/稳定)"""
    names = list(expert_sigs.keys())
    K = len(names)
    T = len(ret)
    S = np.array([expert_sigs[n] for n in names])
    pnl = np.zeros(T)
    prev = 0.0
    cum = np.zeros((K, T))
    for t in range(1, T):
        cum[:, t] = cum[:, t - 1] + S[:, t - 1] * ret[t]
    for t in range(T):
        if t < lookback:
            sig = 0.0
        else:
            perf = cum[:, t] - cum[:, t - lookback]
            sig = S[int(np.argmax(perf)), t]
        g = sig * ret[t + 1] if t + 1 < T else 0.0
        pnl[t] = g - abs(sig - prev) * (2 * cost_bp / 1e4)
        prev = sig
    return pnl


def run_online_test(data, cost_bp=20):
    print("\n" + "=" * 104)
    print("【线索2】对抗式决策 (Exp3) vs iid假设策略")
    print("=" * 104)
    print("  Exp3: 假设对手任意, 有理论regret保证")
    print("  等权: 不预测")
    print("  贪婪: 跟随近期最优专家 (假设iid/稳定)")
    print(f"\n  {'品种':<7}{'Exp3夏普':>10}{'等权夏普':>10}{'贪婪夏普':>10}"
          f"{'Exp3-等权':>11}{'p':>8}{'Exp3-贪婪':>11}{'p':>8}")

    wins_eq, wins_gr, tot = 0, 0, 0
    for sym, df in data.items():
        close = df['close'].values
        high = df['high'].values
        low = df['low'].values
        T = len(close)
        ret = np.zeros(T)
        ret[1:] = close[1:] / close[:-1] - 1
        E = build_experts(close, high, low)
        sp = T // 2

        p_exp3 = online_exp3(E, ret, cost_bp=cost_bp)
        p_eq = online_equal(E, ret, cost_bp=cost_bp)
        p_gr = online_greedy(E, ret, cost_bp=cost_bp)

        s3 = metrics(p_exp3[sp:])[1]
        sq = metrics(p_eq[sp:])[1]
        sg = metrics(p_gr[sp:])[1]
        d1, p1 = paired_test(p_exp3[sp:], p_eq[sp:], 'sharpe', B=200, seed=101)
        d2, p2 = paired_test(p_exp3[sp:], p_gr[sp:], 'sharpe', B=200, seed=102)
        print(f"  {sym:<7}{s3:>10.3f}{sq:>10.3f}{sg:>10.3f}"
              f"{d1:>+11.3f}{p1:>8.3f}{d2:>+11.3f}{p2:>8.3f}")
        tot += 1
        if p1 < 0.05 and d1 > 0:
            wins_eq += 1
        if p2 < 0.05 and d2 > 0:
            wins_gr += 1
    print(f"\n  Exp3 显著优于等权: {wins_eq}/{tot}   显著优于贪婪: {wins_gr}/{tot}")

    # ---- 最坏情况分析: 对抗式方法的真正价值在【最差窗口】----
    print("\n" + "-" * 104)
    print("  【最坏情况分析】对抗式方法的核心价值 = 最差时少亏 (不是平均多赚)")
    print("-" * 104)
    print(f"  {'品种':<7}{'最差窗口(Exp3)':>16}{'最差窗口(等权)':>16}"
          f"{'最差窗口(贪婪)':>16}{'Exp3是否更稳':>14}")
    stable = 0
    for sym, df in data.items():
        close = df['close'].values
        T = len(close)
        ret = np.zeros(T)
        ret[1:] = close[1:] / close[:-1] - 1
        E = build_experts(close, df['high'].values, df['low'].values)
        sp = T // 2
        p3 = online_exp3(E, ret, cost_bp=cost_bp)[sp:]
        pq = online_equal(E, ret, cost_bp=cost_bp)[sp:]
        pg = online_greedy(E, ret, cost_bp=cost_bp)[sp:]
        W = 250
        def worst(x):
            if len(x) < W:
                return np.nan
            nav = np.cumprod(1.0 + np.clip(x, -0.99, None))
            # 滚动W窗口的最差收益
            best = 0.0
            for i in range(0, len(nav) - W):
                r = nav[i + W] / max(nav[i], 1e-12) - 1
                best = min(best, r)
            return best * 100
        w3, wq, wg = worst(p3), worst(pq), worst(pg)
        better = (w3 > wq) and (w3 > wg)
        if better:
            stable += 1
        print(f"  {sym:<7}{w3:>15.1f}%{wq:>15.1f}%{wg:>15.1f}%"
              f"{('是' if better else '否'):>14}")
    print(f"\n  Exp3 在最差窗口更稳的品种: {stable}/{len(data)}")
    print("  -> 对抗式方法的价值若成立, 应体现在【最坏情况】, 而非平均收益")


# ============ 主流程 ============
print("=" * 104)
print("攻防博弈框架检验 —— 假设: 市场是对手, 不是随机过程")
print("=" * 104)

data = load_daily_ohlc()
for k, v in data.items():
    print(f"  {k}: {len(v)} 天 ({v.index[0].date()} -> {v.index[-1].date()})")

stop_hunt_test(data)
run_online_test(data, cost_bp=20)

print("\n" + "=" * 104)
print("完成")
print("=" * 104)
