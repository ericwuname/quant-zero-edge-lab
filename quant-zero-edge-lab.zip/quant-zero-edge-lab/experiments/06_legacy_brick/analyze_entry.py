import numpy as np, pandas as pd

FILES = {'DOGE':'/data/inputs/DOGEUSDT_1h.csv','DOT':'/data/inputs/DOTUSDT_1h.csv',
         'CRV':'/data/inputs/CRVUSDT_1h.csv','DASH':'/data/inputs/DASHUSDT_1h.csv',
         'ETH':'/data/inputs/ETHUSDT_1h.csv','FIL':'/data/inputs/FILUSDT_1h.csv',
         'HBAR':'/data/inputs/HBARUSDT_1h.csv'}

def load():
    o={}
    for k,p in FILES.items():
        d=pd.read_csv(p)
        o[k]=dict(close=d['close'].values.astype(float),
                  high=d['high'].values.astype(float),
                  low=d['low'].values.astype(float))
    return o

def mom(cl,w):
    n=len(cl); s=np.zeros(n)
    s[w:]=np.sign(cl[w:]/np.maximum(cl[:-w],1e-9)-1)
    return s

data=load()
print("="*92)
print("【入场信号体检】mom_5 = sign(close[t] / close[t-5] - 1)")
print("="*92)

print(f"\n[1] 信号分布 (全样本)")
print(f"{'品种':<7}{'多%':>8}{'空%':>8}{'零%':>8}{'翻转次数':>10}{'平均持续(bar)':>14}")
print("-"*60)
for k,D in data.items():
    s=mom(D['close'],5)
    long=(s>0).mean()*100; short=(s<0).mean()*100; zero=(s==0).mean()*100
    flips=np.sum(np.abs(np.diff(s))>0)
    runs=flips+1 if flips>0 else 1
    avg_run=len(s)/runs
    print(f"{k:<7}{long:>7.1f}%{short:>7.1f}%{zero:>7.1f}%{flips:>10}{avg_run:>14.1f}")

print(f"\n[2] 交易频率与持仓时长 (mom_5, s=5%, R=2, maker2bp, 样本外)")
def run(D,sg,s=0.05,R=2.0,cost_bp=2,max_hold=800,start=0,end=None):
    hi,lo,cl=D['high'],D['low'],D['close']
    n=len(cl) if end is None else min(end,len(cl))
    cR=2*cost_bp/1e4/s
    net=[];holds=[];dirs=[]
    i=max(start,120)
    while i<n-2:
        if sg[i]==0: i+=1; continue
        d=1 if sg[i]>0 else -1
        e=cl[i]; out=None; j=i
        for jj in range(i+1,min(i+max_hold,n)):
            adv=(lo[jj]/e-1) if d==1 else (1-hi[jj]/e)
            fav=(hi[jj]/e-1) if d==1 else (1-lo[jj]/e)
            if adv<=-s: out=-1.0;j=jj;break
            if fav>=R*s: out=R;j=jj;break
        if out is None:
            j=min(i+max_hold,n-1); out=((cl[j]/e-1)*d)/s
        net.append(out-cR); holds.append(j-i); dirs.append(d)
        i=j+1
    return np.array(net),np.array(holds),np.array(dirs)

print(f"{'品种':<7}{'笔数':>7}{'平均持仓(bar)':>14}{'中位持仓':>10}{'超时率%':>9}{'多单占比%':>10}")
print("-"*62)
for k,D in data.items():
    n=len(D['close']); sg=mom(D['close'],5)
    net,h,d=run(D,sg,start=n//2)
    if len(net)<30: continue
    to=(h>=799).mean()*100
    print(f"{k:<7}{len(net):>7}{h.mean():>14.1f}{np.median(h):>10.0f}{to:>9.1f}{(d>0).mean()*100:>10.1f}")

print(f"\n[3] 关键问题: 信号是'始终在市'还是'触发式'?")
k='DOGE'; D=data[k]; s5=mom(D['close'],5)
print(f"  非零信号占比: {(s5!=0).mean()*100:.2f}%  -> 几乎每个bar都有仓位")
print(f"  即: 不是'条件满足才入场', 而是'永远持仓, 方向跟5bar动量走'")
print(f"  => 它承担 100% 的 beta, 不是市场中性")

print(f"\n[4] 信号强度 vs 是否过滤 (用 |5bar收益| 分层, DOGE样本外)")
n=len(D['close']); sp=n//2
cl=D['close']
ret5=np.zeros(n); ret5[5:]=cl[5:]/np.maximum(cl[:-5],1e-9)-1
absr=np.abs(ret5)
q=np.nanpercentile(absr[sp:], [50,80])
sg_full=mom(cl,5)
for tag,mask in [('全部',np.ones(n,bool)),
                 ('|ret5|<=中位',absr<=q[0]),
                 ('中位<|ret5|<=80%',(absr>q[0])&(absr<=q[1])),
                 ('|ret5|>80%分位',absr>q[1])]:
    sg=np.where(mask,sg_full,0.0)
    net,h,d=run(D,sg,start=sp)
    if len(net)<30: continue
    E=net.mean(); t=E/(net.std()/np.sqrt(len(net)))
    print(f"  {tag:<20} N={len(net):>5} 胜率{(net>0).mean()*100:>5.1f}% E={E:+.3f}R t={t:+.2f}")
