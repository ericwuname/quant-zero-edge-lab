# -*- coding: utf-8 -*-
"""时段效应最终判决: beta中性确认 + 成本扣减 + 低成本变体 + NEW6干净验证"""
import sys, numpy as np, pandas as pd, warnings
sys.path.insert(0,'/data/workspace/brick')
warnings.filterwarnings('ignore')
from entry_lib import *

def hourstat(syms):
    acc={}
    for sym in syms:
        df=load(sym); o=df['open'].values
        hr=pd.to_datetime(df['timestamp'].values,unit='ms').hour
        r=np.zeros(len(o)); r[1:]=o[1:]/o[:-1]-1
        for hh in range(24):
            m=(hr==hh); m[0]=False
            acc.setdefault(hh,[]).append(r[m].mean())
    return {h:np.mean(v) for h,v in acc.items()}, acc

hb,acc = hourstat(OLD7)
print('OLD7 拟合的24小时方向 (bp/bar):')
print('  ' + ' '.join(f'{h:>2}h:{hb[h]*1e4:+5.1f}' for h in range(0,12)))
print('  ' + ' '.join(f'{h:>2}h:{hb[h]*1e4:+5.1f}' for h in range(12,24)))
npos=sum(1 for h in hb if hb[h]>0)
print(f'做多小时数={npos}, 做空小时数={24-npos}  -> 天然市场中性' if npos==12 else f'做多{npos}')

def trade_hours(df, hb, cost, mode='all', topk=24):
    o=df['open'].values; n=len(o)
    hr=pd.to_datetime(df['timestamp'].values,unit='ms').hour
    r=np.zeros(n); r[1:]=o[1:]/o[:-1]-1
    base=np.array([hb[h] for h in hr])
    if mode=='all':
        sig=np.sign(base)
    else:  # 只交易绝对值最大的topk个小时, 其余空仓
        order=np.argsort(-np.abs([hb[h] for h in range(24)]))
        keep=set(order[:topk])
        sig=np.array([np.sign(base[i]) if hr[i] in keep else 0 for i in range(n)])
    gross=r*sig
    # 换手: 相邻bar仓位变化才付往返成本
    pos=sig
    chg=np.zeros(n); chg[1:]=np.abs(np.diff(pos))>0
    net=gross - chg*2*cost
    m=np.arange(n)>0
    return net[m].mean(), gross[m].mean(), chg[m].mean()

print()
print('='*88)
print('判决: 时段效应扣成本后 (每根bar都按小时信号持仓)')
print('='*88)
print(f'{"模式":<28}{"成本":<10}{"毛(bp/bar)":>12}{"净(bp/bar)":>12}{"换手率":>10}{"NEW6为正":>10}')
for mode,topk,label in [('all',24,'全时段24h'),('top',8,'只做最强8h'),('top',6,'只做最强6h'),('top',4,'只做最强4h')]:
    for cname,c in [('maker2bp',0.0002),('taker10bp',0.0010)]:
        net=[];gr=[];tu=[]
        for sym in NEW6:
            df=load(sym); a,b,t=trade_hours(df,hb,c,mode,topk); net.append(a);gr.append(b);tu.append(t)
        net=np.array(net);gr=np.array(gr);tu=np.array(tu)
        t=net.mean()/(net.std(ddof=1)/np.sqrt(len(net)))
        print(f'{label:<28}{cname:<10}{gr.mean()*1e4:>12.3f}{net.mean()*1e4:>12.3f}{tu.mean():>10.2%}{(net>0).mean():>10.2f}   t={t:+.2f}')

print()
print('='*88)
print('beta中性确认: NEW6 上时段策略的多头/空头分解')
print('='*88)
for sym in NEW6:
    df=load(sym); o=df['open'].values
    hr=pd.to_datetime(df['timestamp'].values,unit='ms').hour
    r=np.zeros(len(o)); r[1:]=o[1:]/o[:-1]-1
    sig=np.sign(np.array([hb[h] for h in hr])); m=np.arange(len(o))>0
    L=r[m][sig[m]>0].mean(); S=r[m][sig[m]<0].mean()*-1
    print(f'{sym:>5}: 多头小时均收益={L*1e4:+7.3f}bp  空头小时(反向)收益={S*1e4:+7.3f}bp  差={(L+S)*1e4:+7.3f}bp')
