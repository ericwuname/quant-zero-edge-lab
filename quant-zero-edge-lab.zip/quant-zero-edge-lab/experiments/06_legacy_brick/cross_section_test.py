"""
横截面 / 相对价值 检验 (Cross-Sectional)
===========================================
与之前所有测试的【数学结构不同】:
  之前 = 单品种时序: 用 X 的过去 预测 X 的未来 (自相关)  -> 0/7
  本次 = 横截面    : 同一时刻横向比较, 做多相对强的/做空相对弱的
                     (可市场中性, 剔除beta, 剩下的才是纯alpha)

策略族:
  A. 横截面动量 (CSM): 按过去L天收益排序, 多top-k / 空bottom-k
  B. 横截面反转 (CSR): 反向
  C. BTC领先性 (LEAD): 用BTC滞后d天收益预测山寨未来收益 (经济学基础: 资金传导)
  D. 波动率目标 (VOLTARGET): 预测风险->调仓位 (不预测方向)
评价: 收益/夏普/回撤 + RealityCheck + 配对bootstrap + 成本
"""
import numpy as np
import pandas as pd
import time

# ---------- 数据 ----------
DAILY = {'BTC': '/data/inputs/BTCUSDT_1d.csv',
         'BNB': '/data/inputs/BNBUSDT_1d.csv',
         'BCH': '/data/inputs/BCHUSDT_1d.csv'}
HOURLY = {'DOGE': '/data/inputs/DOGEUSDT_1h.csv',
          'DOT':  '/data/inputs/DOTUSDT_1h.csv',
          'CRV':  '/data/inputs/CRVUSDT_1h.csv',
          'DASH': '/data/inputs/DASHUSDT_1h.csv'}

LOOKBACK = [5, 10, 20, 60]      # 横截面排序回看窗口
HOLD     = [1, 5, 10, 20]       # 持有期(天) - 越长换手越低
TOPK     = [1, 2]               # 多头/空头各取几个
COSTS    = [0, 10, 20]          # 单边成本 bp
B_BOOT   = 300
BLK      = 20
DAYS_YR  = 365


def load_daily():
    px = {}
    for k, p in DAILY.items():
        df = pd.read_csv(p)
        s = pd.Series(df['close'].values,
                      index=pd.to_datetime(df['timestamp'], unit='ms').dt.normalize())
        px[k] = s[~s.index.duplicated()]
    for k, p in HOURLY.items():
        df = pd.read_csv(p)
        s = pd.Series(df['close'].values,
                      index=pd.to_datetime(df['timestamp'], unit='ms'))
        px[k] = s.resample('1D').last().dropna()
    df = pd.DataFrame(px).dropna()
    return df


def build_panel(df):
    """返回 ret(t+1) 矩阵 与 各品种过去L天收益"""
    ret = df.pct_change()
    return df, ret


# ---------- 横截面策略 ----------
def cs_signal(ret, L, mode, topk):
    """
    每t日: 用 [t-L+1, t] 累计收益排序 -> 生成 t+1 的持仓权重
    mode: 'mom' 做多强 / 'rev' 做多弱
    返回 weights (T x N), 已对齐为 t+1 持仓
    """
    R = ret.values
    T, N = R.shape
    cum = pd.DataFrame(R).rolling(L).sum().values     # 过去L天累计收益
    W = np.zeros((T, N))
    for t in range(L, T - 1):
        row = cum[t]
        if np.isnan(row).any():
            continue
        order = np.argsort(row)
        if mode == 'mom':
            longs, shorts = order[-topk:], order[:topk]
        else:
            longs, shorts = order[:topk], order[-topk:]
        W[t + 1, longs] = 1.0 / topk
        W[t + 1, shorts] = -1.0 / topk
    return W


def hold_signal(W, H):
    """持有期H天: 信号每H天更新一次, 中间保持不变 (降换手)"""
    T, N = W.shape
    Wh = np.zeros_like(W)
    for t in range(T):
        src = (t // H) * H
        if src < T:
            Wh[t] = W[src]
    return Wh


def backtest_panel(W, ret, cost_bp):
    """W[t] 是 t 日持仓, 赚 t 日收益(已对齐); 换仓扣成本"""
    R = ret.values
    pnl = np.sum(W * R, axis=1)
    turn = np.zeros(len(W))
    turn[1:] = np.abs(W[1:] - W[:-1]).sum(axis=1)
    turn[0] = np.abs(W[0]).sum()
    cost = turn * (2 * cost_bp / 1e4)
    return pnl - cost


def long_only_equal(df, ret, cost_bp):
    """等权做多所有品种 (对照: 横截面的'beta')"""
    T, N = ret.shape
    W = np.ones((T, N)) / N
    R = ret.values
    pnl = np.sum(W * R, axis=1)
    turn = np.zeros(T)
    turn[0] = 1.0
    return pnl - turn * (2 * cost_bp / 1e4)


# ---------- BTC 领先性 ----------
def btc_lead_test(df, ret, maxlag=5):
    """
    用 BTC 滞后 d 天收益 -> 预测 山寨 t+1 收益 (排除BTC自身)
    返回: 每个lag的相关系数矩阵与联合检验
    """
    cols = list(df.columns)
    if 'BTC' not in cols:
        return None
    alts = [c for c in cols if c != 'BTC']
    out = {}
    for d in range(1, maxlag + 1):
        rows = []
        for a in alts:
            x = ret['BTC'].shift(d).values      # BTC 在 t-d 的收益
            y = ret[a].shift(-1).values         # 山寨 t+1 收益
            ok = ~np.isnan(x) & ~np.isnan(y)
            if ok.sum() < 100:
                continue
            r = np.corrcoef(x[ok], y[ok])[0, 1]
            tstat = r * np.sqrt((ok.sum() - 2) / max(1e-12, 1 - r ** 2))
            rows.append((a, r, tstat, ok.sum()))
        out[d] = rows
    return out


# ---------- 波动率目标 ----------
def vol_target_test(df, ret, target_ann=0.40, cost_bp=20):
    """
    预测下一期波动率 -> 调仓位 (不预测方向, 只预测风险)
    对照: 固定满仓 vs 波动率目标
    """
    R = ret.values
    T, N = R.shape
    port = R.mean(axis=1)                       # 等权组合收益
    # EWMA 预测波动率 (无前视: 只用t及之前)
    lam = 0.94
    var = np.zeros(T)
    var[0] = port[:20].var() if T > 20 else port.var()
    for t in range(1, T):
        var[t] = lam * var[t - 1] + (1 - lam) * port[t - 1] ** 2
    fvol = np.sqrt(var * DAYS_YR)               # 年化预测波动
    fvol = np.maximum(fvol, 0.05)
    # 只做多版本: 仓位 = target/fvol, 上限2倍
    lev = np.clip(target_ann / fvol, 0.0, 2.0)
    vol_pnl = np.zeros(T)
    vol_pnl[1:] = lev[:-1] * port[1:]
    turn = np.abs(np.diff(lev))
    vol_cost = np.concatenate([[abs(lev[0])], turn]) * (2 * cost_bp / 1e4)
    vol_pnl = vol_pnl - vol_cost
    # 固定满仓对照
    fix_pnl = port.copy()
    fix_pnl[0] = 0.0
    return vol_pnl, fix_pnl, lev, fvol


# ---------- 评价 ----------
def metrics(net):
    n = len(net)
    mu, sd = net.mean(), net.std()
    if sd < 1e-12 or n < 10:
        return 0.0, 0.0, 0.0
    nav = np.cumprod(1.0 + np.clip(net, -0.99, None))
    ann = (nav[-1] ** (DAYS_YR / n) - 1) * 100 if nav[-1] > 0 else -100.0
    ann = float(np.clip(ann, -100, 1e6))
    sh = mu / sd * np.sqrt(DAYS_YR)
    peak = np.maximum.accumulate(nav)
    dd = (nav - peak) / np.maximum(peak, 1e-12)
    return ann, sh, float(-dd.min() * 100)


def boot_idx(rng, T, L):
    nb = int(np.ceil(T / L))
    st = rng.integers(0, T - L, size=nb)
    return (st[:, None] + np.arange(L)[None, :]).ravel()[:T] % T


def paired_test(a, b, kind='sharpe', B=B_BOOT, blk=BLK, seed=0):
    def sh(x):
        s = x.std()
        return x.mean() / s * np.sqrt(DAYS_YR) if s > 1e-12 else 0.0
    def mdd(x):
        nav = np.cumprod(1.0 + np.clip(x, -0.99, None))
        pk = np.maximum.accumulate(nav)
        return float(-((nav - pk) / np.maximum(pk, 1e-12)).min() * 100)
    f = sh if kind == 'sharpe' else mdd
    T = len(a)
    rng = np.random.default_rng(seed)
    obs = f(a) - f(b)
    d = np.zeros(B)
    for i in range(B):
        idx = boot_idx(rng, T, blk)
        d[i] = f(a[idx]) - f(b[idx])
    p = 2 * min((d <= 0).mean(), (d >= 0).mean())
    return obs, min(p, 1.0)


def reality_check(mats, best_idx, B=B_BOOT, blk=BLK, seed=0):
    M, T = mats.shape
    rng = np.random.default_rng(seed)
    om = mats.mean(axis=1)
    ob = om[best_idx]
    bm = np.zeros(B)
    for i in range(B):
        idx = boot_idx(rng, T, blk)
        bm[i] = (mats[:, idx].mean(axis=1) - om).max()
    return ob, (bm >= ob).mean()


# ============ 主流程 ============
print("=" * 100)
print("横截面 / 相对价值 / BTC领先性 / 波动率目标 检验")
print("=" * 100)

df = load_daily()
ret = df.pct_change().fillna(0.0)
T, N = ret.shape
print(f"\n面板: {N} 个品种 x {T} 天  ({df.index[0].date()} -> {df.index[-1].date()})")
print(f"品种: {list(df.columns)}")
sp = T // 2
print(f"样本内[0,{sp})  样本外[{sp},{T})")

# ---------- A/B: 横截面动量与反转 ----------
print("\n" + "=" * 100)
print("【A/B】横截面动量 / 反转 (市场中性: 多top-k 空bottom-k)")
print("=" * 100)

cs_names, cs_W = [], {}
for mode in ['mom', 'rev']:
    for L in LOOKBACK:
        for H in HOLD:
            for k in TOPK:
                W = hold_signal(cs_signal(ret, L, mode, k), H)
                nm = f'cs_{mode}_L{L}_H{H}_k{k}'
                cs_W[nm] = W
                cs_names.append(nm)
print(f"策略族: {len(cs_names)} 个横截面策略")

for cost in COSTS:
    nets = {nm: backtest_panel(cs_W[nm], ret, cost) for nm in cs_names}
    is_sh = {nm: metrics(nets[nm][:sp])[1] for nm in cs_names}
    best = max(is_sh, key=is_sh.get)
    oos = nets[best][sp:]
    a, s_, d_ = metrics(oos)
    bh = long_only_equal(df, ret, cost)
    ba, bs, bd = metrics(bh[sp:])
    print(f"\n  -- 成本{cost}bp --")
    print(f"    样本内夏普最优: {best}")
    print(f"      横截面: 年化{a:>8.2f}%  夏普{s_:>7.3f}  回撤{d_:>7.2f}%")
    print(f"      等权多头: 年化{ba:>8.2f}%  夏普{bs:>7.3f}  回撤{bd:>7.2f}%")
    if cost in [0, 20]:
        dsh, psh = paired_test(oos, bh[sp:], 'sharpe', seed=41)
        ddd, pdd = paired_test(oos, bh[sp:], 'mdd', seed=42)
        print(f"      配对: Δ夏普={dsh:+.3f} (p={psh:.3f} {'显著' if psh<0.05 else '不显著'})  "
              f"Δ回撤={ddd:+.2f}% (p={pdd:.3f} {'显著' if pdd<0.05 else '不显著'})")

print(f"\n  【Reality Check · 横截面】校正{len(cs_names)}个策略:")
for cost in [0, 20]:
    nets = {nm: backtest_panel(cs_W[nm], ret, cost) for nm in cs_names}
    is_sh = {nm: metrics(nets[nm][:sp])[1] for nm in cs_names}
    best = max(is_sh, key=is_sh.get)
    mats = np.array([nets[nm][sp:] for nm in cs_names])
    ob, p = reality_check(mats, cs_names.index(best), seed=51)
    print(f"    成本{cost:>2}bp | 最优 {best:<22} 样本外均值={ob*1e4:>7.3f}bp/日  "
          f"RC p={p:.3f} ({'显著' if p<0.05 else '不显著'})")

# ---------- C: BTC 领先性 ----------
print("\n" + "=" * 100)
print("【C】BTC 领先性 (BTC滞后d天收益 -> 山寨次日收益)")
print("=" * 100)
lead = btc_lead_test(df, ret, maxlag=5)
print(f"  {'lag':>4}  " + "  ".join(f"{a:>18}" for a in [x[0] for x in lead[1]]))
for d in sorted(lead.keys()):
    cells = []
    for a, r, t, n in lead[d]:
        mark = '*' if abs(t) > 1.96 else ' '
        cells.append(f"{a}:r={r:+.4f} t={t:+5.2f}{mark}")
    print(f"  {d:>4}  " + "  ".join(f"{c:>18}" for c in cells))
print("  (* = |t|>1.96, 单品种名义显著; 但已做5lag x 6品种=30次检验)")
print("  Bonferroni 校正阈值: |t| > 2.81")

# ---------- D: 波动率目标 ----------
print("\n" + "=" * 100)
print("【D】波动率目标 (预测风险->调仓位, 不预测方向)")
print("=" * 100)
for cost in [10, 20]:
    vol_pnl, fix_pnl, lev, fvol = vol_target_test(df, ret, cost_bp=cost)
    va, vs, vd = metrics(vol_pnl[sp:])
    fa, fs, fd = metrics(fix_pnl[sp:])
    print(f"\n  -- 成本{cost}bp --")
    print(f"    波动率目标: 年化{va:>8.2f}%  夏普{vs:>7.3f}  回撤{vd:>7.2f}%  "
          f"(平均杠杆{lev[sp:].mean():.2f})")
    print(f"    固定满仓  : 年化{fa:>8.2f}%  夏普{fs:>7.3f}  回撤{fd:>7.2f}%")
    dsh, psh = paired_test(vol_pnl[sp:], fix_pnl[sp:], 'sharpe', seed=61)
    ddd, pdd = paired_test(vol_pnl[sp:], fix_pnl[sp:], 'mdd', seed=62)
    print(f"    配对: Δ夏普={dsh:+.3f} (p={psh:.3f} {'显著' if psh<0.05 else '不显著'})  "
          f"Δ回撤={ddd:+.2f}% (p={pdd:.3f} {'显著改善' if pdd<0.05 and ddd<0 else '不显著'})")

print("\n" + "=" * 100)
print("完成")
print("=" * 100)
