"""
矛盾论·反例求解器
========================================
核心思想: 不再靠猜, 而是把"可抓的矛盾"变成【可解的方程】

矛盾论的反例定义:
  找一个市场 + 一组参数, 使得:
    矛盾强度 > 成本的压制  ->  扣成本后期望为正
    且这个矛盾在【有限样本内可检测】

关键突破: 把"能赚钱"翻译成一个【闭式不等式】, 然后解它

推导:
  设砖块大小 A(对数), 成本占比 c = 2*cost_rate/A
  1:1 盈亏比下, 盈亏平衡胜率 p* = (1+c)/2

  而胜率 p 由【结构强度 rho】决定:
    价格是 AR(1) 时, 下一块的延续概率:
      p ≈ Phi( rho * A / (sigma_step * sqrt(2)) )   (近似)

  正期望条件: p > p*
    => Phi(rho*A/(sigma*sqrt2)) > (1 + 2*cost/A)/2
    => rho > rho_crit(A)

  这就给出了【矛盾必须强到什么程度】的临界曲线!

  再用检测门槛: 检测 rho 需要的最小样本 N_req(rho)

  => 可行域 = { A, rho : p(A,rho) > p*(A) 且  N_req(rho) < N_avail(A) }

本程序: 数值求解这个可行域, 找出【真正的反例参数】
"""
import numpy as np
from scipy.stats import norm
from zoo_tick import (INIT_CAP, PRICE0, COST_RATE, TICKS_PER_HOUR,
                      HOURS_PER_YEAR)


# ============================================================
# 一、理论: 胜率 vs 结构强度
# ============================================================
def win_rate_from_rho(rho, A, sigma_step):
    """
    AR(1) 结构下, 砖块延续概率的解析近似
      rho    : lag-1 自相关 (矛盾强度, 正=趋势 负=反转)
      A      : 砖块大小(对数)
      sigma  : 单步波动(对数)
    直觉: 漂移 = rho * (A/sigma) * sigma = rho*A per step
    """
    if rho == 0:
        return 0.5
    # 有效漂移(每步): mu_eff = rho * sigma_step
    # 走完一个 A 需要 T = (A/sigma)^2 步
    T = (A / max(sigma_step, 1e-12)) ** 2
    mu_total = rho * A            # 累积漂移(近似)
    noise = sigma_step * np.sqrt(max(T, 1.0))
    return float(norm.cdf(mu_total / max(noise, 1e-12)))


def pstar_of_A(A, cost_rate=COST_RATE):
    """盈亏平衡胜率 = (1 + 2*cost/A)/2"""
    c = 2.0 * cost_rate / A
    return (1.0 + c) / 2.0


def rho_crit(A, sigma_step, cost_rate=COST_RATE):
    """
    解出临界矛盾强度: 使 p(rho) = p* 的 rho
    用二分法
    """
    pstar = pstar_of_A(A, cost_rate)
    if win_rate_from_rho(0.0, A, sigma_step) >= pstar:
        return 0.0
    lo, hi = 0.0, 1.0
    for _ in range(80):
        mid = (lo + hi) / 2
        if win_rate_from_rho(mid, A, sigma_step) < pstar:
            lo = mid
        else:
            hi = mid
        if hi - lo < 1e-10:
            break
    return (lo + hi) / 2


def n_detect(rho, alpha=0.05, power=0.80):
    """检测 rho 所需的最小样本量(近似)"""
    if abs(rho) < 1e-9:
        return np.inf
    za, zb = norm.ppf(1 - alpha), norm.ppf(power)
    return ((za + zb) / abs(rho)) ** 2


# ============================================================
# 二、求解可行域 —— 找"真正的反例"
# ============================================================
def solve_feasible(sigma_step, n_avail, cost_rate=COST_RATE, verbose=True):
    """
    扫描砖块大小 A, 找可行域:
      rho_crit(A) < rho_max_feasible
      且 n_detect(rho_crit) < n_avail
    """
    rows = []
    A_grid = sigma_step * np.array([1, 2, 3, 5, 8, 12, 20, 30, 50, 80, 120, 200])
    for A in A_grid:
        rc = rho_crit(A, sigma_step, cost_rate)
        pstar = pstar_of_A(A, cost_rate)
        p_at_rc = win_rate_from_rho(rc, A, sigma_step)
        nd = n_detect(rc)
        # 该 A 下的砖块数 ≈ 总路程/A
        n_bricks = n_avail * sigma_step / A
        feasible = (rc < 0.5) and (nd <= n_bricks)
        rows.append(dict(A=A, A_bp=A * 1e4, A_per_sig=A / sigma_step,
                         pstar=pstar, rho_crit=rc, n_detect=nd,
                         n_bricks=n_bricks, feasible=feasible))
    if verbose:
        print(f"\n  {'A(bp)':>8}{'A/σ':>7}{'p*':>8}{'临界ρ':>10}"
              f"{'需样本':>10}{'可得砖':>9}{'可行':>7}")
        for r in rows:
            print(f"  {r['A_bp']:>8.1f}{r['A_per_sig']:>7.1f}{r['pstar']:>8.4f}"
                  f"{r['rho_crit']:>10.5f}{r['n_detect']:>10.0f}"
                  f"{r['n_bricks']:>9.0f}{'YES' if r['feasible'] else 'no':>7}")
    return rows


# ============================================================
# 三、构造"真正的反例市场" —— 强度刚好跨过门槛
# ============================================================
def gen_mkt_rho(kind, n, sigma, seed, rho_target=0.05, price0=PRICE0):
    """
    生成具有【指定自相关强度】的市场
      kind='trend'  -> 正 rho (趋势主导)
      kind='rev'    -> 负 rho (反转主导)
    用 AR(1) 直接控制: r_t = phi * r_{t-1} + eps
      phi 与 lag-1 自相关的关系: rho = phi (AR1)
    """
    rng = np.random.default_rng(seed)
    sign = 1.0 if kind == 'trend' else -1.0
    phi = sign * abs(rho_target)
    eps_sd = sigma * np.sqrt(max(1 - phi ** 2, 1e-12))
    r = np.zeros(n)
    e = rng.normal(0, eps_sd, n)
    for t in range(1, n):
        r[t] = phi * r[t - 1] + e[t]
    return price0 * np.exp(np.cumsum(r))


def gen_mkt_strong(kind, n, sigma, seed, strength=0.9, price0=PRICE0):
    """
    更强的结构: 分段趋势(regime), 强度可控
      strength: 漂移 相对 噪声 的比例
    """
    rng = np.random.default_rng(seed)
    if kind == 'trend':
        L = max(200, n // 12)
        signs = rng.choice([-1, 1], int(np.ceil(n / L)))
        d = signs.repeat(L)[:n] * sigma * strength
        r = d + rng.normal(0, sigma, n)
    else:
        # 震荡: 强均值回归
        phi = -min(0.5, strength)
        eps_sd = sigma * np.sqrt(1 - phi ** 2)
        r = np.zeros(n)
        e = rng.normal(0, eps_sd, n)
        for t in range(1, n):
            r[t] = phi * r[t - 1] + e[t]
    return price0 * np.exp(np.cumsum(r))
