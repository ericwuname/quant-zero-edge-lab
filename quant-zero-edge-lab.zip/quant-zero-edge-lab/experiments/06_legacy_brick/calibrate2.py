"""
【核心2】检测效率 —— 加上帝视角上界
========================================
【问题】calibrate.py 发现: 植入最强edge, 检出率仅33%
  但必须先排除: 植入的结构是否真的产生了可测量的edge?
  若植入强度0.025其实只产生极微弱的可预测性 -> 校准无效

【解决: 上帝视角】
  用【未来信息】(作弊)构造"理论最优策略" -> 得到 edge 的理论上界
  然后看我的流程捕获了多少 -> 检测效率 = 实际捕获 / 理论上界

【三层对比】
  L0 上帝视角 (作弊, 用未来收益选方向)   -> 理论最大可捕获
  L1 完美信号 (作弊, 用真实的trend_comp) -> 若结构被完美利用
  L2 我的流程 (诚实, 只用过去信息)       -> 实际捕获

【这回答】
  1. 植入的结构是否真实存在? (L0/L1 是否显著>0)
  2. 我的流程效率如何? (L2/L1)
  3. 真实市场若edge强度=L1, 我能发现吗?
"""
import numpy as np
import pandas as pd
from scipy import stats
import sys
sys.path.insert(0, '/data/workspace/brick')
from world_v5 import World

DAYS_YR = 365
COST_BP = 10


def build_signals(prices):
    T = len(prices) - 1
    P = prices[:T]
    S = {}
    for w in [5, 10, 20, 60]:
        if T > w + 1:
            mom = np.zeros(T)
            mom[w:] = P[w:] / np.maximum(P[:-w], 1e-9) - 1
            S[f'mom_{w}'] = np.sign(mom)
            S[f'rev_{w}'] = -np.sign(mom)
    for w in [10, 30]:
        if T > w + 1:
            ma = pd.Series(P).rolling(w).mean().values
            sig = np.where(P > ma, 1.0, -1.0)
            sig[:w] = 0.0
            S[f'ma_{w}'] = sig
    return S


def backtest(sig, r, cost_bp):
    T = len(r)
    pnl = np.zeros(T)
    pnl[:-1] = sig[:-1] * r[1:]
    turn = np.abs(np.diff(np.concatenate([[0.0], sig])))
    return pnl - turn * (2 * cost_bp / 1e4)


def sharpe(x):
    s = x.std()
    return x.mean() / s * np.sqrt(DAYS_YR) if s > 1e-12 else 0.0


def boot_idx(rng, T, L):
    nb = int(np.ceil(T / L))
    st = rng.integers(0, T - L, size=nb)
    return (st[:, None] + np.arange(L)[None, :]).ravel()[:T] % T


def reality_check(oos_matrix, B=200, blk=20, seed=0):
    M, T = oos_matrix.shape
    means = oos_matrix.mean(axis=1)
    bi = int(np.argmax(means))
    obs = means[bi]
    rng = np.random.default_rng(seed)
    centered = oos_matrix - means[:, None]
    null_max = np.zeros(B)
    for b in range(B):
        null_max[b] = centered[:, boot_idx(rng, T, blk)].mean(axis=1).max()
    return obs, (null_max >= obs).mean(), bi


def run_world(ts, seed, n_steps=10000):
    """返回该世界的三层结果"""
    w = World(seed=seed, beta=0.0005)
    prices, wh, kinds = w.run(n_steps=n_steps, trend_strength=ts)
    r = np.diff(prices) / np.maximum(prices[:-1], 1e-9)
    T = len(r)
    sp = T // 2

    # ---- L0 上帝视角: 用【未来收益】的符号作弊 ----
    god_sig = np.zeros(T)
    god_sig[:-1] = np.sign(r[1:])          # 完美预知下一期方向
    l0 = backtest(god_sig, r, COST_BP)

    # ---- L1 完美结构信号: 用真实的趋势状态 (植入时可知) ----
    # 重新生成以拿到 trend_comp (用同seed重跑并重建)
    # 简化: 用长窗口动量近似真实趋势状态 (比L0弱, 但接近"若结构被识别")
    P = prices[:T]
    if T > 120:
        trend_state = np.zeros(T)
        trend_state[60:] = P[60:] / np.maximum(P[:-60], 1e-9) - 1
        l1_sig = np.sign(trend_state)
    else:
        l1_sig = np.zeros(T)
    l1 = backtest(l1_sig, r, COST_BP)

    # ---- L2 我的诚实流程 ----
    S = build_signals(prices)
    names = list(S.keys())
    is_sh = {nm: sharpe(backtest(S[nm], r, COST_BP)[:sp]) for nm in names}
    best = max(is_sh, key=is_sh.get)
    oos = np.array([backtest(S[nm], r, COST_BP)[sp:] for nm in names])
    obs, p, bi = reality_check(oos, seed=seed)
    l2_oos = oos[bi]

    return dict(
        L0_god=sharpe(l0[sp:]), L0_mean=l0[sp:].mean() * 1e4,
        L1_struct=sharpe(l1[sp:]), L1_mean=l1[sp:].mean() * 1e4,
        L2_mine=sharpe(l2_oos), L2_mean=l2_oos.mean() * 1e4,
        rc_p=p, detected=(p < 0.05),
    )


print("=" * 100)
print("【核心2】检测效率 —— 上帝视角上界 vs 我的流程")
print("=" * 100)
print("  L0 = 上帝视角(作弊, 完美预知下一期方向) -> 理论最大")
print("  L1 = 结构信号(用真实趋势状态)         -> 若结构被完美识别")
print("  L2 = 我的流程(诚实, 只用过去信息)     -> 实际表现")
print(f"\n  每个强度 {20} 个独立世界, 成本 {COST_BP}bp 单边")

strengths = [0.0, 0.002, 0.005, 0.010, 0.020, 0.035, 0.050]
N_W = 20

print(f"\n  {'强度':>7}{'L0夏普':>9}{'L1夏普':>9}{'L2夏普':>9}"
      f"{'检测效率':>10}{'检出率':>9}{'平均p':>9}")
print("  " + "-" * 64)

rows = []
for ts in strengths:
    res = [run_world(ts, seed=2000 + i) for i in range(N_W)]
    l0 = np.mean([x['L0_god'] for x in res])
    l1 = np.mean([x['L1_struct'] for x in res])
    l2 = np.mean([x['L2_mine'] for x in res])
    det = np.mean([x['detected'] for x in res])
    pp = np.mean([x['rc_p'] for x in res])
    eff = l2 / l1 if abs(l1) > 1e-6 else np.nan
    print(f"  {ts:>7.3f}{l0:>9.2f}{l1:>9.3f}{l2:>9.3f}{eff*100:>9.0f}%"
          f"{det*100:>8.0f}%{pp:>9.3f}")
    rows.append((ts, l0, l1, l2, det, pp))

print("\n" + "=" * 100)
print("【关键判读】")
print("=" * 100)
l1s = np.array([r[2] for r in rows])
l2s = np.array([r[3] for r in rows])
dets = np.array([r[4] for r in rows])
tss = np.array([r[0] for r in rows])

# L1 是否随强度增长 (验证植入有效)
if len(tss) > 2:
    cc = np.corrcoef(tss, l1s)[0, 1]
    print(f"  1. 植入是否有效? L1夏普 vs 强度 相关系数 = {cc:+.3f}")
    print(f"     {'✓ 植入确实产生了可测量结构' if cc > 0.5 else '✗ 植入未产生有效结构(校准可疑)'}")

# 检测效率的量级
valid = [i for i in range(len(rows)) if abs(rows[i][2]) > 0.05]
if valid:
    effs = [rows[i][3] / rows[i][2] for i in valid]
    print(f"\n  2. 检测效率 (L2/L1): 平均 {np.mean(effs)*100:.0f}%  "
          f"范围 {min(effs)*100:.0f}%~{max(effs)*100:.0f}%")

print(f"\n  3. 检出率 vs 强度:")
for ts, l0, l1, l2, det, pp in rows:
    bar = "█" * int(det * 20)
    print(f"     强度{ts:>6.3f} (L1夏普{l1:>6.3f}) | {bar:<20} {det*100:>3.0f}%")

# 50% 检出率临界
crit_l1 = None
for i in range(len(dets) - 1):
    if dets[i] < 0.5 <= dets[i + 1]:
        f = (0.5 - dets[i]) / (dets[i + 1] - dets[i])
        crit_l1 = l1s[i] + f * (l1s[i + 1] - l1s[i])
        break
if crit_l1 is not None:
    print(f"\n  ★ 50%检出率 需要 L1夏普(真实结构强度) ≈ {crit_l1:.3f}")
else:
    print(f"\n  ★ 测试范围内最高检出率 {dets.max()*100:.0f}%, 未达50%")
    print(f"     -> 需要真实结构强度超过 L1夏普={l1s.max():.3f} 才能可靠检出")

print("\n" + "=" * 100)
print("这直接回答: 真实市场需要多强的edge, 我才能发现?")
print("=" * 100)
