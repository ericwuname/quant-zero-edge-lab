"""
矛盾论 v3 —— 用【自相关】作为结构指标 (真正的"力量对比")
================================================================
v1 错误: 用胜率(结果指标) -> 循环论证
v2 错误: 用多尺度能量 -> 趋势成分占99.4%, 无法区分市场(用错尺子)
v3 修正: 用【自相关 ACF】 —— 直接度量"趋势 vs 反转"的力量对比

矛盾论映射:
  主要矛盾    = ACF 的符号 (正=趋势主导, 负=反转主导)
  矛盾的强度  = |ACF| (力量对比的悬殊程度)
  度(量变质变)= |ACF| 必须跨过【成本决定的临界值】才出手
  矛盾转化    = 滚动 ACF 的符号翻转
  对立统一    = 趋势与反转是同一序列的正负两面, 非互斥开关
"""
import numpy as np
from zoo_tick import (INIT_CAP, PRICE0, COST_RATE, TICKS_PER_HOUR,
                      HOURS_PER_YEAR)


def gen_mkt(kind, n, sigma, seed, price0=PRICE0):
    rng = np.random.default_rng(seed)
    r = np.zeros(n)
    if kind == 'rw':
        r = rng.normal(0, sigma, n)
    elif kind == 'weakmom':
        d = np.zeros(n)
        for t in range(1, n):
            d[t] = 0.98 * d[t - 1] + rng.normal(0, sigma * 0.020)
        r = d + rng.normal(0, sigma, n)
        sd = r.std()
        if sd > 0:
            r = r / sd * sigma
    elif kind == 'oscill':
        phi = -0.08
        e = rng.normal(0, sigma * np.sqrt(1 - phi ** 2), n)
        for t in range(1, n):
            r[t] = phi * r[t - 1] + e[t]
    elif kind == 'regime':
        state = 0
        for t in range(1, n):
            if rng.random() < 0.002:
                state = 1 - state
            r[t] = (0.03 if state == 1 else -0.03) * r[t - 1] + rng.normal(0, sigma)
    elif kind == 'compress':
        seg = n // 6
        for k in range(6):
            s0, s1 = k * seg, min((k + 1) * seg, n)
            L = s1 - s0
            if L <= 1:
                continue
            if k % 2 == 0:
                r[s0:s1] = rng.normal(0, sigma * 0.35, L)
            else:
                d = rng.choice([-1, 1]) * sigma * 0.9
                r[s0:s1] = d + rng.normal(0, sigma * 0.7, L)
    return price0 * np.exp(np.cumsum(r))


def roll_acf1(px, W=2000, lag=1):
    """滚动 lag-1 自相关 —— 结构指标(只看过去)"""
    r = np.diff(np.log(px))
    n = len(r)
    acf = np.full(n, np.nan)
    # 增量式: 用滑动窗口的协方差/方差
    cs = np.concatenate([[0.0], np.cumsum(r)])
    cs2 = np.concatenate([[0.0], np.cumsum(r * r)])
    cr = np.concatenate([[0.0], np.cumsum(r[:-lag] * r[lag:])])
    cr = np.concatenate([cr, np.zeros(max(0, n - len(cr)))])
    for i in range(W + lag, n):
        a, b = i - W, i
        m1 = (cs[b] - cs[a]) / W
        m2 = (cs[b + lag] - cs[a + lag]) / W if b + lag <= n else m1
        v1 = (cs2[b] - cs2[a]) / W - m1 * m1
        idx = min(b - lag, n - lag)
        cov = (cr[min(idx, len(cr) - 1)] - cr[min(a, len(cr) - 1)]) / W - m1 * m2 \
            if min(idx, len(cr) - 1) > min(a, len(cr) - 1) else 0.0
        v2 = v1
        denom = np.sqrt(max(v1 * v2, 1e-18))
        acf[i] = cov / denom
    return acf


def run_contra3(px, A, W=2000, theta=0.02, cap0=INIT_CAP, risk=0.01,
                cost_rate=COST_RATE, lev_cap=5.0, min_gap=0.0):
    """
    矛盾论 v3:
      Step1 结构指标: 滚动 lag-1 自相关 rho (力量对比)
      Step2 主要矛盾: rho > +theta -> 趋势主导(赌延续)
                      rho < -theta -> 反转主导(赌反转)
      Step3 度      : |rho| < theta -> 矛盾未分化, 不出手
      Step4 对立统一: 只要 |rho| 足够, 两个方向都可能做
    """
    n = len(px)
    lp = np.log(px)
    acf = roll_acf1(px, W=W)
    c_cost = 2.0 * cost_rate / A
    pstar = (1.0 + c_cost) / 2.0

    cap = cap0
    equity = np.empty(n)
    equity[:] = cap0
    peak, maxdd = cap0, 0.0
    pos = 0
    entry = 0.0
    lots = 0.0
    n_mom = n_rev = n_skip = 0

    for i in range(W, n - 1):
        rho = acf[i]
        if np.isnan(rho):
            equity[i] = cap
            continue

        # 度的约束
        if abs(rho) < theta:
            n_skip += 1
            if pos == 0:
                equity[i] = cap
                continue

        # 主要矛盾判定
        if rho > theta:
            direction = 1.0      # 趋势主导 -> 顺势(赌延续)
        elif rho < -theta:
            direction = -1.0     # 反转主导 -> 逆势(赌反转)
        else:
            direction = 0.0

        if pos == 0 and direction != 0:
            if direction > 0:
                n_mom += 1
            else:
                n_rev += 1
            entry = lp[i]
            pos = direction
            lots = cap * risk / (PRICE0 * A)
            if lots * PRICE0 > cap * lev_cap:
                lots = cap * lev_cap / PRICE0
            if lots > 0:
                cap -= lots * PRICE0 * cost_rate

        if pos != 0:
            pl = (lp[i] - entry) * pos
            if pl >= A or pl <= -A:
                cap += (pl - c_cost * A) * lots * PRICE0
                pos = 0

        eq = cap
        if pos != 0:
            eq += (lp[i] - entry) * pos * lots * PRICE0
        equity[i] = max(eq, 0.0)
        peak = max(peak, equity[i])
        maxdd = max(maxdd, (peak - equity[i]) / peak if peak > 0 else 0)
        if cap <= 0:
            equity[i:] = 0.0
            break

    return dict(final=equity[-2] if len(equity) > 1 else cap0,
                equity=equity, maxdd=maxdd, n_mom=n_mom, n_rev=n_rev,
                n_skip=n_skip, pstar=pstar,
                skip_rate=n_skip / max(1, n - W))
