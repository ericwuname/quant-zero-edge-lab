"""
实例化交易世界 v1 —— 基于主体的市场模拟器
=============================================
【为什么做这个】
  真实市场永远没有对照组: 我们不知道测出的效应是真结构还是噪声
  在自建世界里, 我们【知道真相】—— 可以校准测量工具
  这是唯一能打破"我凭什么相信我看到的是真的"这个死穴的方法

【设计】
  主体类型:
    - fundamentalist: 价格低于价值买入 (均值回归, 提供稳定性)
    - trend_follower: 跟动量 (制造趋势/肥尾)
    - contrarian    : 反向 (提供流动性/抑制极端)
    - market_maker  : 提供流动性, 赚价差
    - noise_trader  : 随机

  价格形成: 超额需求驱动
    r_t = beta * (D_t^net) + shock
    D^net = sum_i (w_i * demand_i)

  主体演化: 按表现调整权重 (亏光的被淘汰, 赚钱的被模仿)
    -> 这是内生的"生态演化", 不是外生设定

【验证标准】(stylized facts, 必须复现)
  1. 收益率肥尾 (峰度 > 3)
  2. 收益率无/弱自相关
  3. 波动率聚集 (|r| 有显著正自相关)
  4. 无长期可预测性 (大部分时间)
"""
import numpy as np
import pandas as pd
from scipy import stats


class Agent:
    """交易主体基类"""
    def __init__(self, kind, weight=1.0):
        self.kind = kind
        self.weight = weight
        self.wealth = 1.0
        self.pnl = 0.0

    def demand(self, price, hist, rng, params):
        raise NotImplementedError


class Fundamentalist(Agent):
    """基本面: 价格偏离价值 -> 反向交易 (提供稳定性)"""
    def __init__(self, weight=1.0, speed=0.05):
        super().__init__('fundamentalist', weight)
        self.speed = speed
        self.value = 100.0

    def demand(self, price, hist, rng, params):
        # 价值缓慢随机游走 (真实世界: 基本面在变)
        self.value *= (1 + rng.normal(0, params['fund_value_vol']))
        dev = (self.value - price) / max(price, 1e-9)
        return np.tanh(dev / self.speed) * self.weight


class TrendFollower(Agent):
    """趋势: 按多尺度动量加权 (制造趋势与肥尾)"""
    def __init__(self, weight=1.0, lookbacks=(5, 20, 60)):
        super().__init__('trend', weight)
        self.lookbacks = lookbacks

    def demand(self, price, hist, rng, params):
        if len(hist) < max(self.lookbacks) + 1:
            return 0.0
        sig = 0.0
        for lb in self.lookbacks:
            mom = price / max(hist[-lb], 1e-9) - 1.0
            sig += np.tanh(mom / params['trend_scale'])
        sig /= len(self.lookbacks)
        return sig * self.weight


class Contrarian(Agent):
    """反转: 反向于近期动量 (提供流动性, 抑制极端)"""
    def __init__(self, weight=1.0, lookback=10):
        super().__init__('contrarian', weight)
        self.lookback = lookback

    def demand(self, price, hist, rng, params):
        if len(hist) < self.lookback + 1:
            return 0.0
        mom = price / max(hist[-self.lookback], 1e-9) - 1.0
        return -np.tanh(mom / params['contra_scale']) * self.weight


class MarketMaker(Agent):
    """做市商: 提供流动性, 赚价差, 同时轻微反向"""
    def __init__(self, weight=1.0):
        super().__init__('market_maker', weight)

    def demand(self, price, hist, rng, params):
        if len(hist) < 5:
            return 0.0
        dev = (hist[-5:].mean() - price) / max(price, 1e-9)
        return np.tanh(dev / params['mm_scale']) * self.weight


class NoiseTrader(Agent):
    """噪声: 随机需求"""
    def __init__(self, weight=1.0):
        super().__init__('noise', weight)

    def demand(self, price, hist, rng, params):
        return rng.normal(0, 1) * self.weight


def simulate(n_steps=10000, seed=0,
             params=None,
             # --- 可植入的"真相"参数 ---
             true_drift=0.0,          # 真实漂移(外生alpha)
             trend_strength=0.0,      # 趋势成分强度(可被利用的结构)
             regime_switch=False,     # 体制切换
             ):
    """
    运行模拟, 返回 价格序列 与 主体演化历史
    """
    if params is None:
        params = dict(
            fund_value_vol=0.002,
            trend_scale=0.02,
            contra_scale=0.02,
            mm_scale=0.01,
            beta=0.02,            # 价格对超额需求的敏感度
            shock_vol=0.005,
            evol_speed=0.02,      # 主体权重演化速度
        )

    rng = np.random.default_rng(seed)

    agents = [
        Fundamentalist(weight=1.0),
        TrendFollower(weight=1.0),
        Contrarian(weight=1.0),
        MarketMaker(weight=1.0),
        NoiseTrader(weight=0.5),
    ]

    price = 100.0
    hist = [price]
    prices = [price]
    weights_hist = []
    trend_comp = 0.0

    for t in range(n_steps):
        # --- 可植入的真实结构 ---
        if regime_switch:
            # 体制切换: 每500步翻转趋势方向
            regime = 1 if (t // 500) % 2 == 0 else -1
        else:
            regime = 1
        if trend_strength > 0:
            # 缓慢漂移的趋势成分 (真实存在的可预测结构)
            trend_comp = (1 - 0.02) * trend_comp + 0.02 * rng.normal(0, 1)
        else:
            trend_comp = 0.0

        # --- 各主体需求 ---
        net_demand = 0.0
        for a in agents:
            d = a.demand(price, np.array(hist), rng, params)
            net_demand += d
            a.pnl += d * 0.0   # 占位: 实际pnl用下期收益更新

        # --- 价格更新 ---
        shock = rng.normal(0, params['shock_vol'])
        drift = true_drift + trend_strength * trend_comp * regime
        r = params['beta'] * net_demand + drift + shock
        price = price * (1 + r)
        prices.append(price)
        hist.append(price)
        if len(hist) > 200:
            hist.pop(0)

        # --- 主体演化: 按上一期表现调整权重 ---
        for a in agents:
            # 用"需求方向 * 实际收益"近似其盈利能力
            a.pnl = a.pnl * 0.99 + (a.last_d if hasattr(a, 'last_d') else 0) * r
            a.weight = max(0.05, a.weight + params['evol_speed'] * np.tanh(a.pnl * 10))
        # 记录需求用于下期pnl
        for a in agents:
            a.last_d = a.demand(price, np.array(hist), rng, params) if False else 0.0

        if t % 100 == 0:
            weights_hist.append([a.weight for a in agents])

    return np.array(prices), np.array(weights_hist), params


def stylized_facts(prices, label=""):
    """检验典型事实"""
    r = np.diff(prices) / prices[:-1]
    r = r[np.isfinite(r)]
    if len(r) < 100:
        return None

    # 1. 肥尾
    kurt = stats.kurtosis(r)              # excess kurtosis (正态=0)
    total_kurt = kurt + 3.0

    # 2. 收益率自相关
    ac1 = np.corrcoef(r[:-1], r[1:])[0, 1]
    ac5 = np.corrcoef(r[:-5], r[5:])[0, 1] if len(r) > 10 else np.nan

    # 3. 波动率聚集: |r| 的自相关
    ar = np.abs(r)
    av1 = np.corrcoef(ar[:-1], ar[1:])[0, 1]
    av5 = np.corrcoef(ar[:-5], ar[5:])[0, 1] if len(ar) > 10 else np.nan

    # 4. 方差比 (随机游走=1, 趋势>1, 反转<1)
    def var_ratio(k):
        if len(r) < k * 10:
            return np.nan
        var1 = r.var()
        vark = np.var(np.add.reduceat(r[:len(r)//k*k], np.arange(0, len(r)//k*k, k)), axis=-1) if k>1 else var1
        vark = np.var([r[i:i+k].sum() for i in range(0, len(r)-k, k)])
        return vark / (k * var1) if var1 > 0 else np.nan

    vr5 = var_ratio(5)

    res = dict(
        n=len(r),
        mean=r.mean() * 1e4,
        vol=r.std() * 1e4,
        kurtosis=total_kurt,
        ac1=ac1,
        ac5=ac5,
        abs_ac1=av1,
        abs_ac5=av5,
        var_ratio5=vr5,
    )
    return res


def print_facts(res, label):
    print(f"\n  【{label}】")
    print(f"    样本数        : {res['n']}")
    print(f"    日收益均值    : {res['mean']:>8.2f} bp")
    print(f"    日波动        : {res['vol']:>8.2f} bp")
    print(f"    峰度(正态=3)  : {res['kurtosis']:>8.2f}   "
          f"{'✓肥尾' if res['kurtosis']>3.5 else '✗'}")
    print(f"    收益率AC(1)   : {res['ac1']:>+8.4f}   "
          f"{'✓无自相关' if abs(res['ac1'])<0.05 else ('趋势' if res['ac1']>0 else '反转')}")
    print(f"    收益率AC(5)   : {res['ac5']:>+8.4f}")
    print(f"    |r| AC(1)     : {res['abs_ac1']:>+8.4f}   "
          f"{'✓波动聚集' if res['abs_ac1']>0.05 else '✗无聚集'}")
    print(f"    |r| AC(5)     : {res['abs_ac5']:>+8.4f}")
    print(f"    方差比(5)     : {res['var_ratio5']:>8.3f}   "
          f"({'趋势' if res['var_ratio5']>1.05 else ('反转' if res['var_ratio5']<0.95 else '随机游走')})")


# ============ 主流程 ============
print("=" * 100)
print("实例化交易世界 v1 —— 基于主体的市场模拟")
print("=" * 100)

configs = [
    ("纯噪声世界 (无结构)", dict(true_drift=0.0, trend_strength=0.0)),
    ("含趋势成分 (植入edge)", dict(true_drift=0.0, trend_strength=0.0008)),
    ("含漂移 (牛市)", dict(true_drift=0.0002, trend_strength=0.0)),
]

for label, cfg in configs:
    prices, wh, params = simulate(n_steps=8000, seed=42, **cfg)
    res = stylized_facts(prices)
    if res:
        print_facts(res, label)

print("\n" + "=" * 100)
print("阶段1完成: 世界已建成, 正在检验是否像真实市场")
print("=" * 100)
