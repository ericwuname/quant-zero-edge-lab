"""
【决定性检验】3个全新品种 ETH/FIL/HBAR —— 从未参与任何选择
================================================================
【背景】
  之前 mom_5+fixed 池化4品种: E=+0.064R, t=+2.03
  但那4个品种参与了信号扫描/参数挑选 -> 可能是过拟合

【本次】
  ETH / FIL / HBAR 是全新数据, 从未参与任何选择
  -> 若它们也为正 => t=2.03 的可信度大幅提升
  -> 若为负/零     => 确认过拟合

【规格】完全沿用之前锁定的参数, 不重新调:
  入场 mom_5 (5根bar动量)
  止损 5%, 止盈 固定 1:2 (10%)
  成本 maker 2bp

【额外】A. 合成世界对照: 明知无edge的世界里跑同一规格, 看是否凭空造出显著
       B. 7品种池化
"""
import numpy as np
import pandas as pd

FILES = {
    # 旧4品种(参与过选择)
    'DOGE': '/data/inputs/DOGEUSDT_1h.csv',
    'DOT':  '/data/inputs/DOTUSDT_1h.csv',
    'CRV':  '/data/inputs/CRVUSDT_1h.csv',
    'DASH': '/data/inputs/DASHUSDT_1h.csv',
    # 新3品种(纯样本外)
    'ETH':  '/data/inputs/ETHUSDT_1h.csv',
    'FIL':  '/data/inputs/FILUSDT_1h.csv',
    'HBAR': '/data/inputs/HBARUSDT_1h.csv',
}
NEW = ['ETH', 'FIL', 'HBAR']
OLD = ['DOGE', 'DOT', 'CRV', 'DASH']

S_STOP, R_MULT = 0.05, 2.0


def load():
    out = {}
    for k, p in FILES.items():
        try:
            d = pd.read_csv(p)
        except Exception as e:
            print(f"  [跳过] {k}: {e}"); continue
        cols = {c.lower(): c for c in d.columns}
        need = ['high', 'low', 'close']
        if not all(n in cols for n in need):
            print(f"  [跳过] {k}: 缺列 {d.columns.tolist()}"); continue
        out[k] = dict(high=d[cols['high']].values.astype(float),
                      low=d[cols['low']].values.astype(float),
                      close=d[cols['close']].values.astype(float))
    return out


def mom_signal(cl, w):
    n = len(cl)
    s = np.zeros(n)
    s[w:] = np.sign(cl[w:] / np.maximum(cl[:-w], 1e-9) - 1)
    return s


def run_trades(D, signal, s, R, cost_bp=2, max_hold=800, start=0, end=None):
    """fixed 出场, 保守触及顺序(同bar双触及时算止损)"""
    hi, lo, cl = D['high'], D['low'], D['close']
    n = len(cl) if end is None else min(end, len(cl))
    cost_R = 2 * cost_bp / 1e4 / s
    net = []
    i = max(start, 120)
    while i < n - 2:
        sg = signal[i]
        if sg == 0:
            i += 1; continue
        direction = 1 if sg > 0 else -1
        entry = cl[i]
        out_R = None
        j = i
        for jj in range(i + 1, min(i + max_hold, n)):
            if direction == 1:
                adv = lo[jj] / entry - 1
                fav = hi[jj] / entry - 1
            else:
                adv = 1 - hi[jj] / entry
                fav = 1 - lo[jj] / entry
            if adv <= -s:
                out_R = -1.0; j = jj; break
            if fav >= R * s:
                out_R = R; j = jj; break
        if out_R is None:
            j = min(i + max_hold, n - 1)
            out_R = ((cl[j] / entry - 1) * direction) / s
        net.append(out_R - cost_R)
        i = j + 1
    return np.array(net)


def stats_of(net):
    if len(net) < 30: return None
    E = net.mean()
    sd = net.std()
    t = E / (sd / np.sqrt(len(net))) if sd > 0 else 0
    return dict(n=len(net), win=(net > 0).mean(), E_R=E, t=t)


def path_risk(net, f=0.01, init=10000.0):
    nav = np.empty(len(net) + 1); nav[0] = init
    for i, r in enumerate(net):
        nav[i + 1] = nav[i] * (1.0 + f * r)
        if nav[i + 1] <= 0: nav[i + 1:] = 0; break
    mc, cur = 0, 0
    for r in net:
        if r < 0: cur += 1; mc = max(mc, cur)
        else: cur = 0
    pk = np.maximum.accumulate(nav)
    return dict(final=nav[-1],
                mdd=-((nav - pk) / np.maximum(pk, 1e-12)).min() * 100,
                max_consec=mc)


def pooled(syms, data, cost_bp=2, oos_only=True):
    allnet = []
    for sym in syms:
        if sym not in data: continue
        D = data[sym]
        n = len(D['close'])
        st0 = 0 if not oos_only else n // 2
        sg = mom_signal(D['close'], 5)
        nt = run_trades(D, sg, S_STOP, R_MULT, cost_bp=cost_bp,
                        start=st0, end=n)
        if len(nt) >= 30: allnet.append(nt)
    if not allnet: return None, None
    cat = np.concatenate(allnet)
    return stats_of(cat), path_risk(cat)


data = load()
print("=" * 100)
print("【决定性检验】3个全新品种 ETH/FIL/HBAR (从未参与任何选择)")
print("=" * 100)
print(f"  规格锁定: mom_5入场, 止损5%, 止盈1:2, maker 2bp")
print(f"  盈亏平衡胜率 p* = {(1+2*2e-4/S_STOP)/(1+R_MULT)*100:.2f}%")

# ---------- 1. 新3品种单独 ----------
print(f"\n  【1】新3品种 单独结果 (全样本 + 样本外50%)")
print(f"  {'品种':<7}{'样本':<10}{'笔数':>7}{'胜率':>9}{'E(R)':>10}{'t':>8}{'判定':>8}")
print("  " + "-" * 62)
new_results = {}
for sym in NEW:
    if sym not in data: continue
    D = data[sym]
    n = len(D['close'])
    sg = mom_signal(D['close'], 5)
    for tag, st0 in [('全样本', 0), ('样本外', n // 2)]:
        nt = run_trades(D, sg, S_STOP, R_MULT, cost_bp=2, start=st0, end=n)
        st = stats_of(nt)
        if st is None: continue
        new_results[(sym, tag)] = st
        pv = '★' if (st['t'] > 1.96 and st['E_R'] > 0) else ('正' if st['E_R'] > 0 else '负')
        print(f"  {sym:<7}{tag:<10}{st['n']:>7}{st['win']*100:>8.1f}%"
              f"{st['E_R']:>+10.3f}{st['t']:>+8.2f}{pv:>8}")

pos_new = sum(1 for (s, tg), st in new_results.items()
              if tg == '样本外' and st['E_R'] > 0)
print(f"    -> 新品种样本外 E>0: {pos_new}/3")

# ---------- 2. 池化对比 ----------
print(f"\n  【2】池化对比")
print(f"  {'组合':<18}{'笔数':>8}{'胜率':>9}{'E(R)':>10}{'t':>8}{'终值':>10}{'回撤':>8}")
print("  " + "-" * 72)
for label, syms in [('旧4品种', OLD), ('新3品种', NEW), ('全部7品种', OLD + NEW)]:
    st, pr = pooled(syms, data)
    if st is None: continue
    print(f"  {label:<18}{st['n']:>8}{st['win']*100:>8.1f}%{st['E_R']:>+10.3f}"
          f"{st['t']:>+8.2f}{pr['final']:>10.0f}{pr['mdd']:>7.1f}%")

# ---------- 3. 合成世界对照 ----------
print(f"\n  【3】合成世界对照 (明知【无edge】, 跑同一规格)")
print(f"      若这里也跑出 t>1.96 => 流程会凭空造假的显著")
print(f"  {'世界':<14}{'笔数':>8}{'胜率':>9}{'E(R)':>10}{'t':>8}{'判定':>8}")
print("  " + "-" * 58)


def make_random_world(n=50000, seed=0, vol=0.006):
    rng = np.random.default_rng(seed)
    r = rng.normal(0, vol, n)
    # 加轻微波动聚集(GARCH感), 但不加方向可预测性
    vol_t = np.abs(r)
    for i in range(1, n):
        vol_t = vol  # 简化: 固定波动
    cl = 100 * np.exp(np.cumsum(r))
    hi = cl * (1 + np.abs(rng.normal(0, vol * 0.8, n)))
    lo = cl * (1 - np.abs(rng.normal(0, vol * 0.8, n)))
    return dict(close=cl, high=np.maximum(hi, cl), low=np.minimum(lo, cl))


sig_count = 0
for seed in range(20):
    W = make_random_world(seed=seed)
    sg = mom_signal(W['close'], 5)
    nt = run_trades(W, sg, S_STOP, R_MULT, cost_bp=2, start=0)
    st = stats_of(nt)
    if st is None: continue
    if st['t'] > 1.96 and st['E_R'] > 0:
        sig_count += 1
    if seed < 5:
        print(f"  随机世界#{seed:<8}{st['n']:>8}{st['win']*100:>8.1f}%"
              f"{st['E_R']:>+10.3f}{st['t']:>+8.2f}")
print(f"  -> 20个无edge世界中, 跑出'显著正'的个数: {sig_count}/20 "
      f"(期望<=1, 若>=3说明流程有正向偏误)")

# ---------- 4. 7品种分年度 ----------
print(f"\n  【4】7品种池化 分年度稳定性")
print(f"  {'段':<10}{'笔数':>8}{'胜率':>9}{'E(R)':>10}{'t':>8}")
print("  " + "-" * 46)
for si in range(1, 6):
    allnet = []
    for sym in OLD + NEW:
        if sym not in data: continue
        D = data[sym]
        n = len(D['close']); L = n // 6
        a, b = si * L, min((si + 1) * L, n)
        if b - a < 500: continue
        sg = mom_signal(D['close'], 5)
        nt = run_trades(D, sg, S_STOP, R_MULT, cost_bp=2, start=a, end=b)
        if len(nt) >= 30: allnet.append(nt)
    if not allnet: continue
    st = stats_of(np.concatenate(allnet))
    if st is None: continue
    print(f"  第{si}段{'':<5}{st['n']:>8}{st['win']*100:>8.1f}%"
          f"{st['E_R']:>+10.3f}{st['t']:>+8.2f}")

print("\n" + "=" * 100)
print("完成")
print("=" * 100)
