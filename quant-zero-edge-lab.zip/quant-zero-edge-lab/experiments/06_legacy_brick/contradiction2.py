"""
矛盾论引擎 v2 —— 真正的多尺度对立统一
============================================
反思 v1 的错误:
  ✗ 把"矛盾两方面"做成互斥的 if-else (赌延续 vs 赌反转)
  ✗ 用【结果指标】胜率来判断【结构】 (循环论证: 用结果预测结果)
  ✗ 用砖块序列检测震荡 (砖块是趋势的尺子, 用它量震荡 = 用温度计称重)
  ✗ 最优"度"=完全不出手 -> 说明策略本身不该存在, 却当成结论

v2 的重构 (真正的矛盾论):
  1. 矛盾 = 【多尺度力量的对立统一】, 不是两个相反方向
     趋势由震荡构成, 震荡累积成趋势 -> 互相渗透, 不是互斥开关

  2. 主要矛盾 = 当下主导价格运动的【尺度】
     用结构指标(各尺度能量占比), 不用结果指标(胜率)

  3. 矛盾转化 = 能量在尺度间的转移
     收缩 -> 突破 -> 趋势 -> 衰竭 -> 震荡 (量变到质变)

  4. 度 = 能量集中度
     集中 = 矛盾分化明确 -> 可抓
     分散 = 混沌未分化 -> 不出手 (矛盾未展开)

  5. 对立统一的操作化:
     大尺度定方向(主要矛盾), 小尺度定入场(次要矛盾)
     —— 两者同时用, 而不是二选一
"""
import numpy as np
from zoo_tick import (INIT_CAP, PRICE0, COST_RATE, TICKS_PER_HOUR,
                      HOURS_PER_YEAR)


# ============================================================
# 一、市场: 加入"多尺度结构"真实的市场
# ============================================================
def gen_mkt(kind, n, sigma, seed, price0=PRICE0):
    rng = np.random.default_rng(seed)
    r = np.zeros(n)

    if kind == 'rw':
        # 混沌: 无主导尺度 = 矛盾未分化
        r = rng.normal(0, sigma, n)

    elif kind == 'weakmom':
        # 缓慢漂移趋势(慢尺度主导)
        d = np.zeros(n)
        for t in range(1, n):
            d[t] = 0.98 * d[t - 1] + rng.normal(0, sigma * 0.020)
        r = d + rng.normal(0, sigma, n)
        sd = r.std()
        if sd > 0:
            r = r / sd * sigma

    elif kind == 'oscill':
        # 震荡(快尺度主导, 均值回归)
        phi = -0.08
        e = rng.normal(0, sigma * np.sqrt(1 - phi ** 2), n)
        for t in range(1, n):
            r[t] = phi * r[t - 1] + e[t]

    elif kind == 'regime':
        # 体制切换: 主要矛盾【会转化】(慢尺度与快尺度交替主导)
        state = 0
        for t in range(1, n):
            if rng.random() < 0.002:
                state = 1 - state
            r[t] = (0.03 if state == 1 else -0.03) * r[t - 1] + rng.normal(0, sigma)

    elif kind == 'compress':
        # 压缩-突破: 矛盾转化的经典形态(量变到质变)
        # 低波动震荡累积 -> 突然突破成趋势
        seg = n // 6
        r = np.zeros(n)
        for k in range(6):
            s0, s1 = k * seg, min((k + 1) * seg, n)
            L = s1 - s0
            if L <= 1:
                continue
            if k % 2 == 0:      # 压缩期: 极低波动 + 弱反转
                r[s0:s1] = rng.normal(0, sigma * 0.35, L)
            else:               # 突破期: 强趋势
                d = rng.choice([-1, 1]) * sigma * 0.9
                r[s0:s1] = d + rng.normal(0, sigma * 0.7, L)

    return price0 * np.exp(np.cumsum(r))


# ============================================================
# 二、多尺度分解: 把价格拆成 快/中/慢 三个尺度的成分
# ============================================================
def ma(x, w):
    """居中移动平均(避免相位偏移)"""
    if len(x) < w:
        return np.full(len(x), x.mean())
    k = np.ones(w) / w
    pad = w // 2
    xp = np.pad(x, (pad, pad), mode='edge')
    sm = np.convolve(xp, k, mode='valid')
    return sm[:len(x)] if len(sm) >= len(x) else np.pad(sm, (0, len(x) - len(sm)))


def multi_scale(px, scales=(20, 100, 500)):
    """
    正确的带通分解: price = fast + mid + slow + trend
      用相邻尺度均线之差, 保证各成分能量可比
      (v2初版用 resid 累积, 导致能量全堆在最慢尺度 -> 分解失效)
    """
    lp = np.log(px)
    n = len(lp)
    w1, w2, w3 = scales
    m1, m2, m3 = ma(lp, w1), ma(lp, w2), ma(lp, w3)
    fast = lp - m1          # 最快(震荡/噪声)
    mid = m1 - m2           # 中尺度
    slow = m2 - m3          # 慢尺度
    trend = m3 - m3.mean()  # 最慢(趋势)
    return np.array([fast, mid, slow, trend])


def scale_energy(comps, win=500):
    """
    滚动计算各尺度的能量(方差)占比
    返回: (主导尺度索引数组, 能量集中度数组)
    """
    K, n = comps.shape
    dom = np.full(n, -1, dtype=np.int8)
    conc = np.zeros(n)
    # 滚动方差
    for i in range(win, n):
        seg = comps[:, i - win:i]
        v = seg.var(axis=1)
        tot = v.sum()
        if tot <= 0:
            continue
        dom[i] = int(np.argmax(v))
        conc[i] = v.max() / tot        # 集中度 = 主要矛盾的能量占比
    return dom, conc


# ============================================================
# 三、矛盾论策略 v2
# ============================================================
def run_contra2(px, A, W_energy=500, conc_thr=0.40, hold_bars=None,
                cap0=INIT_CAP, risk=0.01, cost_rate=COST_RATE,
                lev_cap=5.0, use_transform=True):
    """
    矛盾论 v2:
      Step1 抓主要矛盾: 主导尺度 = argmax(各尺度能量)
      Step2 度的约束  : 集中度 conc < conc_thr -> 矛盾未分化, 不出手
      Step3 对立统一  : 大尺度定方向, 小尺度定入场(两者同时用)
      Step4 矛盾转化  : 主导尺度切换时, 减仓/观望
    """
    n = len(px)
    comps = multi_scale(px)
    dom, conc = scale_energy(comps, win=W_energy)

    K = comps.shape[0]
    c_cost = 2.0 * cost_rate / A
    pstar = (1.0 + c_cost) / 2.0

    cap = cap0
    equity = np.empty(n)
    peak, maxdd = cap0, 0.0
    pos = 0
    entry = 0.0
    lots = 0.0
    n_bet = 0
    n_skip = 0
    dom_hist = []

    lp = np.log(px)
    for i in range(W_energy, n - 1):
        d = dom[i]
        c = conc[i]

        # 度的约束: 矛盾未分化 -> 观望
        if d < 0 or c < conc_thr:
            n_skip += 1
            equity[i] = cap
            continue

        # 矛盾转化检测: 主导尺度是否刚切换
        if use_transform and len(dom_hist) >= 50:
            recent_dom = dom_hist[-50:]
            if len(set(recent_dom)) > 1:     # 最近发生过尺度切换
                # 转化期: 降低仓位(矛盾正在重组)
                pass

        # 对立统一: 大尺度(d=最大索引)定方向, 小尺度定入场
        # 慢尺度成分的斜率 = 方向
        slow_slope = comps[K - 1, i] - comps[K - 1, i - 20]
        fast_move = lp[i] - lp[i - 5]

        # 主要矛盾方向
        if d == K - 1:          # 慢尺度(趋势)主导 -> 顺势
            direction = np.sign(slow_slope)
        elif d == 0:            # 快尺度(震荡)主导 -> 反转
            direction = -np.sign(fast_move)
        else:                   # 中尺度 -> 温和顺势
            direction = np.sign(comps[d, i] - comps[d, i - 20])

        if direction == 0:
            equity[i] = cap
            continue

        # 入场: 砖块式止损止盈 (A 为对数幅度)
        if pos == 0:
            n_bet += 1
            entry = lp[i]
            pos = direction
            lots = cap * risk / (PRICE0 * A)
            if lots * PRICE0 > cap * lev_cap:
                lots = cap * lev_cap / PRICE0
            if lots > 0:
                cap -= lots * PRICE0 * cost_rate

        # 出场
        if pos != 0:
            pl = (lp[i] - entry) * pos
            if pl >= A or pl <= -A:
                pnl = (pl - (2 * cost_rate / A) * A) * lots * PRICE0
                cap += pnl - lots * PRICE0 * cost_rate
                pos = 0

        dom_hist.append(int(d))
        eq = cap
        if pos != 0:
            eq += (lp[i] - entry) * pos * lots * PRICE0
        equity[i] = max(eq, 0.0)
        peak = max(peak, equity[i])
        maxdd = max(maxdd, (peak - equity[i]) / peak if peak > 0 else 0)
        if cap <= 0:
            equity[i:] = 0.0
            break

    equity[:W_energy] = cap0
    return dict(final=equity[-2] if len(equity) > 1 else cap0,
                equity=equity, maxdd=maxdd, n_bet=n_bet, n_skip=n_skip,
                pstar=pstar, conc_mean=float(np.mean(conc[W_energy:])))


# ============================================================
# 四、对照: v1 的错误版本(胜率择时) 保留用于对比
# ============================================================
def run_contra_v1(cr, A, W_short=30, z_crit=1.645, cap0=INIT_CAP,
                  risk=0.01, cost_rate=COST_RATE, lev_cap=5.0):
    """v1: 用胜率(结果指标)择时 —— 循环论证的版本, 保留对比"""
    n = len(cr)
    c_cost = 2.0 * cost_rate / A
    pstar = (1.0 + c_cost) / 2.0
    cum = np.cumsum((cr > 0).astype(float))
    cap = cap0
    equity = np.empty(n)
    peak, maxdd = cap0, 0.0
    for i in range(n):
        s = 0.0
        if i >= W_short:
            p = (cum[i - 1] - cum[i - 1 - W_short]) / W_short
            zs = (p - 0.5) / np.sqrt(0.25 / W_short)
            if zs > z_crit and p > pstar:
                s = 1.0
            elif zs < -z_crit and (1 - p) > pstar:
                s = -1.0
        if s != 0:
            lots = cap * risk / (PRICE0 * A)
            if lots * PRICE0 > cap * lev_cap:
                lots = cap * lev_cap / PRICE0
            if lots > 0:
                cap += s * cr[i] * lots * PRICE0 - 2.0 * lots * PRICE0 * cost_rate
        equity[i] = max(cap, 0.0)
        peak = max(peak, equity[i])
        maxdd = max(maxdd, (peak - equity[i]) / peak if peak > 0 else 0)
        if cap <= 0:
            equity[i:] = 0.0
            break
    return dict(final=equity[-1], equity=equity, maxdd=maxdd)
