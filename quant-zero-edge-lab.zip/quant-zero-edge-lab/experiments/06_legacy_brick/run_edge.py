"""
实验D: edge 的"厚度" —— 真edge能扛住多少摩擦?
================================================
核心问题: 期望为正是根。那这个"正"有多厚?
  - 无edge市场: 成本=0 时收益≈0, 一加摩擦立刻为负 (厚度为0)
  - 有edge市场: 能扛住一定摩擦, 超过临界成本才转负 (厚度>0)

再验证: 多策略/多品种组合 —— 能否把"我只有一条线"的困境改善?
"""
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from zoo import (gen_market, eval_bar, strat_ma_cross, strat_tsmom,
                 strat_breakout, strat_rsi_rev)

plt.rcParams['font.sans-serif'] = ['WenQuanYi Micro Hei', 'DejaVu Sans']
plt.rcParams['axes.unicode_minus'] = False

N = 12000
NSEED = 15
COSTS = [0.0, 0.0002, 0.0005, 0.001, 0.002, 0.004, 0.008]

print("=" * 92)
print("实验D-1: 成本临界 —— 趋势策略(均线10/50)的净期望 vs 交易成本")
print("=" * 92)
print(f"  {'成本(每次换手)':>14} {'随机游走(无edge)':>18} {'趋势市场(有edge)':>18}")
rows = []
for c in COSTS:
    rw_v, tv_v = [], []
    for s in range(NSEED):
        px, _ = gen_market("RW", N, seed=11000 + s)
        rw_v.append(eval_bar(px, strat_ma_cross(px, 10, 50), cost=c)["ret_ann"] * 100)
        px2, _ = gen_market("TRENDVOL", N, seed=12000 + s)
        tv_v.append(eval_bar(px2, strat_ma_cross(px2, 10, 50), cost=c)["ret_ann"] * 100)
    rw_m, tv_m = np.mean(rw_v), np.mean(tv_v)
    rows.append((c, rw_m, tv_m))
    print(f"  {c:>14.4f} {rw_m:>17.2f}% {tv_m:>17.2f}%")

# 临界成本: 趋势市场收益转负的点
crit = None
for i in range(1, len(rows)):
    if rows[i - 1][2] > 0 and rows[i][2] <= 0:
        crit = rows[i][1 - 1] if False else rows[i][0]
        break
print(f"\n  无edge市场: 成本=0 时 ≈{rows[0][1]:.2f}% (≈0, 本来就无edge), 一加摩擦立刻负 -> 厚度=0")
if crit:
    print(f"  有edge市场: 临界成本 ≈ {crit*100:.2f}% -> 摩擦超过它, 真edge也被吃光 (厚度有限)")
else:
    print(f"  有edge市场: 即使成本 {COSTS[-1]*100:.1f}% 仍为正 -> edge 很厚")

print("\n" + "=" * 92)
print("实验D-2: 组合效应 —— 多策略低相关组合, 能否改善我'只有一条线'的困境?")
print("=" * 92)
print("  逻辑: 组合不创造edge, 但降低波动 -> 同样的edge, Sharpe更高, 更容易活到验证完")

STRATS = [("趋势A(均线10/50)", lambda p: strat_ma_cross(p, 10, 50)),
          ("趋势B(均线20/100)", lambda p: strat_ma_cross(p, 20, 100)),
          ("时序动量(60)", lambda p: strat_tsmom(p, 60)),
          ("通道突破(40)", lambda p: strat_breakout(p, 40))]

print(f"  {'策略':<18} {'年化%':>9} {'Sharpe':>8} {'交易次数':>9}")
singles, sharpes, rets_series = [], [], []
for name, fn in STRATS:
    rs, shs, nts = [], [], []
    for s in range(NSEED):
        px, _ = gen_market("TRENDVOL", N, seed=13000 + s)
        e = eval_bar(px, fn(px))
        rs.append(e["ret_ann"] * 100); shs.append(e["sharpe"]); nts.append(e["n_trades"])
    singles.append(np.mean(rs)); sharpes.append(np.mean(shs))
    rets_series.append(rs)
    print(f"  {name:<18} {np.mean(rs):>8.2f}% {np.mean(shs):>8.3f} {np.mean(nts):>9.0f}")

# 等权组合: 把各策略的净收益序列平均 (近似)
print(f"\n  {'等权组合':<18} ", end="")
comb_r, comb_s = [], []
for s in range(NSEED):
    px, _ = gen_market("TRENDVOL", N, seed=13000 + s)
    nets = []
    for name, fn in STRATS:
        pos = np.roll(fn(px), 1); pos[0] = 0
        rlog = np.concatenate([[0.0], np.log(px[1:] / px[:-1])])
        turnover = np.abs(np.diff(pos, prepend=0.0))
        nets.append(pos * rlog - turnover * 0.0005)
    avg = np.mean(nets, axis=0)
    comb_r.append(avg.mean() * 252 * 100)
    comb_s.append(avg.mean() / avg.std() * np.sqrt(252) if avg.std() > 0 else 0)
print(f"{np.mean(comb_r):>8.2f}% {np.mean(comb_s):>8.3f}")
print(f"\n  单策略平均 Sharpe: {np.mean(sharpes):.3f}  ->  组合 Sharpe: {np.mean(comb_s):.3f}")
print(f"  改善: {(np.mean(comb_s)/max(1e-9,np.mean(sharpes))-1)*100:+.1f}%  (组合降低波动, 但不创造edge)")

# ============================================================
# 图
# ============================================================
fig, axes = plt.subplots(1, 2, figsize=(15, 5.4))
fig.suptitle("edge 的“厚度”：真 edge 能扛住多少摩擦？组合能救什么？",
             fontsize=14, fontweight='bold')

ax = axes[0]
cs = [r[0] * 100 for r in rows]
ax.plot(cs, [r[1] for r in rows], 'o-', color='salmon', lw=2.4, ms=8, label='随机游走 (无edge)')
ax.plot(cs, [r[2] for r in rows], 's-', color='steelblue', lw=2.4, ms=8, label='趋势市场 (有真edge)')
ax.axhline(0, color='k', lw=1.3, ls='--')
ax.set_xlabel("每次换手的交易成本 %")
ax.set_ylabel("年化净收益 %")
ax.set_title("① 成本临界：edge 的“厚度”\n无edge: 厚度为0, 一加摩擦立刻负\n有edge: 能扛摩擦, 但超过临界值也归零",
             fontsize=11)
ax.legend(fontsize=10); ax.grid(alpha=.3)
if crit:
    ax.axvline(crit * 100, color='red', ls=':', lw=1.8)
    ax.text(crit * 100 + 0.02, ax.get_ylim()[0] + 1, f'临界\n{crit*100:.2f}%',
            fontsize=9, color='red')

ax = axes[1]
names = [s[0] for s in STRATS] + ["等权组合"]
vals = sharpes + [np.mean(comb_s)]
cols = ['steelblue'] * len(STRATS) + ['green']
ax.bar(range(len(names)), vals, color=cols)
ax.axhline(0, color='k', lw=1.2)
ax.set_xticks(range(len(names)))
ax.set_xticklabels(names, rotation=20, fontsize=9)
ax.set_ylabel("Sharpe（风险调整后）")
ax.set_title("② 组合：不创造edge, 但压低波动 → Sharpe提升\n这是你'只有一条线'困境里唯一可改善的部分",
             fontsize=11)
ax.grid(alpha=.3, axis='y')
for i, v in enumerate(vals):
    ax.text(i, v + 0.01, f"{v:.3f}", ha='center', fontsize=9)

plt.tight_layout(rect=[0, 0, 1, 0.92])
plt.savefig("/data/workspace/brick/fig_edge.png", dpi=130)
print("\n[已保存] fig_edge.png")
