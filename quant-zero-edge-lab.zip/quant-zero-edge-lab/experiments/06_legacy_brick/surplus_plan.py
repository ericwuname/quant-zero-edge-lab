"""
【盈余公积方案测试】
用户方案: 不做复利, 定期结算, 提取盈余, 判据="累计提取 > 投入本金"即真赚到
         本金亏完则用公积金"开新店"
对比: A纯复利 / B定期提取 / C多店序列
"""
import numpy as np, pandas as pd
FILES={'DOGE':'/data/inputs/DOGEUSDT_1h.csv','DOT':'/data/inputs/DOTUSDT_1h.csv',
       'CRV':'/data/inputs/CRVUSDT_1h.csv','DASH':'/data/inputs/DASHUSDT_1h.csv',
       'ETH':'/data/inputs/ETHUSDT_1h.csv','FIL':'/data/inputs/FILUSDT_1h.csv',
       'HBAR':'/data/inputs/HBARUSDT_1h.csv'}
def load():
    o={}
    for k,p in FILES.items():
        d=pd.read_csv(p);c={x.lower():x for x in d.columns}
        o[k]=dict(open=d[c['open']].values.astype(float),high=d[c['high']].values.astype(float),
                  low=d[c['low']].values.astype(float),close=d[c['close']].values.astype(float))
    return o
def s_brk(cl,w):
    n=len(cl);s=np.zeros(n)
    for i in range(w,n):
        h=cl[i-w:i].max();l=cl[i-w:i].min()
        if cl[i]>h:s[i]=1
        elif cl[i]<l:s[i]=-1
    return s
def s_mom(cl,w):
    n=len(cl);s=np.zeros(n);s[w:]=np.sign(cl[w:]/np.maximum(cl[:-w],1e-9)-1);return s
def run(D,sg,s,R,cost_bp,slip_bp,max_hold,start,end,mode):
    op,hi,lo,cl=D['open'],D['high'],D['low'],D['close']
    n=len(cl) if end is None else min(end,len(cl))
    cR=2*cost_bp/1e4/s; slipR=slip_bp/1e4/s; stopd=s+slip_bp/1e4
    net=[];i=max(start,120)
    while i<n-3:
        d=1 if sg[i]>0 else (-1 if sg[i]<0 else 0)
        if d==0:i+=1;continue
        e=op[i+1];i0=i+1;out=None;j=i0
        for jj in range(i0,min(i0+max_hold,n)):
            adv=(lo[jj]/e-1) if d==1 else (1-hi[jj]/e)
            fav=(hi[jj]/e-1) if d==1 else (1-lo[jj]/e)
            if adv<=-stopd: out=-1.0-slipR;j=jj;break
            if fav>=R*s: out=R;j=jj;break
            if mode=='flip' and sg[jj]*d<0: out=((cl[jj]/e-1)*d)/s;j=jj;break
        if out is None:
            j=min(i0+max_hold,n-1);out=((cl[j]/e-1)*d)/s
        net.append(out-cR);i=j+1
    return np.array(net)

data=load()
alln=[]
for k,D in data.items():
    n=len(D['close'])
    nt=run(D,s_brk(D['close'],20),0.05,2.0,2,5,800,n//2,n,'flip')
    if len(nt)>=30: alln.append(nt)
R_pool=np.concatenate(alln)
print("="*104)
print("【盈余公积方案】基准序列 brk20_flip: E[R]=%+.4f  σ=%.3f  N=%d"%(R_pool.mean(),R_pool.std(),len(R_pool)))
print("="*104)

W0=10000.0   # 单店本金
F=0.01       # 每笔风险1%
BUST=0.20    # 净值跌破本金20% => 关店(爆仓)
NSIM=2000
HORIZON=3000 # 模拟笔数

def sim_compound(rng):
    """A 纯复利: 全再投入, 不提取"""
    R=rng.choice(R_pool,HORIZON,replace=True)
    W=W0; peak=W0; mdd=0; bankrupt=False
    for r in R:
        W*= (1+F*r)
        if W>peak: peak=W
        mdd=max(mdd,(peak-W)/peak)
        if W<W0*BUST: bankrupt=True;break
    return dict(total=W, withdrawn=0, leftover=W, bankrupt=bankrupt, mdd=mdd,
                got_profit=W>W0)

def sim_withdraw(rng, q, period):
    """B 定期提取: 每period笔结算, 提取超出本金部分的q"""
    R=rng.choice(R_pool,HORIZON,replace=True)
    W=W0; G=0.0; peak=W0; mdd=0; bankrupt=False
    first_win=None
    for i,r in enumerate(R):
        W*=(1+F*r)
        if W>peak: peak=W
        mdd=max(mdd,(peak-W)/peak)
        if W<W0*BUST: bankrupt=True;break
        if (i+1)%period==0 and W>W0:
            draw=(W-W0)*q
            W-=draw; G+=draw
            peak=W
        if first_win is None and G>W0: first_win=i+1
    return dict(total=W+G, withdrawn=G, leftover=W, bankrupt=bankrupt, mdd=mdd,
                got_profit=G>W0, first_win=first_win)

def sim_multishop(rng, q, period, nshop):
    """C 多店序列: 每店跑到爆仓或到期, 关店后用公积金开新店"""
    G=0.0; total_left=0.0; shops=0; any_win=False; fwin=None; cum_bars=0
    for sh in range(nshop):
        # 开店本金: 第一店用初始, 后续用公积金(够W0才开)
        if sh==0: capital=W0
        else:
            if G>=W0:
                capital=W0; G-=W0
            else: break
        R=rng.choice(R_pool,HORIZON,replace=True)
        W=capital; peak=W; mdd=0; closed=False
        for i,r in enumerate(R):
            W*=(1+F*r)
            if W>peak: peak=W
            mdd=max(mdd,(peak-W)/peak)
            if W<capital*BUST: closed=True;break
            if (i+1)%period==0 and W>capital:
                draw=(W-capital)*q
                W-=draw; G+=draw; peak=W
            if fwin is None and G>W0: fwin=cum_bars+i+1
        G+=W  # 关店/到期, 剩余归入公积金
        cum_bars+=len(R) if not closed else i+1
        shops+=1
        if G>W0: any_win=True
        if closed and G<W0: break
    return dict(total=G, withdrawn=G, leftover=0, bankrupt=False, mdd=mdd,
                got_profit=any_win, first_win=fwin, shops=shops)

rng=np.random.default_rng(42)
print(f"\n  模拟: {NSIM}次bootstrap, 每店本金{W0:.0f}, 每笔风险{F*100:.0f}%, "
      f"爆仓线{int(BUST*100)}%, 视野{HORIZON}笔")
print(f"\n  【A vs B】纯复利 vs 定期提取(提取率q, 结算周期)")
print(f"  {'模式':<28}{'最终总资产':>11}{'累计提取':>10}{'剩余净值':>10}{'真赚到%':>9}{'爆仓%':>8}{'回撤':>8}")
print("  "+"-"*88)

def summarize(res,label):
    tot=np.array([x['total'] for x in res])
    wd=np.array([x['withdrawn'] for x in res])
    lf=np.array([x['leftover'] for x in res])
    gp=np.array([x['got_profit'] for x in res])
    bk=np.array([x['bankrupt'] for x in res])
    md=np.array([x['mdd'] for x in res])
    print(f"  {label:<28}{np.median(tot):>11.0f}{np.median(wd):>10.0f}{np.median(lf):>10.0f}"
          f"{gp.mean()*100:>8.1f}%{bk.mean()*100:>7.1f}%{np.median(md)*100:>7.1f}%")
    return dict(med_total=np.median(tot),p_win=gp.mean(),p_bust=bk.mean(),med_wd=np.median(wd))

resA=[sim_compound(rng) for _ in range(NSIM)]
A=summarize(resA,'A 纯复利(不提取)')

for q in [0.5,1.0]:
    for period in [50,200]:
        res=[sim_withdraw(rng,q,period) for _ in range(NSIM)]
        summarize(res,f'B 提取{int(q*100)}% 每{period}笔结算')

print(f"\n  【C 多店序列】(用公积金开新店, 最多5店)")
for q in [0.5,1.0]:
    res=[sim_multishop(rng,q,200,5) for _ in range(NSIM)]
    tot=np.array([x['total'] for x in res])
    gp=np.array([x['got_profit'] for x in res])
    sh=np.array([x['shops'] for x in res])
    print(f"  C 提取{int(q*100)}% 每200笔  最终中位={np.median(tot):.0f}  真赚到={gp.mean()*100:.1f}%  平均开店数={sh.mean():.1f}")

print(f"\n  【关键对比】'真的赚到'=累计提取>本金({W0:.0f})")
print(f"    纯复利: 靠净值增长, 提取=0, 判定靠 leftover>W0")
print(f"    提取制: 靠公积金累积, 判定靠 withdrawn>W0  <- 钱已落袋, 不受后续回撤影响")
print("\n"+"="*104)
