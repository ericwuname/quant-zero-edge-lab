import numpy as np, pandas as pd
FILES={'DOGE':'/data/inputs/DOGEUSDT_1h.csv','DOT':'/data/inputs/DOTUSDT_1h.csv',
       'CRV':'/data/inputs/CRVUSDT_1h.csv','DASH':'/data/inputs/DASHUSDT_1h.csv',
       'ETH':'/data/inputs/ETHUSDT_1h.csv','FIL':'/data/inputs/FILUSDT_1h.csv',
       'HBAR':'/data/inputs/HBARUSDT_1h.csv'}
def load():
    o={}
    for k,p in FILES.items():
        d=pd.read_csv(p);c={x.lower():x for x in d.columns}
        o[k]=dict(open=d[c['open']].values.astype(float),high=d[c['high']].values.astype(float),
                  low=d[c['low']].values.astype(float),close=d[c['close']].values.astype(float))
    return o
data=load()

print("="*100)
print("【C】极阳桶重验 — 修复框架(去前视, 用open入场)")
print("="*100)
print("  旧结论: 极阳(z>2)后10日 +483bp, p=0.000 (日线+收盘价, 有前视嫌疑)")
print("  新检验: 1h, 240bar动量z-score分桶, 未来10bar用open[t+1]..open[t+11]")
print(f"\n  {'分桶':<10}{'N':>8}{'未来10bar(bp)':>16}{'t':>8}")
print("  "+"-"*44)
allb={}
for k,D in data.items():
    cl=D['close'];op=D['open'];n=len(cl);w=240;h=10
    L=n-w-h-1
    if L<1000: continue
    # 信号: 过去w bar收益
    r240=cl[w:w+L]/np.maximum(cl[0:L],1e-9)-1
    # 用更早期数据估mu/sd (避免自身包含)
    lr=np.diff(np.log(np.maximum(cl,1e-9)))
    df=pd.Series(lr)
    mu=df.rolling(w).mean().values; sd=df.rolling(w).std().values
    mu_v=mu[w-1:w-1+L]; sd_v=sd[w-1:w-1+L]
    m=np.isfinite(sd_v)&(sd_v>1e-12)&np.isfinite(mu_v)&np.isfinite(r240)
    z=np.full(L,np.nan); z[m]=(r240[m]-mu_v[m])/sd_v[m]
    # 未来h bar收益: open[w+1] -> open[w+1+h]
    fut=op[w+1+h:w+1+h+L]/np.maximum(op[w+1:w+1+L],1e-9)-1
    v=np.isfinite(z)&np.isfinite(fut)
    zv=z[v];fv=fut[v]*1e4
    edges=[-np.inf,-1,-0.5,0.5,1,np.inf]
    for i,lab in enumerate(['极阴','阴','中','阳','极阳']):
        mk=(zv>=edges[i])&(zv<edges[i+1])
        if mk.sum()<200: continue
        allb.setdefault(lab,[]).append(fv[mk])
rows=[]
for lab in ['极阴','阴','中','阳','极阳']:
    if lab not in allb: continue
    a=np.concatenate(allb[lab]);N=len(a)
    t=a.mean()/(a.std()/np.sqrt(N)) if a.std()>0 else 0
    rows.append((lab,N,a.mean(),t))
    print(f"  {lab:<10}{N:>8}{a.mean():>16.1f}{t:>8.2f}")
if rows:
    yang=[r for r in rows if r[0]=='极阳']
    zhong=[r for r in rows if r[0]=='中']
    if yang and zhong:
        d=yang[0][2]-zhong[0][2]
        print(f"\n  极阳 - 中 = {d:+.1f} bp/10bar")
        print(f"  旧结论称 +483bp/10日; 新(修复前视后)= {d:+.1f}bp/10bar")

print("\n"+"="*100)
print("【D】短期反转可交易性 — 修复框架")
print("="*100)
def s_mom(cl,w):
    n=len(cl);s=np.zeros(n);s[w:]=np.sign(cl[w:]/np.maximum(cl[:-w],1e-9)-1);return s
def run(D,sg,s=0.05,R=2.0,cost_bp=2,slip_bp=5,max_hold=800,start=0,end=None):
    op,hi,lo,cl=D['open'],D['high'],D['low'],D['close']
    n=len(cl) if end is None else min(end,len(cl))
    cR=2*cost_bp/1e4/s;slipR=slip_bp/1e4/s;stopd=s+slip_bp/1e4
    net=[];i=max(start,120)
    while i<n-3:
        d=1 if sg[i]>0 else (-1 if sg[i]<0 else 0)
        if d==0: i+=1;continue
        e=op[i+1];i0=i+1;out=None;j=i0
        for jj in range(i0,min(i0+max_hold,n)):
            adv=(lo[jj]/e-1) if d==1 else (1-hi[jj]/e)
            fav=(hi[jj]/e-1) if d==1 else (1-lo[jj]/e)
            if adv<=-stopd: out=-1.0-slipR;j=jj;break
            if fav>=R*s: out=R;j=jj;break
            if sg[jj]*d<0: out=((cl[jj]/e-1)*d)/s;j=jj;break
        if out is None:
            j=min(i0+max_hold,n-1);out=((cl[jj]/e-1)*d)/s if False else ((cl[j]/e-1)*d)/s
        net.append(out-cR);i=j+1
    return np.array(net)
def st(net):
    if len(net)<30: return None
    E=net.mean();sd=net.std()
    return dict(n=len(net),win=(net>0).mean(),E=E,t=E/(sd/np.sqrt(len(net))) if sd>0 else 0)

print(f"  {'信号':<10}{'止损':>7}{'R':>4}{'N':>8}{'胜率':>8}{'E(R)':>9}{'t':>8}")
print("  "+"-"*56)
for nm,sginv in [('rev_5(反转)',True),('mom_5(动量)',False)]:
    for s in [0.02,0.05]:
        for R in [1,2]:
            alln=[]
            for k,D in data.items():
                n=len(D['close'])
                sg=s_mom(D['close'],5)
                if sginv: sg=-sg
                nt=run(D,sg,s=s,R=R,cost_bp=2,slip_bp=5,start=n//2,end=n)
                if len(nt)>=30: alln.append(nt)
            if not alln: continue
            c=np.concatenate(alln);s_=st(c)
            print(f"  {nm:<10}{s*100:>6.0f}%{R:>4}{s_['n']:>8}{s_['win']*100:>7.1f}%{s_['E']:>+9.4f}{s_['t']:>+8.2f}")
print("\n"+"="*100)
