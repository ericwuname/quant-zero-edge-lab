"""
【下一步】分散化能否跨过检测门槛?
=====================================
【核心命题】
  组合夏普 = 单市场夏普 × sqrt(N_eff)     (N_eff = 有效独立市场数)
  -> 分散化【提高信噪比】, 且不增加过拟合
  -> 这是唯一能"合法"跨过检测门槛的方法

【为什么这和"加策略"不同】
  加策略(同一市场): 多重检验 -> Reality Check 更严 -> 更找不出
  加市场(同一策略): 独立样本 -> 检测力上升     -> 更可能找出

【实验设计】
  1. 在我的世界里生成 M 个【独立】世界 (不同seed, 相关性应≈0)
  2. 每个世界植入【弱】edge (单市场夏普 < 0.673 门槛)
  3. 用【固定策略】(不加选择, 无选择偏差) 在各市场分别交易
  4. 等权组合 N 个市场 -> 看组合夏普如何随 N 增长
  5. 关键对照: 【无edge世界】组合夏普是否也随N增长?
     (若也增长 -> 分散化能凭空造edge, 危险! 若否 -> 分散化只放大真edge)

【真实数据部分】
  crypto 7品种相关性 0.497 -> 有效独立市场数 = N/(1+(N-1)ρ) = ?
  推算: 需要多少个真正独立的市场才能跨过门槛?
"""
import numpy as np
import pandas as pd
from scipy import stats
import sys
sys.path.insert(0, '/data/workspace/brick')
from world_v5 import World

DAYS_YR = 365
COST_BP = 10
CRITICAL_SHARPE = 0.673


def build_signals(prices):
    T = len(prices) - 1
    P = prices[:T]
    S = {}
    for w in [5, 10, 20, 60]:
        if T > w + 1:
            mom = np.zeros(T)
            mom[w:] = P[w:] / np.maximum(P[:-w], 1e-9) - 1
            S[f'mom_{w}'] = np.sign(mom)
    return S


def backtest(sig, r, cost_bp):
    T = len(r)
    pnl = np.zeros(T)
    pnl[:-1] = sig[:-1] * r[1:]
    turn = np.abs(np.diff(np.concatenate([[0.0], sig])))
    return pnl - turn * (2 * cost_bp / 1e4)


def sharpe(x):
    s = x.std()
    return x.mean() / s * np.sqrt(DAYS_YR) if s > 1e-12 else 0.0


print("=" * 100)
print("【下一步】分散化能否跨过检测门槛?")
print("=" * 100)
print(f"  检测门槛(校准得出): 结构夏普需 > {CRITICAL_SHARPE}")
print(f"  命题: 组合夏普 = 单市场夏普 × sqrt(N_eff)")

M = 30          # 世界数(模拟独立市场数)
N_STEPS = 6000
WEAK_EDGE = 0.020      # 弱edge强度 (单市场夏普目标 ~0.2, 远低于门槛)

# ---------- 生成独立世界 ----------
print(f"\n  生成 {M} 个独立世界 (每个 {N_STEPS} 步)...")

def make_worlds(ts, m=M):
    out = []
    for i in range(m):
        w = World(seed=5000 + i, beta=0.0005)
        prices, wh, kinds = w.run(n_steps=N_STEPS, trend_strength=ts)
        out.append(prices)
    return out

worlds_edge = make_worlds(WEAK_EDGE)
worlds_none = make_worlds(0.0)
print(f"  ✓ 完成 (有edge {len(worlds_edge)}个, 无edge {len(worlds_none)}个)")


def oos_pnls(worlds, strat='mom_20'):
    """每个世界用固定策略, 返回样本外pnl列表"""
    out = []
    for prices in worlds:
        r = np.diff(prices) / np.maximum(prices[:-1], 1e-9)
        T = len(r); sp = T // 2
        S = build_signals(prices)
        if strat not in S:
            continue
        pnl = backtest(S[strat], r, COST_BP)
        out.append(pnl[sp:])
    return out

pnl_edge = oos_pnls(worlds_edge)
pnl_none = oos_pnls(worlds_none)

# ---------- 验证世界间独立性 ----------
print(f"\n  【验证1】这些'市场'是否真的独立? (pnl相关性)")
if len(pnl_edge) >= 10:
    mat = np.corrcoef(np.array(pnl_edge[:15]))
    off = mat[~np.eye(len(mat), dtype=bool)]
    print(f"    前15个市场的pnl相关性: 均值 {off.mean():+.4f} "
          f"({'✓独立' if abs(off.mean())<0.05 else '✗相关'})")

# ---------- 核心: 组合夏普 vs N ----------
print(f"\n  【核心】组合夏普 随市场数 N 的变化")
print(f"  {'N':>5}{'有edge组合夏普':>16}{'理论(√N)':>12}"
      f"{'无edge组合夏普':>16}{'判定':>14}")

Ns = [1, 2, 3, 5, 10, 15, 20, 25, 30]
sr1_edge = sharpe(pnl_edge[0])
sr1_none = sharpe(pnl_none[0])
rows = []
for N in Ns:
    if N > len(pnl_edge):
        break
    comb_e = np.mean(pnl_edge[:N], axis=0)
    comb_n = np.mean(pnl_none[:N], axis=0)
    sh_e = sharpe(comb_e)
    sh_n = sharpe(comb_n)
    theo = sr1_edge * np.sqrt(N) if sr1_edge > 0 else np.nan
    rows.append((N, sh_e, sh_n, theo))
    print(f"  {N:>5}{sh_e:>16.3f}{theo:>12.3f}{sh_n:>16.3f}"
          f"{('跨过门槛' if sh_e>CRITICAL_SHARPE else ''):>14}")

# ---------- 关键对照 ----------
print(f"\n  【关键对照】分散化是否凭空造edge?")
sh_e_30 = rows[-1][1] if rows else np.nan
sh_n_30 = rows[-1][2] if rows else np.nan
print(f"    有弱edge世界, N=30 组合夏普: {sh_e_30:.3f}")
print(f"    无edge世界,   N=30 组合夏普: {sh_n_30:.3f}")
print(f"    -> {'✓ 分散化只放大真edge, 不凭空造' if abs(sh_n_30) < abs(sh_e_30)/2 else '⚠ 需检查: 无edge也增长了'}")

# ---------- 需要多少市场? ----------
print(f"\n  【推算】跨过门槛 {CRITICAL_SHARPE} 需要多少个独立市场?")
if rows:
    # 用单市场夏普推算
    sr1 = np.mean([sharpe(p) for p in pnl_edge])
    print(f"    单市场平均夏普: {sr1:.3f}")
    if sr1 > 0:
        N_need = (CRITICAL_SHARPE / sr1) ** 2
        print(f"    理论需要 N = ({CRITICAL_SHARPE}/{sr1:.3f})² = {N_need:.1f} 个独立市场")
    # 实测插值
    Ns_a = np.array([r[0] for r in rows])
    shs = np.array([r[1] for r in rows])
    crit_N = None
    for i in range(len(shs) - 1):
        if shs[i] < CRITICAL_SHARPE <= shs[i + 1]:
            f = (CRITICAL_SHARPE - shs[i]) / (shs[i + 1] - shs[i])
            crit_N = Ns_a[i] + f * (Ns_a[i + 1] - Ns_a[i])
            break
    if crit_N:
        print(f"    实测插值: 需要约 {crit_N:.0f} 个独立市场")
    elif shs[0] >= CRITICAL_SHARPE:
        print(f"    实测: 单市场已跨过门槛")
    else:
        print(f"    实测: 30个市场内未达门槛 (最大 {shs.max():.3f})")

# ---------- 真实crypto的有效市场数 ----------
print(f"\n  【真实数据】crypto 7品种 = 多少个有效独立市场?")
RHO = 0.497
N_real = 7
N_eff = N_real / (1 + (N_real - 1) * RHO)
print(f"    7个品种, 平均相关性 {RHO}")
print(f"    有效独立市场数 = N/(1+(N-1)ρ) = {N_real}/(1+{N_real-1}×{RHO}) = {N_eff:.2f}")
print(f"    -> crypto内部再多加品种: 收益递减, 上限 = 1/ρ = {1/RHO:.2f} 个等效市场")
print(f"    -> 无论加到多少个crypto品种, 有效市场数最多 ≈ {1/RHO:.1f}")

print(f"\n  【结论】")
print(f"    crypto 7品种 ≈ {N_eff:.1f} 个独立市场")
if rows and 'N_need' in dir():
    print(f"    跨过门槛需要 ≈ {N_need:.0f} 个独立市场 (若单市场夏普 {sr1:.3f})")
    print(f"    -> 缺口: {N_need/N_eff:.0f} 倍")
print(f"    -> 必须【跨资产类别】(股/债/商品/外汇), 不是加crypto品种")

print("\n" + "=" * 100)
print("完成")
print("=" * 100)
