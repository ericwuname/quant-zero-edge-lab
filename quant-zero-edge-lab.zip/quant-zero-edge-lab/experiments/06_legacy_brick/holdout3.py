"""
第三批干净样本外验证: TRX/UNI/XLM/XMR/XRP/ZEC
从未参与任何参数/信号选择过程。
锁定规格: brk_20(旧4品种选出), s=5%, R=2, maker 2bp, 修复框架(open[t+1]入场)
"""
import numpy as np, pandas as pd

OLD4 = ['DOGE', 'DOT', 'CRV', 'DASH']
NEW3 = ['ETH', 'FIL', 'HBAR']
NEW6 = ['TRX', 'UNI', 'XLM', 'XMR', 'XRP', 'ZEC']
FILES = {k: f'/data/inputs/{k}USDT_1h.csv' for k in OLD4 + NEW3 + NEW6}


def load():
    o = {}
    for k, p in FILES.items():
        d = pd.read_csv(p)
        c = {x.lower(): x for x in d.columns}
        o[k] = dict(open=d[c['open']].values.astype(float),
                    high=d[c['high']].values.astype(float),
                    low=d[c['low']].values.astype(float),
                    close=d[c['close']].values.astype(float))
    return o


def s_mom(cl, w):
    n = len(cl)
    s = np.zeros(n)
    s[w:] = np.sign(cl[w:] / np.maximum(cl[:-w], 1e-9) - 1)
    return s


def s_brk(cl, w):
    n = len(cl)
    s = np.zeros(n)
    for i in range(w, n):
        h = cl[i - w:i].max()
        l = cl[i - w:i].min()
        if cl[i] > h:
            s[i] = 1
        elif cl[i] < l:
            s[i] = -1
    return s


def run(D, sg, s, R, cost_bp, slip_bp, max_hold, start, end, mode):
    op, hi, lo, cl = D['open'], D['high'], D['low'], D['close']
    n = len(cl) if end is None else min(end, len(cl))
    cR = 2 * cost_bp / 1e4 / s
    slipR = slip_bp / 1e4 / s
    stopd = s + slip_bp / 1e4
    recs = []
    i = max(start, 120)
    while i < n - 3:
        if sg[i] > 0:
            d = 1
        elif sg[i] < 0:
            d = -1
        else:
            i += 1
            continue
        e = op[i + 1]
        i0 = i + 1
        out = None
        j = i0
        kind = 'timeout'
        for jj in range(i0, min(i0 + max_hold, n)):
            adv = (lo[jj] / e - 1) if d == 1 else (1 - hi[jj] / e)
            fav = (hi[jj] / e - 1) if d == 1 else (1 - lo[jj] / e)
            if adv <= -stopd:
                out = -1.0 - slipR
                j = jj
                kind = 'stop'
                break
            if fav >= R * s:
                out = R
                j = jj
                kind = 'target'
                break
            if mode == 'flip' and sg[jj] * d < 0:
                out = ((cl[jj] / e - 1) * d) / s
                j = jj
                kind = 'flip'
                break
        if out is None:
            j = min(i0 + max_hold, n - 1)
            out = ((cl[j] / e - 1) * d) / s
            kind = 'timeout'
        recs.append((kind, out, out - cR, j - i0))
        i = j + 1
    return pd.DataFrame(recs, columns=['kind', 'gross', 'net', 'hold'])


def stat(df, R, s, cost_bp):
    n = len(df)
    if n < 30:
        return None
    cR = 2 * cost_bp / 1e4 / s
    win = df[df.net > 0]
    loss = df[df.net <= 0]
    realR = win.gross.mean() / abs(loss.gross.mean()) if len(loss) > 0 and loss.gross.mean() != 0 else np.nan
    return dict(n=n,
                hit_target=(df.kind == 'target').mean(),
                flip=(df.kind == 'flip').mean(),
                win_net=(df.net > 0).mean(),
                E_gross=df.gross.mean(),
                E_net=df.net.mean(),
                t=df.net.mean() / (df.net.std() / np.sqrt(n)) if df.net.std() > 0 else 0,
                realR=realR,
                pstar=(1 + cR) / (R + 1),
                hold=df.hold.mean())


SIG = {'mom_5': lambda c: s_mom(c, 5), 'rev_5': lambda c: -s_mom(c, 5),
       'mom_20': lambda c: s_mom(c, 20), 'rev_20': lambda c: -s_mom(c, 20),
       'brk_20': lambda c: s_brk(c, 20)}

data = load()
print("=" * 100)
print("第三批干净样本外 | 锁定规格 brk_20 (旧4品种选出) | s=5% R=2 maker2bp")
print("=" * 100)

for mode in ['flip', 'target']:
    print(f"\n### 设计: {'信号驱动(翻转即平)' if mode=='flip' else '目标驱动(只认止损止盈)'}")
    print(f"  {'品种':<7}{'批次':<6}{'N':>6}{'触止盈%':>9}{'平仓为正%':>10}{'p*':>7}{'实际R':>7}{'毛E(R)':>9}{'净E(R)':>9}{'t':>8}")
    print("  " + "-" * 84)
    for k in OLD4 + NEW3 + NEW6:
        batch = '旧4(选)' if k in OLD4 else ('新3' if k in NEW3 else '新6(净)')
        D = data[k]
        sg = s_brk(D['close'], 20)
        n = len(D['close'])
        f = run(D, sg, 0.05, 2.0, 2, 5, 800, n // 2, n, mode)
        a = stat(f, 2.0, 0.05, 2)
        if a is None:
            continue
        print(f"  {k:<7}{batch:<6}{a['n']:>6}{a['hit_target']*100:>8.1f}%{a['win_net']*100:>9.1f}%"
              f"{a['pstar']*100:>6.1f}%{a['realR']:>7.2f}{a['E_gross']:>+9.4f}{a['E_net']:>+9.4f}{a['t']:>+8.2f}")

    # 分批汇总
    print("  " + "-" * 84)
    for lbl, keys in [('旧4(参与选择)', OLD4), ('新3(第二批)', NEW3), ('新6(完全干净)', NEW6)]:
        frames = []
        for k in keys:
            D = data[k]
            sg = s_brk(D['close'], 20)
            n = len(D['close'])
            f = run(D, sg, 0.05, 2.0, 2, 5, 800, n // 2, n, mode)
            if len(f) >= 30:
                frames.append(f)
        a = stat(pd.concat(frames, ignore_index=True), 2.0, 0.05, 2)
        print(f"  【{lbl}】N={a['n']:>6}  触止盈{a['hit_target']*100:>5.1f}%  平仓为正{a['win_net']*100:>5.1f}%  "
              f"毛E{a['E_gross']:>+8.4f}  净E{a['E_net']:>+8.4f}  t={a['t']:>+6.2f}")

print("\n" + "=" * 100)
print("全部5个信号 × 6个干净品种 (参考: 仅用于观察, 不可据此选择)")
print("=" * 100)
for mode in ['flip', 'target']:
    print(f"\n[{mode}]")
    print(f"  {'信号':<9}{'N':>7}{'净E(R)':>9}{'t':>8}{'正品种数':>9}")
    print("  " + "-" * 46)
    for nm, fn in SIG.items():
        frames = []
        per = []
        for k in NEW6:
            D = data[k]
            sg = fn(D['close'])
            n = len(D['close'])
            f = run(D, sg, 0.05, 2.0, 2, 5, 800, n // 2, n, mode)
            if len(f) >= 30:
                frames.append(f)
                per.append(f.net.mean())
        a = stat(pd.concat(frames, ignore_index=True), 2.0, 0.05, 2)
        pos = sum(1 for x in per if x > 0)
        print(f"  {nm:<9}{a['n']:>7}{a['E_net']:>+9.4f}{a['t']:>+8.2f}{pos:>7}/{len(per)}")
