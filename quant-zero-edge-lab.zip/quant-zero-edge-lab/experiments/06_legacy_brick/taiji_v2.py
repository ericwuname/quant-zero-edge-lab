"""
太极 修正检验 (v2)
=====================
【修正1 - C】v1 用重叠滚动窗口算自相关 -> 严重高估显著性
    修正: 不重叠窗口 + block bootstrap p 值 + 多窗口稳健性

【修正2 - A】v1 只测线性相关, 但数据显示【U型】关系:
    极端上涨后 与 极端下跌后 的收益【都高】, 中立区间最低
    线性 rho 接近0 掩盖了这个非线性结构
    修正: 分桶看完整形状, 检验 U型/倒U型

【新增 - E】尺度依赖: 物极必反在哪个时间尺度成立?
    A显示日频是动量(rho>0), 但C的宏观比值显示均值回归
    -> 假设: 短尺度动量, 长尺度反转 (这正是阴阳: 微观看阳, 宏观看阴)
"""
import numpy as np
import pandas as pd
from scipy import stats

DAILY = {'BTC': '/data/inputs/BTCUSDT_1d.csv',
         'BNB': '/data/inputs/BNBUSDT_1d.csv',
         'BCH': '/data/inputs/BCHUSDT_1d.csv'}
HOURLY = {'DOGE': '/data/inputs/DOGEUSDT_1h.csv',
          'DOT':  '/data/inputs/DOTUSDT_1h.csv',
          'CRV':  '/data/inputs/CRVUSDT_1h.csv',
          'DASH': '/data/inputs/DASHUSDT_1h.csv'}
DAYS_YR = 365
COST_BP = 20
BLK = 20


def load():
    px = {}
    for k, p in DAILY.items():
        d = pd.read_csv(p)
        s = pd.Series(d['close'].values,
                      index=pd.to_datetime(d['timestamp'], unit='ms').dt.normalize())
        px[k] = s[~s.index.duplicated()]
    for k, p in HOURLY.items():
        d = pd.read_csv(p)
        s = pd.Series(d['close'].values,
                      index=pd.to_datetime(d['timestamp'], unit='ms'))
        px[k] = s.resample('1D').last().dropna()
    return pd.DataFrame(px).dropna()


def boot_idx(rng, T, L):
    nb = int(np.ceil(T / L))
    st = rng.integers(0, T - L, size=nb)
    return (st[:, None] + np.arange(L)[None, :]).ravel()[:T] % T


def logret(r):
    return np.log1p(np.clip(r, -0.99, None))


def metrics(net):
    n = len(net)
    mu, sd = net.mean(), net.std()
    if sd < 1e-12 or n < 10:
        return 0.0, 0.0, 0.0
    nav = np.cumprod(1.0 + np.clip(net, -0.99, None))
    ann = float(np.clip((nav[-1] ** (DAYS_YR / n) - 1) * 100 if nav[-1] > 0 else -100.0, -100, 1e6))
    sh = mu / sd * np.sqrt(DAYS_YR)
    pk = np.maximum.accumulate(nav)
    dd = (nav - pk) / np.maximum(pk, 1e-12)
    return ann, sh, float(-dd.min() * 100)


# ==================================================================
# 修正A: 分桶完整形状 (U型检验)
# ==================================================================
def test_A_shape(df):
    print("\n" + "=" * 100)
    print("【修正A】物极必反的完整形状 —— 是线性反转, 还是 U 型?")
    print("=" * 100)
    print("  v1只用线性rho, 但极端两侧收益都高 -> 线性rho≈0 掩盖了真相")
    print("  本检验: 按 z 分5桶, 看每桶未来收益的完整形状")

    port = df.pct_change().fillna(0).mean(axis=1)
    r = port.values
    lr = logret(r)
    T = len(r)
    N, H = 20, 10

    cum = pd.Series(lr).rolling(N).sum().values
    vol = pd.Series(r).rolling(60).std().values
    z = np.where(vol * np.sqrt(N) > 1e-12, cum / (vol * np.sqrt(N)), 0.0)
    z = np.where(np.isnan(z), 0.0, z)

    fwd = np.full(T, np.nan)
    for t in range(T - H):
        fwd[t] = lr[t + 1:t + 1 + H].sum()
    ok = ~np.isnan(fwd) & (np.abs(z) > 0)
    zz, ff = z[ok], fwd[ok]

    print(f"\n  z 分5桶 (N={N}, H={H}):")
    print(f"  {'桶':<14}{'z范围':>22}{'天数':>7}{'未来收益':>12}{'vs全样本':>11}")
    qs = np.percentile(zz, [20, 40, 60, 80])
    labels = ['①极阴(超跌)', '②阴', '③中', '④阳', '⑤极阳(超涨)']
    bounds = [(-99, qs[0]), (qs[0], qs[1]), (qs[1], qs[2]),
              (qs[2], qs[3]), (qs[3], 99)]
    base = ff.mean()
    shape = []
    for lab, (lo, hi) in zip(labels, bounds):
        m = (zz > lo) & (zz <= hi)
        if m.sum() < 20:
            continue
        v = ff[m].mean()
        shape.append(v)
        print(f"  {lab:<14}[{lo:>+6.2f},{hi:>+6.2f}]{m.sum():>7}{v*1e4:>11.1f}bp"
              f"{(v-base)*1e4:>+10.1f}bp")

    shape = np.array(shape)
    # U型检验: 两端 > 中间?
    mid = shape[2]
    ends = (shape[0] + shape[4]) / 2
    print(f"\n  U型检验: 两端均值 {ends*1e4:.1f}bp  vs  中间桶 {mid*1e4:.1f}bp  "
          f"差 {(ends-mid)*1e4:+.1f}bp")

    # 关键: 极阴 vs 极阳 的对称检验
    # 物极必反预测: 极阴(超跌) 未来收益 > 极阳(超涨) 未来收益
    print(f"\n  【物极必反的核心检验】")
    print(f"    极阴(超跌)桶未来收益: {shape[0]*1e4:.1f}bp")
    print(f"    极阳(超涨)桶未来收益: {shape[4]*1e4:.1f}bp")
    print(f"    差(阴-阳): {(shape[0]-shape[4])*1e4:+.1f}bp")
    if shape[0] > shape[4]:
        print(f"    -> 超跌后收益 > 超涨后收益 = 【物极必反成立】")
    else:
        print(f"    -> 超涨后收益 >= 超跌后收益 = 【物极必反不成立, 反而是动量】")

    # block bootstrap 检验这个差
    lo_m = zz <= qs[0]
    hi_m = zz > qs[3]
    obs = ff[lo_m].mean() - ff[hi_m].mean()
    rng = np.random.default_rng(41)
    d = np.zeros(1000)
    idx_all = np.arange(len(ff))
    for i in range(1000):
        b = rng.choice(idx_all, len(idx_all), replace=True)
        z_b, f_b = zz[b], ff[b]
        l_ = z_b <= qs[0]
        h_ = z_b > qs[3]
        if l_.sum() > 5 and h_.sum() > 5:
            d[i] = f_b[l_].mean() - f_b[h_].mean()
    p = 2 * min((d <= 0).mean(), (d >= 0).mean())
    print(f"    block bootstrap p = {min(p,1.0):.3f} "
          f"({'显著' if p<0.05 else '不显著'})")
    return obs, p


# ==================================================================
# 修正C: 不重叠窗口 + block bootstrap
# ==================================================================
def test_C_rigorous(df):
    print("\n" + "=" * 100)
    print("【修正C】阴阳消长 —— 不重叠窗口 + block bootstrap")
    print("=" * 100)
    print("  v1用重叠滚动窗口 -> 独立样本极少 -> p值严重失真")
    print("  修正: 不重叠分块 + 配对bootstrap")

    port = df.pct_change().fillna(0).mean(axis=1).values
    T = len(port)

    print(f"\n  {'窗口(天)':>9}{'块数':>7}{'阳/阴均值':>11}{'阳/阴标准差':>12}"
          f"{'滞后自相关':>12}{'bootstrap p':>13}{'判定':>12}")
    for W in [60, 125, 250]:
        nb = T // W
        if nb < 8:
            continue
        ratios = []
        for i in range(nb):
            w = port[i * W:(i + 1) * W]
            pos = w[w > 0].sum()
            neg = -w[w < 0].sum()
            if neg > 1e-12:
                ratios.append(pos / neg)
            else:
                ratios.append(np.nan)
        ratios = np.array(ratios)
        ok = ~np.isnan(ratios)
        rr = ratios[ok]
        if len(rr) < 8:
            continue
        # 滞后1自相关 (不重叠块)
        cur, nxt = rr[:-1], rr[1:]
        if len(cur) < 5:
            continue
        rho = np.corrcoef(cur, nxt)[0, 1]
        # 配对 bootstrap
        rng = np.random.default_rng(51)
        d = np.zeros(2000)
        n_ = len(cur)
        for i in range(2000):
            idx = rng.choice(n_, n_, replace=True)
            c_, n_2 = cur[idx], nxt[idx]
            if c_.std() > 1e-12 and n_2.std() > 1e-12:
                d[i] = np.corrcoef(c_, n_2)[0, 1]
        p = 2 * min((d <= 0).mean(), (d >= 0).mean())
        verdict = '均值回归' if (p < 0.05 and rho < 0) else ('动量' if (p < 0.05 and rho > 0) else '无结构')
        print(f"  {W:>9}{len(rr):>7}{rr.mean():>11.3f}{rr.std():>12.3f}"
              f"{rho:>+12.4f}{min(p,1.0):>13.3f}{verdict:>12}")

    print("\n  判读: 负自相关 = 失衡后回归平衡 = '阴阳消长'的动态平衡成立")
    print("        但这是【不可交易的】: 它说的是年度/季度聚合层面的回归,")
    print("        而日内成本会吃掉任何试图捕捉它的操作")


# ==================================================================
# 新增E: 尺度依赖 —— 短尺度动量 vs 长尺度反转?
# ==================================================================
def test_E_scale(df):
    print("\n" + "=" * 100)
    print("【新增E】尺度依赖 —— 物极必反在哪个尺度成立?")
    print("=" * 100)
    print("  A显示日频是动量(rho>0), C显示宏观比值均值回归")
    print("  假设: 短尺度延续(阳), 长尺度反转(阴) —— 这正是太极的阴阳互根")

    port = df.pct_change().fillna(0).mean(axis=1).values
    T = len(port)

    print(f"\n  {'回看尺度':>9}{'持有尺度':>9}{'Spearman':>11}{'p(boot)':>10}"
          f"{'方向':>10}{'判定':>14}")
    results = []
    for N in [5, 10, 20, 60, 125, 250]:
        for H in [5, 20, 60, 125]:
            if N + H >= T // 2:
                continue
            # 不重叠: 用过去N日 -> 未来H日
            xs, ys = [], []
            i = 0
            while i + N + H <= T:
                xs.append(port[i:i + N].sum())
                ys.append(port[i + N:i + N + H].sum())
                i += N + H          # 不重叠!
            xs, ys = np.array(xs), np.array(ys)
            if len(xs) < 12:
                continue
            rho, _ = stats.spearmanr(xs, ys)
            # block bootstrap
            rng = np.random.default_rng(61)
            d = np.zeros(1000)
            n_ = len(xs)
            for i in range(1000):
                idx = rng.choice(n_, n_, replace=True)
                if xs[idx].std() > 1e-12 and ys[idx].std() > 1e-12:
                    d[i] = stats.spearmanr(xs[idx], ys[idx])[0]
            p = 2 * min((d <= 0).mean(), (d >= 0).mean())
            direction = '反转' if rho < 0 else '动量'
            verdict = f'{direction}({"显著" if p<0.05 else "不显著"})'
            print(f"  {N:>9}{H:>9}{rho:>+11.4f}{min(p,1.0):>10.3f}"
                  f"{direction:>10}{verdict:>14}")
            results.append((N, H, rho, min(p, 1.0)))

    print(f"\n  判读: 若短N短H 显示动量、长N长H 显示反转")
    print(f"        -> 阴阳互根: 短期是阳(延续), 长期是阴(回归)")
    print(f"        -> 但两者都无法扣成本后变现(已测: 所有策略扣成本后跑输)")
    if results:
        rs = np.array([x[2] for x in results])
        print(f"\n  汇总: rho均值 {rs.mean():+.4f}  "
              f"反转{(rs<0).sum()}/{len(rs)}组, 动量{(rs>0).sum()}/{len(rs)}组")


# ============ 主流程 ============
print("=" * 100)
print("太极 修正检验 v2 (修重叠窗口 / U型形状 / 尺度依赖)")
print("=" * 100)
df = load()
print(f"面板: {df.shape[1]}品种 x {df.shape[0]}天 ({df.index[0].date()} -> {df.index[-1].date()})")

test_A_shape(df)
test_C_rigorous(df)
test_E_scale(df)

print("\n" + "=" * 100)
print("完成")
print("=" * 100)
