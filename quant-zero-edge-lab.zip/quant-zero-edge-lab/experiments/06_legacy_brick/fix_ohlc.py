"""
【关键修正】用 OHLC high/low 判断触及, 保守假设
======================================================
【发现的bug】
  之前用【收盘价】判断止损/止盈
  -> 若bar内暴跌5%但收盘回到-0.5%, 代码认为未触发止损
  -> 系统性【低估亏损】 -> E(R)虚高 -> 年化150%是假的

【修正】
  做多: 止损 low <= entry*(1-s);  止盈 high >= entry*(1+R*s)
  做空: 止损 high >= entry*(1+s); 止盈 low <= entry*(1-R*s)
  同一bar内【两者都触及】-> 保守假设【先触及止损】(最坏情况)

【为什么这很重要】
  crypto 1h 的 high-low range 常达 1~3%
  s=1% 的止损在bar内几乎必被触及
  -> 保守修正后, 窄止损会【崩溃】

【重新扫描】
  s 需要更宽 (因为bar内波动)
  找到真正的"度"
"""
import numpy as np
import pandas as pd
from scipy import stats

HOURLY = {'DOGE': '/data/inputs/DOGEUSDT_1h.csv',
          'DOT':  '/data/inputs/DOTUSDT_1h.csv',
          'CRV':  '/data/inputs/CRVUSDT_1h.csv',
          'DASH': '/data/inputs/DASHUSDT_1h.csv'}


def load():
    out = {}
    for k, p in HOURLY.items():
        d = pd.read_csv(p)
        out[k] = dict(open=d['open'].values, high=d['high'].values,
                      low=d['low'].values, close=d['close'].values)
    return out


def momentum_signal(close, w=60):
    n = len(close)
    sig = np.zeros(n)
    sig[w:] = np.sign(close[w:] / np.maximum(close[:-w], 1e-9) - 1)
    return sig


def run_trades_ohlc(D, signal, s, R, mode='maker', max_hold=800,
                    seed=42, start=0, end=None):
    """用high/low判断, 同bar双触及 -> 保守取止损"""
    hi, lo, cl = D['high'], D['low'], D['close']
    n = len(cl) if end is None else min(end, len(cl))
    if mode == 'maker':
        c_win = 2 * 2e-4 / s; c_loss = 2 * 2e-4 / s
    elif mode == 'mixed':
        c_win = 2 * 2e-4 / s; c_loss = (2e-4 + 10e-4) / s
    else:
        c_win = 2 * 10e-4 / s; c_loss = 2 * 10e-4 / s

    rng = np.random.default_rng(seed)
    net = []
    i = max(start, 60)
    while i < n - 2:
        sg = signal[i]
        if sg == 0:
            sg = rng.choice([-1, 1])
        direction = 1 if sg > 0 else -1
        entry = cl[i]
        out_R = None
        j = i
        for jj in range(i + 1, min(i + max_hold, n)):
            if direction == 1:
                hit_sl = lo[jj] <= entry * (1 - s)
                hit_tp = hi[jj] >= entry * (1 + R * s)
            else:
                hit_sl = hi[jj] >= entry * (1 + s)
                hit_tp = lo[jj] <= entry * (1 - R * s)
            if hit_sl and hit_tp:
                out_R = -1.0; j = jj; break      # 保守: 先止损
            if hit_sl:
                out_R = -1.0; j = jj; break
            if hit_tp:
                out_R = R; j = jj; break
        if out_R is None:
            j = min(i + max_hold, n - 1)
            out_R = (cl[j] / entry - 1) * direction / s
        net.append(out_R - (c_win if out_R > 0 else c_loss))
        i = j + 1
    return np.array(net)


def stats_of(net):
    if len(net) < 30: return None
    E = net.mean()
    t = E / (net.std() / np.sqrt(len(net))) if net.std() > 0 else 0
    return dict(n=len(net), win=(net > 0).mean(), E_R=E, t=t)


def path_risk(net, f=0.01, init=10000.0):
    nav = np.empty(len(net) + 1); nav[0] = init
    for i, r in enumerate(net):
        nav[i + 1] = nav[i] * (1.0 + f * r)
        if nav[i + 1] <= 0: nav[i + 1:] = 0; break
    mc, cur = 0, 0
    for r in net:
        if r < 0: cur += 1; mc = max(mc, cur)
        else: cur = 0
    pk = np.maximum.accumulate(nav)
    return dict(final=nav[-1],
                mdd=-((nav - pk) / np.maximum(pk, 1e-12)).min() * 100,
                max_consec=mc)


data = load()
print("=" * 100)
print("【关键修正】OHLC high/low + 保守假设(同bar双触及→止损)")
print("=" * 100)
print("  修正前(bug): 用收盘价 -> 低估止损 -> 年化150%虚假")
print("  修正后: 用high/low, 双触及取最坏")

# 先看bar内波动幅度, 理解为什么窄止损不行
print(f"\n  【0】crypto 1h bar内波动 (high-low)/close")
print(f"  {'品种':<7}{'均值':>9}{'中位数':>9}{'75%':>9}{'90%':>9}")
print("  " + "-" * 46)
for sym, D in data.items():
    rng_pct = (D['high'] - D['low']) / D['close'] * 100
    print(f"  {sym:<7}{rng_pct.mean():>8.2f}%{np.median(rng_pct):>8.2f}%"
          f"{np.percentile(rng_pct,75):>8.2f}%{np.percentile(rng_pct,90):>8.2f}%")

print(f"\n  -> 若bar内波动中位数 ~1-2%, 则 s=1%的止损几乎每bar都可能被触及")

# ---------- 重新扫描 ----------
print(f"\n  【1】修正后网格 (DOGE, maker) —— E(R)每笔")
print("  s\\R      " + "".join(f"{f'1:{r}':>20}" for r in [1.5, 2, 3, 4]))
print("  " + "-" * 92)
D = data['DOGE']; cl = D['close']
n = len(cl); sp = n // 2
sg = momentum_signal(cl, 60)
pos = tot = 0
for s in [0.01, 0.02, 0.03, 0.05, 0.08, 0.12]:
    row = f"  {s*100:>6.1f}%  "
    for R in [1.5, 2, 3, 4]:
        net = run_trades_ohlc(D, sg, s, R, mode='maker', start=sp, end=n)
        st = stats_of(net)
        if st:
            row += f"{st['E_R']:>+8.3f}(t{st['t']:>+6.1f})"
            tot += 1
            if st['E_R'] > 0: pos += 1
        else:
            row += f"{'—':>20}"
    print(row)
print(f"\n    修正后 maker: {pos}/{tot} 为正")

# ---------- 多品种验证 (用较宽止损) ----------
print(f"\n  【2】多品种验证 (修正后, maker, s=5%, R=2)")
print(f"  {'品种':<7}{'模式':<8}{'笔数':>7}{'胜率':>8}{'E(R)':>9}{'t':>8}"
      f"{'终值':>10}{'回撤':>8}{'连亏':>7}")
print("  " + "-" * 68)
for mode in ['maker', 'mixed', 'taker']:
    for sym in ['DOGE', 'CRV', 'DOT', 'DASH']:
        D2 = data[sym]; c2 = D2['close']
        n2 = len(c2); sp2 = n2 // 2
        sg2 = momentum_signal(c2, 60)
        net = run_trades_ohlc(D2, sg2, 0.05, 2, mode=mode, start=sp2, end=n2)
        st = stats_of(net)
        if st is None: continue
        pr = path_risk(net)
        flag = '★' if (st['t'] > 1.96 and st['E_R'] > 0) else ''
        print(f"  {sym:<7}{mode:<8}{st['n']:>7}{st['win']*100:>7.1f}%"
              f"{st['E_R']:>+9.3f}{st['t']:>+8.2f}{pr['final']:>10.0f}"
              f"{pr['mdd']:>7.1f}%{pr['max_consec']:>7}{flag}")
    print()

print("=" * 100)
print("完成")
print("=" * 100)
