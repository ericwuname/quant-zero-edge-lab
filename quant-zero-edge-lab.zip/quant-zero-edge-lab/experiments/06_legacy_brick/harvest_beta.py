# -*- coding: utf-8 -*-
"""收割制结果的可信度检验: 剥离beta ? 对照买入持有 ? 分年度 ?"""
import sys, numpy as np, pandas as pd, warnings
sys.path.insert(0,'/data/workspace/brick')
warnings.filterwarnings('ignore')
from entry_lib import *
rng=np.random.default_rng(11); COST=0.0002

def gen(sym, sigfn, stop=0.05, R=2.0, half='second', longonly=False):
    df=load(sym); o=df['open'].values; h=df['high'].values; l=df['low'].values; c=df['close'].values
    n=len(o); cut=n//2; sig=sigfn(c)
    if longonly: sig=np.where(sig<0,0,sig)
    a,b=(cut,n) if half=='second' else (0,cut)
    out=[]; dirs=[]; i=a
    bh=o[b-1]/o[a]-1                      # 同期买入持有
    while i<b-1:
        if sig[i]==0: i+=1; continue
        d=sig[i]; ep=o[i+1]; sp=ep*(1-stop*d); tp=ep*(1+stop*R*d)
        j=i+1; res=None
        while j<b:
            if d>0:
                if l[j]<=sp: res=-1.0;break
                if h[j]>=tp: res=R;break
            else:
                if h[j]>=sp: res=-1.0;break
                if l[j]<=tp: res=R;break
            if j+1<b and sig[j+1]==-d: res=(o[j+1]/ep-1)*d/stop;break
            j+=1
        if res is None: res=(o[min(j,b-1)]/ep-1)*d/stop
        out.append(res-2*COST/stop); dirs.append(d); i=max(j,i+1)
    return np.array(out), np.array(dirs), bh, (b-a)/n

def sig_brk20(c):
    s=np.zeros(len(c)); hh=pd.Series(c).rolling(20).max().values; ll=pd.Series(c).rolling(20).min().values
    s[20:]=np.where(c[20:]>hh[:-20],1,np.where(c[20:]<ll[:-20],-1,0)); return np.where(np.isnan(s),0,s)
def sig_mom240(c):
    s=np.zeros(len(c)); s[240:]=np.sign(c[240:]/c[:-240]-1); return s
def sig_ma200(c):
    ma=pd.Series(c).rolling(200).mean().values; s=np.where(c>ma,1,-1); s[:200]=0
    return np.where(np.isnan(s),0,s)

print('='*100)
print('检验A  brk20 的 E(R) 是 alpha 还是 beta ?  多空分解 + 买入持有对照')
print('='*100)
print(f'{"策略":<10}{"E(R)":>10}{"多头E":>10}{"空头E":>10}{"多空差":>10}{"差t":>8}{"同期BH":>12}{"策略年化":>12}')
for name,fn in [('brk20',sig_brk20),('mom240',sig_mom240),('ma200',sig_ma200)]:
    allR=[];allD=[];bhs=[];bars=[];anns=[]
    for sym in ALL13:
        R_,D_,bh,frac=gen(sym,fn)
        if len(R_)<30: continue
        allR.append(R_);allD.append(D_);bhs.append(bh);bars.append(frac)
        anns.append(R_.sum()/(frac/ (24*365)))   # 年化笔数 * E
    per=np.array([x.mean() for x in allR])
    L=np.array([x[x>0].mean() if (x>0).sum()>5 else np.nan for x in allR])
    S=np.array([x[x<0].mean() if (x<0).sum()>5 else np.nan for x in allR])
    diff=np.array([ (allR[k][allD[k]>0].mean() if (allD[k]>0).sum()>5 else np.nan) +
                    (allR[k][allD[k]<0].mean() if (allD[k]<0).sum()>5 else np.nan) for k in range(len(allR))])
    diff=diff[~np.isnan(diff)]
    td=diff.mean()/(diff.std(ddof=1)/np.sqrt(len(diff))) if len(diff)>2 else np.nan
    bhann=np.array([(1+b)**(1/(f/(24*365/ (24*365)) ))-1 if False else b/ (bars[k]/(24*365)) for k,b in enumerate(bhs)])
    print(f'{name:<10}{per.mean():>10.4f}{np.nanmean(L):>10.4f}{np.nanmean(S):>10.4f}{diff.mean():>10.4f}{td:>8.2f}'
          f'{np.mean(bhs):>12.1%}{np.mean(anns):>12.1%}')

print()
print('='*100)
print('检验B  分年度: brk20 后半段的 E(R) 是否稳定 (还是被单一牛市年撑起)')
print('='*100)
yrs={}
for sym in ALL13:
    df=load(sym); o=df['open'].values; h=df['high'].values; l=df['low'].values; c=df['close'].values
    ts=df['timestamp'].values; yr=pd.to_datetime(ts,unit='ms').year
    n=len(o); cut=n//2; sig=sig_brk20(c); a,b=cut,n
    i=a
    while i<b-1:
        if sig[i]==0: i+=1; continue
        d=sig[i]; ep=o[i+1]; sp=ep*(1-0.05*d); tp=ep*1.10**0 if d<0 else ep*1.10
        tp=ep*(1+0.05*2*d)
        j=i+1; res=None
        while j<b:
            if d>0:
                if l[j]<=sp: res=-1.0;break
                if h[j]>=tp: res=2.0;break
            else:
                if h[j]>=sp: res=-1.0;break
                if l[j]<=tp: res=2.0;break
            if j+1<b and sig[j+1]==-d: res=(o[j+1]/ep-1)*d/0.05;break
            j+=1
        if res is None: res=(o[min(j,b-1)]/ep-1)*d/0.05
        yrs.setdefault(yr[min(j,b-1)],[]).append(res-0.008); i=max(j,i+1)
print(f'  {"年份":<8}{"笔数":>10}{"E(R)":>12}{"为正比例":>10}')
for y in sorted(yrs):
    a=np.array(yrs[y]); print(f'  {y:<8}{len(a):>10}{a.mean():>12.4f}{np.mean(a>0):>10.1%}')
ay=np.array([np.mean(yrs[y]) for y in sorted(yrs)])
t=ay.mean()/(ay.std(ddof=1)/np.sqrt(len(ay)))
print(f'\n  年度间 t (n={len(ay)}年, 时间独立样本) = {t:+.2f}')

print()
print('='*100)
print('检验C  纯做多(不做空) vs 多空双向 —— 若收益全来自做多腿, 就是beta')
print('='*100)
for name,fn in [('brk20',sig_brk20),('ma200',sig_ma200)]:
    lo=[];ls=[]
    for sym in ALL13:
        R1,_,_,_=gen(sym,fn,longonly=True)
        R2,D2,_,_=gen(sym,fn)
        if len(R1)>20: lo.append(R1.mean())
        if len(R2)>20: ls.append(R2.mean())
    print(f'  {name:<8} 纯做多 E(R)={np.mean(lo):+.4f}   多空双向 E(R)={np.mean(ls):+.4f}')
