"""用已知答案的合成数据检验脚本本身对不对"""
import numpy as np
from solve_counterexample import gen_mkt_rho, gen_mkt_strong
from zoo_tick import TICKS_PER_HOUR, HOURS_PER_YEAR
N=60000; ANN=0.20; SIG=ANN/np.sqrt(TICKS_PER_HOUR*HOURS_PER_YEAR)
import os
os.makedirs('/data/workspace/brick/testdata',exist_ok=True)

# 生成已知 rho 的测试数据
cases = [('rw_rho0.csv', 'rw', 0.0), ('trend_rho05.csv','trend',0.05),
         ('trend_rho30.csv','trend',0.30), ('rev_rho30.csv','rev',0.30)]
print("生成测试数据(已知真值):")
for fn,kind,rho in cases:
    if kind=='rw':
        rng=np.random.default_rng(42); r=rng.normal(0,SIG,N)
        px=100000*np.exp(np.cumsum(r))
    else:
        px=gen_mkt_rho(kind,N,SIG,seed=42,rho_target=rho)
    np.savetxt(f'/data/workspace/brick/testdata/{fn}',px,fmt='%.4f',header='price',comments='')
    print(f"  {fn}: 设定rho={rho}")
