"""
真实回测引擎 v3 —— 把之前所有简化全部补上
=============================================
补上的真实细节:
  1. OHLC 数据: 用 high/low 判断止损止盈【谁先触发】(之前只用close, 是错的)
  2. 跨区间处理: 一根K线跨多个区间时, 逐区间成交
  3. 周期: 1分钟 / 1小时 / 日线 对比 -> 跨区间概率
  4. 区间: 固定100 vs ATR动态
  5. 成本: 手续费(按比例) + 滑点(按tick)
  6. 头寸: 固定1手 vs 固定风险%(分数手支持)
  7. 资金: 初始10000, 杠杆, 保证金, 爆仓/强平
  8. 蒙特卡洛: 多条路径 -> 看"我只是其中一条线"
"""
import numpy as np

BARS_PER_YEAR = {'1m': 252 * 1440, '1h': 252 * 8, '1d': 252}


# ============================================================
# 一、OHLC 合成 (带真实的日内 high/low)
# ============================================================
def gen_ohlc(n, sigma_bar, kind='trendvol', seed=0, intrabar_ratio=1.0,
             price0=100000.0):
    """
    生成 OHLC。intrabar_ratio: bar内high-low幅度 相对 |close-open| 的倍数
    真实市场: 即使收盘价变动很小, bar内的high-low也可能很大 -> 止损易被触发
    """
    rng = np.random.default_rng(seed)
    n = int(n)
    if kind == 'rw':
        r = rng.normal(0, sigma_bar, n)
    elif kind == 'mom':
        phi = 0.05
        r = np.zeros(n)
        e = rng.normal(0, sigma_bar * np.sqrt(1 - phi ** 2), n)
        for t in range(1, n):
            r[t] = phi * r[t - 1] + e[t]
    elif kind == 'trendvol':
        r = np.zeros(n); h = sigma_bar ** 2; d = np.zeros(n)
        for t in range(1, n):
            h = 0.9 * h + 0.1 * r[t - 1] ** 2 + 1e-12
            d[t] = 0.95 * d[t - 1] + rng.normal(0, sigma_bar * 0.06)
            r[t] = d[t] + np.sqrt(h) * rng.normal()
        sd = r.std()
        if sd > 0:
            r = r / sd * sigma_bar
    else:
        r = rng.normal(0, sigma_bar, n)

    close = price0 * np.exp(np.cumsum(r))
    op = np.concatenate([[price0], close[:-1]])

    # bar内极值与收盘的关系: 真实市场 high-low 通常远大于 |close-open|
    body = np.abs(close - op)
    noise = rng.uniform(0.3, 1.5, n) * sigma_bar * price0 * intrabar_ratio
    span = body + noise                       # high-low 幅度
    up = rng.uniform(0, 1, n)
    high = np.maximum(op, close) + span * up * 0.5
    low = np.minimum(op, close) - span * (1 - up) * 0.5
    high = np.maximum(high, np.maximum(op, close))
    low = np.minimum(low, np.minimum(op, close))
    return dict(open=op, high=high, low=low, close=close)


# ============================================================
# 二、ATR
# ============================================================
def atr(o, w=14):
    h, l, c = o['high'], o['low'], o['close']
    pc = np.concatenate([[c[0]], c[:-1]])
    tr = np.maximum(h - l, np.maximum(np.abs(h - pc), np.abs(l - pc)))
    a = np.full(len(c), np.nan)
    if len(c) >= w:
        a[w - 1] = tr[:w].mean()
        for i in range(w, len(c)):
            a[i] = (a[i - 1] * (w - 1) + tr[i]) / w
    return a


# ============================================================
# 三、砖块/区间系统 (事件驱动, 用 high/low 精确判断)
# ============================================================
def run_system(o, A, cost_rate=0.0001, slip_ticks=1.0, tick_size=1.0,
               init_cap=10000.0, risk_pct=None, fixed_lots=None,
               leverage=1.0, contract_mult=1.0, reverse=False,
               max_bars=None):
    """
    A: 区间大小 -> 可以是常数, 或数组(ATR动态)
    事件驱动逻辑:
      区间 [lo, hi]。
      - 价格触及 hi -> 做多1笔(在hi成交), 新区间 [hi, hi+A]
      - 价格触及 lo -> 做空1笔, 新区间 [lo-A, lo]
      每笔交易: 入场后, 反向走满一个A就止损/止盈离场(1:1)
    用 high/low 判断谁先触发:
      - 多头: 若 low <= 入场价-A -> 止损; 若 high >= 入场价+A -> 止盈
        (同一根bar内两者都触及 -> 保守假设先止损)
    """
    h, l, c = o['high'], o['low'], o['close']
    n = len(c) if max_bars is None else min(len(c), max_bars)
    A_arr = np.full(n, A) if np.isscalar(A) else A[:n]

    cap = init_cap
    equity = np.zeros(n)
    peak = init_cap
    maxdd = 0.0
    trades = []
    pos = 0            # 0 空仓, 1 多, -1 空
    entry = 0.0
    lots = 0.0
    anchor_hi = c[0] + A_arr[0]
    anchor_lo = c[0] - A_arr[0]
    bankrupt = False
    n_cross = 0        # 一根bar跨多个区间的次数
    slip = slip_ticks * tick_size

    for i in range(n):
        if np.isnan(A_arr[i]) or A_arr[i] <= 0:
            equity[i] = cap
            continue
        Ai = A_arr[i]
        # 当前bar内可能连续跨多个区间
        guard = 0
        while guard < 50:
            guard += 1
            if guard > 1:
                n_cross += 1
            if pos == 0:
                # 判断触及哪边
                if h[i] >= anchor_hi:
                    # 做多, 在 anchor_hi + 滑点 成交
                    fill = anchor_hi + slip
                    pos = 1
                    entry = fill
                    # 头寸
                    if fixed_lots is not None:
                        lots = fixed_lots
                    else:
                        risk_amt = cap * risk_pct
                        per = (Ai + slip) * contract_mult
                        lots = risk_amt / per if per > 0 else 0
                        lots = np.floor(lots * 100) / 100   # 最小0.01手
                        if lots < 0.01:
                            lots = 0.0
                    if lots > 0:
                        cap -= lots * fill * contract_mult * cost_rate
                    anchor_lo = anchor_hi - Ai
                    anchor_hi_new = anchor_hi + Ai
                    # 检查是否同bar内立即被止损/止盈
                    if l[i] <= entry - Ai:
                        pnl = (-Ai - slip) * contract_mult * lots
                        cap += pnl - lots * (entry - Ai) * contract_mult * cost_rate
                        trades.append(pnl)
                        pos = 0
                        anchor_hi = entry - Ai
                        anchor_lo = anchor_hi - Ai
                    elif h[i] >= entry + Ai:
                        pnl = (Ai - slip) * contract_mult * lots
                        cap += pnl - lots * (entry + Ai) * contract_mult * cost_rate
                        trades.append(pnl)
                        pos = 0
                        anchor_hi = entry + Ai
                        anchor_lo = anchor_hi - Ai
                    else:
                        anchor_hi = anchor_hi_new
                    if pos == 1:
                        break
                elif l[i] <= anchor_lo:
                    fill = anchor_lo - slip
                    pos = -1
                    entry = fill
                    if fixed_lots is not None:
                        lots = fixed_lots
                    else:
                        risk_amt = cap * risk_pct
                        per = (Ai + slip) * contract_mult
                        lots = risk_amt / per if per > 0 else 0
                        lots = np.floor(lots * 100) / 100
                        if lots < 0.01:
                            lots = 0.0
                    if lots > 0:
                        cap -= lots * fill * contract_mult * cost_rate
                    anchor_hi = anchor_lo + Ai
                    if h[i] >= entry + Ai:
                        pnl = (-Ai - slip) * contract_mult * lots
                        cap += pnl - lots * (entry + Ai) * contract_mult * cost_rate
                        trades.append(pnl)
                        pos = 0
                        anchor_lo = entry + Ai
                        anchor_hi = anchor_lo + Ai
                    elif l[i] <= entry - Ai:
                        pnl = (Ai - slip) * contract_mult * lots
                        cap += pnl - lots * (entry - Ai) * contract_mult * cost_rate
                        trades.append(pnl)
                        pos = 0
                        anchor_lo = entry - Ai
                        anchor_hi = anchor_lo + Ai
                    else:
                        anchor_lo = anchor_lo - Ai
                    if pos == -1:
                        break
                else:
                    break
            else:
                break

        # 持仓中: 用 high/low 判断出场
        if pos != 0 and lots > 0:
            Ai_now = A_arr[i]
            if pos == 1:
                stop = entry - Ai_now
                targ = entry + Ai_now
                if l[i] <= stop:
                    pnl = (-Ai_now - slip) * contract_mult * lots
                    cap += pnl - lots * stop * contract_mult * cost_rate
                    trades.append(pnl); pos = 0
                    anchor_hi = stop; anchor_lo = stop - Ai_now
                elif h[i] >= targ:
                    pnl = (Ai_now - slip) * contract_mult * lots
                    cap += pnl - lots * targ * contract_mult * cost_rate
                    trades.append(pnl); pos = 0
                    anchor_hi = targ; anchor_lo = targ - Ai_now
            else:
                stop = entry + Ai_now
                targ = entry - Ai_now
                if h[i] >= stop:
                    pnl = (-Ai_now - slip) * contract_mult * lots
                    cap += pnl - lots * stop * contract_mult * cost_rate
                    trades.append(pnl); pos = 0
                    anchor_lo = stop; anchor_hi = stop + Ai_now
                elif l[i] <= targ:
                    pnl = (Ai_now - slip) * contract_mult * lots
                    cap += pnl - lots * targ * contract_mult * cost_rate
                    trades.append(pnl); pos = 0
                    anchor_lo = targ; anchor_hi = targ + Ai_now

        # 持仓浮亏计入权益(简化: 用收盘估算)
        eq = cap
        if pos != 0 and lots > 0:
            if pos == 1:
                eq += (c[i] - entry) * contract_mult * lots
            else:
                eq += (entry - c[i]) * contract_mult * lots
        equity[i] = max(eq, 0.0)
        peak = max(peak, equity[i])
        maxdd = max(maxdd, (peak - equity[i]) / peak if peak > 0 else 0)
        if equity[i] <= 0:
            bankrupt = True
            equity[i:] = 0.0
            break

    t = np.array(trades) if trades else np.array([0.0])
    return dict(
        equity=equity, final=equity[-1] if not bankrupt else 0.0,
        bankrupt=bankrupt, maxdd=maxdd, n_trades=len(trades),
        win=float((t > 0).mean()) if len(t) > 0 else np.nan,
        avg=float(t.mean()) if len(t) > 0 else 0.0,
        total_pnl=float(t.sum()), n_cross=n_cross,
        trades=t,
    )
