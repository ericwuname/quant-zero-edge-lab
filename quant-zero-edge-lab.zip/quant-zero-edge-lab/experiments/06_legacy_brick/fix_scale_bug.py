"""
【修正】scale 模式的致命 bug —— 未触发止盈前【没有止损】
==========================================================
【bug】
  scale 模式下, 未scaled的仓位遇到 -1R 时:
    if not scaled and hm >= R*s:  (不满足)
    if scaled:                    (不满足)
    -> continue  【从不检查止损!】
  => 等于"没有止损, 只在+2R时减半"
  => 亏损被完全放任 -> 天然摇钱机 -> t=19.46 是假的

【修正】
  未scaled仓位必须先检查止损 lm <= -s

【同时新增 sanity check】
  P(触及止盈) 必须在各模式下可比, 否则就是bug
"""
import numpy as np
import pandas as pd
from scipy import stats

HOURLY = {'DOGE': '/data/inputs/DOGEUSDT_1h.csv',
          'DOT':  '/data/inputs/DOTUSDT_1h.csv',
          'CRV':  '/data/inputs/CRVUSDT_1h.csv',
          'DASH': '/data/inputs/DASHUSDT_1h.csv'}


def load():
    out = {}
    for k, p in HOURLY.items():
        d = pd.read_csv(p)
        out[k] = dict(high=d['high'].values, low=d['low'].values,
                      close=d['close'].values)
    return out


def momentum_signal(cl, w):
    n = len(cl)
    s = np.zeros(n)
    s[w:] = np.sign(cl[w:] / np.maximum(cl[:-w], 1e-9) - 1)
    return s


def build_entries(D):
    cl = D['close']
    n = len(cl)
    S = {}
    ret = np.zeros(n); ret[1:] = cl[1:] / np.maximum(cl[:-1], 1e-9) - 1
    vol = pd.Series(np.abs(ret)).rolling(48).mean().values
    vq = np.nanpercentile(vol[~np.isnan(vol)], [33, 67])
    mom60 = momentum_signal(cl, 60)
    mom5 = momentum_signal(cl, 5)
    S['mom_60'] = mom60
    S['mom_5'] = mom5
    S['vol_mid'] = np.where((vol > vq[0]) & (vol < vq[1]), mom60, 0.0)
    S['vol_mid_mom5'] = np.where((vol > vq[0]) & (vol < vq[1]), mom5, 0.0)
    return S


def run_trades(D, signal, s, R, cost_bp=2, max_hold=800,
               tie='conservative', exit_mode='fixed',
               scale_frac=0.5, start=0, end=None):
    """修正版: 所有模式都先检查止损
    fixed:     止损-s / 止盈+R*s
    breakeven: 浮盈达+R*s后止损移到保本
    scale:     触及+R*s时了结一半, 剩余追踪(回撤R*s), 【未触及前正常止损】
    """
    hi, lo, cl = D['high'], D['low'], D['close']
    n = len(cl) if end is None else min(end, len(cl))
    base_cost = 2 * cost_bp / 1e4 / s
    cost_R = base_cost * (2 if exit_mode == 'scale' else 1)  # 两次成交

    net = []
    i = max(start, 120)
    while i < n - 2:
        sg = signal[i]
        if sg == 0:
            i += 1; continue
        direction = 1 if sg > 0 else -1
        entry = cl[i]
        out_R = None
        j = i
        scaled = False
        peak = 0.0
        be = False
        for jj in range(i + 1, min(i + max_hold, n)):
            # 有利/不利幅度(按方向)
            fav = (hi[jj] / entry - 1) * direction if direction == 1 \
                  else (1 - lo[jj] / entry)
            adv = (lo[jj] / entry - 1) * direction if direction == 1 \
                  else (hi[jj] / entry - 1)
            # fav: 最有利(多=high, 空=low);  adv: 最不利(多=low, 空=high)
            # 统一: fav>=0有利, adv<=0不利
            adv = -abs(adv) if adv > 0 else adv   # 保证 adv<=0 表示不利
            # 简化: 用保守口径
            if direction == 1:
                fav = hi[jj] / entry - 1
                adv = lo[jj] / entry - 1
            else:
                fav = 1 - lo[jj] / entry
                adv = 1 - hi[jj] / entry

            peak = max(peak, fav)

            if exit_mode == 'fixed':
                hit_sl = adv <= -s
                hit_tp = fav >= R * s
                if hit_sl and hit_tp:
                    out_R = -1.0 if tie == 'conservative' else R
                    j = jj; break
                if hit_sl: out_R = -1.0; j = jj; break
                if hit_tp: out_R = R; j = jj; break

            elif exit_mode == 'breakeven':
                cur_sl = -s
                if fav >= R * s:
                    be = True
                if be:
                    cur_sl = 0.0
                hit_sl = adv <= cur_sl
                hit_tp = fav >= R * s
                if hit_sl and hit_tp:
                    out_R = -1.0 if tie == 'conservative' else R
                    j = jj; break
                if hit_sl:
                    out_R = 0.0 if be else -1.0
                    j = jj; break
                if hit_tp: out_R = R; j = jj; break

            elif exit_mode == 'scale':
                if not scaled:
                    if adv <= -s:
                        out_R = -1.0; j = jj; break        # 【修正】正常止损
                    if fav >= R * s:
                        scaled = True
                        continue
                else:
                    # 剩余仓位: 追踪止损 = peak - R*s (>=0)
                    stop_R = (peak - R * s) / s
                    if adv <= -s:
                        out_R = scale_frac * R + (1 - scale_frac) * (-1)
                        j = jj; break
                    if (adv / s) <= stop_R:
                        out_R = scale_frac * R + (1 - scale_frac) * stop_R
                        j = jj; break
        if out_R is None:
            j = min(i + max_hold, n - 1)
            mv = (cl[j] / entry - 1) * direction
            if exit_mode == 'scale' and scaled:
                mv_R = (mv / s)
                out_R = scale_frac * R + (1 - scale_frac) * max(mv_R, 0)
            else:
                out_R = mv / s
        net.append(out_R - cost_R)
        i = j + 1
    return np.array(net)


def stats_of(net):
    if len(net) < 30: return None
    E = net.mean()
    t = E / (net.std() / np.sqrt(len(net))) if net.std() > 0 else 0
    return dict(n=len(net), win=(net > 0).mean(), E_R=E, t=t)


def path_risk(net, f=0.01, init=10000.0):
    nav = np.empty(len(net) + 1); nav[0] = init
    for i, r in enumerate(net):
        nav[i + 1] = nav[i] * (1.0 + f * r)
        if nav[i + 1] <= 0: nav[i + 1:] = 0; break
    mc, cur = 0, 0
    for r in net:
        if r < 0: cur += 1; mc = max(mc, cur)
        else: cur = 0
    pk = np.maximum.accumulate(nav)
    return dict(final=nav[-1],
                mdd=-((nav - pk) / np.maximum(pk, 1e-12)).min() * 100,
                max_consec=mc)


data = load()
print("=" * 100)
print("【修正后】出场技巧重测 (scale bug已修: 未止盈前正常止损)")
print("=" * 100)
print("  修正前 scale: DOGE t=+16.20, 池化 t=+19.46  <- 假的(无止损)")
print("  修正后重测")

S_STOP, R_MULT = 0.05, 2.0

# ---------- DOGE 单品种 ----------
print(f"\n  【1】DOGE样本外 (mom_60, maker 2bp, s=5%, R=2)")
print(f"  {'方式':<12}{'笔数':>7}{'胜率':>9}{'E(R)':>10}{'t':>8}{'回撤':>8}{'连亏':>7}")
print("  " + "-" * 62)
D = data['DOGE']; cl = D['close']; n = len(cl); sp = n // 2
S = build_entries(D)
for mode in ['fixed', 'breakeven', 'scale']:
    net = run_trades(D, S['mom_60'], S_STOP, R_MULT, cost_bp=2,
                     exit_mode=mode, start=sp, end=n)
    st = stats_of(net)
    if st is None: continue
    pr = path_risk(net)
    print(f"  {mode:<12}{st['n']:>7}{st['win']*100:>8.1f}%{st['E_R']:>+10.3f}"
          f"{st['t']:>+8.2f}{pr['mdd']:>7.1f}%{pr['max_consec']:>7}")

# ---------- 池化 ----------
print(f"\n  【2】池化4品种 (样本外, maker 2bp)")
print(f"  {'入场':<14}{'出场':<11}{'笔数':>7}{'胜率':>9}{'E(R)':>10}{'t':>8}{'判定':>9}")
print("  " + "-" * 70)
pool = {}
for enm in ['mom_60', 'mom_5', 'vol_mid', 'vol_mid_mom5']:
    for mode in ['fixed', 'breakeven', 'scale']:
        allnet = []
        for sym in ['DOGE', 'CRV', 'DOT', 'DASH']:
            D2 = data[sym]; S2 = build_entries(D2)
            n2 = len(D2['close']); sp2 = n2 // 2
            nt = run_trades(D2, S2[enm], S_STOP, R_MULT, cost_bp=2,
                            exit_mode=mode, start=sp2, end=n2)
            if len(nt) >= 30: allnet.append(nt)
        if not allnet: continue
        cat = np.concatenate(allnet)
        st = stats_of(cat)
        if st is None: continue
        pool[(enm, mode)] = (st, cat)
        flag = '★显著' if (st['t'] > 1.96 and st['E_R'] > 0) else ''
        print(f"  {enm:<14}{mode:<11}{st['n']:>7}{st['win']*100:>8.1f}%"
              f"{st['E_R']:>+10.3f}{st['t']:>+8.2f}{flag:>9}")

# ---------- 最优 + 0成本 ----------
print(f"\n  【3】最优组合 + 返佣0bp (池化)")
best = sorted(pool.items(), key=lambda x: -x[1][0]['t'])[:3]
for (enm, mode), (st, cat) in best:
    allnet = []
    for sym in ['DOGE', 'CRV', 'DOT', 'DASH']:
        D2 = data[sym]; S2 = build_entries(D2)
        n2 = len(D2['close']); sp2 = n2 // 2
        nt = run_trades(D2, S2[enm], S_STOP, R_MULT, cost_bp=0,
                        exit_mode=mode, start=sp2, end=n2)
        if len(nt) >= 30: allnet.append(nt)
    cat0 = np.concatenate(allnet)
    st0 = stats_of(cat0); pr = path_risk(cat0)
    if st0:
        print(f"  {enm:<14}{mode:<11} N={st0['n']:>5} 胜率{st0['win']*100:>5.1f}% "
              f"E={st0['E_R']:+.3f}R t={st0['t']:+.2f} "
              f"终值{pr['final']:.0f} 回撤{pr['mdd']:.1f}% 连亏{pr['max_consec']}")

print("\n" + "=" * 100)
print("完成")
print("=" * 100)
