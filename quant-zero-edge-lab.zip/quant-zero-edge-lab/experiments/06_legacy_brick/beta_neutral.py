"""
终极检验: 策略收益是 alpha 还是 beta?
方法: 多空对冲组合(beta中性) + 策略E与BH的相关性 + 分牛熊
"""
import numpy as np, pandas as pd

OLD4 = ['DOGE', 'DOT', 'CRV', 'DASH']
NEW3 = ['ETH', 'FIL', 'HBAR']
NEW6 = ['TRX', 'UNI', 'XLM', 'XMR', 'XRP', 'ZEC']
ALL = OLD4 + NEW3 + NEW6


def load():
    o = {}
    for k in ALL:
        d = pd.read_csv(f'/data/inputs/{k}USDT_1h.csv')
        c = {x.lower(): x for x in d.columns}
        o[k] = dict(open=d[c['open']].values.astype(float), high=d[c['high']].values.astype(float),
                    low=d[c['low']].values.astype(float), close=d[c['close']].values.astype(float))
    return o


def s_brk(cl, w):
    n = len(cl)
    s = np.zeros(n)
    for i in range(w, n):
        h = cl[i - w:i].max(); l = cl[i - w:i].min()
        if cl[i] > h: s[i] = 1
        elif cl[i] < l: s[i] = -1
    return s


def run(D, sg, s, R, cost_bp, slip_bp, max_hold, start, end, mode):
    op, hi, lo, cl = D['open'], D['high'], D['low'], D['close']
    n = len(cl) if end is None else min(end, len(cl))
    cR = 2 * cost_bp / 1e4 / s; slipR = slip_bp / 1e4 / s; stopd = s + slip_bp / 1e4
    recs = []; i = max(start, 120)
    while i < n - 3:
        if sg[i] > 0: d = 1
        elif sg[i] < 0: d = -1
        else:
            i += 1; continue
        e = op[i + 1]; i0 = i + 1; out = None; j = i0; kind = 'timeout'
        for jj in range(i0, min(i0 + max_hold, n)):
            adv = (lo[jj] / e - 1) if d == 1 else (1 - hi[jj] / e)
            fav = (hi[jj] / e - 1) if d == 1 else (1 - lo[jj] / e)
            if adv <= -stopd: out = -1.0 - slipR; j = jj; kind = 'stop'; break
            if fav >= R * s: out = R; j = jj; kind = 'target'; break
            if mode == 'flip' and sg[jj] * d < 0:
                out = ((cl[jj] / e - 1) * d) / s; j = jj; kind = 'flip'; break
        if out is None:
            j = min(i0 + max_hold, n - 1); out = ((cl[j] / e - 1) * d) / s; kind = 'timeout'
        recs.append((kind, out, out - cR, j - i0, d)); i = j + 1
    return pd.DataFrame(recs, columns=['kind', 'gross', 'net', 'hold', 'dir'])


data = load()

print("=" * 100)
print("终极检验 1: 多空对冲组合 (beta中性近似) —— 真alpha的判据")
print("=" * 100)
print("原理: 多头与空头各占~50%, 两者含相同市场beta。多E-空E 相减后beta抵消, 剩余即纯方向能力")

for mode in ['flip', 'target']:
    print(f"\n### {mode}")
    allL, allS = [], []
    for k in ALL:
        D = data[k]; sg = s_brk(D['close'], 20); n = len(D['close'])
        f = run(D, sg, 0.05, 2.0, 2, 5, 800, n // 2, n, mode)
        L = f[f.dir == 1].net.values; S = f[f.dir == -1].net.values
        allL.append(L); allS.append(S)
    L = np.concatenate(allL); S = np.concatenate(allS)
    # 配对: 随机配对的差值
    rng = np.random.default_rng(42)
    n = min(len(L), len(S))
    diffs = np.array([L[rng.integers(len(L))] - S[rng.integers(len(S))] for _ in range(20000)])
    d = diffs.mean(); se = diffs.std() / np.sqrt(len(diffs))
    print(f"  多头 N={len(L)} E={L.mean():+.4f}")
    print(f"  空头 N={len(S)} E={S.mean():+.4f}")
    print(f"  多空差 = {L.mean()-S.mean():+.4f}   (bootstrap t={(L.mean()-S.mean())/(np.sqrt(L.var()/len(L)+S.var()/len(S))):+.2f})")
    tt = (L.mean() - S.mean()) / np.sqrt(L.var() / len(L) + S.var() / len(S))
    print(f"  → {'存在beta中性alpha' if abs(tt) > 1.96 else '无beta中性alpha (差与噪声不可区分)'}")

print("\n" + "=" * 100)
print("终极检验 2: 策略E 与 同期买入持有 的相关性 (越高说明越是beta)")
print("=" * 100)
rows = []
for k in ALL:
    batch = '旧4' if k in OLD4 else ('新3' if k in NEW3 else '新6')
    D = data[k]; cl = D['close']; n = len(cl); h = n // 2
    bh = cl[n - 1] / cl[h] - 1
    sg = s_brk(cl, 20)
    f1 = run(D, sg, 0.05, 2.0, 2, 5, 800, h, n, 'flip')
    f2 = run(D, sg, 0.05, 2.0, 2, 5, 800, h, n, 'target')
    rows.append((k, batch, bh, f1.net.mean(), f2.net.mean()))
df = pd.DataFrame(rows, columns=['k', 'b', 'bh', 'ef', 'et'])
print(f"  {'品种':<7}{'批次':<6}{'BH收益':>10}{'flipE':>10}{'targetE':>10}")
print("  " + "-" * 46)
for _, r in df.iterrows():
    print(f"  {r.k:<7}{r.b:<6}{r.bh*100:>9.1f}%{r.ef:>+10.4f}{r.et:>+10.4f}")
print("  " + "-" * 46)
for m in ['ef', 'et']:
    c = np.corrcoef(df.bh, df[m])[0, 1]
    # 置换检验
    rng = np.random.default_rng(7)
    perm = [abs(np.corrcoef(rng.permutation(df.bh.values), df[m].values)[0, 1]) for _ in range(5000)]
    p = np.mean([x >= abs(c) for x in perm])
    print(f"  corr(BH, {m}) = {c:+.3f}  置换 p={p:.3f}  {'显著→收益主要是beta' if p < 0.05 else '不显著'}")

print("\n" + "=" * 100)
print("终极检验 3: 分牛熊 —— 若真有alpha, 牛市熊市都应赚")
print("=" * 100)
for mode in ['flip', 'target']:
    print(f"\n[{mode}]")
    bull = df[df.bh > 0]; bear = df[df.bh <= 0]
    m = 'ef' if mode == 'flip' else 'et'
    print(f"  牛市品种 (BH>0, n={len(bull)}): 平均E={bull[m].mean():+.4f}  正比例={np.mean(bull[m]>0)*100:.0f}%")
    print(f"  熊市品种 (BH<=0, n={len(bear)}): 平均E={bear[m].mean():+.4f}  正比例={np.mean(bear[m]>0)*100:.0f}%")
    if len(bull) > 1 and len(bear) > 1:
        se = np.sqrt(bull[m].var() / len(bull) + bear[m].var() / len(bear))
        t = (bull[m].mean() - bear[m].mean()) / se if se > 0 else 0
        print(f"  牛-熊差 = {bull[m].mean()-bear[m].mean():+.4f}  t={t:+.2f}  "
              f"{'显著→依赖市场环境(beta)' if abs(t)>1.96 else '不显著'}")

print("\n" + "=" * 100)
print("终极检验 4: 剔除XMR的合理性检验 (事后剔除=作弊?)")
print("=" * 100)
print("  XMR flip E=-0.1137 (t=-4.84), 是6个新品种里唯一的极端负值。")
print("  剔除后新6 flip: E=+0.0239 t=+1.84; target: E=+0.0700 t=+2.06")
print("  但若'剔除极端值'合法, 也应剔除极端正值 → 检验对称剔除:")
for mode in ['flip', 'target']:
    vals = {}
    for k in NEW6:
        D = data[k]; sg = s_brk(D['close'], 20); n = len(D['close'])
        f = run(D, sg, 0.05, 2.0, 2, 5, 800, n // 2, n, mode)
        vals[k] = f.net.mean()
    s = pd.Series(vals)
    print(f"\n  [{mode}] 各品种E: " + "  ".join(f"{k}={v:+.4f}" for k, v in s.items()))
    print(f"    去最差(XMR): E={s.drop(s.idxmin()).mean():+.4f}")
    print(f"    去最好({s.idxmax()}): E={s.drop(s.idxmax()).mean():+.4f}")
    print(f"    去两端(对称): E={s.drop([s.idxmin(), s.idxmax()]).mean():+.4f}")
    print(f"    → 不对称剔除会把均值人为抬高 {s.drop(s.idxmin()).mean()-s.mean():+.4f} (作弊幅度)")
