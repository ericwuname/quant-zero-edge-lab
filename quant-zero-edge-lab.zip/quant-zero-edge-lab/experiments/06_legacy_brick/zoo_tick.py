"""
tick级 策略动物园 —— 把多种策略接入已过铁律检验的引擎
==========================================================
关键设计（消除伪影）:
  * 用 tick 级数据, 格点索引 k=floor((lp-lp0)/A) 向量化提取砖块事件
  * 成交价 = 触及那个 tick 的【实际价格】(含超调) -> 滑点的不利部分自动计入
  * 所有策略共享同一条事件流 -> 公平对照
  * 统一表示: cont_ret[i] = b[i]*(lp[i+1]-lp[i])  = "赌延续"的每笔对数收益
             策略输出 s[i] ∈ {+1 赌延续, -1 赌反转, 0 不下注}
             实际收益 = s[i]*cont_ret[i] - 成本
  * 铁律: 随机游走市场里, 所有策略扣成本后终值必须 <= 本金
"""
import numpy as np

PRICE0 = 100000.0
COST_RATE = 0.0001      # 单边手续费(按名义)
INIT_CAP = 10000.0
RISK = 0.01
LEV_CAP = 5.0
TICKS_PER_HOUR = 20
HOURS_PER_YEAR = 252 * 8


# ============================================================
# 一、市场
# ============================================================
def gen_ticks(kind, n, sigma, seed, price0=PRICE0):
    rng = np.random.default_rng(seed)
    r = np.zeros(n)
    if kind == 'rw':
        r = rng.normal(0, sigma, n)
    elif kind == 'trendvol':
        h, d = sigma ** 2, np.zeros(n)
        for t in range(1, n):
            h = 0.9 * h + 0.1 * r[t - 1] ** 2 + 1e-16
            d[t] = 0.95 * d[t - 1] + rng.normal(0, sigma * 0.10)
            r[t] = d[t] + np.sqrt(h) * rng.normal()
        sd = r.std()
        if sd > 0:
            r = r / sd * sigma
    elif kind == 'regime':
        state = 0
        for t in range(1, n):
            if rng.random() < 0.0005:
                state = 1 - state
            r[t] = (0.10 if state == 1 else -0.10) * r[t - 1] + rng.normal(0, sigma)
    elif kind == 'strong':
        L = max(50, n // 8)
        signs = rng.choice([-1, 1], int(np.ceil(n / L)))
        r = signs.repeat(L)[:n] * sigma * 0.30 + rng.normal(0, sigma, n)
    return price0 * np.exp(np.cumsum(r))


def brick_events(px, A):
    """
    标准 Renko 循环(正确语义):
      区间 [anchor-A, anchor+A]
      上破 -> +1砖, anchor 上移 A (要回落 A 才算反向砖)
      下破 -> -1砖, anchor 下移 A
    成交价 = 触及那个 tick 的【实际对数价格】(含超调 -> 自动计入不利滑点)

    注意: 不能用 floor((lp-lp0)/A) 全局格点!
          那样价格在边界抖动会产生位移≈0 的伪砖块, 严重失真。
    """
    lp = np.log(px)
    n = len(lp)
    dirs = []
    prices = []
    anchor = float(lp[0])
    hi = anchor + A
    lo = anchor - A
    for i in range(1, n):
        p = lp[i]
        while True:
            if p >= hi:
                dirs.append(1.0)
                prices.append(p)
                anchor = hi
                hi = anchor + A
                lo = anchor - A
            elif p <= lo:
                dirs.append(-1.0)
                prices.append(p)
                anchor = lo
                hi = anchor + A
                lo = anchor - A
            else:
                break
    if len(dirs) < 2:
        return None
    return np.array(dirs), np.array(prices)


def cont_returns(ev_dir, ev_lp):
    """cont_ret[i] = 赌'下一块同向'的对数收益 (i=0..n-2)"""
    b = ev_dir[:-1]
    dp = np.diff(ev_lp)
    return b * dp


# ============================================================
# 二、策略: 输入历史, 输出 s ∈ {-1,0,+1}
#    统一在事件流上运行, 只用过去
# ============================================================
def sig_const(cr, t, **kw):
    return 1.0


def sig_rev(cr, t, **kw):
    return -1.0


def _streak(b, i, k):
    """第 i 块之前是否连续 k 块同向"""
    if i < k:
        return False
    seg = b[i - k:i]
    return bool(np.all(seg == seg[0]))


def make_mom(k):
    def f(cr, t, b=None, **kw):
        return 1.0 if _streak(b, t, k) else 0.0
    return f


def make_rev(k):
    def f(cr, t, b=None, **kw):
        return -1.0 if _streak(b, t, k) else 0.0
    return f


def sig_stat(cr, t, W=100, **kw):
    """最近W笔均值符号决定方向, 不显著则不下注"""
    if t < W:
        return 0.0
    seg = cr[t - W:t]
    m = seg.mean()
    sd = seg.std()
    if sd <= 0:
        return 0.0
    z = m / (sd / np.sqrt(W))
    if abs(z) < 1.645:
        return 0.0
    return 1.0 if m > 0 else -1.0


def sig_stat_mom(cr, t, W=100, **kw):
    """只在显著为正时赌延续(趋势), 否则空仓"""
    if t < W:
        return 0.0
    seg = cr[t - W:t]
    z = seg.mean() / (seg.std() / np.sqrt(W)) if seg.std() > 0 else 0
    return 1.0 if z > 1.645 else 0.0


# ============================================================
# 三、回测: 单策略 / 组合 / 元选择
# ============================================================
def run_single(cr, signal_fn, A, b=None, cap0=INIT_CAP, risk=RISK,
               cost_rate=COST_RATE, W=100):
    n = len(cr)
    cap = cap0
    equity = np.empty(n)
    peak = cap0
    maxdd = 0.0
    for i in range(n):
        s = signal_fn(cr, i, b=b, W=W)
        if s != 0:
            lots = cap * risk / (PRICE0 * A)
            if lots * PRICE0 > cap * LEV_CAP:
                lots = cap * LEV_CAP / PRICE0
            if lots > 0:
                gross = s * cr[i] * lots * PRICE0
                fee = 2.0 * lots * PRICE0 * cost_rate
                cap += gross - fee
        equity[i] = max(cap, 0.0)
        peak = max(peak, equity[i])
        maxdd = max(maxdd, (peak - equity[i]) / peak if peak > 0 else 0)
        if cap <= 0:
            equity[i:] = 0.0
            break
    ntr = int(cr.shape[0])
    return dict(final=equity[-1], equity=equity, maxdd=maxdd)


def run_combo(cr, fns, A, b=None, cap0=INIT_CAP, risk=RISK,
              cost_rate=COST_RATE, W=100, weights=None):
    """多策略等权(或指定权重)组合, 每个分到 risk/len 的风险预算"""
    n = len(cr)
    m = len(fns)
    wts = np.ones(m) / m if weights is None else np.asarray(weights, float)
    wts = wts / wts.sum()
    cap = cap0
    equity = np.empty(n)
    peak = cap0
    maxdd = 0.0
    for i in range(n):
        for j, fn in enumerate(fns):
            s = fn(cr, i, b=b, W=W)
            if s != 0:
                lots = cap * risk * wts[j] / (PRICE0 * A)
                if lots * PRICE0 > cap * LEV_CAP:
                    lots = cap * LEV_CAP / PRICE0
                if lots > 0:
                    cap += s * cr[i] * lots * PRICE0 - 2.0 * lots * PRICE0 * cost_rate
        equity[i] = max(cap, 0.0)
        peak = max(peak, equity[i])
        maxdd = max(maxdd, (peak - equity[i]) / peak if peak > 0 else 0)
        if cap <= 0:
            equity[i:] = 0.0
            break
    return dict(final=equity[-1], equity=equity, maxdd=maxdd)


def run_meta(cr, fns, A, b=None, cap0=INIT_CAP, risk=RISK,
             cost_rate=COST_RATE, W=100):
    """元选择(bandit): 每步用最近W笔各策略的实绩, 选最好的那个下注"""
    n = len(cr)
    m = len(fns)
    cap = cap0
    equity = np.empty(n)
    peak = cap0
    maxdd = 0.0
    # 预计算各策略信号
    sigs = np.zeros((m, n))
    for j, fn in enumerate(fns):
        for i in range(n):
            sigs[j, i] = fn(cr, i, b=b, W=W)
    for i in range(n):
        if i >= W:
            # 最近 W 笔各策略的累计收益
            perf = np.array([(sigs[j, i - W:i] * cr[i - W:i]).sum() for j in range(m)])
            jbest = int(np.argmax(perf))
        else:
            jbest = 0
        s = sigs[jbest, i]
        if s != 0:
            lots = cap * risk / (PRICE0 * A)
            if lots * PRICE0 > cap * LEV_CAP:
                lots = cap * LEV_CAP / PRICE0
            if lots > 0:
                cap += s * cr[i] * lots * PRICE0 - 2.0 * lots * PRICE0 * cost_rate
        equity[i] = max(cap, 0.0)
        peak = max(peak, equity[i])
        maxdd = max(maxdd, (peak - equity[i]) / peak if peak > 0 else 0)
        if cap <= 0:
            equity[i:] = 0.0
            break
    return dict(final=equity[-1], equity=equity, maxdd=maxdd)
