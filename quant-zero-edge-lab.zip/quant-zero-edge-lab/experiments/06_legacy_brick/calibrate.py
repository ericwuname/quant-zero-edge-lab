"""
【核心】检测能力校准 —— 我到底能发现多强的 edge?
=======================================================
这是整个"实例化世界"计划的核心价值:

  真实市场永远没有对照组 -> 我不知道测出的是真结构还是噪声
  在我的世界里 -> 我【知道真相】, 可以校准尺子

【关键问题】
  植入一个已知强度的 edge, 用我全套流程去测
  -> 多强的 edge 我才能发现?
  -> 真实市场的 edge 若低于这个阈值, "找不到"就不是市场没有, 而是我测不出

【方法】
  1. 生成不同强度的真实结构 (trend_strength 从 0 递增)
  2. 对每个强度, 生成多个世界(不同seed)
  3. 用标准流程检测: walk-forward + Reality Check + 成本
  4. 统计"检出率" vs "edge强度"
  5. 找到【检出率=50%的临界强度】

【这直接回答】
  "我凭什么相信我看到的是真的" -> 给出检测能力的定量下限
"""
import numpy as np
import pandas as pd
from scipy import stats
import sys
sys.path.insert(0, '/data/workspace/brick')
from world_v5 import World, facts

DAYS_YR = 365
COST_BP = 10          # 单边成本
N_STRATS = 12


def build_signals(prices):
    """构建策略族 (只用t及之前信息)
    prices 长度 = T+1, r 长度 = T, 信号长度必须 = T 且与 r 对齐:
    signal[t] 用 t 及之前的价格 -> 赚 r[t+1]
    """
    T = len(prices) - 1
    P = prices[:T]          # 与 r 对齐的价格 (r[t] = P[t]->P[t+1] 的下一期)
    S = {}
    for w in [5, 10, 20, 60]:
        if T > w + 1:
            mom = np.zeros(T)
            mom[w:] = P[w:] / np.maximum(P[:-w], 1e-9) - 1
            S[f'mom_{w}'] = np.sign(mom)
            S[f'rev_{w}'] = -np.sign(mom)
    for w in [10, 30]:
        if T > w + 1:
            ma = pd.Series(P).rolling(w).mean().values
            sig = np.where(P > ma, 1.0, -1.0)
            sig[:w] = 0.0
            S[f'ma_{w}'] = sig
    return S


def backtest(sig, r, cost_bp):
    T = len(r)
    pnl = np.zeros(T)
    pnl[:-1] = sig[:-1] * r[1:]
    turn = np.abs(np.diff(np.concatenate([[0.0], sig])))
    return pnl - turn * (2 * cost_bp / 1e4)


def sharpe(x):
    s = x.std()
    return x.mean() / s * np.sqrt(DAYS_YR) if s > 1e-12 else 0.0


def boot_idx(rng, T, L):
    nb = int(np.ceil(T / L))
    st = rng.integers(0, T - L, size=nb)
    return (st[:, None] + np.arange(L)[None, :]).ravel()[:T] % T


def reality_check(oos_matrix, B=200, blk=20, seed=0):
    """
    oos_matrix: (n_strategies, T) 样本外收益
    返回 (最优策略的样本外均值, RC p值)
    """
    M, T = oos_matrix.shape
    means = oos_matrix.mean(axis=1)
    best_idx = int(np.argmax(means))
    obs_best = means[best_idx]
    # 用 stationary bootstrap 生成零假设下 max 的分布
    rng = np.random.default_rng(seed)
    centered = oos_matrix - means[:, None]
    null_max = np.zeros(B)
    for b in range(B):
        idx = boot_idx(rng, T, blk)
        null_max[b] = centered[:, idx].mean(axis=1).max()
    p = (null_max >= obs_best).mean()
    return obs_best, p, best_idx


def detect_one_world(prices, seed=0, cost_bp=COST_BP):
    """在一个世界里跑完整检测流程"""
    r = np.diff(prices) / np.maximum(prices[:-1], 1e-9)
    T = len(r)
    sp = T // 2
    S = build_signals(prices)
    names = list(S.keys())
    if len(names) < 4:
        return None

    # 样本内选最优 (按夏普)
    is_sh = {}
    for nm in names:
        pnl = backtest(S[nm], r, cost_bp)
        is_sh[nm] = sharpe(pnl[:sp])
    best = max(is_sh, key=is_sh.get)

    # 样本外
    oos = np.array([backtest(S[nm], r, cost_bp)[sp:] for nm in names])
    obs, p, bi = reality_check(oos, seed=seed)
    return dict(best=names[bi] if bi < len(names) else best,
                oos_mean=obs * 1e4,     # bp/期
                rc_p=p,
                best_sharpe_oos=sharpe(oos[bi]) if bi < len(oos) else 0.0)


print("=" * 100)
print("【核心】检测能力校准 —— 我能发现多强的 edge?")
print("=" * 100)
print(f"  策略族: {N_STRATS} 个 (动量/反转/均线)")
print(f"  成本: {COST_BP}bp 单边")
print(f"  流程: 样本内选最优 -> 样本外验证 -> Reality Check")
print(f"  每个强度跑 12 个独立世界 (不同seed)")

strengths = [0.0, 0.001, 0.002, 0.004, 0.008, 0.015, 0.025]
N_WORLDS = 12

print(f"\n  {'植入强度':>9}{'检出数':>8}{'检出率':>9}{'平均p':>9}"
      f"{'平均样本外收益(bp)':>20}{'平均夏普':>10}")
print("  " + "-" * 66)

results = []
for ts in strengths:
    detects = 0
    ps = []
    means = []
    shps = []
    for wi in range(N_WORLDS):
        w = World(seed=1000 + wi, beta=0.0005)
        prices, wh, kinds = w.run(n_steps=10000, trend_strength=ts)
        res = detect_one_world(prices, seed=wi)
        if res is None:
            continue
        ps.append(res['rc_p'])
        means.append(res['oos_mean'])
        shps.append(res['best_sharpe_oos'])
        if res['rc_p'] < 0.05:
            detects += 1
    if not ps:
        continue
    rate = detects / len(ps)
    print(f"  {ts:>9.4f}{detects:>8}{rate*100:>8.0f}%{np.mean(ps):>9.3f}"
          f"{np.mean(means):>19.2f}bp{np.mean(shps):>10.3f}")
    results.append((ts, rate, np.mean(ps), np.mean(means)))

# 找临界强度 (检出率=50%)
print("\n" + "=" * 100)
print("【检测临界点】")
print("=" * 100)
if len(results) >= 2:
    ts_arr = np.array([r[0] for r in results])
    rt_arr = np.array([r[1] for r in results])
    # 插值找 50% 检出率对应的强度
    crit = None
    for i in range(len(rt_arr) - 1):
        if rt_arr[i] < 0.5 <= rt_arr[i + 1]:
            # 线性插值
            f = (0.5 - rt_arr[i]) / (rt_arr[i + 1] - rt_arr[i])
            crit = ts_arr[i] + f * (ts_arr[i + 1] - ts_arr[i])
            break
    if rt_arr[0] >= 0.5:
        crit = ts_arr[0]
    if crit is not None:
        print(f"  50% 检出率对应的 edge 强度: {crit:.4f}")
    else:
        print(f"  在测试范围内未达到 50% 检出率 (最大检出率 {rt_arr.max()*100:.0f}%)")

    print(f"\n  检出率曲线:")
    for ts, rt, p, m in results:
        bar = "█" * int(rt * 20)
        print(f"    强度{ts:>7.4f} | {bar:<20} {rt*100:>3.0f}%  "
              f"(平均p={p:.3f}, 样本外{m:+.1f}bp)")

print("\n" + "=" * 100)
print("解读:")
print("  1. 若【真实市场的edge强度】低于临界值 -> '找不到'是检测能力问题")
print("  2. 这个临界值可用于反推: 真实市场需要多强的edge我才能发现")
print("  3. 对比真实数据测出的效应量级, 判断是否在可检测范围")
print("=" * 100)
