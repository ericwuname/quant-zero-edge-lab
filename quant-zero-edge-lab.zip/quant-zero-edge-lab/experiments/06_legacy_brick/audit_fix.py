"""
【逻辑审计】旧版有5个逻辑问题, 逐项量化影响
F1 入场时点: close[t]入场 -> 应用 open[t+1] (同bar入场不可执行)
F2 信号脱节: 持仓期间信号已翻转多轮仍不平仓 -> 加 flip_exit
F3 止损滑点: 止损按 -s 精确成交 -> 实际有滑点
F4 止盈可达性: 止盈挂单是否真能成交(maker) 
F5 数据质量: 上市初期极端波动段是否污染
"""
import numpy as np, pandas as pd

FILES={'DOGE':'/data/inputs/DOGEUSDT_1h.csv','DOT':'/data/inputs/DOTUSDT_1h.csv',
       'CRV':'/data/inputs/CRVUSDT_1h.csv','DASH':'/data/inputs/DASHUSDT_1h.csv',
       'ETH':'/data/inputs/ETHUSDT_1h.csv','FIL':'/data/inputs/FILUSDT_1h.csv',
       'HBAR':'/data/inputs/HBARUSDT_1h.csv'}

def load():
    o={}
    for k,p in FILES.items():
        d=pd.read_csv(p)
        c={x.lower():x for x in d.columns}
        o[k]=dict(open=d[c['open']].values.astype(float),
                  high=d[c['high']].values.astype(float),
                  low=d[c['low']].values.astype(float),
                  close=d[c['close']].values.astype(float))
    return o

def mom(cl,w):
    n=len(cl);s=np.zeros(n)
    s[w:]=np.sign(cl[w:]/np.maximum(cl[:-w],1e-9)-1)
    return s

def run(D,sg,s=0.05,R=2.0,cost_bp=2,max_hold=800,
        entry='close',      # 'close'=旧(同bar) / 'next_open'=修复
        flip_exit=False,    # True=信号翻转即平仓
        slip_bp=0.0,        # 止损额外滑点(bp)
        start=0,end=None):
    op,hi,lo,cl=D['open'],D['high'],D['low'],D['close']
    n=len(cl) if end is None else min(end,len(cl))
    cR=2*cost_bp/1e4/s
    slip=slip_bp/1e4/s   # 换算成R单位
    net=[];holds=[]
    i=max(start,120)
    while i<n-2:
        if sg[i]==0: i+=1; continue
        d=1 if sg[i]>0 else -1
        # 入场价
        if entry=='next_open':
            if i+1>=n-1: break
            e=op[i+1]; i0=i+1
        else:
            e=cl[i]; i0=i
        out=None;j=i0
        for jj in range(i0+1,min(i0+max_hold,n)):
            adv=(lo[jj]/e-1) if d==1 else (1-hi[jj]/e)
            fav=(hi[jj]/e-1) if d==1 else (1-lo[jj]/e)
            # F3: 止损含滑点
            if adv<=-(s+slip_bp/1e4): out=-1.0-slip; j=jj; break
            # F2: 信号翻转即平
            if flip_exit and sg[jj]*d<0:
                mv=((cl[jj]/e-1)*d)
                out=mv/s; j=jj; break
            if fav>=R*s: out=R; j=jj; break
        if out is None:
            j=min(i0+max_hold,n-1)
            out=((cl[j]/e-1)*d)/s
        net.append(out-cR); holds.append(j-i0)
        i=j+1
    return np.array(net),np.array(holds)

def st(net):
    if len(net)<30: return None
    E=net.mean();sd=net.std()
    return dict(n=len(net),win=(net>0).mean(),E=E,t=E/(sd/np.sqrt(len(net))) if sd>0 else 0)

data=load()
print("="*104)
print("【逻辑审计】5项修复, 逐项量化对 E(R) 的影响 (7品种池化, 样本外)")
print("="*104)
print("  基准: mom_5, s=5%, R=2, maker2bp, entry=close(旧), 无flip_exit, 无滑点")

def pooled(**kw):
    alln=[]
    for k in FILES:
        if k not in data: continue
        D=data[k];n=len(D['close']);sp=n//2
        sg=mom(D['close'],5)
        nt,_=run(D,sg,start=sp,end=n,**kw)
        if len(nt)>=30: alln.append(nt)
    return st(np.concatenate(alln)) if alln else None

base=pooled()
print(f"\n  [基准 旧版全bug] E={base['E']:+.4f}R  t={base['t']:+.2f}  N={base['n']}")
print(f"\n  {'修复项':<34}{'E(R)':>10}{'Δvs基准':>10}{'t':>8}")
print("  "+"-"*64)

fixes=[]
r1=pooled(entry='next_open');            fixes.append(('F1 入场改用open[t+1](去前视)',r1))
r2=pooled(flip_exit=True);               fixes.append(('F2 信号翻转即平仓',r2))
r3=pooled(slip_bp=5);                    fixes.append(('F3 止损+5bp滑点',r3))
r4=pooled(entry='next_open',flip_exit=True); fixes.append(('F1+F2 联合',r4))
r5=pooled(entry='next_open',flip_exit=True,slip_bp=5); fixes.append(('F1+F2+F3 全部修复',r5))
for nm,r in fixes:
    if r is None: continue
    print(f"  {nm:<34}{r['E']:>+10.4f}{r['E']-base['E']:>+10.4f}{r['t']:>+8.2f}")

print(f"\n  [F5 数据质量] 剔除各品种上市初期前10%数据后重跑(全修复)")
alln=[]
for k in FILES:
    if k not in data: continue
    D=data[k];n=len(D['close'])
    sp=int(n*0.55)
    sg=mom(D['close'],5)
    nt,_=run(D,sg,entry='next_open',flip_exit=True,slip_bp=5,start=sp,end=n)
    if len(nt)>=30: alln.append(nt)
r6=st(np.concatenate(alln))
if r6: print(f"  全修复+剔除初期: E={r6['E']:+.4f}R t={r6['t']:+.2f} N={r6['n']}")

print("\n"+"="*104)
