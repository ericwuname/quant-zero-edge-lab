"""
干净的最终实验: 加入策略后能"试出来"吗?
==============================================
修正上一版的问题:
  * 去掉不现实的"强趋势"(tick级漂移过强 -> 复利爆炸到1e20)
  * regime 市场的 AR 强度调弱, 使其真正"趋势/震荡交替"而非 tick 级强动量
  * 只看现实强度的市场

市场:
  rw       零结构(数学上绝无edge)
  weakmom  弱动量(最像真实市场里那点微弱趋势)
  regime   体制切换(趋势段/震荡段交替, 温和)

策略: 10 个 + 组合 + 元选择
"""
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from zoo_tick import (gen_ticks, brick_events, cont_returns, sig_const,
                      sig_rev, make_mom, make_rev, sig_stat, sig_stat_mom,
                      run_single, run_combo, run_meta, INIT_CAP,
                      TICKS_PER_HOUR, HOURS_PER_YEAR, PRICE0)

plt.rcParams['font.sans-serif'] = ['WenQuanYi Micro Hei', 'DejaVu Sans']
plt.rcParams['axes.unicode_minus'] = False

N = 120000
ANN = 0.20
SIG = ANN / np.sqrt(TICKS_PER_HOUR * HOURS_PER_YEAR)
NPATH = 12
YEARS = N / (TICKS_PER_HOUR * HOURS_PER_YEAR)
A_MULT = 5                      # 样本量够(3632笔)
A = A_MULT * SIG

print(f"设置: {YEARS:.1f}年tick  A={A_MULT}σ={A*1e4:.0f}bp  初始{INIT_CAP:.0f}元  "
      f"每笔风险1%  {NPATH}路径")


def gen(kind, n, sigma, seed):
    rng = np.random.default_rng(seed)
    r = np.zeros(n)
    if kind == 'rw':
        r = rng.normal(0, sigma, n)
    elif kind == 'weakmom':
        # 温和的缓慢漂移(最像真实市场那点微弱趋势)
        d = np.zeros(n)
        for t in range(1, n):
            d[t] = 0.98 * d[t - 1] + rng.normal(0, sigma * 0.020)
        r = d + rng.normal(0, sigma, n)
        sd = r.std()
        if sd > 0:
            r = r / sd * sigma
    elif kind == 'regime':
        # 温和的体制切换: 弱动量段 与 弱反转段 交替
        state = 0
        for t in range(1, n):
            if rng.random() < 0.002:
                state = 1 - state
            r[t] = (0.03 if state == 1 else -0.03) * r[t - 1] + rng.normal(0, sigma)
    return PRICE0 * np.exp(np.cumsum(r))


FNS = {
    '纯延续': sig_const, '纯反转': sig_rev,
    '动量2': make_mom(2), '动量3': make_mom(3),
    '反转2': make_rev(2), '反转3': make_rev(3),
    '统计双向': sig_stat, '统计只多': sig_stat_mom,
}
COMBO = [make_mom(2), make_mom(3), make_rev(2), make_rev(3)]
META = [sig_const, sig_rev, make_mom(2), make_rev(2)]
MK = ['rw', 'weakmom', 'regime']
MK_NAME = {'rw': '随机游走', 'weakmom': '弱动量', 'regime': '体制切换'}


def ev1(mk, seed):
    px = gen(mk, N, SIG, seed)
    e = brick_events(px, A)
    if e is None:
        return None
    b, lp = e
    if len(b) < 60:
        return None
    cr = cont_returns(b, lp)
    o = {}
    for n, f in FNS.items():
        o[n] = run_single(cr, f, A, b=b)
    o['等权组合'] = run_combo(cr, COMBO, A, b=b)
    o['元选择'] = run_meta(cr, META, A, b=b)
    o['_n'] = len(cr)
    o['_cr'] = cr
    return o


print("=" * 96)
print("结果: 中位终值 (本金 10000)")
print("=" * 96)
res = {}
for mk in MK:
    res[mk] = {}
    for name in list(FNS) + ['等权组合', '元选择']:
        fs, dds = [], []
        for s in range(NPATH):
            o = ev1(mk, 9000 + s)
            if o:
                fs.append(o[name]['final']); dds.append(o[name]['maxdd'])
        res[mk][name] = dict(f=np.array(fs), med=float(np.median(fs)),
                             mean=float(np.mean(fs)), dd=float(np.median(dds)))

names = list(FNS) + ['等权组合', '元选择']
print(f"\n  {'策略':<10}" + "".join(f"{MK_NAME[m]:>13}" for m in MK) + f"{'最差':>10}{'回撤均值':>10}")
for n in names:
    meds = [res[mk][n]['med'] for mk in MK]
    dds = [res[mk][n]['dd'] for mk in MK]
    print(f"  {n:<10}" + "".join(f"{v:>13.0f}" for v in meds) +
          f"{min(meds):>10.0f}{np.mean(dds)*100:>9.1f}%")

print(f"\n  铁律: 随机游走列应 <=10000 ->", end=" ")
bad = [n for n in names if res['rw'][n]['med'] > INIT_CAP * 1.03]
print(f"{'全部通过' if not bad else '违反: ' + str(bad)}")

print("\n" + "=" * 96)
print("稳健性排名 (按最差市场表现, 因为你事前不知道在哪个市场)")
print("=" * 96)
rank = sorted(names, key=lambda n: -min(res[mk][n]['med'] for mk in MK))
print(f"  {'排名':<5}{'策略':<10}{'最差中位':>10}{'收益':>9}{'平均回撤':>10}{'评价':>10}")
for i, n in enumerate(rank, 1):
    meds = [res[mk][n]['med'] for mk in MK]
    dd = np.mean([res[mk][n]['dd'] for mk in MK])
    worst = min(meds)
    ev = "打平" if worst > 9500 else ("小亏" if worst > 8000 else "亏")
    print(f"  {i:<5}{n:<10}{worst:>10.0f}{(worst/INIT_CAP-1)*100:>+8.1f}%{dd*100:>9.1f}%{ev:>10}")

print("\n" + "=" * 96)
print("组合 vs 单策略: 收益 vs 回撤")
print("=" * 96)
singles = ['纯延续', '纯反转', '动量2', '反转2']
print(f"  {'':<12}{'平均中位':>10}{'平均回撤':>10}")
for n in singles + ['等权组合', '元选择']:
    meds = np.mean([res[mk][n]['med'] for mk in MK])
    dd = np.mean([res[mk][n]['dd'] for mk in MK])
    tag = " <-组合" if n in ('等权组合', '元选择') else ""
    print(f"  {n:<12}{meds:>10.0f}{dd*100:>9.1f}%{tag}")
print("\n  单策略平均回撤: "
      f"{np.mean([np.mean([res[mk][n]['dd'] for mk in MK]) for n in singles])*100:.1f}%")
print(f"  等权组合回撤  : {np.mean([res[mk]['等权组合']['dd'] for mk in MK])*100:.1f}%")

ns = []
for s in range(8):
    o = ev1('weakmom', 9000 + s)
    if o:
        ns.append(o['_n'])
print(f"\n  交易次数 ≈ {np.mean(ns):.0f}  (验证2个点优势需~1700 -> "
      f"{'够' if np.mean(ns) >= 1700 else '不够'})")

# ============================================================
# 图
# ============================================================
fig, axes = plt.subplots(1, 2, figsize=(16.5, 5.8))
fig.suptitle("加入策略后能“试出来”吗？（tick级，现实强度市场，A=5σ）", fontsize=14, fontweight='bold')

ax = axes[0]
x = np.arange(len(names))
w = 0.26
cols = ['salmon', 'steelblue', 'orange']
for i, mk in enumerate(MK):
    ax.bar(x + i * w - w, [res[mk][n]['med'] for n in names], w,
           label=MK_NAME[mk], color=cols[i], alpha=.85)
ax.axhline(INIT_CAP, color='k', ls='--', lw=2, label='本金10000')
ax.set_xticks(x)
ax.set_xticklabels(names, fontsize=9.5, rotation=20)
ax.set_ylabel("中位终值 (元)")
ax.set_title("① 各策略在各市场：同一个策略换个市场就翻转\n（期望来自【匹配】，不来自策略本身）", fontsize=11)
ax.legend(fontsize=9)
ax.grid(alpha=.3, axis='y')

ax = axes[1]
xs = np.arange(len(rank))
worst = [min(res[mk][n]['med'] for mk in MK) for n in rank]
dds = [np.mean([res[mk][n]['dd'] for mk in MK]) * 100 for n in rank]
ax.bar(xs, worst, color=['green' if v > 9500 else 'salmon' for v in worst])
ax.axhline(INIT_CAP, color='k', ls='--', lw=1.8, label='本金')
ax2 = ax.twinx()
ax2.plot(xs, dds, 'o-', color='navy', lw=2, ms=7, label='平均回撤%')
ax.set_xticks(xs)
ax.set_xticklabels(rank, fontsize=9, rotation=25)
ax.set_ylabel("最差市场终值 (元)")
ax2.set_ylabel("平均回撤 %")
ax.set_title("② 稳健性排名：看最差市场（你不知自己在哪）\n柱=最差终值  线=回撤", fontsize=11)
ax.legend(fontsize=8.5, loc='upper left')
ax2.legend(fontsize=8.5, loc='upper right')
ax.grid(alpha=.3, axis='y')

plt.tight_layout(rect=[0, 0, 1, 0.93])
plt.savefig("/data/workspace/brick/fig_final_zoo.png", dpi=130)
print("\n[已保存] fig_final_zoo.png")
