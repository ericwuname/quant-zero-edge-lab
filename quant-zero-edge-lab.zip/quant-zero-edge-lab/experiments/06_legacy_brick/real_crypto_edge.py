"""
真实加密货币日线 —— 边际(edge)检验
=====================================
严谨设计（修掉之前所有已知问题）:
  1. 不"翻译": 直接模拟成交, 不用 rho->胜率 的解析公式
  2. 无前视: signal[t] 只用 t 日及之前信息, 收益 = signal[t] * ret[t+1]
  3. walk-forward: 前50%训练选策略, 后50%【样本外】验证
  4. Reality Check: stationary bootstrap 多重检验校正
  5. 随机对照: 打乱收益得到零假设基线
  6. 成本敏感性: 扫 0/5/10/20/50 bp 单边成本
  7. beta 对照: 与买入持有比较

策略族 (20条): 5个窗口 x 4种规则
"""
import numpy as np
import pandas as pd

# ---------------- 配置 ----------------
FILES = {
    'BTCUSDT': '/data/inputs/BTCUSDT_1d.csv',
    'BNBUSDT': '/data/inputs/BNBUSDT_1d.csv',
    'BCHUSDT': '/data/inputs/BCHUSDT_1d.csv',
}
WINDOWS = [5, 10, 20, 50, 100]
COST_BPS = [0, 5, 10, 20, 50]      # 单边成本(bp)


def load(path):
    df = pd.read_csv(path)
    df['ret'] = df['close'].pct_change()
    return df.dropna().reset_index(drop=True)


# ---------------- 策略信号 ----------------
def build_signals(df):
    """返回 dict: name -> signal array (+1/-1/0), 只用 t 日及之前信息"""
    c = df['close'].values
    n = len(c)
    sigs = {}
    for w in WINDOWS:
        # 过去 w 日收益
        mom = np.zeros(n)
        for t in range(w, n):
            mom[t] = c[t] / c[t - w] - 1.0
        # 1) 动量: 涨则多, 跌则空
        sigs[f'mom_{w}'] = np.sign(mom)
        # 2) 反转: 涨则空, 跌则多
        sigs[f'rev_{w}'] = -np.sign(mom)
        # 3) 突破: 上破w日最高做多, 下破最低做空
        hi = pd.Series(c).rolling(w).max().shift(1).values
        lo = pd.Series(c).rolling(w).min().shift(1).values
        brk = np.zeros(n)
        for t in range(w, n):
            if np.isnan(hi[t]) or np.isnan(lo[t]):
                continue
            if c[t] > hi[t]:
                brk[t] = 1.0
            elif c[t] < lo[t]:
                brk[t] = -1.0
        sigs[f'brk_{w}'] = brk
        # 4) 均线: 收盘>MA做多
        ma = pd.Series(c).rolling(w).mean().values
        sigs[f'ma_{w}'] = np.where(c > ma, 1.0, -1.0)
    return sigs


def strat_returns(df, sigs, cost_bp):
    """signal[t] * ret[t+1], 扣成本(每次换仓扣)"""
    r = df['ret'].values
    n = len(r)
    out = {}
    for name, s in sigs.items():
        # 收益: t 日信号 * t+1 日收益
        gross = np.zeros(n)
        gross[:-1] = s[:-1] * r[1:]
        # 换仓成本: signal 变化才有成本
        pos = s.copy()
        turnover = np.zeros(n)
        turnover[1:] = np.abs(np.diff(pos))
        # 只在有持仓时算换仓
        active = (pos != 0).astype(float)
        cost = turnover * active * (2 * cost_bp / 1e4)   # 双边
        out[name] = gross - cost
    return out


def stationary_bootstrap(x, block, rng, B=2000):
    """Stationary bootstrap: 重抽样收益序列"""
    n = len(x)
    out = np.zeros(B)
    for b in range(B):
        idx = np.empty(n, dtype=int)
        i = rng.integers(0, n)
        for t in range(n):
            if rng.random() < 1.0 / block:
                i = rng.integers(0, n)
            else:
                i = (i + 1) % n
            idx[t] = i
        out[b] = x[idx].mean()
    return out


def reality_check(oos_rets_dict, best_name, rng, block=10, B=2000):
    """
    White's Reality Check: 检验"最优策略"是否显著优于随机
    零假设: 最优策略的样本外表现 = 随机挑选的运气
    """
    names = list(oos_rets_dict.keys())
    rets = np.array([oos_rets_dict[n] for n in names])   # (M, T)
    M, T = rets.shape
    # 样本外均值
    obs = np.array([rets[i].mean() for i in range(M)])
    best_idx = names.index(best_name)
    stat_obs = obs[best_idx]
    # bootstrap: 对每个策略的收益序列做 stationary bootstrap,
    # 重新计算"最优", 得到"最大值的零分布"
    boots = np.zeros(B)
    for b in range(B):
        idx = np.empty(T, dtype=int)
        i = rng.integers(0, T)
        for t in range(T):
            if rng.random() < 1.0 / block:
                i = rng.integers(0, T)
            else:
                i = (i + 1) % T
            idx[t] = i
        # 重抽样后的各策略均值 (减去原均值做中心化)
        bm = np.array([rets[j][idx].mean() for j in range(M)])
        centered = bm - obs            # 中心化: 去掉真实edge
        boots[b] = centered.max()      # 最优的运气成分
    p = (boots >= stat_obs).mean()
    return stat_obs, p


def analyze(symbol, path):
    df = load(path)
    n = len(df)
    print("\n" + "=" * 96)
    print(f"{symbol}  样本 {n} 根日线  时间跨度 {n/365:.1f} 年")
    print("=" * 96)
    print(f"  区间: close {df['close'].iloc[0]:.2f} -> {df['close'].iloc[-1]:.2f}")
    bh = df['close'].iloc[-1] / df['close'].iloc[0] - 1
    print(f"  买入持有: {bh*100:+.1f}%   年化 {((1+bh)**(365/n)-1)*100:+.2f}%")

    sigs = build_signals(df)
    split = n // 2

    # 各成本档
    print(f"\n  {'单边成本':>8}{'样本内最优':>16}{'样本内bp/日':>14}"
          f"{'样本外bp/日':>14}{'样本外年化':>13}{'RC p值':>10}{'判定':>10}")
    rng = np.random.default_rng(42)
    results = {}
    for cb in COST_BPS:
        rets = strat_returns(df, sigs, cb)
        # 样本内选最优 (按 bp/日)
        in_means = {k: v[:split].mean() * 1e4 for k, v in rets.items()}
        best = max(in_means, key=in_means.get)
        # 样本外
        oos = {k: v[split:] for k, v in rets.items()}
        oos_mean = oos[best].mean() * 1e4
        oos_ann = oos_mean * 365 / 1e4 * 100      # 年化%
        # Reality Check
        stat, p = reality_check(oos, best, rng, block=10, B=1500)
        verdict = "显著" if p < 0.05 else "不显著"
        print(f"  {cb:>7}bp{best:>16}{in_means[best]:>14.3f}{oos_mean:>14.3f}"
              f"{oos_ann:>12.2f}%{p:>10.3f}{verdict:>10}")
        results[cb] = dict(best=best, in_bp=in_means[best], oos_bp=oos_mean,
                           oos_ann=oos_ann, p=p)

    # 详细: 零成本下所有策略样本外
    print(f"\n  【零成本】全部策略样本外表现 (bp/日):")
    rets0 = strat_returns(df, sigs, 0)
    oos0 = {k: v[split:] for k, v in rets0.items()}
    in0 = {k: v[:split].mean() * 1e4 for k, v in rets0.items()}
    for name in sorted(oos0, key=lambda x: -oos0[x].mean() * 1e4)[:8]:
        print(f"    {name:<10} 样本内 {in0[name]:>8.2f}  样本外 {oos0[name].mean()*1e4:>8.2f} bp/日")

    # 买入持有对照
    print(f"\n  对照: 样本外买入持有 = {oos_buy_hold(df, split)*1e4:.2f} bp/日")
    return results


def oos_buy_hold(df, split):
    r = df['ret'].values
    return r[split:].mean()


print("=" * 96)
print("真实加密货币日线 —— 边际(edge)检验")
print("方法: 直接模拟成交 | walk-forward | Reality Check | 多重检验校正")
print("=" * 96)

for sym, p in FILES.items():
    try:
        analyze(sym, p)
    except Exception as e:
        print(f"\n[!] {sym} 失败: {type(e).__name__}: {e}")
