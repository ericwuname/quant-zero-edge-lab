# -*- coding: utf-8 -*-
"""时段效应致命检验: 时间独立性 —— 6品种共享同一条时间轴, 是真独立样本还是1个?"""
import sys, numpy as np, pandas as pd, warnings
sys.path.insert(0,'/data/workspace/brick')
warnings.filterwarnings('ignore')
from entry_lib import *

def build(sym):
    df=load(sym); o=df['open'].values
    hr=pd.to_datetime(df['timestamp'].values,unit='ms').hour.values
    r=np.zeros(len(o)); r[1:]=o[1:]/o[:-1]-1
    ts=df['timestamp'].values
    return o,hr,r,ts

# ---------- 1. 时间外推: 前50%时间拟合小时方向, 后50%时间验证 ----------
print('='*92)
print('检验1  时间外推 (关键): 前50%时间拟合24小时方向 -> 后50%时间验证')
print('='*92)
res={}
for sym in ALL13:
    o,hr,r,ts=build(sym)
    n=len(o); cut=n//2
    # 前50%拟合
    hb={}
    for hh in range(24):
        m=(hr[:cut]==hh); m[0]=False
        hb[hh]=r[:cut][m].mean() if m.sum()>10 else 0.0
    # 后50%验证
    sig=np.sign(np.array([hb[h] for h in hr[cut:]]))
    rr=r[cut:]; mm=np.arange(len(rr))>0
    gross=(rr*sig)[mm].mean()
    res[sym]=gross
    print(f'  {sym:>5}: 后50%时段策略毛收益 = {gross*1e4:+8.3f} bp/bar')
v=np.array([res[s] for s in ALL13])
t=v.mean()/(v.std(ddof=1)/np.sqrt(len(v)))
print(f'\n  13品种均值 = {v.mean()*1e4:+.3f} bp/bar   为正比例={np.mean(v>0):.1%}   t(品种级,n=13)={t:+.2f}')

# ---------- 2. 分年度稳定性: OLD7拟合 -> NEW6逐年 ----------
print()
print('='*92)
print('检验2  分年度稳定性: OLD7全样本拟合的小时方向, 在NEW6上逐年验证')
print('='*92)
hb={}
acc={}
for sym in OLD7:
    o,hr,r,ts=build(sym)
    for hh in range(24):
        m=(hr==hh); m[0]=False
        acc.setdefault(hh,[]).append(r[m].mean())
hb={h:np.mean(v) for h,v in acc.items()}
print('  拟合方向(做多小时):', sorted([h for h in hb if hb[h]>0]))
years={}
for sym in NEW6:
    o,hr,r,ts=build(sym)
    yr=pd.to_datetime(ts,unit='ms').year
    sig=np.sign(np.array([hb[h] for h in hr])); m=np.arange(len(r))>0
    for y in sorted(set(yr)):
        mm=m&(yr==y)
        if mm.sum()>500:
            years.setdefault(y,[]).append((r*sig)[mm].mean()*1e4)
print(f'\n  {"年份":<8}{"品种数":>8}{"均值(bp/bar)":>16}{"为正比例":>10}')
for y in sorted(years):
    a=np.array(years[y])
    print(f'  {y:<8}{len(a):>8}{a.mean():>16.3f}{np.mean(a>0):>10.1%}')
allyr=np.array([np.mean(years[y]) for y in sorted(years)])
if len(allyr)>1:
    t2=allyr.mean()/(allyr.std(ddof=1)/np.sqrt(len(allyr)))
    print(f'\n  年度间 t 值 (n={len(allyr)}年, 真正的时间独立样本) = {t2:+.2f}')
    print(f'  年度间符号: ' + ' '.join(f'{y}:{np.mean(years[y]):+.2f}' for y in sorted(years)))

# ---------- 3. 时间块自助: 正确的时间相关显著性 ----------
print()
print('='*92)
print('检验3  时间块自助 (block bootstrap, 块长=720bar=30天): 修正时间自相关')
print('='*92)
rng=np.random.default_rng(7)
for cost_name,cost in [('maker2bp',0.0002),('taker10bp',0.0010)]:
    nets=[]
    for sym in NEW6:
        o,hr,r,ts=build(sym)
        sig=np.sign(np.array([hb[h] for h in hr]))
        chg=np.zeros(len(sig)); chg[1:]=(np.abs(np.diff(sig))>0).astype(float)
        net=r*sig-chg*2*cost
        m=np.arange(len(net))>0
        nets.append(np.asarray(net[m]))
    # 对齐长度后按"时间"求截面平均 -> 这是一条时间序列(不是6个独立点)
    L=min(len(x) for x in nets)
    M=np.array([x[:L] for x in nets])
    port=M.mean(axis=0)           # 组合每日(bar)收益 = 一条时间序列
    obs=port.mean()*1e4
    # block bootstrap
    B=2000; bl=720; nb=L//bl
    cnt=0; sims=[]
    idx=np.arange(nb)
    for b in range(B):
        pick=rng.choice(nb,size=nb,replace=True)
        seg=np.concatenate([port[i*bl:(i+1)*bl] for i in pick])
        sims.append(seg.mean()*1e4)
    sims=np.array(sims)
    p=(sims<=0).mean()
    print(f'  {cost_name}: 组合净收益={obs:+.3f} bp/bar   块自助p(<=0)={p:.3f}   '
          f'95%CI=[{np.percentile(sims,2.5):+.3f},{np.percentile(sims,97.5):+.3f}]')
