import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from contradiction3 import gen_mkt, roll_acf1, run_contra3
from zoo_tick import INIT_CAP, TICKS_PER_HOUR, HOURS_PER_YEAR

plt.rcParams['font.sans-serif']=['WenQuanYi Micro Hei','DejaVu Sans']
plt.rcParams['axes.unicode_minus']=False
N=60000; ANN=0.20; SIG=ANN/np.sqrt(TICKS_PER_HOUR*HOURS_PER_YEAR)
NPATH=8; A=5*SIG
MKS=['rw','weakmom','oscill','regime','compress']
MK={'rw':'随机游走','weakmom':'弱动量','oscill':'震荡','regime':'体制切换','compress':'压缩突破'}

print("="*94)
print("矛盾论 v3: 用【自相关】作为结构指标")
print("="*94)
print("\n检验1: 结构指标(滚动ACF)能否识别各市场的主要矛盾?")
print(f"  {'市场':<10}{'ACF均值':>10}{'ACF标准差':>11}{'识别为':>12}")
acf_stat={}
for mk in MKS:
    vs=[]
    for s in range(4):
        px=gen_mkt(mk,N,SIG,seed=100+s)
        a=roll_acf1(px,W=2000)
        vs.append(np.nanmean(a))
    m=np.nanmean(vs); sd=np.nanstd(vs)
    acf_stat[mk]=(m,sd)
    lab = "趋势主导" if m>0.01 else ("反转主导" if m<-0.01 else "未分化")
    print(f"  {MK[mk]:<10}{m:>10.4f}{sd:>11.4f}{lab:>12}")

print("\n" + "="*94)
print("检验2: v3策略回测 (度 theta 扫描)")
print("="*94)
THETAS=[0.005,0.01,0.02,0.04,0.08]
print(f"  {'theta':>8}"+"".join(f"{MK[m]:>10}" for m in MKS)+f"{'最差':>10}{'平均空仓':>10}")
rows=[]
for th in THETAS:
    meds={};skips=[];mm=[];rr=[]
    for mk in MKS:
        fs=[];sk=[];nm=[];nr=[]
        for s in range(NPATH):
            px=gen_mkt(mk,N,SIG,seed=200+s)
            r=run_contra3(px,A,W=2000,theta=th)
            fs.append(r['final']);sk.append(r['skip_rate'])
            nm.append(r['n_mom']);nr.append(r['n_rev'])
        meds[mk]=float(np.median(fs));skips.append(np.mean(sk))
        mm.append(np.mean(nm));rr.append(np.mean(nr))
    worst=min(meds.values())
    rows.append((th,meds,worst,np.mean(skips),np.mean(mm),np.mean(rr)))
    print(f"  {th:>8.3f}"+"".join(f"{meds[m]:>10.0f}" for m in MKS)+
          f"{worst:>10.0f}{np.mean(skips)*100:>9.0f}%")

best=max(rows,key=lambda r:r[2])
print(f"\n  最优度: theta={best[0]:.3f} 最差{best[2]:.0f} 空仓率{best[3]*100:.0f}%")
print(f"  该设置下 赌延续{best[4]:.0f}次 赌反转{best[5]:.0f}次")
if best[3]>0.95: print("  ⚠ 仍≈完全空仓")
else: print("  ✓ 伴随真实交易")

print("\n"+"="*94)
print("检验3: 铁律 —— 随机游走(矛盾未分化)应 <= 本金")
print("="*94)
for th in THETAS:
    fs=[]
    for s in range(NPATH):
        px=gen_mkt('rw',N,SIG,seed=200+s)
        r=run_contra3(px,A,W=2000,theta=th)
        fs.append(r['final'])
    print(f"  theta={th:.3f}: 中位={np.median(fs):.0f} {'OK' if np.median(fs)<=INIT_CAP*1.05 else '违反'}")

# 图
fig,axes=plt.subplots(1,2,figsize=(16,5.6))
fig.suptitle("矛盾论 v3：自相关作为结构指标",fontsize=14,fontweight='bold')
ax=axes[0]
xs=np.arange(len(MKS))
ax.bar(xs,[acf_stat[m][0] for m in MKS],
       color=['green' if acf_stat[m][0]>0 else 'salmon' for m in MKS])
ax.axhline(0,color='k',lw=1.3)
ax.set_xticks(xs);ax.set_xticklabels([MK[m] for m in MKS],fontsize=9.5)
ax.set_ylabel("lag-1 自相关")
ax.set_title("① 结构指标：正=趋势主导 负=反转主导\n（不再是胜率这个结果指标）",fontsize=11)
ax.grid(alpha=.3,axis='y')
for i,m in enumerate(MKS):
    ax.text(i,acf_stat[m][0]+(0.003 if acf_stat[m][0]>0 else -0.008),
            f"{acf_stat[m][0]:.3f}",ha='center',fontsize=9)

ax=axes[1]
for mk in MKS:
    ax.plot(THETAS,[r[1][mk] for r in rows],'o-',lw=2,label=MK[mk])
ax.axhline(INIT_CAP,color='k',ls='--',lw=1.8,label='本金')
ax.axvline(best[0],color='green',ls=':',lw=2,label=f'最优{best[0]:.3f}')
ax.set_xlabel("度: theta (出手门槛)")
ax.set_ylabel("终值 (元)")
ax.set_title("② 度的扫描\n矛盾未分化时不出手 -> 能否避损?",fontsize=11)
ax.legend(fontsize=8.5);ax.grid(alpha=.3)
plt.tight_layout(rect=[0,0,1,0.92])
plt.savefig("/data/workspace/brick/fig_contra3.png",dpi=130)
print("\n[已保存] fig_contra3.png")
