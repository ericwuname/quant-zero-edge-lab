"""
波动率目标 严格检验: 是真结构, 还是只是"降仓"的功劳?
==========================================================
上一轮发现: 波动率目标 vs 固定满仓
   夏普 0.890 vs 0.644 (Δ=+0.246, p=0.193 不显著)
   回撤 41.4% vs 64.6% (Δ=-23.2%, p=0.007 显著)

【致命替代解释】波动率目标平均杠杆只有0.71 (即长期降仓)。
  如果只是"降仓", 那同等平均杠杆的固定仓位应该也能达到同样效果,
  那波动率目标就毫无价值 —— 你只要少买点就行了。

本脚本做三组关键对照:
  A. 固定杠杆匹配: 用【相同平均杠杆】的固定仓位 作为对照
     -> 若波动率目标仍胜出 = 真有择时价值
     -> 若只是打平 = 纯粹是降仓效应
  B. 随机杠杆对照: 打乱波动率序列 -> 零假设基线 (扣伪影)
  C. walk-forward: 参数(目标波动率/EWMA lambda)在样本内选, 样本外验证
  D. Reality Check: 校正多参数挑选
  E. 分品种检验: 每个品种单独做, 看是否稳健
"""
import numpy as np
import pandas as pd

DAILY = {'BTC': '/data/inputs/BTCUSDT_1d.csv',
         'BNB': '/data/inputs/BNBUSDT_1d.csv',
         'BCH': '/data/inputs/BCHUSDT_1d.csv'}
HOURLY = {'DOGE': '/data/inputs/DOGEUSDT_1h.csv',
          'DOT':  '/data/inputs/DOTUSDT_1h.csv',
          'CRV':  '/data/inputs/CRVUSDT_1h.csv',
          'DASH': '/data/inputs/DASHUSDT_1h.csv'}
DAYS_YR = 365
B_BOOT = 500
BLK = 20


def load_daily():
    px = {}
    for k, p in DAILY.items():
        d = pd.read_csv(p)
        px[k] = pd.Series(d['close'].values,
                          index=pd.to_datetime(d['timestamp'], unit='ms').dt.normalize())
        px[k] = px[k][~px[k].index.duplicated()]
    for k, p in HOURLY.items():
        d = pd.read_csv(p)
        s = pd.Series(d['close'].values,
                      index=pd.to_datetime(d['timestamp'], unit='ms'))
        px[k] = s.resample('1D').last().dropna()
    return pd.DataFrame(px).dropna()


def metrics(net):
    n = len(net)
    mu, sd = net.mean(), net.std()
    if sd < 1e-12 or n < 10:
        return 0.0, 0.0, 0.0, 0.0
    nav = np.cumprod(1.0 + np.clip(net, -0.99, None))
    ann = float(np.clip((nav[-1] ** (DAYS_YR / n) - 1) * 100 if nav[-1] > 0 else -100.0, -100, 1e6))
    sh = mu / sd * np.sqrt(DAYS_YR)
    pk = np.maximum.accumulate(nav)
    dd = (nav - pk) / np.maximum(pk, 1e-12)
    mdd = float(-dd.min() * 100)
    calmar = ann / mdd if mdd > 1e-9 else 0.0
    return ann, sh, mdd, calmar


def boot_idx(rng, T, L):
    nb = int(np.ceil(T / L))
    st = rng.integers(0, T - L, size=nb)
    return (st[:, None] + np.arange(L)[None, :]).ravel()[:T] % T


def paired_test(a, b, kind='sharpe', B=B_BOOT, blk=BLK, seed=0):
    def sh(x):
        s = x.std()
        return x.mean() / s * np.sqrt(DAYS_YR) if s > 1e-12 else 0.0
    def mdd(x):
        nav = np.cumprod(1.0 + np.clip(x, -0.99, None))
        pk = np.maximum.accumulate(nav)
        return float(-((nav - pk) / np.maximum(pk, 1e-12)).min() * 100)
    f = sh if kind == 'sharpe' else mdd
    T = len(a)
    rng = np.random.default_rng(seed)
    obs = f(a) - f(b)
    d = np.zeros(B)
    for i in range(B):
        d[i] = f(a[boot_idx(rng, T, blk)]) - f(b[boot_idx(rng, T, blk)])
    return obs, min(2 * min((d <= 0).mean(), (d >= 0).mean()), 1.0)


def ewma_vol(port, lam, floor=0.05):
    T = len(port)
    var = np.zeros(T)
    var[0] = port[:20].var() if T > 20 else max(port.var(), 1e-12)
    for t in range(1, T):
        var[t] = lam * var[t - 1] + (1 - lam) * port[t - 1] ** 2
    return np.maximum(np.sqrt(var * DAYS_YR), floor)


def run_vol(port, fvol, target, cost_bp, cap=2.0):
    T = len(port)
    lev = np.clip(target / fvol, 0.0, cap)
    pnl = np.zeros(T)
    pnl[1:] = lev[:-1] * port[1:]
    turn = np.concatenate([[abs(lev[0])], np.abs(np.diff(lev))])
    return pnl - turn * (2 * cost_bp / 1e4), lev


# ============ 主流程 ============
df = load_daily()
ret = df.pct_change().fillna(0.0)
T, N = ret.shape
sp = T // 2
print("=" * 100)
print("波动率目标 严格检验 —— 排除'降仓效应'")
print("=" * 100)
print(f"面板 {N}品种 x {T}天 ({df.index[0].date()} -> {df.index[-1].date()})  "
      f"样本外[{sp},{T})")

port = ret.mean(axis=1).values        # 等权组合日收益

# ---------- A. 固定杠杆匹配对照 (关键!) ----------
print("\n" + "=" * 100)
print("【A】关键对照: 同等平均杠杆的固定仓位 vs 波动率目标")
print("=" * 100)
print(f"  {'成本':>5}{'目标波动':>9}{'平均杠杆':>9} | {'VT年化':>9}{'VT夏普':>8}{'VT回撤':>8}"
      f" | {'固定年化':>9}{'固定夏普':>8}{'固定回撤':>8} | {'Δ夏普':>8}{'p':>7}{'Δ回撤':>8}{'p':>7}")

rows = []
for cost in [10, 20]:
    for target in [0.30, 0.40, 0.50, 0.60]:
        fvol = ewma_vol(port, 0.94)
        vt, lev = run_vol(port, fvol, target, cost)
        avg_lev = lev[sp:].mean()
        # 固定仓位: 用相同平均杠杆 (匹配!)
        fix = np.zeros(T)
        fix[1:] = avg_lev * port[1:]
        fix[0] = 0.0
        # 固定仓位的成本(建仓一次)
        fix = fix.copy()
        fix[1] -= avg_lev * (2 * cost / 1e4)
        va, vs, vd, vc = metrics(vt[sp:])
        fa, fs, fd, fc = metrics(fix[sp:])
        dsh, psh = paired_test(vt[sp:], fix[sp:], 'sharpe', seed=71)
        ddd, pdd = paired_test(vt[sp:], fix[sp:], 'mdd', seed=72)
        rows.append((cost, target, avg_lev, vs, fs, vd, fd, dsh, psh, ddd, pdd))
        print(f"  {cost:>4}bp{target:>9.2f}{avg_lev:>9.2f} | {va:>8.2f}%{vs:>8.3f}{vd:>7.2f}%"
              f" | {fa:>8.2f}%{fs:>8.3f}{fd:>7.2f}% | {dsh:>+8.3f}{psh:>7.3f}"
              f"{ddd:>+7.2f}%{pdd:>7.3f}")

print("\n  判读: 与【同等平均杠杆的固定仓位】比, 波动率目标是否仍显著更优?")

# ---------- B. 随机波动率对照 (扣伪影) ----------
print("\n" + "=" * 100)
print("【B】随机对照: 打乱波动率序列 -> 零假设基线")
print("=" * 100)
cost = 20
fvol_real = ewma_vol(port, 0.94)
vt_real, lev_real = run_vol(port, fvol_real, 0.40, cost)
va, vs, vd, _ = metrics(vt_real[sp:])
rng = np.random.default_rng(7)
sh_boot, dd_boot, sh_real_list = [], [], []
for b in range(300):
    perm = rng.permutation(T)
    fv = fvol_real[perm]
    v_b, _ = run_vol(port, fv, 0.40, cost)
    a_, s_, d_, _ = metrics(v_b[sp:])
    sh_boot.append(s_)
    dd_boot.append(d_)
sh_boot = np.array(sh_boot)
dd_boot = np.array(dd_boot)
print(f"  真实波动率目标  : 夏普 {vs:.3f}  回撤 {vd:.2f}%")
print(f"  随机波动率序列  : 夏普 {sh_boot.mean():.3f} ± {sh_boot.std():.3f}   "
      f"回撤 {dd_boot.mean():.2f}% ± {dd_boot.std():.2f}%")
p_sh = (sh_boot >= vs).mean()
p_dd = (dd_boot <= vd).mean()
print(f"  真实 vs 随机    : 夏普 p={p_sh:.3f} ({'显著' if p_sh<0.05 else '不显著'})  "
      f"回撤 p={p_dd:.3f} ({'显著' if p_dd<0.05 else '不显著'})")
print("  -> 若'随机波动率序列'也能达到类似效果, 说明是【降仓效应】而非【择时能力】")

# ---------- C. walk-forward ----------
print("\n" + "=" * 100)
print("【C】walk-forward: 样本内选参数 -> 样本外验证")
print("=" * 100)
best, best_sh = None, -1e9
for lam in [0.90, 0.94, 0.97]:
    for target in [0.30, 0.40, 0.50, 0.60, 0.80]:
        fv = ewma_vol(port, lam)
        v, _ = run_vol(port, fv, target, 20)
        s_ = metrics(v[:sp])[1]
        if s_ > best_sh:
            best_sh, best = s_, (lam, target)
lam_b, tgt_b = best
fv_b = ewma_vol(port, lam_b)
vt_b, lev_b = run_vol(port, fv_b, tgt_b, 20)
avg_lev = lev_b[sp:].mean()
fix_b = np.zeros(T)
fix_b[1:] = avg_lev * port[1:]
fix_b[1] -= avg_lev * (2 * 20 / 1e4)
va, vs, vd, vc = metrics(vt_b[sp:])
fa, fs, fd, fc = metrics(fix_b[sp:])
print(f"  样本内最优参数: lambda={lam_b}, target={tgt_b:.2f} (样本内夏普={best_sh:.3f})")
print(f"  样本外 波动率目标: 年化{va:>7.2f}%  夏普{vs:.3f}  回撤{vd:>6.2f}%  Calmar{vc:.3f}")
print(f"  样本外 同杠杆固定: 年化{fa:>7.2f}%  夏普{fs:.3f}  回撤{fd:>6.2f}%  Calmar{fc:.3f}")
dsh, psh = paired_test(vt_b[sp:], fix_b[sp:], 'sharpe', seed=81)
ddd, pdd = paired_test(vt_b[sp:], fix_b[sp:], 'mdd', seed=82)
print(f"  配对: Δ夏普={dsh:+.3f} (p={psh:.3f} {'显著' if psh<0.05 else '不显著'})  "
      f"Δ回撤={ddd:+.2f}% (p={pdd:.3f} {'显著改善' if pdd<0.05 and ddd<0 else '不显著'})")

# ---------- D. 分品种稳健性 ----------
print("\n" + "=" * 100)
print("【D】分品种稳健性 (每个品种单独: 波动率目标 vs 满仓)")
print("=" * 100)
print(f"  {'品种':<8}{'VT夏普':>9}{'满仓夏普':>10}{'Δ夏普':>9}{'p':>8}"
      f"{'VT回撤':>9}{'满仓回撤':>10}{'Δ回撤':>9}{'p':>8}")
wins_sh, wins_dd = 0, 0
for c in df.columns:
    p_ = ret[c].values
    fv = ewma_vol(p_, lam_b)
    v, lv = run_vol(p_, fv, tgt_b, 20)
    al = lv[sp:].mean()
    fx = np.zeros(T)
    fx[1:] = al * p_[1:]
    fx[1] -= al * (2 * 20 / 1e4)
    vs_, = metrics(v[sp:])[1:2]
    fs_, = metrics(fx[sp:])[1:2]
    vd_ = metrics(v[sp:])[2]
    fd_ = metrics(fx[sp:])[2]
    d1, p1 = paired_test(v[sp:], fx[sp:], 'sharpe', B=200, seed=91)
    d2, p2 = paired_test(v[sp:], fx[sp:], 'mdd', B=200, seed=92)
    if p1 < 0.05 and d1 > 0:
        wins_sh += 1
    if p2 < 0.05 and d2 < 0:
        wins_dd += 1
    print(f"  {c:<8}{vs_:>9.3f}{fs_:>10.3f}{d1:>+9.3f}{p1:>8.3f}"
          f"{vd_:>8.2f}%{fd_:>9.2f}%{d2:>+8.2f}%{p2:>8.3f}")
print(f"\n  显著改善的品种数: 夏普 {wins_sh}/{N}   回撤 {wins_dd}/{N}")

print("\n" + "=" * 100)
print("结论提示: 关键看【A】和【B】——若与同等杠杆固定仓位无显著差异,")
print("          则波动率目标的价值 = 降仓, 而非择时能力。")
print("=" * 100)
