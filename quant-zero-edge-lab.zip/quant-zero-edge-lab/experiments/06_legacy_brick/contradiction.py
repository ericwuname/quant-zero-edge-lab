"""
矛盾论交易引擎
================================================
把《矛盾论》的方法论变成可计算的策略:

1. 矛盾的普遍性: 趋势(延续) 与 震荡(反转) 是对立统一体
   -> 二者互为存在前提, 且严格镜像(数学上可证)

2. 抓主要矛盾: 当下是"延续"占主导, 还是"反转"占主导?
   -> aspect = p_short - 0.5  (矛盾的主要方面)

3. 矛盾的转化: 主要方面在加强还是在向对立面转化?
   -> convert = p_short - p_long  (转化速度/方向)

4. 度 (量变到质变): 证据未达临界, 不出手
   -> z 检验阈值 z_crit; 过犹不及, 存在最优区间

5. 内因与外因: 市场结构(内因) 通过 成本/资金(外因) 起效
   -> 外因约束: 只有 p > p* (扣成本的盈亏平衡) 才出手

核心策略: 双向自适应 —— 不像之前所有策略那样只赌一个方向
"""
import numpy as np
from zoo_tick import (gen_ticks, brick_events, cont_returns, run_single,
                      sig_const, sig_rev, sig_stat_mom, make_mom, make_rev,
                      INIT_CAP, PRICE0, COST_RATE, TICKS_PER_HOUR,
                      HOURS_PER_YEAR)


# ============================================================
# 一、市场: 加入"震荡"市场(负自相关), 让矛盾的另一方也真实存在
# ============================================================
def gen_mkt(kind, n, sigma, seed, price0=PRICE0):
    rng = np.random.default_rng(seed)
    r = np.zeros(n)
    if kind == 'rw':
        # 零结构: 矛盾未分化
        r = rng.normal(0, sigma, n)
    elif kind == 'weakmom':
        # 弱动量: 主要矛盾 = 趋势延续 (最像真实市场那点微弱趋势)
        d = np.zeros(n)
        for t in range(1, n):
            d[t] = 0.98 * d[t - 1] + rng.normal(0, sigma * 0.020)
        r = d + rng.normal(0, sigma, n)
        sd = r.std()
        if sd > 0:
            r = r / sd * sigma
    elif kind == 'oscill':
        # 震荡/均值回归: 主要矛盾 = 反转 (这是矛盾的另一方)
        phi = -0.08
        e = rng.normal(0, sigma * np.sqrt(1 - phi ** 2), n)
        for t in range(1, n):
            r[t] = phi * r[t - 1] + e[t]
    elif kind == 'regime':
        # 体制切换: 主要矛盾【会转化】—— 这是矛盾论的核心场景
        state = 0
        for t in range(1, n):
            if rng.random() < 0.002:
                state = 1 - state
            r[t] = (0.03 if state == 1 else -0.03) * r[t - 1] + rng.normal(0, sigma)
    return price0 * np.exp(np.cumsum(r))


# ============================================================
# 二、矛盾论策略: 双向自适应
# ============================================================
def run_contra(cr, A, W_short=30, W_long=300, z_crit=1.645,
               conv_tol=0.05, cap0=INIT_CAP, risk=0.01,
               cost_rate=COST_RATE, lev_cap=5.0):
    """
    矛盾论策略:
      Step1 抓主要矛盾: aspect = p_short - 0.5
      Step2 看矛盾转化: convert = p_short - p_long
      Step3 度的约束  : |z| > z_crit 才认为矛盾已分化
      Step4 外因约束  : 扣成本后 p > p* 才出手
    """
    n = len(cr)
    # 成本占比(外因): 每笔毛利=A, 每笔成本=2*COST_RATE/A (占比)
    c_cost = 2.0 * cost_rate / A
    pstar = (1.0 + c_cost) / 2.0

    cum = np.cumsum((cr > 0).astype(float))
    cap = cap0
    equity = np.empty(n)
    peak = cap0
    maxdd = 0.0
    n_bet = 0
    n_mom = 0
    n_rev = 0

    for i in range(n):
        s = 0.0
        if i >= W_long:
            p_short = (cum[i - 1] - cum[i - 1 - W_short]) / W_short
            p_long = (cum[i - 1] - cum[i - 1 - W_long]) / W_long
            aspect = p_short - 0.5            # 矛盾的主要方面
            convert = p_short - p_long        # 转化速度

            se = np.sqrt(0.25 / W_short)
            zs = aspect / se

            if zs > z_crit and convert > -conv_tol and p_short > pstar:
                s = 1.0        # 主要矛盾 = 趋势延续, 且在加强/稳定
                n_mom += 1
            elif zs < -z_crit and convert < conv_tol and (1 - p_short) > pstar:
                s = -1.0       # 主要矛盾 = 震荡反转, 且在加强/稳定
                n_rev += 1

        if s != 0:
            n_bet += 1
            lots = cap * risk / (PRICE0 * A)
            if lots * PRICE0 > cap * lev_cap:
                lots = cap * lev_cap / PRICE0
            if lots > 0:
                cap += s * cr[i] * lots * PRICE0 - 2.0 * lots * PRICE0 * cost_rate

        equity[i] = max(cap, 0.0)
        peak = max(peak, equity[i])
        maxdd = max(maxdd, (peak - equity[i]) / peak if peak > 0 else 0)
        if cap <= 0:
            equity[i:] = 0.0
            break

    return dict(final=equity[-1], equity=equity, maxdd=maxdd,
                n_bet=n_bet, n_mom=n_mom, n_rev=n_rev, pstar=pstar,
                c_cost=c_cost)


# ============================================================
# 三、只用"半个矛盾"的对照策略(证明抓全矛盾的价值)
# ============================================================
def run_half(cr, A, direction, W_short=30, z_crit=1.645,
             cap0=INIT_CAP, risk=0.01, cost_rate=COST_RATE, lev_cap=5.0):
    """只抓一个方向(延续 or 反转) —— 相当于只看到矛盾的一个方面"""
    n = len(cr)
    c_cost = 2.0 * cost_rate / A
    pstar = (1.0 + c_cost) / 2.0
    cum = np.cumsum((cr > 0).astype(float))
    cap = cap0
    equity = np.empty(n)
    peak, maxdd = cap0, 0.0
    for i in range(n):
        s = 0.0
        if i >= W_short:
            p = (cum[i - 1] - cum[i - 1 - W_short]) / W_short
            se = np.sqrt(0.25 / W_short)
            zs = (p - 0.5) / se
            if direction == 'mom' and zs > z_crit and p > pstar:
                s = 1.0
            elif direction == 'rev' and zs < -z_crit and (1 - p) > pstar:
                s = -1.0
        if s != 0:
            lots = cap * risk / (PRICE0 * A)
            if lots * PRICE0 > cap * lev_cap:
                lots = cap * lev_cap / PRICE0
            if lots > 0:
                cap += s * cr[i] * lots * PRICE0 - 2.0 * lots * PRICE0 * cost_rate
        equity[i] = max(cap, 0.0)
        peak = max(peak, equity[i])
        maxdd = max(maxdd, (peak - equity[i]) / peak if peak > 0 else 0)
        if cap <= 0:
            equity[i:] = 0.0
            break
    return dict(final=equity[-1], equity=equity, maxdd=maxdd)
