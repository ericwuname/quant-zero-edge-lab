# -*- coding: utf-8 -*-
"""收割制(不复利)重算 —— 用时间外推后的干净序列, 而非被品种外推污染的序列"""
import sys, numpy as np, pandas as pd, warnings
sys.path.insert(0,'/data/workspace/brick')
warnings.filterwarnings('ignore')
from entry_lib import *

rng=np.random.default_rng(11)
COST=0.0002   # maker 单边

def gen_R(sym, sigfn, cost=COST, stop=0.05, R=2.0, half='second'):
    """分段回测 -> R倍数序列. 只用后半时间(真样本外)"""
    df=load(sym); o=df['open'].values; h=df['high'].values; l=df['low'].values; c=df['close'].values
    n=len(o); cut=n//2
    sig=sigfn(c)                      # 信号只用close, 无前视
    a,b=(cut,n) if half=='second' else (0,cut)
    out=[]; i=a; s=0
    while i<b-1:
        if sig[i]==0: i+=1; continue
        d=sig[i]; ep=o[i+1]           # open[t+1]成交
        sp=ep*(1-stop*d); tp=ep*(1+stop*R*d)
        j=i+1; res=None
        while j<b:
            if d>0:
                if l[j]<=sp: res=-1.0; break
                if h[j]>=tp: res=R; break
            else:
                if h[j]>=sp: res=-1.0; break
                if l[j]<=tp: res=R; break
            if j+1<b and sig[j+1]==-d: res=(o[j+1]/ep-1)*d/stop; break   # 翻转平仓
            j+=1
        if res is None: res=(o[min(j,b-1)]/ep-1)*d/stop
        out.append(res-2*cost/stop)   # 成本占风险 = 2*cost/stop
        i=max(j,i+1)
    return np.array(out), (b-a)

def sig_brk20(c):
    s=np.zeros(len(c)); hh=pd.Series(c).rolling(20).max().values; ll=pd.Series(c).rolling(20).min().values
    s[20:]=np.where(c[20:]>hh[:-20],1,np.where(c[20:]<ll[:-20],-1,0))
    return np.where(np.isnan(s),0,s)
def sig_mom240(c):
    s=np.zeros(len(c)); s[240:]=np.sign(c[240:]/c[:-240]-1); return s
def sig_ma200(c):
    ma=pd.Series(c).rolling(200).mean().values
    s=np.where(c>ma,1,-1); s[:200]=0; return np.where(np.isnan(s),0,s)

print('='*94)
print('第一步  时间外推后的真实 R 序列 (只用后半段, 从未参与任何选择)')
print('='*94)
print(f'{"策略":<12}{"品种数":>8}{"总笔数":>10}{"E(R)":>12}{"品种级t":>10}{"E>0比例":>10}')
pool={}
for name,fn in [('brk20',sig_brk20),('mom240',sig_mom240),('ma200',sig_ma200)]:
    per=[];  seqs=[]
    for sym in ALL13:
        R_,bars=gen_R(sym,fn)
        if len(R_)<30: continue
        per.append(R_.mean()); seqs.append(R_)
    per=np.array(per)
    t=per.mean()/(per.std(ddof=1)/np.sqrt(len(per)))
    pool[name]=seqs
    print(f'{name:<12}{len(per):>8}{sum(len(x) for x in seqs):>10}{per.mean():>12.4f}{t:>10.2f}{np.mean(per>0):>10.1%}')

print()
print('='*94)
print('第二步  收割制(不复利)模拟: 固定注 + 净值翻倍即收割 + 20%爆仓线')
print('='*94)
print('目标 = P(爆仓前累计提取 >= 本金)   [本金1万, 每笔风险f*C0, 不做复利]')

def harvest(seqs, f, T=1.0, C0=10000, ruin=0.2, N=3000, B=2000):
    allR=np.concatenate(seqs)
    allR=allR[np.isfinite(allR)]
    if len(allR)<50: return None
    ok=0; tot=[]; ruined=0
    draws=rng.choice(allR,size=(B,N),replace=True)
    for b in range(B):
        W=C0; ext=0.0; dead=False
        for k in range(N):
            if W<=ruin*C0: dead=True; break
            bet=min(f*C0, W)
            W+=bet*draws[b,k]
            if W>=C0*(1+T):
                ext+=W-C0; W=C0
        if ext>=C0: ok+=1
        if dead: ruined+=1
        tot.append(ext+max(W,0)-C0)
    return ok/B, np.median(tot), ruined/B

print(f'\n{"策略":<10}{"仓位f":>8}{"P(赚回本金)":>14}{"最终盈亏中位":>14}{"爆仓率":>10}')
for name in pool:
    for f in [0.01,0.02,0.03]:
        r=harvest(pool[name], f)
        if r: print(f'{name:<10}{f:>8.1%}{r[0]:>14.1%}{r[1]:>14.0f}{r[2]:>10.1%}')

print()
print('='*94)
print('对照  同样结构下, 若真实 E=0 (把序列中心化) —— 几何白送的成功率有多少')
print('='*94)
for name in pool:
    seqs=[s-s.mean() for s in pool[name]]     # 强制零期望
    for f in [0.02]:
        r=harvest(seqs, f)
        if r: print(f'{name:<10}{f:>8.1%}{r[0]:>14.1%}{r[1]:>14.0f}{r[2]:>10.1%}')
