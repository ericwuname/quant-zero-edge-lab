import numpy as np, pandas as pd
FILES={'DOGE':'/data/inputs/DOGEUSDT_1h.csv','DOT':'/data/inputs/DOTUSDT_1h.csv',
       'CRV':'/data/inputs/CRVUSDT_1h.csv','DASH':'/data/inputs/DASHUSDT_1h.csv',
       'ETH':'/data/inputs/ETHUSDT_1h.csv','FIL':'/data/inputs/FILUSDT_1h.csv',
       'HBAR':'/data/inputs/HBARUSDT_1h.csv'}
print("="*96)
print("【IC 显著性】h=1 的反转效应: 是否统计显著? 能否覆盖成本?")
print("="*96)
print(f"  {'品种':<7}{'IC(h=1)':>10}{'N':>9}{'t=IC*sqrt(N)':>14}{'1bar波动(bp)':>13}{'预期收益(bp)':>13}")
print("  "+"-"*66)
ics=[];ts=[];gains=[]
for k,p in FILES.items():
    d=pd.read_csv(p);c={x.lower():x for x in d.columns}
    cl=d[c['close']].values.astype(float);n=len(cl)
    L=n-1-5
    sig=cl[5:5+L]/np.maximum(cl[0:L],1e-9)-1
    fut=cl[6:6+L]/np.maximum(cl[5:5+L],1e-9)-1
    m=np.isfinite(sig)&np.isfinite(fut)&(np.abs(sig)>1e-12)
    ic=np.corrcoef(sig[m],fut[m])[0,1]
    N=m.sum(); t=ic*np.sqrt(N)
    # 1bar波动
    r=np.diff(cl)/np.maximum(cl[:-1],1e-9)
    vol=np.std(r)*1e4
    gain=abs(ic)*vol   # 每bar预期收益bp (若正确利用方向)
    ics.append(ic);ts.append(t);gains.append(gain)
    print(f"  {k:<7}{ic:>+10.4f}{N:>9}{t:>+14.2f}{vol:>13.1f}{gain:>13.2f}")
print(f"  {'均值':<7}{np.mean(ics):>+10.4f}{'':>9}{np.mean(ts):>+14.2f}{'':>13}{np.mean(gains):>13.2f}")
print(f"\n  7/7品种IC为负 -> 若随机, 概率=(1/2)^7={0.5**7*100:.2f}%  => 一致性很强")
print(f"  但品种间非独立(同为crypto), 实际显著性弱于该值")
print(f"\n  【经济可行性】")
print(f"  每bar预期毛收益: {np.mean(gains):.2f} bp")
for c in [2,1,0.5]:
    cost=2*c
    print(f"    成本 {c}bp单边(往返{cost}bp): 净 = {np.mean(gains)-cost:+.2f} bp/bar -> "
          f"{'可行' if np.mean(gains)>cost else '不可行'}")
print(f"\n  => 即使统计显著, 毛收益({np.mean(gains):.2f}bp) < 最低往返成本(1bp) * 2 = 2bp")
print(f"     且需每bar换手, 实际滑点远高于理论")
