"""
实例化交易世界 v3 —— 加入容量约束(反身性的刹车)
======================================================
【v2 的失败原因】
  趋势者财富冲到157/200 -> 垄断 -> 价格被它主导 -> 自证预言 -> AC(1)=+0.26
  这是【反身性的失控】: 策略成功->资金涌入->价格被主导->更成功

【真实市场靠什么阻止这个? —— 容量约束】
  1. 冲击成本: 资金越大, 同样需求的边际价格影响递减 (流动性有限)
  2. 策略拥挤: 越多人用同一策略, 该策略的edge越薄
  3. 财富不能无限集中 (现实中大型策略会被迫降低仓位)

【v3 加入三个刹车】
  1. 冲击成本: wealth_eff = wealth^gamma (gamma<1, 边际递减)
  2. 拥挤衰减: 某类型占比越高, 其信号有效性越低
  3. 价格水平锚定: 防止指数爆炸 (真实市场有估值约束)

【目标】
  |AC(1)| < 0.10, 峰度>3, |r|AC(1)>0.05, 无类型垄断
"""
import numpy as np
from scipy import stats


class WorldV3:
    def __init__(self, seed=0, params=None):
        self.p = params or self.default_params()
        self.rng = np.random.default_rng(seed)
        self.value = self.p['p0']

    @staticmethod
    def default_params():
        return dict(
            p0=100.0, n_agents=300, init_wealth=1.0,
            frac_fund=0.20, frac_trend=0.20, frac_contra=0.20,
            frac_mm=0.15, frac_noise=0.25,
            fund_speed=0.15,        # 基本面: 收紧(更强锚定)
            fund_value_vol=0.006,
            trend_lbs=(5, 20, 60), trend_scale=0.06,
            contra_lb=10, contra_scale=0.04, contra_thresh=0.015,
            mm_scale=0.02, noise_vol=1.0,
            beta=0.0009,            # 降低
            shock_vol=0.010,        # 提高噪声占比
            evol_speed=0.05,
            # --- 三个刹车 ---
            gamma=0.5,              # 冲击成本: 有效财富 = wealth^gamma
            crowd_penalty=1.5,      # 拥挤衰减强度
            anchor=0.002,           # 价格水平锚定(对数价格向价值回复)
        )

    def setup(self):
        p = self.p
        n = p['n_agents']
        nf = int(n * p['frac_fund']); nt = int(n * p['frac_trend'])
        nc = int(n * p['frac_contra']); nm = int(n * p['frac_mm'])
        nn = n - nf - nt - nc - nm
        self.kinds = np.array(['fund']*nf + ['trend']*nt + ['contra']*nc
                              + ['mm']*nm + ['noise']*nn)
        self.wealth = np.ones(n) * p['init_wealth']

    def demand(self, price, hist):
        p = self.p; rng = self.rng; kinds = self.kinds
        n = len(kinds); d = np.zeros(n)

        m = kinds == 'fund'
        if m.sum():
            dev = (self.value - price) / max(price, 1e-9)
            d[m] = np.tanh(dev / p['fund_speed'])

        m = kinds == 'trend'
        if m.sum() and len(hist) >= max(p['trend_lbs']):
            sig = np.zeros(m.sum())
            for lb in p['trend_lbs']:
                if len(hist) >= lb:
                    mom = price / max(hist[-lb], 1e-9) - 1.0
                    sig += np.tanh(mom / p['trend_scale'])
            d[m] = sig / len(p['trend_lbs'])

        m = kinds == 'contra'
        if m.sum() and len(hist) >= p['contra_lb']:
            mom = price / max(hist[-p['contra_lb']], 1e-9) - 1.0
            if abs(mom) > p['contra_thresh']:
                d[m] = -np.tanh(mom / p['contra_scale'])

        m = kinds == 'mm'
        if m.sum() and len(hist) >= 5:
            dev = (hist[-5:].mean() - price) / max(price, 1e-9)
            d[m] = np.tanh(dev / p['mm_scale'])

        m = kinds == 'noise'
        if m.sum():
            d[m] = rng.normal(0, p['noise_vol'], m.sum())
        return d

    def run(self, n_steps=10000, true_drift=0.0, trend_strength=0.0,
            mean_revert_strength=0.0, record_every=50):
        p = self.p; rng = self.rng
        self.setup()
        kinds = self.kinds; n = len(kinds)

        price = p['p0']; hist = [price]; prices = [price]
        prev_d = np.zeros(n); wealth_hist = []
        trend_comp = 0.0

        for t in range(n_steps):
            self.value *= (1 + rng.normal(0, p['fund_value_vol']))

            if trend_strength > 0:
                trend_comp = 0.98 * trend_comp + 0.02 * rng.normal(0, 1)
            else:
                trend_comp = 0.0

            d = self.demand(price, np.array(hist))

            # --- 刹车1: 冲击成本 (财富边际递减) ---
            w_eff = np.power(np.maximum(self.wealth, 1e-6), p['gamma'])

            # --- 刹车2: 拥挤衰减 (某类型占比越高, 信号越无效) ---
            shares = {}
            for k in ['fund', 'trend', 'contra', 'mm', 'noise']:
                mk = kinds == k
                shares[k] = w_eff[mk].sum() / max(w_eff.sum(), 1e-9)
            crowd = np.zeros(n)
            for k in ['fund', 'trend', 'contra', 'mm']:
                crowd[kinds == k] = 1.0 / (1.0 + p['crowd_penalty'] * max(shares[k] - 0.2, 0))
            crowd[kinds == 'noise'] = 1.0

            w_final = w_eff * crowd
            net_d = (d * w_final).sum() / max(w_final.sum(), 1e-9)

            # --- 价格更新 ---
            shock = rng.normal(0, p['shock_vol'])
            # 刹车3: 对数价格锚定
            anchor_r = -p['anchor'] * np.log(price / self.value) if price > 0 else 0
            struct = trend_strength * trend_comp
            if mean_revert_strength > 0 and len(hist) >= 50:
                struct += mean_revert_strength * (-(price / np.mean(hist[-50:]) - 1))
            r = p['beta'] * net_d * 50 + true_drift + struct + anchor_r + shock
            price = max(price * (1 + r), 1e-6)
            prices.append(price); hist.append(price)
            if len(hist) > 300:
                hist.pop(0)

            # 演化
            gains = prev_d * r * n
            self.wealth = self.wealth + p['evol_speed'] * gains
            self.wealth = np.maximum(self.wealth, 0.2 * p['init_wealth'])
            tw = self.wealth.sum()
            if tw > 0:
                self.wealth = self.wealth / tw * (n * p['init_wealth'])
            prev_d = d

            if t % record_every == 0:
                wealth_hist.append([self.wealth[kinds == k].sum()
                                    for k in ['fund', 'trend', 'contra', 'mm', 'noise']])

        return np.array(prices), np.array(wealth_hist), kinds


def facts(prices):
    r = np.diff(prices) / prices[:-1]
    r = r[np.isfinite(r)]
    if len(r) < 500:
        return None
    ar = np.abs(r)
    def ac(x, k):
        return np.corrcoef(x[:-k], x[k:])[0, 1] if len(x) > k + 10 else np.nan
    def vr(k):
        v1 = r.var()
        if v1 <= 0 or len(r) < k*20:
            return np.nan
        return np.array([r[i:i+k].sum() for i in range(0, len(r)-k, k)]).var() / (k*v1)
    return dict(n=len(r), mean=r.mean()*1e4, vol=r.std()*1e4,
                kurt=stats.kurtosis(r)+3.0,
                ac1=ac(r,1), ac5=ac(r,5), ac20=ac(r,20),
                aac1=ac(ar,1), aac5=ac(ar,5),
                vr5=vr(5), vr20=vr(20))


print("="*100)
print("实例化交易世界 v3 —— 容量约束(冲击成本+拥挤衰减+锚定)")
print("="*100)

results = []
for label, cfg in [("① 纯生态", {}),
                   ("② 趋势成分", dict(trend_strength=0.006)),
                   ("③ 均值回归", dict(mean_revert_strength=0.03))]:
    w = WorldV3(seed=42)
    prices, wh, kinds = w.run(n_steps=12000, **cfg)
    res = facts(prices)
    ok1 = abs(res['ac1']) < 0.10
    ok2 = res['kurt'] > 3.0
    ok3 = res['aac1'] > 0.03
    last = wh[-1]
    maxshare = max(last) / sum(last)
    ok4 = maxshare < 0.50          # 无垄断
    print(f"\n  【{label}】")
    print(f"    均值 {res['mean']:>7.2f}bp  波动 {res['vol']:>7.1f}bp  峰度 {res['kurt']:>6.2f} "
          f"{'✓' if ok2 else '✗'}")
    print(f"    收益AC(1) {res['ac1']:>+7.4f} {'✓' if ok1 else '✗'}   "
          f"AC(5/20) {res['ac5']:>+7.4f}/{res['ac20']:>+7.4f}")
    print(f"    |r|AC(1)  {res['aac1']:>+7.4f} {'✓' if ok3 else '✗'}   "
          f"|r|AC(5) {res['aac5']:>+7.4f}")
    print(f"    方差比(5/20) {res['vr5']:>6.3f}/{res['vr20']:>6.3f}")
    print(f"    终局占比: 基本面{last[0]:.1f} 趋势{last[1]:.1f} 反转{last[2]:.1f} "
          f"做市{last[3]:.1f} 噪声{last[4]:.1f}   最大占比{maxshare*100:.1f}% "
          f"{'✓无垄断' if ok4 else '✗垄断'}")
    results.append((label, ok1 and ok2 and ok3 and ok4))

print("\n"+"="*100)
for lb, ok in results:
    print(f"  {lb}: {'✓ 合格' if ok else '✗ 不合格'}")
print(f"\n  世界可用性: {'✓ 可用于校准' if all(o for _,o in results) else '✗ 继续标定'}")
print("="*100)
