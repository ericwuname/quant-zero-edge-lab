"""
【下一步 v2】分散化能否跨过检测门槛? (修正版)
==================================================
【v1 的发现与缺陷】
  缺陷: 固定策略mom_20在植入结构上不赚钱 -> 单市场夏普为负
        -> 分散化只让负夏普更负 (无参考价值)

  但v1意外暴露了一个【重要真相】:
    无edge世界的组合夏普随N单调恶化: -0.95 -> -3.42
    原因: 成本造成【负均值】, 分散化让波动按1/√N下降,
          但负均值不变 -> 夏普 = 负均值/(波动/√N) = -√N × 常数
    => 没有真edge时, 分散化让你【更确定地亏】, 不是更安全!

【v2 修正】
  1. 先扫描植入强度, 找到【单市场净夏普为正但<0.673】的参数
  2. 用该强度, 验证组合夏普是否按 √N 增长并跨过门槛
  3. 同时报告【毛夏普】(扣成本前) 与【净夏普】(扣成本后)
     -> 分离"结构强度"与"成本拖累"
  4. 关键对照: 无edge世界 (验证分散化不凭空造正夏普)

【这直接回答】
  跨市场分散能否让弱edge变得可检测? 需要多少个市场?
"""
import numpy as np
import pandas as pd
from scipy import stats
import sys
sys.path.insert(0, '/data/workspace/brick')
from world_v5 import World

DAYS_YR = 365
COST_BP = 10
CRITICAL_SHARPE = 0.673


def build_signals(prices):
    T = len(prices) - 1
    P = prices[:T]
    S = {}
    for w in [5, 10, 20, 60, 120]:
        if T > w + 1:
            mom = np.zeros(T)
            mom[w:] = P[w:] / np.maximum(P[:-w], 1e-9) - 1
            S[f'mom_{w}'] = np.sign(mom)
    return S


def backtest(sig, r, cost_bp):
    T = len(r)
    pnl = np.zeros(T)
    pnl[:-1] = sig[:-1] * r[1:]
    if cost_bp > 0:
        turn = np.abs(np.diff(np.concatenate([[0.0], sig])))
        pnl = pnl - turn * (2 * cost_bp / 1e4)
    return pnl


def sharpe(x):
    s = x.std()
    return x.mean() / s * np.sqrt(DAYS_YR) if s > 1e-12 else 0.0


print("=" * 100)
print("【下一步 v2】分散化能否跨过检测门槛? (修正版)")
print("=" * 100)

# ---------- 步骤1: 找"单市场正夏普但低于门槛"的强度 ----------
print(f"\n【步骤1】扫描植入强度, 找单市场净夏普为正但 < {CRITICAL_SHARPE} 的参数")
print(f"  {'强度':>7}{'策略':>10}{'毛夏普':>10}{'净夏普':>10}{'判定':>16}")

N_STEPS = 6000
candidates = []
for ts in [0.010, 0.020, 0.030, 0.040, 0.060]:
    w = World(seed=6000, beta=0.0005)
    prices, wh, kinds = w.run(n_steps=N_STEPS, trend_strength=ts)
    r = np.diff(prices) / np.maximum(prices[:-1], 1e-9)
    T = len(r); sp = T // 2
    S = build_signals(prices)
    for strat in ['mom_20', 'mom_60', 'mom_120']:
        if strat not in S:
            continue
        gross = backtest(S[strat], r, 0)
        net = backtest(S[strat], r, COST_BP)
        sh_g = sharpe(gross[sp:])
        sh_n = sharpe(net[sp:])
        ok = 0.02 < sh_n < CRITICAL_SHARPE
        if ok:
            candidates.append((ts, strat, sh_n))
        if ts in [0.020, 0.040, 0.060] or ok:
            print(f"  {ts:>7.3f}{strat:>10}{sh_g:>10.3f}{sh_n:>10.3f}"
                  f"{('✓候选' if ok else ''):>16}")

if not candidates:
    print("\n  ⚠ 未找到'正但低于门槛'的参数, 用相对最优的继续")
    # 用扫描里最高的
    candidates = [(0.040, 'mom_60', 0.0)]

ts_use, strat_use, sh_single = max(candidates, key=lambda x: x[2])
print(f"\n  选用: 强度={ts_use}, 策略={strat_use}, 单市场净夏普={sh_single:.3f}")

# ---------- 步骤2: 生成独立世界, 测组合夏普 vs N ----------
M = 40
print(f"\n【步骤2】生成 {M} 个独立世界, 用固定策略 {strat_use}")
print(f"  (强度={ts_use}, 单市场净夏普目标={sh_single:.3f}, 门槛={CRITICAL_SHARPE})")

def make(ts, m, seed0):
    out = []
    for i in range(m):
        w = World(seed=seed0 + i, beta=0.0005)
        prices, wh, kinds = w.run(n_steps=N_STEPS, trend_strength=ts)
        out.append(prices)
    return out

worlds_e = make(ts_use, M, 7000)
worlds_n = make(0.0, M, 8000)
print(f"  ✓ 完成")

def oos(worlds, strat):
    out_g, out_n = [], []
    for prices in worlds:
        r = np.diff(prices) / np.maximum(prices[:-1], 1e-9)
        T = len(r); sp = T // 2
        S = build_signals(prices)
        if strat not in S:
            continue
        g = backtest(S[strat], r, 0)
        n = backtest(S[strat], r, COST_BP)
        out_g.append(g[sp:]); out_n.append(n[sp:])
    return out_g, out_n

pg_e, pn_e = oos(worlds_e, strat_use)
pg_n, pn_n = oos(worlds_n, strat_use)

if len(pn_e) >= 10:
    mat = np.corrcoef(np.array(pn_e[:15]))
    off = mat[~np.eye(len(mat), dtype=bool)]
    print(f"  市场间相关性: {off.mean():+.4f} {'✓独立' if abs(off.mean())<0.05 else '✗相关'}")

print(f"\n  【核心】组合净夏普 vs 市场数 N")
print(f"  {'N':>5}{'有edge(净)':>13}{'有edge(毛)':>13}{'无edge(净)':>13}"
      f"{'理论√N':>10}{'判定':>12}")
Ns = [1, 2, 3, 5, 8, 12, 16, 20, 25, 30, 35, 40]
sr1 = np.mean([sharpe(p) for p in pn_e])
rows = []
for N in Ns:
    if N > len(pn_e):
        break
    ce = np.mean(pn_e[:N], axis=0)
    cg = np.mean(pg_e[:N], axis=0)
    cn = np.mean(pn_n[:N], axis=0)
    she, shg, shn = sharpe(ce), sharpe(cg), sharpe(cn)
    theo = sr1 * np.sqrt(N)
    rows.append((N, she, shg, shn))
    print(f"  {N:>5}{she:>13.3f}{shg:>13.3f}{shn:>13.3f}{theo:>10.3f}"
          f"{('★跨过' if she>CRITICAL_SHARPE else ''):>12}")

# ---------- 关键对照 ----------
print(f"\n  【关键对照】分散化是否凭空造正夏普?")
if rows:
    print(f"    有edge  N={rows[-1][0]}: 净夏普 {rows[-1][1]:+.3f}")
    print(f"    无edge  N={rows[-1][0]}: 净夏普 {rows[-1][3]:+.3f}")
    print(f"    -> 无edge世界分散化后夏普【更负】(成本负均值被放大)")
    print(f"    -> {'✓ 分散化只放大真结构, 不凭空造edge' if rows[-1][1] > rows[-1][3] else '✗ 异常'}")

# ---------- 需要多少市场 ----------
print(f"\n  【推算】跨过门槛需要多少个独立市场?")
if sr1 > 0:
    N_need = (CRITICAL_SHARPE / sr1) ** 2
    print(f"    单市场平均净夏普: {sr1:.3f}")
    print(f"    理论需要 N = ({CRITICAL_SHARPE}/{sr1:.3f})² = {N_need:.1f} 个")
Ns_a = np.array([r[0] for r in rows])
shs = np.array([r[1] for r in rows])
crit_N = None
for i in range(len(shs) - 1):
    if shs[i] < CRITICAL_SHARPE <= shs[i + 1]:
        f = (CRITICAL_SHARPE - shs[i]) / (shs[i + 1] - shs[i])
        crit_N = Ns_a[i] + f * (Ns_a[i + 1] - Ns_a[i])
        break
if crit_N:
    print(f"    实测插值: 约 {crit_N:.0f} 个独立市场")
elif shs.max() < CRITICAL_SHARPE:
    print(f"    实测: {Ns_a.max()}个市场内未跨过 (最大夏普 {shs.max():.3f})")
    print(f"    -> 需要 > {Ns_a.max()} 个市场, 或单市场edge更强")

# ---------- 真实crypto ----------
print(f"\n  【真实数据】crypto 有效独立市场数")
for N_r, rho in [(7, 0.497), (20, 0.497), (50, 0.1), (50, 0.0)]:
    ne = N_r / (1 + (N_r - 1) * rho)
    print(f"    {N_r:>2}个市场, ρ={rho:.2f} -> 有效独立市场 {ne:>5.2f} "
          f"(上限 1/ρ = {1/rho if rho>0 else float('inf'):.1f})")

print("\n" + "=" * 100)
print("完成")
print("=" * 100)
