import numpy as np, pandas as pd
FILES={'DOGE':'/data/inputs/DOGEUSDT_1h.csv','DOT':'/data/inputs/DOTUSDT_1h.csv',
       'CRV':'/data/inputs/CRVUSDT_1h.csv','DASH':'/data/inputs/DASHUSDT_1h.csv',
       'ETH':'/data/inputs/ETHUSDT_1h.csv','FIL':'/data/inputs/FILUSDT_1h.csv',
       'HBAR':'/data/inputs/HBARUSDT_1h.csv'}
def load():
    o={}
    for k,p in FILES.items():
        d=pd.read_csv(p);c={x.lower():x for x in d.columns}
        o[k]=dict(open=d[c['open']].values.astype(float),high=d[c['high']].values.astype(float),
                  low=d[c['low']].values.astype(float),close=d[c['close']].values.astype(float))
    return o
def s_mom(cl,w):
    n=len(cl);s=np.zeros(n);s[w:]=np.sign(cl[w:]/np.maximum(cl[:-w],1e-9)-1);return s
def s_brk(cl,w):
    n=len(cl);s=np.zeros(n)
    for i in range(w,n):
        h=cl[i-w:i].max();l=cl[i-w:i].min()
        if cl[i]>h:s[i]=1
        elif cl[i]<l:s[i]=-1
    return s
def run(D,sg,s,R,cost_bp,slip_bp,max_hold,start,end,mode):
    op,hi,lo,cl=D['open'],D['high'],D['low'],D['close']
    n=len(cl) if end is None else min(end,len(cl))
    cR=2*cost_bp/1e4/s; slipR=slip_bp/1e4/s; stopd=s+slip_bp/1e4
    net=[];i=max(start,120)
    while i<n-3:
        d=1 if sg[i]>0 else (-1 if sg[i]<0 else 0)
        if d==0:i+=1;continue
        e=op[i+1];i0=i+1;out=None;j=i0
        for jj in range(i0,min(i0+max_hold,n)):
            adv=(lo[jj]/e-1) if d==1 else (1-hi[jj]/e)
            fav=(hi[jj]/e-1) if d==1 else (1-lo[jj]/e)
            if adv<=-stopd: out=-1.0-slipR;j=jj;break
            if fav>=R*s: out=R;j=jj;break
            if mode=='flip' and sg[jj]*d<0: out=((cl[jj]/e-1)*d)/s;j=jj;break
        if out is None:
            j=min(i0+max_hold,n-1);out=((cl[j]/e-1)*d)/s
        net.append(out-cR);i=j+1
    return np.array(net)

data=load()
print("="*104)
print("【验证你的洞察】复利走向幻灭: 算术期望 vs 几何期望")
print("="*104)
print("  核心: 几何增长率 g ≈ f·E[R] − (f·σ)²/2")
print("        若 f·E[R] > 0 但 < (f·σ)²/2  =>  '看起来赚' 但复利必归零")

# 生成交易序列
seqs={}
for nm,fn in [('brk20_flip',lambda c:s_brk(c,20)),('mom20_flip',lambda c:s_mom(c,20)),
              ('brk20_target',lambda c:s_brk(c,20))]:
    mode='flip' if 'flip' in nm else 'target'
    alln=[]
    for k,D in data.items():
        n=len(D['close'])
        nt=run(D,fn(D['close']),0.05,2.0,2,5,800,n//2,n,mode)
        if len(nt)>=30: alln.append(nt)
    seqs[nm]=np.concatenate(alln)

print(f"\n  {'序列':<14}{'N':>7}{'E[R](算术)':>12}{'σ_R':>8}{'E[ln]实际':>11}{'波动拖累(fσ)²/2':>16}{'判定':>22}")
print("  "+"-"*92)
for nm,R in seqs.items():
    f=0.01
    mu=R.mean(); sd=R.std()
    # 实际几何增长率(用f=1%)
    g_act=np.log(1+f*R).mean()
    drag=(f*sd)**2/2
    arith=f*mu
    verdict=''
    if arith>0 and g_act<0: verdict='算术正但复利归零★'
    elif arith>0: verdict='复利正'
    else: verdict='算术负'
    print(f"  {nm:<14}{len(R):>7}{mu:>+12.4f}{sd:>8.3f}{g_act:>+11.5f}{drag:>16.6f}{verdict:>22}")

print(f"\n  【关键】brk20_flip 算术 E[R]={seqs['brk20_flip'].mean():+.4f} (正)")
print(f"         但 f=1% 时几何 E[ln(1+fR)]={np.log(1+0.01*seqs['brk20_flip']).mean():+.6f}")
print(f"         -> 复利增长率{'为负' if np.log(1+0.01*seqs['brk20_flip']).mean()<0 else '为正'}, "
      f"长期{'必然归零' if np.log(1+0.01*seqs['brk20_flip']).mean()<0 else '增长'}")

# 临界仓位
print(f"\n  【临界仓位 f*】使 g=0 的最大仓位 (超过则复利归零)")
print(f"  {'序列':<14}{'f*':>10}{'说明':>40}")
print("  "+"-"*64)
for nm,R in seqs.items():
    mu=R.mean();sd=R.std()
    if mu>0:
        # g ≈ f*mu - (f*sd)^2/2 = 0 => f* = 2*mu/sd^2
        fstar=2*mu/(sd**2)
        print(f"  {nm:<14}{fstar*100:>9.2f}%   超过此仓位复利即归零")
    else:
        print(f"  {nm:<14}{'N/A':>10}   算术期望<=0,任何仓位都归零")
print("\n"+"="*104)
