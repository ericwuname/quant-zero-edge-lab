"""
【第二层验证】成本敏感性 + 路径风险 + 滚动前瞻
==========================================================
【待验证三件事】
  1. 成本敏感性: 2bp(maker) -> 10bp(taker), E是否变负?
  2. 路径风险:  胜率仅20~24%, 连亏期能否扛过?
                - 最大连亏次数
                - 账户级最大回撤 (按仓位算)
                - 破产/触及"被迫停止"阈值的概率
  3. 滚动前瞻:  不只切一刀, 用滚动窗口逐年验证

【关键: 账户级模拟】
  之前算的是【每笔E】, 但真正决定生死的是【账户净值路径】
  胜率23% -> 连亏常态 -> 若仓位不当, 正期望也会被路径杀死(遍历性!)

【破产风险计算】
  固定分数仓位 f, 初始10000
  逐笔更新净值, 记录:
    - 最大连亏
    - 最大回撤
    - 是否跌破 50%(心理阈值) / 20%(实际放弃阈值)
"""
import numpy as np
import pandas as pd
from scipy import stats

HOURLY = {'DOGE': '/data/inputs/DOGEUSDT_1h.csv',
          'DOT':  '/data/inputs/DOTUSDT_1h.csv',
          'CRV':  '/data/inputs/CRVUSDT_1h.csv',
          'DASH': '/data/inputs/DASHUSDT_1h.csv'}


def load():
    out = {}
    for k, p in HOURLY.items():
        d = pd.read_csv(p)
        out[k] = d['close'].values.astype(float)
    return out


def momentum_signal(px, w=60):
    n = len(px)
    sig = np.zeros(n)
    sig[w:] = np.sign(px[w:] / np.maximum(px[:-w], 1e-9) - 1)
    return sig


def run_trades(px, signal, risk, trail, cost_bp=2,
               max_hold=1000, seed=42, start=0, end=None):
    n = len(px) if end is None else min(end, len(px))
    rng = np.random.default_rng(seed)
    rets = []
    i = max(start, 60)
    while i < n - 2:
        s = signal[i]
        if s == 0:
            s = rng.choice([-1, 1])
        direction = 1 if s > 0 else -1
        entry = px[i]
        sl = entry * (1 - risk) if direction == 1 else entry * (1 + risk)
        peak = entry
        exit_i = None
        for j in range(i + 1, min(i + max_hold, n)):
            p = px[j]
            if direction == 1:
                if p > peak: peak = p
                if p <= sl: exit_i = j; break
                if p <= peak * (1 - trail): exit_i = j; break
            else:
                if p < peak: peak = p
                if p >= sl: exit_i = j; break
                if p >= peak * (1 + trail): exit_i = j; break
        if exit_i is None:
            exit_i = min(i + max_hold, n - 1)
        ret = (px[exit_i] / entry - 1) * direction
        ret -= 2 * cost_bp / 1e4
        rets.append(ret)
        i = exit_i + 1
    return np.array(rets)


def stats_of(rets):
    if len(rets) < 30:
        return None
    pw = (rets > 0).mean()
    aw = rets[rets > 0].mean() if (rets > 0).any() else 0
    al = -rets[rets < 0].mean() if (rets < 0).any() else 0
    E = rets.mean()
    t = E / (rets.std() / np.sqrt(len(rets))) if rets.std() > 0 else 0
    return dict(n=len(rets), win=pw, aw=aw, al=al, E_bp=E * 1e4, t=t,
                R=aw / al if al > 0 else 0)


def path_risk(rets, f, init=10000.0):
    """账户级路径风险
    f: 每笔风险占净值比例 (仓位 = f / risk_per_trade)
    """
    nav = np.empty(len(rets) + 1)
    nav[0] = init
    # 每笔的净值变化 = f * ret / risk  (ret是相对入场的收益)
    # 简化: 直接用 ret * f / 0.02 (以2%止损为基准的仓位换算)
    for i, rt in enumerate(rets):
        nav[i + 1] = nav[i] * (1.0 + rt * f / 0.02)
        if nav[i + 1] <= 0:
            nav[i + 1:] = 0
            break
    # 最大连亏
    max_consec = 0
    cur = 0
    for rt in rets:
        if rt < 0:
            cur += 1
            max_consec = max(max_consec, cur)
        else:
            cur = 0
    # 最大回撤
    pk = np.maximum.accumulate(nav)
    dd = -((nav - pk) / np.maximum(pk, 1e-12)).min() * 100
    # 阈值触及
    below50 = (nav < init * 0.5).any()
    below20 = (nav < init * 0.2).any()
    return dict(final=nav[-1], max_consec=max_consec, mdd=dd,
                below50=below50, below20=below20, nav=nav)


print("=" * 100)
print("【第二层验证】成本 + 路径风险 + 滚动前瞻")
print("=" * 100)

data = load()
RISK, TRAIL = 0.01, 0.05

# ---------- 1. 成本敏感性 ----------
print(f"\n  【1】成本敏感性 (risk={RISK*100:.0f}%, trail={TRAIL*100:.0f}%, 样本外)")
print(f"  {'品种':<7}" + "".join(f"{f'{c}bp':>16}" for c in [2, 5, 10, 20])
      + f"{'判定':>12}")
print("  " + "-" * 80)

for sym in ['DOGE', 'CRV', 'DOT', 'DASH']:
    px = data[sym]
    n = len(px); sp = n // 2
    sig = momentum_signal(px, 60)
    row = f"  {sym:<7}"
    Es = []
    for c in [2, 5, 10, 20]:
        rets = run_trades(px, sig, RISK, TRAIL, cost_bp=c, start=sp, end=n)
        s = stats_of(rets)
        if s:
            row += f"{s['E_bp']:>+10.1f}(t{s['t']:>+4.2f})"
            Es.append(s['E_bp'])
        else:
            row += f"{'—':>16}"
            Es.append(np.nan)
    ok = '全正' if all(e > 0 for e in Es if not np.isnan(e)) else \
         ('10bp变负' if Es[2] < 0 else '部分为负')
    row += f"{ok:>12}"
    print(row)

print(f"\n    -> 结论: 若 taker(10bp)下仍为正, 则执行方式不致命")

# ---------- 2. 路径风险 ----------
print(f"\n  【2】路径风险 —— 胜率仅20%, 能否扛过连亏? (初始10000)")
print(f"  {'品种':<7}{'仓位f':>7}{'笔数':>7}{'胜率':>8}{'最大连亏':>10}"
      f"{'最大回撤':>10}{'终值':>11}{'破50%':>8}{'破20%':>8}")
print("  " + "-" * 76)

for sym in ['DOGE', 'CRV', 'DOT', 'DASH']:
    px = data[sym]
    n = len(px); sp = n // 2
    sig = momentum_signal(px, 60)
    rets = run_trades(px, sig, RISK, TRAIL, cost_bp=2, start=sp, end=n)
    s = stats_of(rets)
    if s is None:
        continue
    for f in [0.01, 0.02, 0.05]:
        pr = path_risk(rets, f)
        print(f"  {sym:<7}{f*100:>6.0f}%{s['n']:>7}{s['win']*100:>7.1f}%"
              f"{pr['max_consec']:>10}{pr['mdd']:>9.1f}%"
              f"{pr['final']:>11.0f}"
              f"{('是' if pr['below50'] else '否'):>8}"
              f"{('是' if pr['below20'] else '否'):>8}")

print(f"\n    说明: 仓位f=每笔风险占净值1%/2%/5%")
print(f"    -> 关键看【最大连亏】与【破50%】: 前者是心理考验, 后者是放弃阈值")

# ---------- 3. 滚动前瞻 ----------
print(f"\n  【3】滚动前瞻 (每年用前2年选参数, 后1年验证)")
print(f"  {'品种':<7}{'年份':>7}{'笔数':>7}{'E(bp)':>10}{'t值':>8}{'判定':>10}")
print("  " + "-" * 56)

for sym in ['DASH', 'DOGE']:
    px = data[sym]
    n = len(px)
    sig = momentum_signal(px, 60)
    # 数据约6年, 按年切
    yr_len = n // 6
    for yi in range(2, 6):
        tr_end = yi * yr_len
        te_end = min((yi + 1) * yr_len, n)
        if te_end - tr_end < 500:
            continue
        # 样本内选
        best = None
        for rk in [0.005, 0.01, 0.02, 0.04]:
            for tr in [0.02, 0.05, 0.10]:
                r = run_trades(px, sig, rk, tr, start=max(0, tr_end - 2 * yr_len),
                               end=tr_end)
                s = stats_of(r)
                if s and (best is None or s['t'] > best[2]['t']):
                    best = (rk, tr, s)
        if best is None:
            continue
        rk_b, tr_b, s_in = best
        # 样本外
        r_oos = run_trades(px, sig, rk_b, tr_b, start=tr_end, end=te_end)
        s_oos = stats_of(r_oos)
        if s_oos is None:
            continue
        pv = '显著' if abs(s_oos['t']) > 1.96 else ('正' if s_oos['E_bp'] > 0 else '负')
        print(f"  {sym:<7}{2020+yi:>7}{s_oos['n']:>7}{s_oos['E_bp']:>+10.1f}"
              f"{s_oos['t']:>+8.2f}{pv:>10}")

print("\n" + "=" * 100)
print("完成")
print("=" * 100)
