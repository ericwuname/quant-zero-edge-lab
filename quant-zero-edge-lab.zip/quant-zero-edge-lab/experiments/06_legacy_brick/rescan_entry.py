# -*- coding: utf-8 -*-
"""全新入场逻辑重扫: 训练(OLD7) / 干净验证(NEW6) 严格分离"""
import sys, numpy as np, pandas as pd, warnings
sys.path.insert(0,'/data/workspace/brick')
warnings.filterwarnings('ignore')
from entry_lib import *

COST_BP = {'maker':0.0002, 'taker':0.0010}

def run_group(syms, cost_key='maker'):
    cost = COST_BP[cost_key]
    res = {}
    for sym in syms:
        df = load(sym); S = build_signals(df)
        o,h,l = df['open'].values, df['high'].values, df['low'].values
        for name, sig in S.items():
            if name.startswith('_'): continue
            r = backtest(sig, o, h, l, cost=cost)
            if len(r) < 50: continue
            res.setdefault(name, {})[sym] = r
    return res

def summarize(res, syms):
    rows = []
    for name, d in res.items():
        syms_ok = [s for s in syms if s in d]
        if len(syms_ok) < 4: continue
        pool = np.concatenate([d[s] for s in syms_ok])
        per = np.array([d[s].mean() for s in syms_ok])       # 每品种一个E
        # 池化t(乐观, 忽略品种内相关)
        t_pool = pool.mean()/(pool.std(ddof=1)/np.sqrt(len(pool)))
        # 跨品种t(保守, n=品种数)
        t_cross = per.mean()/(per.std(ddof=1)/np.sqrt(len(per))) if len(per)>1 else np.nan
        rows.append(dict(sig=name, n=len(pool), nsym=len(syms_ok),
                         E=pool.mean(), t_pool=t_pool,
                         E_cross=per.mean(), t_cross=t_cross,
                         pos=float((per>0).mean())))
    return pd.DataFrame(rows).sort_values('t_cross', ascending=False)

print('='*78)
print('第一批扫描: 完全干净验证集 NEW6 (TRX/UNI/XLM/XMR/XRP/ZEC) — 从未参与任何选择')
print('='*78)
r_new = run_group(NEW6, 'maker')
df_new = summarize(r_new, NEW6)
print('信号总数:', len(df_new))
print(df_new.head(15).to_string(index=False, float_format=lambda x: f'{x:9.4f}'))
print(' ... 尾部 ...')
print(df_new.tail(8).to_string(index=False, float_format=lambda x: f'{x:9.4f}'))

print()
print('='*78)
print('第二批扫描: 训练集 OLD7')
print('='*78)
r_old = run_group(OLD7, 'maker')
df_old = summarize(r_old, OLD7)
print(df_old.head(15).to_string(index=False, float_format=lambda x: f'{x:9.4f}'))

df_new.to_csv('/data/workspace/brick/scan_new6.csv', index=False)
df_old.to_csv('/data/workspace/brick/scan_old7.csv', index=False)
np.save('/data/workspace/brick/ok.npy', np.array([1]))
