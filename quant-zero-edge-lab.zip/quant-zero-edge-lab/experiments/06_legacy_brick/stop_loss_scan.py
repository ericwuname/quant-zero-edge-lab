"""
【止损维度】止损宽度 = 可控变量 —— 能否同时改善 频率 与 盈亏比?
======================================================================
【用户洞察】
  若盈亏比方向正确, 则【止损】是可控变量
  之前我固定 risk=2%, 从未扫描 -> 这是缺口

【核心假设】
  追踪止盈下, 盈亏比 ≈ trail / risk
  -> 缩小 risk 会【提高盈亏比】
  -> 同时缩小 risk 让止损更快被触及 -> 交易更快结束 -> 【提高笔数N】
  -> t ∝ sqrt(N) × E/σ  => 可能同时改善!

  但代价: risk 太小 -> 被噪声扫损 -> 胜率下降
  => 存在最优 risk, 需要扫描

【本轮新增: 严格样本外验证】(之前缺失)
  1. 前50% 样本内: 扫描 risk × trail 网格, 选最优(按t值)
  2. 后50% 样本外: 用该参数验证 -> 报告 E, t
  3. 参数平原: 输出整张网格, 看是"一片区域为正"还是"孤立尖峰"
     -> 平原=真结构, 尖峰=过拟合  【这是最重要的验证】
  4. 随机入场对照 (分离信号贡献)
  5. 多品种一致性
"""
import numpy as np
import pandas as pd
from scipy import stats

HOURLY = {'DOGE': '/data/inputs/DOGEUSDT_1h.csv',
          'DOT':  '/data/inputs/DOTUSDT_1h.csv',
          'CRV':  '/data/inputs/CRVUSDT_1h.csv',
          'DASH': '/data/inputs/DASHUSDT_1h.csv'}


def load():
    out = {}
    for k, p in HOURLY.items():
        d = pd.read_csv(p)
        out[k] = d['close'].values.astype(float)
    return out


def momentum_signal(px, w=60):
    n = len(px)
    sig = np.zeros(n)
    sig[w:] = np.sign(px[w:] / np.maximum(px[:-w], 1e-9) - 1)
    return sig


def run_trades(px, signal, risk, trail, cost_bp=2,
               max_hold=1000, seed=42, start=0, end=None):
    n = len(px) if end is None else min(end, len(px))
    rng = np.random.default_rng(seed)
    rets = []
    i = max(start, 60)
    while i < n - 2:
        s = signal[i]
        if s == 0:
            s = rng.choice([-1, 1])
        direction = 1 if s > 0 else -1
        entry = px[i]
        sl = entry * (1 - risk) if direction == 1 else entry * (1 + risk)
        peak = entry
        exit_i = None
        for j in range(i + 1, min(i + max_hold, n)):
            p = px[j]
            if direction == 1:
                if p > peak:
                    peak = p
                if p <= sl:
                    exit_i = j; break
                if p <= peak * (1 - trail):
                    exit_i = j; break
            else:
                if p < peak:
                    peak = p
                if p >= sl:
                    exit_i = j; break
                if p >= peak * (1 + trail):
                    exit_i = j; break
        if exit_i is None:
            exit_i = min(i + max_hold, n - 1)
        ret = (px[exit_i] / entry - 1) * direction
        ret -= 2 * cost_bp / 1e4
        rets.append(ret)
        i = exit_i + 1
    return np.array(rets)


def stats_of(rets):
    if len(rets) < 30:
        return None
    pw = (rets > 0).mean()
    aw = rets[rets > 0].mean() if (rets > 0).any() else 0
    al = -rets[rets < 0].mean() if (rets < 0).any() else 0
    E = rets.mean()
    t = E / (rets.std() / np.sqrt(len(rets))) if rets.std() > 0 else 0
    return dict(n=len(rets), win=pw, aw=aw, al=al, E_bp=E * 1e4, t=t,
                R=aw / al if al > 0 else 0)


print("=" * 100)
print("【止损维度】止损宽度扫描 + 严格样本外验证")
print("=" * 100)
print("  假设: 缩小止损 -> 提高盈亏比 且 提高交易频率 -> t值上升")
print("  代价: 太小会被噪声扫损 -> 胜率下降")
print("  新增: 前50%选参数, 后50%验证, 并输出参数平原")

data = load()
RISKS = [0.005, 0.01, 0.02, 0.04, 0.08]
TRAILS = [0.02, 0.05, 0.10]

print(f"\n  【A】样本内(前50%)参数平原 —— E(bp每笔) | t值")
print(f"      行=止损risk, 列=追踪trail    (品种: DOGE)")
sym = 'DOGE'
px = data[sym]
n = len(px); sp = n // 2
sig = momentum_signal(px, 60)

print("\n  risk\\trail    " + "".join(f"{f'{t*100:.0f}%':>18}" for t in TRAILS))
print("  " + "-" * 66)
grid_in = {}
for rk in RISKS:
    row = f"  {rk*100:>6.1f}%    "
    for tr in TRAILS:
        rets = run_trades(px, sig, rk, tr, start=0, end=sp)
        s = stats_of(rets)
        grid_in[(rk, tr)] = s
        if s:
            row += f"{s['E_bp']:>+8.1f}(t{s['t']:>+5.2f})"
        else:
            row += f"{'—':>18}"
    print(row)

print(f"\n  【B】样本外(后50%)用【样本内最优】参数验证")
best_in = None
for k, s in grid_in.items():
    if s and (best_in is None or abs(s['t']) > abs(best_in[1]['t'])):
        best_in = (k, s)
if best_in:
    (rk_b, tr_b), s_in = best_in
    print(f"    样本内最优: risk={rk_b*100:.1f}%, trail={tr_b*100:.0f}%  "
          f"(E={s_in['E_bp']:+.1f}bp, t={s_in['t']:+.2f}, N={s_in['n']})")
    rets_oos = run_trades(px, sig, rk_b, tr_b, start=sp, end=n)
    s_oos = stats_of(rets_oos)
    if s_oos:
        print(f"    样本外结果: E={s_oos['E_bp']:+.1f}bp, t={s_oos['t']:+.2f}, "
              f"N={s_oos['n']}, 胜率={s_oos['win']*100:.1f}%, 盈亏比={s_oos['R']:.2f}")
        print(f"    衰减: {s_oos['E_bp']/s_in['E_bp']*100 if s_in['E_bp']!=0 else 0:.0f}%")

print(f"\n  【C】样本外参数平原 (检验是'平原'还是'尖峰')")
print("  risk\\trail    " + "".join(f"{f'{t*100:.0f}%':>18}" for t in TRAILS))
print("  " + "-" * 66)
pos_cnt = 0; tot = 0
for rk in RISKS:
    row = f"  {rk*100:>6.1f}%    "
    for tr in TRAILS:
        rets = run_trades(px, sig, rk, tr, start=sp, end=n)
        s = stats_of(rets)
        if s:
            row += f"{s['E_bp']:>+8.1f}(t{s['t']:>+5.2f})"
            tot += 1
            if s['E_bp'] > 0:
                pos_cnt += 1
        else:
            row += f"{'—':>18}"
    print(row)
print(f"\n    样本外网格: {pos_cnt}/{tot} 个参数组合 E>0")
print(f"    -> {'✓参数平原(结构稳健)' if pos_cnt >= tot*0.6 else '⚠多为负(可能是尖峰/过拟合)'}")

print(f"\n  【D】多品种: 样本外 用统一参数(risk=1%, trail=5%)")
print(f"  {'品种':<7}{'笔数':>7}{'胜率':>8}{'盈亏比':>9}{'E(bp)':>10}{'t值':>8}"
      f"{'随机对照E':>11}{'差值':>9}")
print("  " + "-" * 70)
for sym2 in ['DOGE', 'CRV', 'DOT', 'DASH']:
    px2 = data[sym2]
    n2 = len(px2); sp2 = n2 // 2
    sg2 = momentum_signal(px2, 60)
    r_sig = run_trades(px2, sg2, 0.01, 0.05, start=sp2, end=n2)
    r_rnd = run_trades(px2, np.zeros(n2), 0.01, 0.05, start=sp2, end=n2)
    s1 = stats_of(r_sig); s2 = stats_of(r_rnd)
    if s1 and s2:
        print(f"  {sym2:<7}{s1['n']:>7}{s1['win']*100:>7.1f}%{s1['R']:>9.2f}"
              f"{s1['E_bp']:>+10.1f}{s1['t']:>+8.2f}{s2['E_bp']:>+11.1f}"
              f"{s1['E_bp']-s2['E_bp']:>+9.1f}")

print("\n" + "=" * 100)
print("完成")
print("=" * 100)
