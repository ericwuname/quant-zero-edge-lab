"""
砖块(格点)价格结构分析引擎
------------------------------------------------
目的：把连续价格投影成 ±1 砖块序列，检验：
  1. 市场"记忆"(自相关)是否可被测出
  2. 在成本 / 微观噪音 / 跳空下，这个测量还剩多少可信度
  3. 砖块大小 A 的可行域是否存在

注意：本脚本用【合成数据】校准显微镜本身。
      合成数据里我"植入"已知自相关，看框架能否检出。
      它不能证明真实市场有 edge —— 真实结论必须拿真实数据跑。
"""
import numpy as np
from scipy import stats

# ============================================================
# 1. 数据生成：控制"市场记忆"的强度 phi
#    对数收益 AR(1):  r_t = phi * r_{t-1} + eps_t
#    phi = 0    -> 纯随机游走(无记忆)
#    phi > 0    -> 动量/趋势惯性
#    phi < 0    -> 均值回归/反转
# ============================================================
def gen_prices(n, sigma, phi, seed, mu=0.0):
    rng = np.random.default_rng(seed)
    eps = rng.normal(0.0, sigma * np.sqrt(max(1e-12, 1 - phi ** 2)), n)
    r = np.zeros(n)
    for t in range(1, n):
        r[t] = phi * r[t - 1] + eps[t]
    r += mu
    return 100.0 * np.exp(np.cumsum(r)), r


def gen_regime(n, sigma, seed, p_trend=0.35):
    """regime切换: 趋势市(带漂移) 与 震荡市(反转) 交替 —— 更接近真实市场"""
    rng = np.random.default_rng(seed)
    r = np.zeros(n)
    state = 0
    for t in range(1, n):
        if rng.random() < 0.01:
            state = 1 - state
        if state == 1:                       # 趋势市: 弱动量
            r[t] = 0.05 * r[t - 1] + rng.normal(0, sigma)
        else:                                # 震荡市: 弱反转
            r[t] = -0.05 * r[t - 1] + rng.normal(0, sigma)
    return 100.0 * np.exp(np.cumsum(r)), r


# ============================================================
# 2. 砖块化引擎 (Renko 式格点跃迁)
#    区间 [lo, hi], 宽 A。触及上界 -> +1 砖, 新区间 [hi, hi+A]
#                        触及下界 -> -1 砖, 新区间 [lo-A, lo]
# ============================================================
def to_bricks(prices, A):
    """
    Renko 式格点跃迁 —— 修正版
    新区间始终以新 anchor 为中心: [anchor-A, anchor+A]
    即: 触及上界 -> +1砖, 新anchor=上界, 要再跌一整块A才反向
        (对应你说的 "101入场, 100止损", 回撤一整块才认输)
    """
    bricks = []
    anchor = float(prices[0])
    hi = anchor + A
    lo = anchor - A
    for p in prices[1:]:
        while True:
            if p >= hi:
                bricks.append(1)
                anchor = hi
                hi = anchor + A
                lo = anchor - A
            elif p <= lo:
                bricks.append(-1)
                anchor = lo
                hi = anchor + A
                lo = anchor - A
            else:
                break
    return np.array(bricks, dtype=np.int8)


# ============================================================
# 3. 统计量
# ============================================================
def runs_test(b):
    """游程检验: z<0 -> 游程偏少 -> 正自相关(趋势);  z>0 -> 反转"""
    n = len(b)
    if n < 10:
        return np.nan
    n1 = int((b == 1).sum())
    n2 = int((b == -1).sum())
    if n1 == 0 or n2 == 0:
        return np.nan
    runs = 1 + int((b[1:] != b[:-1]).sum())
    exp = 1.0 + 2.0 * n1 * n2 / n
    var = (2.0 * n1 * n2 * (2.0 * n1 * n2 - n1 - n2)) / ((n ** 2) * (n - 1))
    if var <= 0:
        return np.nan
    return (runs - exp) / np.sqrt(var)


def cont_prob(b):
    """延续概率 p = P(b_{i+1} == b_i)"""
    if len(b) < 3:
        return np.nan
    return float((b[1:] == b[:-1]).mean())


def cond_cont_prob(b, m):
    """P(延续 | 前面已经连续 m 块同向)  —— 形态条件概率扫描"""
    if len(b) < m + 3:
        return np.nan, 0
    same = np.ones(len(b) - 1, dtype=bool)
    for k in range(m):
        same &= (b[k + 1:len(b) - m + k] == b[k:len(b) - m - 1 + k]) if False else True
    # 直接构造: 位置 i 起连续 m+1 块同向?
    idx = []
    for i in range(len(b) - m - 1):
        seg = b[i:i + m + 1]
        if np.all(seg == seg[0]):
            idx.append(i + m)   # 下一块位置
    if len(idx) < 20:
        return np.nan, len(idx)
    nxt = b[np.array(idx)]
    prev = b[np.array(idx) - 1]
    return float((nxt == prev).mean()), len(idx)


def stats_block(b, c):
    """一次性给出关键判定量. c = 成本/A  (双边成本占砖块幅度比例)"""
    p = cont_prob(b)
    z = runs_test(b)
    n = len(b)
    pstar = (1.0 + c) / 2.0
    # 净期望(以 A 为单位):  E = (2p-1) - c
    net = (2 * p - 1) - c
    # 二项检验 H0: p = pstar
    win = int((b[1:] == b[:-1]).sum())
    N = len(b) - 1
    if N > 0 and 0 < pstar < 1:
        z_bin = (win / N - pstar) / np.sqrt(pstar * (1 - pstar) / N)
        pval = 1 - stats.norm.cdf(z_bin)
    else:
        z_bin, pval = np.nan, np.nan
    return dict(n_bricks=n, p_cont=p, z_runs=z, pstar=pstar,
                net=net, z_bin=z_bin, pval=pval)
