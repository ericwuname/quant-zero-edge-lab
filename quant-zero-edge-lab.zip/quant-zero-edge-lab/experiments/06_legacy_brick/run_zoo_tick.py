"""
策略动物园主实验: 加入策略后, 能不能"试出来"?
==================================================
10 个策略 x 4 个市场 x 3 种砖块大小 x 20 条路径
"""
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from zoo_tick import (gen_ticks, brick_events, cont_returns,
                      sig_const, sig_rev, make_mom, make_rev,
                      sig_stat, sig_stat_mom, run_single, run_combo,
                      run_meta, INIT_CAP, TICKS_PER_HOUR, HOURS_PER_YEAR)

plt.rcParams['font.sans-serif'] = ['WenQuanYi Micro Hei', 'DejaVu Sans']
plt.rcParams['axes.unicode_minus'] = False

N = 120000
ANN = 0.20
SIG = ANN / np.sqrt(TICKS_PER_HOUR * HOURS_PER_YEAR)
NPATH = 12
YEARS = N / (TICKS_PER_HOUR * HOURS_PER_YEAR)

MK = ['rw', 'trendvol', 'regime', 'strong']
MK_NAME = {'rw': '随机游走', 'trendvol': '趋势+波动', 'regime': '体制切换', 'strong': '强趋势'}

FNS = {
    '纯延续': sig_const,
    '纯反转': sig_rev,
    '动量2': make_mom(2),
    '动量3': make_mom(3),
    '反转2': make_rev(2),
    '反转3': make_rev(3),
    '统计双向': sig_stat,
    '统计只多': sig_stat_mom,
}
COMBO_FNS = [make_mom(2), make_mom(3), make_rev(2), make_rev(3)]
META_FNS = [sig_const, sig_rev, make_mom(2), make_rev(2)]

print("=" * 100)
print(f"策略动物园: {YEARS:.1f}年tick  初始{INIT_CAP:.0f}元  每笔风险1%  {NPATH}条路径")
print("  铁律: 随机游走市场里, 所有策略扣成本后终值必须 <= 10000")
print("=" * 100)


def evaluate(mk, A_mult, seed):
    A = A_mult * SIG
    px = gen_ticks(mk, N, SIG, seed=seed)
    ev = brick_events(px, A)
    if ev is None:
        return None
    b, lp = ev
    if len(b) < 50:
        return None
    cr = cont_returns(b, lp)
    out = {}
    for name, fn in FNS.items():
        out[name] = run_single(cr, fn, A, b=b)
    out['等权组合'] = run_combo(cr, COMBO_FNS, A, b=b)
    out['元选择'] = run_meta(cr, META_FNS, A, b=b)
    out['_n'] = len(cr)
    out['_cr'] = cr
    return out


# ============================================================
# Step1: 铁律检验 (只跑随机游走)
# ============================================================
print("\n### 铁律检验: 纯随机游走 (数学上绝无edge) —— 所有策略必须 <= 10000")
print(f"\n  {'策略':<10} {'A=5σ':>10} {'A=10σ':>10} {'A=20σ':>10} {'判定':>12}")
iron_ok = True
for name in list(FNS.keys()) + ['等权组合', '元选择']:
    row = []
    for am in [5, 10, 20]:
        fs = []
        for s in range(NPATH):
            r = evaluate('rw', am, 7000 + s)
            if r:
                fs.append(r[name]['final'])
        row.append(np.median(fs) if fs else np.nan)
    worst = max([v for v in row if not np.isnan(v)])
    ok = worst <= INIT_CAP * 1.02
    if not ok:
        iron_ok = False
    print(f"  {name:<10} {row[0]:>10.0f} {row[1]:>10.0f} {row[2]:>10.0f} "
          f"{'OK' if ok else '!!!违反':>12}")

print(f"\n  => 铁律{'通过: 引擎可信, 后续结果可讨论' if iron_ok else '未通过: 结果不可信'}")

# ============================================================
# Step2: 全市场 x 全策略
# ============================================================
A_SEL = 10
print("\n" + "=" * 100)
print(f"Step2: 四市场 x 十策略 (砖块 A={A_SEL}σ = {A_SEL*SIG*1e4:.0f}bp)")
print("=" * 100)

results = {}
for mk in MK:
    results[mk] = {}
    for name in list(FNS.keys()) + ['等权组合', '元选择']:
        fs, dds = [], []
        for s in range(NPATH):
            r = evaluate(mk, A_SEL, 5000 + s)
            if r:
                fs.append(r[name]['final']); dds.append(r[name]['maxdd'])
        results[mk][name] = dict(f=np.array(fs), med=np.median(fs),
                                 dd=np.median(dds))

print(f"\n  {'策略':<10}" + "".join(f"{MK_NAME[m]:>14}" for m in MK))
for name in list(FNS.keys()) + ['等权组合', '元选择']:
    line = f"  {name:<10}"
    for mk in MK:
        line += f"{results[mk][name]['med']:>14.0f}"
    print(line)

print("\n  (单位: 元, 中位终值。本金=10000)")

# 各市场最佳策略
print("\n" + "-" * 100)
print("各市场最佳策略 (中位终值):")
print("-" * 100)
for mk in MK:
    best = max(results[mk].items(), key=lambda kv: kv[1]['med'])
    print(f"  {MK_NAME[mk]:<10} -> {best[0]:<10} {best[1]['med']:>10.0f}  "
          f"(回撤 {best[1]['dd']*100:>5.1f}%)")

# 跨市场稳健性: 排除强趋势
print("\n" + "=" * 100)
print("关键: 哪个策略在【三个现实市场】上综合最好? (排除人为的强趋势)")
print("=" * 100)
real_mk = ['rw', 'trendvol', 'regime']
print(f"  {'策略':<10} {'平均中位':>10} {'最差市场':>10} {'最差中位':>10} {'回撤均值':>10} {'评价':>12}")
rank = []
for name in list(FNS.keys()) + ['等权组合', '元选择']:
    meds = [results[mk][name]['med'] for mk in real_mk]
    dds = [results[mk][name]['dd'] for mk in real_mk]
    worst = min(meds)
    avg = np.mean(meds)
    rank.append((name, avg, worst, np.mean(dds)))
    ev = "最稳健" if worst > 9900 else ("有风险" if worst > 9500 else "亏")
    print(f"  {name:<10} {avg:>10.0f} {real_mk[int(np.argmin(meds))]:>10} "
          f"{worst:>10.0f} {np.mean(dds)*100:>9.1f}% {ev:>12}")

rank.sort(key=lambda x: -x[2])
print(f"\n  按【最差市场表现】排序(越稳健越靠前):")
for i, (name, avg, worst, dd) in enumerate(rank[:5], 1):
    print(f"    {i}. {name:<10} 最差{worst:>8.0f}  平均{avg:>8.0f}")

# ============================================================
# Step3: 样本量检查
# ============================================================
print("\n" + "=" * 100)
print("样本量检查: 交易次数够不够验证edge?")
print("=" * 100)
for am in [5, 10, 20]:
    ns = []
    for s in range(10):
        r = evaluate('trendvol', am, 5000 + s)
        if r:
            ns.append(r['_n'])
    print(f"  A={am:>2}σ ({am*SIG*1e4:>5.0f}bp): 交易次数 ≈ {np.mean(ns):>6.0f}  "
          f"{'够(需~1700)' if np.mean(ns) >= 1700 else '不够'}")

print("\n  验证2个点优势需约1700笔; 验证1个点需约6800笔")

# ============================================================
# 图
# ============================================================
fig = plt.figure(figsize=(18, 11))
gs = fig.add_gridspec(2, 2, hspace=0.33, wspace=0.2)
fig.suptitle("策略动物园：加入策略后能“试出来”吗？（tick级，已过铁律检验）",
             fontsize=14.5, fontweight='bold')

names = list(FNS.keys()) + ['等权组合', '元选择']
ax = fig.add_subplot(gs[0, :])
x = np.arange(len(names))
w = 0.2
cols = ['salmon', 'steelblue', 'orange', 'green']
for i, mk in enumerate(MK):
    vals = [results[mk][n]['med'] for n in names]
    ax.bar(x + i * w - 0.3, vals, w, label=MK_NAME[mk], color=cols[i], alpha=.85)
ax.axhline(INIT_CAP, color='k', ls='--', lw=2, label='本金10000')
ax.set_xticks(x)
ax.set_xticklabels(names, fontsize=9.5)
ax.set_ylabel("中位终值 (元)")
ax.set_title("① 各策略 × 各市场：中位终值\n（同一策略在不同市场表现天差地别 = 期望来自匹配，不来自策略）",
             fontsize=11.5)
ax.legend(fontsize=9.5)
ax.grid(alpha=.3, axis='y')

ax = fig.add_subplot(gs[1, 0])
real_avg = [np.mean([results[mk][n]['med'] for mk in real_mk]) for n in names]
real_worst = [min([results[mk][n]['med'] for mk in real_mk]) for n in names]
x2 = np.arange(len(names))
ax.bar(x2 - 0.2, real_avg, 0.4, label='三市场平均', color='steelblue')
ax.bar(x2 + 0.2, real_worst, 0.4, label='最差市场', color='salmon')
ax.axhline(INIT_CAP, color='k', ls='--', lw=1.8)
ax.set_xticks(x2)
ax.set_xticklabels(names, fontsize=9, rotation=25)
ax.set_ylabel("终值 (元)")
ax.set_title("② 稳健性：平均 vs 最差\n（真正该看最差，因为你不知道自己在哪个市场）", fontsize=11)
ax.legend(fontsize=9)
ax.grid(alpha=.3, axis='y')

ax = fig.add_subplot(gs[1, 1])
ns_plot = []
for am in [5, 10, 20]:
    ns = []
    for s in range(10):
        r = evaluate('trendvol', am, 5000 + s)
        if r:
            ns.append(r['_n'])
    ns_plot.append(np.mean(ns))
ax.bar(['A=5σ', 'A=10σ', 'A=20σ'], ns_plot, color=['green', 'orange', 'salmon'])
ax.axhline(1700, color='red', ls='--', lw=2, label='验证所需 ~1700 笔')
ax.set_ylabel("交易次数")
ax.set_title("③ 样本量瓶颈\n砖块越小→交易越多(好验证) 但成本占比越高", fontsize=11)
ax.legend(fontsize=9)
ax.grid(alpha=.3, axis='y')
for i, v in enumerate(ns_plot):
    ax.text(i, v + max(ns_plot) * .02, f"{v:.0f}", ha='center', fontsize=9.5)

plt.savefig("/data/workspace/brick/fig_zoo.png", dpi=130)
print("\n[已保存] fig_zoo.png")
