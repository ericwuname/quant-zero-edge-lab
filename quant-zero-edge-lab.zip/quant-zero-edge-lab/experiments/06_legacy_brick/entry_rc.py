# -*- coding: utf-8 -*-
"""多重检验校正 + 逐品种分解 + 换手率诊断 + 时段效应(严格分离)"""
import sys, numpy as np, pandas as pd, itertools, warnings
sys.path.insert(0,'/data/workspace/brick')
warnings.filterwarnings('ignore')
from entry_lib import *
from scipy import stats

def run(syms, cost=0.0002):
    res = {}
    for sym in syms:
        df = load(sym); S = build_signals(df)
        o,h,l = df['open'].values, df['high'].values, df['low'].values
        for name, sig in S.items():
            if name.startswith('_'): continue
            r = backtest(sig, o, h, l, cost=cost)
            if len(r) >= 50: res.setdefault(name, {})[sym] = r
    return res

def perm_p(per):
    """跨品种符号翻转精确置换检验 (零假设: 无方向预测力)"""
    n = len(per)
    if n < 4: return np.nan, np.nan
    obs = per.mean()/(per.std(ddof=1)/np.sqrt(n))
    cnt = 0; tot = 0
    for mask in itertools.product([1,-1], repeat=n):
        v = per*np.array(mask)
        if v.std(ddof=1) == 0: continue
        t = v.mean()/(v.std(ddof=1)/np.sqrt(n))
        tot += 1
        if abs(t) >= abs(obs)-1e-12: cnt += 1
    return obs, cnt/tot

def bh_fdr(p, q=0.05):
    p = np.asarray(p, float); ok = ~np.isnan(p)
    pv = p[ok]; order = np.argsort(pv); m = len(pv)
    thr = q*np.arange(1, m+1)/m
    passed = pv[order] <= thr
    k = np.where(passed)[0]
    cut = pv[order][k[-1]] if len(k) else 0.0
    return p <= max(cut, 0)

print('#'*80)
print('# 主检验: 13品种 (对本次62个新信号而言, 均未参与过选择)')
print('#'*80)
R = run(ALL13)
rows = []
for name, d in R.items():
    syms = [s for s in ALL13 if s in d]
    if len(syms) < 8: continue
    per = np.array([d[s].mean() for s in syms])
    pool = np.concatenate([d[s] for s in syms])
    t_cross, p_perm = perm_p(per)
    t_pool = pool.mean()/(pool.std(ddof=1)/np.sqrt(len(pool)))
    ntr = np.mean([len(d[s]) for s in syms])
    rows.append(dict(sig=name, nsym=len(syms), E=pool.mean(),
                     E_cross=per.mean(), t_cross=t_cross, p=p_perm,
                     t_pool=t_pool, pos=(per>0).mean(), ntrade=ntr))
df13 = pd.DataFrame(rows).sort_values('t_cross', ascending=False)
df13['sig_fdr'] = bh_fdr(df13['p'].values)
print('信号数:', len(df13))
print('\n--- TOP 12 (正) ---')
print(df13.head(12)[['sig','nsym','E','E_cross','t_cross','p','pos','ntrade']].to_string(index=False, float_format=lambda x:f'{x:8.4f}'))
print('\n--- BOTTOM 10 (负) ---')
print(df13.tail(10)[['sig','nsym','E','E_cross','t_cross','p','pos','ntrade']].to_string(index=False, float_format=lambda x:f'{x:8.4f}'))
print('\n通过BH-FDR(q=0.05)的信号数:', int(df13['sig_fdr'].sum()),
      '->', list(df13[df13['sig_fdr']]['sig']))

print()
print('#'*80)
print('# 干净验证集 NEW6 单独检验 (最保守)')
print('#'*80)
rows6 = []
for name, d in R.items():
    syms = [s for s in NEW6 if s in d]
    if len(syms) < 6: continue
    per = np.array([d[s].mean() for s in syms])
    t_cross, p_perm = perm_p(per)
    rows6.append(dict(sig=name, E_cross=per.mean(), t_cross=t_cross, p=p_perm, pos=(per>0).mean()))
df6 = pd.DataFrame(rows6).sort_values('t_cross', ascending=False)
df6['sig_fdr'] = bh_fdr(df6['p'].values)
print(df6.head(10).to_string(index=False, float_format=lambda x:f'{x:8.4f}'))
print('NEW6 通过FDR:', int(df6['sig_fdr'].sum()), '->', list(df6[df6['sig_fdr']]['sig']))

df13.to_csv('/data/workspace/brick/main13.csv', index=False)
df6.to_csv('/data/workspace/brick/main6.csv', index=False)
