"""
受控宇宙实验室 v2 —— 修正版 (无前视偏差 / 对数收益 / 砖块精确评估)
=====================================================================
v1 的 bug:
  1. 前视偏差: 信号用了 px[i], 却乘以 bar i 的收益 -> 时序动量在随机游走里都"赚24%"
  2. 采样伪影: 砖块 A≈σ_bar 时虚假趋势 -> 砖块策略在随机游走里"赚100%"

v2 修正:
  - 所有 bar 级策略信号统一 shift 1 (只用 px[:i] 决定 pos[i])
  - 用【对数收益】评估 (买入持有在随机游走里几何增长=0, 公平)
  - 砖块策略用【精确 trade 级评估】: 每块砖盈亏精确 = ±A, 独立统计
  - 砖块专门做【伪影基线对照】: 同A下随机游走测出的p0, 扣掉才是真edge
"""
import numpy as np
from numpy.lib.stride_tricks import sliding_window_view

BARS_PER_YEAR = 252


# ============================================================
# 一、市场宇宙
# ============================================================
def gen_market(kind, n, seed, sigma=0.010):
    rng = np.random.default_rng(seed)
    eps = rng.normal(0, 1, n)

    if kind == "RW":
        r = sigma * eps
    elif kind == "MOM":
        phi = 0.06
        r = np.zeros(n); e = rng.normal(0, sigma * np.sqrt(1 - phi ** 2), n)
        for t in range(1, n):
            r[t] = phi * r[t - 1] + e[t]
    elif kind == "MR":
        phi = -0.06
        r = np.zeros(n); e = rng.normal(0, sigma * np.sqrt(1 - phi ** 2), n)
        for t in range(1, n):
            r[t] = phi * r[t - 1] + e[t]
    elif kind == "REGIME":
        r = np.zeros(n); state = 0
        for t in range(1, n):
            if rng.random() < 0.004:
                state = 1 - state
            if state == 1:
                r[t] = 0.07 * r[t - 1] + rng.normal(0, sigma)
            else:
                r[t] = -0.07 * r[t - 1] + rng.normal(0, sigma)
    elif kind == "VOL":
        r = np.zeros(n); h = sigma ** 2
        for t in range(1, n):
            h = 0.00002 + 0.10 * r[t - 1] ** 2 + 0.85 * h
            r[t] = np.sqrt(h) * eps[t]
    elif kind == "TRENDVOL":
        r = np.zeros(n); h = sigma ** 2; d = np.zeros(n)
        for t in range(1, n):
            h = 0.00002 + 0.10 * r[t - 1] ** 2 + 0.85 * h
            d[t] = 0.93 * d[t - 1] + rng.normal(0, 0.0016)
            r[t] = d[t] + np.sqrt(h) * eps[t]
    elif kind == "JUMP":
        r = sigma * eps
        jt = rng.random(n) < 0.002
        r[jt] += rng.choice([-1, 1], int(jt.sum())) * sigma * 12
    # 关键公平性修正: 把所有市场标准化到【同一实际波动率】
    # 否则 GARCH/跳跃市场波动更大 -> 砖块数暴涨 -> 采样伪影大小不同 -> 无法比较
    sd = r.std()
    if sd > 0:
        r = r / sd * sigma
    px = 100.0 * np.exp(np.cumsum(r))
    return px, r


# ============================================================
# 二、工具
# ============================================================
def roll_max(x, w):
    out = np.full(len(x), np.nan)
    if len(x) >= w:
        out[w - 1:] = sliding_window_view(x, w).max(axis=-1)
    return out


def roll_min(x, w):
    out = np.full(len(x), np.nan)
    if len(x) >= w:
        out[w - 1:] = sliding_window_view(x, w).min(axis=-1)
    return out


def roll_std(x, w):
    out = np.full(len(x), np.nan)
    if len(x) >= w:
        out[w - 1:] = sliding_window_view(x, w).std(axis=-1)
    return out


def sma(x, w):
    c = np.cumsum(np.insert(x, 0, 0.0))
    out = np.full(len(x), np.nan)
    if len(x) >= w:
        out[w - 1:] = (c[w:] - c[:-w]) / w
    return out


# ============================================================
# 三、bar级策略: 内部算 raw[i] (可用 px[:i+1]), 统一 shift -> 无前视
# ============================================================
def strat_ma_cross(px, fast=10, slow=50):
    f, s = sma(px, fast), sma(px, slow)
    raw = np.zeros(len(px))
    raw[(f > s) & ~np.isnan(f) & ~np.isnan(s)] = 1
    raw[(f < s) & ~np.isnan(f) & ~np.isnan(s)] = -1
    return raw


def strat_breakout(px, w=40):
    up, dn = roll_max(px, w), roll_min(px, w)
    raw = np.zeros(len(px))
    cur = 0.0
    for i in range(1, len(px)):
        if np.isnan(up[i - 1]) or np.isnan(dn[i - 1]):
            continue
        if px[i] > up[i - 1]:
            cur = 1.0
        elif px[i] < dn[i - 1]:
            cur = -1.0
        raw[i] = cur
    return raw


def strat_tsmom(px, w=60):
    raw = np.zeros(len(px))
    for i in range(w, len(px)):
        raw[i] = np.sign(px[i - 1] / px[i - 1 - w] - 1.0)   # 只用 px[i-1] 及之前
    return raw


def strat_rsi_rev(px, w=14, lo=30, hi=70):
    d = np.diff(px, prepend=px[0])
    up = np.clip(d, 0, None); dn = np.clip(-d, 0, None)
    au, ad = sma(up, w), sma(dn, w)
    rs = np.where(ad <= 0, 100.0, au / np.maximum(ad, 1e-12))
    rsi = 100 - 100 / (1 + rs)
    raw = np.zeros(len(px))
    cur = 0.0
    for i in range(1, len(px)):
        if np.isnan(rsi[i - 1]):
            continue
        if rsi[i - 1] < lo:
            cur = 1.0
        elif rsi[i - 1] > hi:
            cur = -1.0
        raw[i] = cur
    return raw


def strat_vol_break(px, w=20, k=1.5, bw_thr=0.02):
    m, sd = sma(px, w), roll_std(px, w)
    raw = np.zeros(len(px))
    cur = 0.0
    for i in range(1, len(px)):
        if np.isnan(m[i - 1]) or np.isnan(sd[i - 1]) or sd[i - 1] <= 0:
            continue
        bw = 2 * k * sd[i - 1] / m[i - 1]
        if bw < bw_thr:
            if px[i - 1] > m[i - 1] + k * sd[i - 1]:
                cur = 1.0
            elif px[i - 1] < m[i - 1] - k * sd[i - 1]:
                cur = -1.0
        raw[i] = cur
    return raw


def strat_buyhold(px):
    return np.ones(len(px))


def strat_random(px, seed=0):
    rng = np.random.default_rng(seed)
    return rng.choice([-1.0, 1.0], len(px))


BAR_STRATS = {
    "均线交叉":  strat_ma_cross,
    "通道突破":  strat_breakout,
    "时序动量":  strat_tsmom,
    "RSI反转":  strat_rsi_rev,
    "波动突破":  strat_vol_break,
    "买入持有":  strat_buyhold,
    "随机对照":  strat_random,
}


# ============================================================
# 四、评估 (对数收益, 无前视)
# ============================================================
def eval_bar(px, raw, cost=0.0005):
    """raw 是策略原始信号, 统一 shift 1 生效 -> pos[i] 只看 px[:i]"""
    pos = np.roll(raw, 1); pos[0] = 0.0
    rlog = np.concatenate([[0.0], np.log(px[1:] / px[:-1])])
    pnl = pos * rlog
    turnover = np.abs(np.diff(pos, prepend=0.0))
    net = pnl - turnover * cost
    ann = BARS_PER_YEAR
    sharpe = (net.mean() / net.std() * np.sqrt(ann)) if net.std() > 0 else 0.0
    growth = net.sum()                      # 累计对数收益 = 几何增长
    return dict(
        growth=growth,
        ret_ann=growth / (len(px) / ann),
        sharpe=sharpe,
        n_trades=int((turnover > 0).sum()),
        cost=turnover.sum() * cost,
    )


def trade_stats(px, raw, cost=0.0005):
    pos = np.roll(raw, 1); pos[0] = 0.0
    rlog = np.concatenate([[0.0], np.log(px[1:] / px[:-1])])
    pnl = pos * rlog
    turnover = np.abs(np.diff(pos, prepend=0.0))
    trades, acc, cur = [], 0.0, 0.0
    for i in range(len(pos)):
        if i > 0:
            acc += pnl[i]
        if turnover[i] > 0:
            if cur != 0.0:
                trades.append(acc - cost * abs(turnover[i]) / max(1.0, abs(turnover[i])) * (1 if turnover[i] > 1 else 1))
            cur = pos[i]; acc = 0.0
    if cur != 0.0 and abs(acc) > 1e-12:
        trades.append(acc - cost)
    if len(trades) < 5:
        return np.nan, np.nan, 0
    t = np.array(trades)
    return float((t > 0).mean()), float(t.mean()), len(t)


# ============================================================
# 五、砖块策略: 精确 trade 级评估 (每块砖盈亏精确 = ±A)
# ============================================================
def bricks_log(px, A_log):
    """砖块基于【对数价格】: 每块砖 = 固定对数幅度 (尺度无关, 无数量级漂移)"""
    lp = np.log(px)
    bs = []
    anchor = float(lp[0]); hi = anchor + A_log; lo = anchor - A_log
    for i in range(1, len(lp)):
        p = lp[i]
        while True:
            if p >= hi:
                bs.append(1); anchor = hi
                hi = anchor + A_log; lo = anchor - A_log
            elif p <= lo:
                bs.append(-1); anchor = lo
                hi = anchor + A_log; lo = anchor - A_log
            else:
                break
    return np.array(bs, np.int8)


def bricks(px, A):
    bs = []
    anchor = float(px[0]); hi = anchor + A; lo = anchor - A
    for i in range(1, len(px)):
        p = px[i]
        while True:
            if p >= hi:
                bs.append(1); anchor = hi
                hi = anchor + A; lo = anchor - A
            elif p <= lo:
                bs.append(-1); anchor = lo
                hi = anchor + A; lo = anchor - A
            else:
                break
    return np.array(bs, np.int8)


def eval_brick(px, A_log, cost_rel=0.0005, reverse=False):
    """
    精确评估(对数砖块): 第 i 笔在砖 i 后入场, 方向 b_i;
    砖 i+1 同向 -> +A_log, 反向 -> -A_log。收益精确, 无前视, 无采样歧义。
    """
    b = bricks_log(px, A_log)
    if len(b) < 5:
        return None
    same = (b[1:] == b[:-1])                    # 延续?
    sign = np.where(same, 1.0, -1.0)            # 延续策略: 同向赚
    if reverse:
        sign = -sign                            # 反转策略: 反向赚
    gross_rel = sign * A_log                    # 对数收益, 精确
    net = gross_rel - cost_rel
    p_win = float((net > 0).mean())
    return dict(
        n=len(sign),
        p_cont=float(same.mean()) if not reverse else float((~same).mean()),
        win=p_win,
        exp_per=float(net.mean()),
        total=float(net.sum()),
        A_log=A_log,
        sharpe=float(net.mean() / net.std() * np.sqrt(len(net))) if net.std() > 0 else 0,
    )
