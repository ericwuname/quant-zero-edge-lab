import numpy as np, pandas as pd
FILES={'DOGE':'/data/inputs/DOGEUSDT_1h.csv','DOT':'/data/inputs/DOTUSDT_1h.csv',
       'CRV':'/data/inputs/CRVUSDT_1h.csv','DASH':'/data/inputs/DASHUSDT_1h.csv',
       'ETH':'/data/inputs/ETHUSDT_1h.csv','FIL':'/data/inputs/FILUSDT_1h.csv',
       'HBAR':'/data/inputs/HBARUSDT_1h.csv'}
def load():
    o={}
    for k,p in FILES.items():
        d=pd.read_csv(p);c={x.lower():x for x in d.columns}
        o[k]=dict(open=d[c['open']].values.astype(float),high=d[c['high']].values.astype(float),
                  low=d[c['low']].values.astype(float),close=d[c['close']].values.astype(float))
    return o
def s_mom(cl,w):
    n=len(cl);s=np.zeros(n);s[w:]=np.sign(cl[w:]/np.maximum(cl[:-w],1e-9)-1);return s
def s_brk(cl,w):
    n=len(cl);s=np.zeros(n)
    for i in range(w,n):
        h=cl[i-w:i].max();l=cl[i-w:i].min()
        if cl[i]>h:s[i]=1
        elif cl[i]<l:s[i]=-1
    return s
def s_ma(cl,w):
    n=len(cl);s=np.zeros(n)
    ma=pd.Series(cl).rolling(w).mean().values
    s[w:]=np.sign(cl[w:]-ma[w:]);return s
def run(D,sg,s,R,cost_bp,slip_bp,max_hold,start,end,mode):
    op,hi,lo,cl=D['open'],D['high'],D['low'],D['close']
    n=len(cl) if end is None else min(end,len(cl))
    cR=2*cost_bp/1e4/s; slipR=slip_bp/1e4/s; stopd=s+slip_bp/1e4
    net=[];holds=[];i=max(start,120)
    while i<n-3:
        d=1 if sg[i]>0 else (-1 if sg[i]<0 else 0)
        if d==0:i+=1;continue
        e=op[i+1];i0=i+1;out=None;j=i0
        for jj in range(i0,min(i0+max_hold,n)):
            adv=(lo[jj]/e-1) if d==1 else (1-hi[jj]/e)
            fav=(hi[jj]/e-1) if d==1 else (1-lo[jj]/e)
            if adv<=-stopd: out=-1.0-slipR;j=jj;break
            if fav>=R*s: out=R;j=jj;break
            if mode=='flip' and sg[jj]*d<0: out=((cl[jj]/e-1)*d)/s;j=jj;break
        if out is None:
            j=min(i0+max_hold,n-1);out=((cl[j]/e-1)*d)/s
        net.append(out-cR);holds.append(j-i0);i=j+1
    return np.array(net),np.array(holds)

data=load()
out={}
NCOIN=len(data)
CONFIGS=[
 ('brk20_flip',   lambda c:s_brk(c,20), 0.05,2.0,'flip'),
 ('brk20_flip_R3',lambda c:s_brk(c,20), 0.05,3.0,'flip'),
 ('brk20_tgt_R2', lambda c:s_brk(c,20), 0.05,2.0,'target'),
 ('brk20_tgt_R3', lambda c:s_brk(c,20), 0.05,3.0,'target'),
 ('brk20_tgt_R5', lambda c:s_brk(c,20), 0.05,5.0,'target'),
 ('mom5_flip',    lambda c:s_mom(c,5),  0.05,2.0,'flip'),
 ('mom20_flip',   lambda c:s_mom(c,20), 0.05,2.0,'flip'),
 ('mom20_tgt_R2', lambda c:s_mom(c,20), 0.05,2.0,'target'),
 ('rev5_flip',    lambda c:-s_mom(c,5), 0.05,2.0,'flip'),
 ('ma50_flip',    lambda c:s_ma(c,50),  0.05,2.0,'flip'),
 ('brk20_s2_R2',  lambda c:s_brk(c,20), 0.02,2.0,'target'),
 ('brk20_s10_R2', lambda c:s_brk(c,20), 0.10,2.0,'target'),
]
print(f"生成序列(并保存持仓时长), 并行币种数={NCOIN}")
print(f"  {'策略':<16}{'N':>7}{'E[R]':>9}{'sig':>7}{'t':>7}{'胜率':>7}{'中位hold':>9}{'年交易数':>9}")
for nm,fn,s,R,mode in CONFIGS:
    alln=[];allh=[]
    for k,D in data.items():
        n=len(D['close'])
        nt,hd=run(D,fn(D['close']),s,R,2,5,800,n//2,n,mode)
        if len(nt)>=30: alln.append(nt);allh.append(hd)
    cat=np.concatenate(alln);hh=np.concatenate(allh)
    out[nm+'_R']=cat; out[nm+'_H']=hh.astype(float)
    mu=cat.mean();sd=cat.std()
    t=mu/(sd/np.sqrt(len(cat))) if sd>0 else 0
    mh=np.median(hh)
    # 年交易数: 每coin每年 8760/mh 笔, 但这里是pooled
    # pooled 序列中每笔对应 wall-clock = mh/NCOIN bar
    trades_per_year = 8760.0/(mh/NCOIN)
    print(f"  {nm:<16}{len(cat):>7}{mu:>+9.4f}{sd:>7.3f}{t:>+7.2f}{(cat>0).mean()*100:>6.1f}%{mh:>9.0f}{trades_per_year:>9.0f}")
np.savez('/data/workspace/brick/seq2.npz',**out)
print("已保存 seq2.npz")
