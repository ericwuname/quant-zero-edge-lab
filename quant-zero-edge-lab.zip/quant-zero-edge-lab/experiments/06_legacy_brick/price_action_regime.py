"""
价格行为 + 市场状态切换 (Regime-Switching) 检验
=================================================
假设(Claude提出): 动量与反转在全样本混测时互相抵消;
  在趋势态(高ER)用动量、震荡态(低ER)用反转, 可能各自有效。

方法(能失败):
  1. Kaufman效率比率 ER 判断状态 (无前视)
  2. 直接模拟成交, 不套解析公式
  3. walk-forward: 前50%样本内选参, 后50%样本外验证
  4. Reality Check: 校正"多参数挑选"的运气 (stationary bootstrap)
  5. 真实成本敏感性
  6. 诊断: 样本外按状态分组, 看动量/反转是否真的各自有效
"""
import numpy as np
import pandas as pd

FILES = {
    'BTCUSDT': '/data/inputs/BTCUSDT_1d.csv',
    'BNBUSDT': '/data/inputs/BNBUSDT_1d.csv',
    'BCHUSDT': '/data/inputs/BCHUSDT_1d.csv',
}
N_ER = [10, 20, 30]          # ER窗口
W_MOM = [5, 10, 20, 50]      # 动量窗口
THR = [0.3, 0.4, 0.5]        # ER阈值 (趋势/震荡分界)
COSTS = [0, 5, 10, 20]       # 单边成本 bp
B_BOOT = 1000


def load(path):
    df = pd.read_csv(path)
    df['ret'] = df['close'].pct_change()
    return df.dropna().reset_index(drop=True)


def calc_er(c, n):
    """Kaufman效率比率 ER[t] = |c[t]-c[t-n]| / Σ|c[i]-c[i-1]|, 无前视"""
    L = len(c)
    d = np.abs(np.diff(c))
    cs = np.concatenate([[0.0], np.cumsum(d)])
    er = np.full(L, np.nan)
    for t in range(n, L):
        vol = cs[t] - cs[t - n]
        er[t] = abs(c[t] - c[t - n]) / vol if vol > 0 else 0.0
    return er


def build_signals(c):
    """返回 (sigs, meta): 36个regime + 4纯动量 + 4纯反转 + 1买入持有"""
    L = len(c)
    sigs, meta = {}, {}
    ers = {n: calc_er(c, n) for n in N_ER}
    moms = {}
    for w in W_MOM:
        m = np.full(L, np.nan)
        for t in range(w, L):
            m[t] = c[t] / c[t - w] - 1.0
        moms[w] = m

    # regime-switching
    for n in N_ER:
        for w in W_MOM:
            for thr in THR:
                s = np.zeros(L)
                for t in range(max(n, w), L):
                    if np.isnan(ers[n][t]) or np.isnan(moms[w][t]):
                        s[t] = 0.0
                    elif ers[n][t] > thr:
                        s[t] = np.sign(moms[w][t])    # 趋势态: 动量
                    else:
                        s[t] = -np.sign(moms[w][t])   # 震荡态: 反转
                nm = f'rs_n{n}_w{w}_t{thr}'
                sigs[nm] = s
                meta[nm] = dict(kind='rs', n=n, w=w, thr=thr)

    # 纯动量 / 纯反转
    for w in W_MOM:
        sm = np.zeros(L)
        sm[w:] = np.sign(moms[w][w:])
        sigs[f'mom_{w}'] = sm
        meta[f'mom_{w}'] = dict(kind='mom', w=w)
        sigs[f'rev_{w}'] = -sm
        meta[f'rev_{w}'] = dict(kind='rev', w=w)

    sigs['BH'] = np.ones(L)
    meta['BH'] = dict(kind='bh')
    return sigs, meta, ers, moms


def backtest(sig, ret, cost_bp):
    """signal[t] -> 赚 t+1 收益; 换仓扣双边成本"""
    L = len(ret)
    gross = np.zeros(L)
    gross[:-1] = sig[:-1] * ret[1:]
    pos = np.asarray(sig, dtype=float)
    turn = np.zeros(L)
    turn[1:] = np.abs(np.diff(pos))
    return gross - turn * (2 * cost_bp / 1e4)


def stationary_boot_idx(rng, T, block):
    idx = np.empty(T, dtype=np.int64)
    i = rng.integers(0, T)
    for t in range(T):
        if rng.random() < 1.0 / block:
            i = rng.integers(0, T)
        else:
            i = (i + 1) % T
        idx[t] = i
    return idx


def reality_check(rets_oos, best_idx, B=B_BOOT, block=10, seed=42):
    """White's RC: 检验'挑出的最优'是否显著优于运气(校正多重挑选)"""
    M, T = rets_oos.shape
    rng = np.random.default_rng(seed)
    obs_mean = rets_oos.mean(axis=1)
    obs_best = obs_mean[best_idx]
    boot_max = np.zeros(B)
    for b in range(B):
        idx = stationary_boot_idx(rng, T, block)
        bm = rets_oos[:, idx].mean(axis=1)
        boot_max[b] = (bm - obs_mean).max()     # 中心化: 去掉真实edge
    p = (boot_max >= obs_best).mean()
    return obs_best, p


def analyze(sym, path):
    df = load(path)
    c, ret = df['close'].values, df['ret'].values
    L = len(c)
    split = L // 2
    sigs, meta, ers, moms = build_signals(c)
    names = list(sigs.keys())
    rs_names = [n for n in names if meta[n]['kind'] == 'rs']

    print("\n" + "=" * 100)
    print(f"{sym}  样本 {L} 根  样本内[0,{split})  样本外[{split},{L})")
    print("=" * 100)
    bh_tot = c[-1] / c[0] - 1
    print(f"  全期买入持有: {bh_tot*100:+.1f}%")

    results = {}
    for cost in COSTS:
        net_all = {}
        for nm in names:
            net = backtest(sigs[nm], ret, cost)
            net_all[nm] = (net[:split], net[split:])

        # === 样本内选最优 (全族45) ===
        is_mean = {nm: net_all[nm][0].mean() * 1e4 for nm in names}
        best_all = max(is_mean, key=is_mean.get)
        # regime族内最优
        is_rs = {nm: is_mean[nm] for nm in rs_names}
        best_rs = max(is_rs, key=is_rs.get)

        # === 样本外表现 ===
        oos_best_all = net_all[best_all][1].mean() * 1e4
        oos_best_rs = net_all[best_rs][1].mean() * 1e4
        oos_bh = net_all['BH'][1].mean() * 1e4
        best_mom = max([f'mom_{w}' for w in W_MOM], key=lambda n: is_mean[n])
        best_rev = max([f'rev_{w}' for w in W_MOM], key=lambda n: is_mean[n])
        oos_mom = net_all[best_mom][1].mean() * 1e4
        oos_rev = net_all[best_rev][1].mean() * 1e4

        results[cost] = dict(best_all=best_all, oos_all=oos_best_all,
                             best_rs=best_rs, oos_rs=oos_best_rs,
                             oos_bh=oos_bh, oos_mom=oos_mom, oos_rev=oos_rev,
                             net_all=net_all)

        print(f"\n  --- 单边成本 {cost}bp ---")
        print(f"  样本内全族最优 : {best_all:<18} 样本外 {oos_best_all:>7.2f} bp/日")
        print(f"  regime族最优   : {best_rs:<18} 样本外 {oos_best_rs:>7.2f} bp/日")
        print(f"  纯动量最优     : {best_mom:<18} 样本外 {oos_mom:>7.2f} bp/日")
        print(f"  纯反转最优     : {best_rev:<18} 样本外 {oos_rev:>7.2f} bp/日")
        print(f"  买入持有       : {'BH':<18} 样本外 {oos_bh:>7.2f} bp/日")

    # === Reality Check (对0和10bp做完整校正) ===
    print(f"\n  【Reality Check】校正'多参数挑选'的运气:")
    for cost in [0, 10]:
        net_all = results[cost]['net_all']
        # 全族45
        mat_all = np.array([net_all[nm][1] for nm in names])
        bi_all = names.index(results[cost]['best_all'])
        ob_all, p_all = reality_check(mat_all, bi_all, seed=42)
        # regime族36
        mat_rs = np.array([net_all[nm][1] for nm in rs_names])
        bi_rs = rs_names.index(results[cost]['best_rs'])
        ob_rs, p_rs = reality_check(mat_rs, bi_rs, seed=43)
        print(f"    成本{cost:>2}bp | 全族最优 p={p_all:.3f} "
              f"({'显著' if p_all<0.05 else '不显著'})  "
              f"| regime族最优 p={p_rs:.3f} "
              f"({'显著' if p_rs<0.05 else '不显著'})")

    # === 诊断: 样本外按ER状态分组, 看动量/反转是否各自有效 ===
    print(f"\n  【诊断】样本外按状态分组 (用最优regime参数):")
    bm = results[10]['best_rs']
    md = meta[bm]
    n_, w_, thr_ = md['n'], md['w'], md['thr']
    er = ers[n_]
    mom = moms[w_]
    oos_slice = slice(split, L)
    er_o, mom_o = er[oos_slice], mom[oos_slice]
    ret_o = ret[oos_slice]
    valid = ~np.isnan(er_o) & ~np.isnan(mom_o)
    trend_mask = (er_o > thr_) & valid
    chop_mask = (er_o <= thr_) & valid
    # 各状态下: 动量和反转的收益 (signal[t]*ret[t+1], 注意ret对齐: 用t的信号配t+1收益)
    # 这里简化: 用当期mom符号 * 下一期收益
    mom_sig = np.sign(mom_o)
    # 对齐: signal在t, 收益在t+1 -> ret_o需后移一位
    fwd_ret = np.roll(ret_o, -1)      # fwd_ret[t] = ret_o[t+1]
    fwd_ret[-1] = np.nan
    ok = valid & ~np.isnan(fwd_ret)
    tm = (er_o > thr_) & ok
    cm = (er_o <= thr_) & ok
    mom_pnl_trend = (mom_sig[tm] * fwd_ret[tm]).mean() * 1e4
    rev_pnl_trend = (-mom_sig[tm] * fwd_ret[tm]).mean() * 1e4
    mom_pnl_chop = (mom_sig[cm] * fwd_ret[cm]).mean() * 1e4
    rev_pnl_chop = (-mom_sig[cm] * fwd_ret[cm]).mean() * 1e4
    print(f"    趋势态 (ER>{thr_}, n={tm.sum()}天): 动量 {mom_pnl_trend:+7.2f} bp/日 | "
          f"反转 {rev_pnl_trend:+7.2f} bp/日")
    print(f"    震荡态 (ER<={thr_}, n={cm.sum()}天): 动量 {mom_pnl_chop:+7.2f} bp/日 | "
          f"反转 {rev_pnl_chop:+7.2f} bp/日")
    if mom_pnl_trend > rev_pnl_trend and rev_pnl_chop > mom_pnl_chop:
        print(f"    -> 状态切换逻辑在样本外方向正确 (趋势动量优, 震荡反转优)")
    else:
        print(f"    -> 状态切换逻辑在样本外未成立")

    return results


print("=" * 100)
print("价格行为 + Regime-Switching 检验 (Kaufman ER 分状态)")
print("=" * 100)
for s, p in FILES.items():
    try:
        analyze(s, p)
    except Exception as e:
        import traceback
        print(f"[!] {s}: {e}")
        traceback.print_exc()
