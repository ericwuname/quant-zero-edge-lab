"""
择时检验: 在市/空仓切换 (只做多, 不做空)
=============================================
与之前"选方向"(多vs空,始终在市)本质不同:
  择时 = 二态 {1 持多, 0 空仓}

为什么值得测: 择时的价值可能不在提高收益,
  而在【降低回撤 + 改善夏普】—— 即使收益略低,
  风险调整后收益的改善是真实价值(可用杠杆放大)。

策略族 (只做多, 择时进出):
  1. MA择时    : close > MA(w) 持多, 否则空仓
  2. 动量择时  : mom(w) > 0 持多, 否则空仓
  3. 低波择时  : realized vol(w) < 分位数阈值 持多 (避高波)
  4. 突破择时  : 上破w日高持多, 下破w日低空仓
  5. ER择时    : ER(w) > 阈值 持多 (趋势在市)
  6. 双过滤    : MA在市 且 低波在市

评价维度 (重点不是收益, 是风险调整):
  - 样本外年化收益 / 夏普 / 最大回撤 / Calmar
  - vs BH(始终持多) 的配对检验
  - Reality Check 校正多重挑选
  - bootstrap 检验夏普改善的显著性
"""
import numpy as np
import pandas as pd
import time

FILES = {
    'DOGEUSDT': '/data/inputs/DOGEUSDT_1h.csv',
    'DOTUSDT':  '/data/inputs/DOTUSDT_1h.csv',
    'CRVUSDT':  '/data/inputs/CRVUSDT_1h.csv',
    'DASHUSDT': '/data/inputs/DASHUSDT_1h.csv',
}
MA_W   = [10, 20, 50, 100, 200]
MOM_W  = [10, 20, 50, 100, 200]
VOL_W  = [20, 50, 100]
BRK_W  = [20, 50, 100]
ER_W   = [20, 50]
VOL_Q  = [0.3, 0.5, 0.7]        # 波动率分位阈值(低波在市)
ER_THR = [0.2, 0.3]
BARS_YR = 24 * 365
COSTS = [0, 10, 20]
B_BOOT = 500
BLK = 100


def load(path):
    df = pd.read_csv(path).dropna(subset=['close']).reset_index(drop=True)
    return df


def calc_er(close, n):
    d = np.abs(np.diff(close))
    cs = np.concatenate([[0.0], np.cumsum(d)])
    L = len(close)
    er = np.full(L, np.nan)
    er[n:] = np.abs(close[n:] - close[:-n]) / np.maximum(cs[n:] - cs[:-n], 1e-12)
    return er


def build_timing(close, high, low, ret):
    """返回 dict: name -> signal in {1(持多), 0(空仓)}"""
    L = len(close)
    S = {}
    s = pd.Series(close)

    # 1. MA择时
    for w in MA_W:
        ma = s.rolling(w).mean().values
        sig = np.where(close > ma, 1.0, 0.0)
        sig[np.isnan(ma)] = 0.0
        S[f'ma_{w}'] = sig

    # 2. 动量择时
    for w in MOM_W:
        mom = np.zeros(L)
        mom[w:] = close[w:] / close[:-w] - 1.0
        S[f'mom_{w}'] = (mom > 0).astype(float)

    # 3. 低波动择时 (realized vol 低于历史分位 -> 在市)
    rv = pd.Series(ret).rolling(50).std().values   # 统一用50算rv, 再按w取分位
    for w in VOL_W:
        for q in VOL_Q:
            thr_arr = pd.Series(rv).rolling(w).quantile(q).values
            sig = np.where(rv < thr_arr, 1.0, 0.0)
            sig[np.isnan(thr_arr) | np.isnan(rv)] = 0.0
            S[f'lowvol_w{w}_q{q}'] = sig
    # 高波动择时(反向: 高波在市)
    for w in VOL_W:
        thr_arr = pd.Series(rv).rolling(w).quantile(0.7).values
        sig = np.where(rv > thr_arr, 1.0, 0.0)
        sig[np.isnan(thr_arr) | np.isnan(rv)] = 0.0
        S[f'highvol_w{w}'] = sig

    # 4. 突破择时 (上破持多, 下破空仓)
    for w in BRK_W:
        hh = pd.Series(high).rolling(w).max().shift(1).values
        ll = pd.Series(low).rolling(w).min().shift(1).values
        sig = np.zeros(L)
        ok = ~np.isnan(hh)
        sig[ok & (close > hh)] = 1.0
        sig[ok & (close < ll)] = 0.0
        # 中间地带: 保持前值(持仓惯性)
        for t in range(1, L):
            if ok[t] and (close[t] <= hh[t]) and (close[t] >= ll[t]):
                sig[t] = sig[t - 1]
        S[f'brk_{w}'] = sig

    # 5. ER择时 (趋势在市)
    for w in ER_W:
        er = calc_er(close, w)
        for thr in ER_THR:
            sig = np.where(er > thr, 1.0, 0.0)
            sig[np.isnan(er)] = 0.0
            S[f'er_{w}_t{thr}'] = sig

    # 6. 双过滤: MA在市 且 低波在市
    for w in [50, 100]:
        ma = s.rolling(w).mean().values
        ma_sig = np.where(close > ma, 1.0, 0.0)
        ma_sig[np.isnan(ma)] = 0.0
        for vw in [50]:
            thr_arr = pd.Series(rv).rolling(vw).quantile(0.5).values
            lv = np.where(rv < thr_arr, 1.0, 0.0)
            lv[np.isnan(thr_arr) | np.isnan(rv)] = 0.0
            S[f'combo_ma{w}_vol{vw}'] = ma_sig * lv

    S['BH'] = np.ones(L)      # 始终持多
    return S


def backtest(sig, ret, cost_bp):
    """signal[t]->赚 t+1 收益; 换仓(0->1或1->0)扣双边成本"""
    L = len(ret)
    gross = np.zeros(L)
    gross[:-1] = sig[:-1] * ret[1:]
    turn = np.zeros(L)
    turn[1:] = np.abs(np.diff(sig))
    turn[0] = np.abs(sig[0])
    return gross - turn * (2 * cost_bp / 1e4)


def _nav(net):
    """复利净值曲线 (修正: 之前用算术累加导致回撤>100%的假象)"""
    return np.cumprod(1.0 + np.clip(net, -0.99, None))


def metrics(net):
    """年化收益%(复利), 夏普, 最大回撤%(复利口径), Calmar"""
    n = len(net)
    mu = net.mean()
    sd = net.std()
    if sd < 1e-12 or n < 10:
        return 0.0, 0.0, 0.0, 0.0
    # 复利年化
    nav = _nav(net)
    if nav[-1] <= 0:
        ann_ret = -100.0
    else:
        ann_ret = (nav[-1] ** (BARS_YR / n) - 1.0) * 100.0
    ann_ret = float(np.clip(ann_ret, -100.0, 1e6))
    sharpe = mu / sd * np.sqrt(BARS_YR)
    # 复利回撤
    peak = np.maximum.accumulate(nav)
    dd = (nav - peak) / np.maximum(peak, 1e-12)
    mdd = float(-dd.min() * 100.0)
    calmar = ann_ret / mdd if mdd > 1e-9 else 0.0
    return ann_ret, sharpe, mdd, calmar


def boot_idx(rng, T, L):
    nb = int(np.ceil(T / L))
    starts = rng.integers(0, T - L, size=nb)
    return (starts[:, None] + np.arange(L)[None, :]).ravel()[:T] % T


def paired_sharpe_test(net_a, net_b, B=B_BOOT, blk=BLK, seed=0):
    """配对bootstrap: 检验 夏普(a) - 夏普(b) 是否显著>0"""
    T = len(net_a)
    rng = np.random.default_rng(seed)
    def sh(x):
        s = x.std()
        return x.mean() / s * np.sqrt(BARS_YR) if s > 1e-12 else 0.0
    obs = sh(net_a) - sh(net_b)
    diffs = np.zeros(B)
    for b in range(B):
        idx = boot_idx(rng, T, blk)
        diffs[b] = sh(net_a[idx]) - sh(net_b[idx])
    p_two = 2 * min((diffs <= 0).mean(), (diffs >= 0).mean())
    return obs, min(p_two, 1.0)


def paired_dd_test(net_a, net_b, B=B_BOOT, blk=BLK, seed=0):
    """配对bootstrap: 检验 最大回撤(a) - 最大回撤(b) 是否显著<0 (回撤更小)"""
    T = len(net_a)
    rng = np.random.default_rng(seed)
    def mdd(x):
        nav = _nav(x)
        peak = np.maximum.accumulate(nav)
        dd = (nav - peak) / np.maximum(peak, 1e-12)
        return -dd.min() * 100
    obs = mdd(net_a) - mdd(net_b)
    diffs = np.zeros(B)
    for b in range(B):
        idx = boot_idx(rng, T, blk)
        diffs[b] = mdd(net_a[idx]) - mdd(net_b[idx])
    p_two = 2 * min((diffs <= 0).mean(), (diffs >= 0).mean())
    return obs, min(p_two, 1.0)


def reality_check_sharpe(rets_oos, best_idx, B=B_BOOT, blk=BLK, seed=0):
    """RC: 校正多重挑选, 检验最优策略的夏普是否显著"""
    def sh(x):
        s = x.std()
        return x.mean() / s * np.sqrt(BARS_YR) if s > 1e-12 else 0.0
    M, T = rets_oos.shape
    rng = np.random.default_rng(seed)
    obs_sh = np.array([sh(r) for r in rets_oos])
    obs_best = obs_sh[best_idx]
    bm = np.zeros(B)
    for b in range(B):
        idx = boot_idx(rng, T, blk)
        bm[b] = np.max([sh(r[idx]) for r in rets_oos])
    return obs_best, (bm >= obs_best).mean()


def analyze(sym, path):
    t0 = time.time()
    df = load(path)
    close = df['close'].values.astype(float)
    high = df['high'].values.astype(float)
    low = df['low'].values.astype(float)
    ret = pd.Series(close).pct_change().fillna(0).values
    L = len(close)
    sp = L // 2
    S = build_timing(close, high, low, ret)
    names = list(S.keys())

    bh_ret = close[-1] / close[0] - 1
    print("\n" + "=" * 100)
    print(f"{sym}  择时检验(只做多/空仓)  样本{L}根  策略族{len(names)}  "
          f"样本外[{sp},{L})")
    print("=" * 100)
    print(f"  全期BH: {bh_ret*100:+.1f}%")

    for cost in COSTS:
        nets = {nm: backtest(S[nm], ret, cost) for nm in names}
        # 样本内按夏普选最优
        is_sh = {}
        for nm in names:
            a, s_, d_, c_ = metrics(nets[nm][:sp])
            is_sh[nm] = s_
        best = max(is_sh, key=is_sh.get)
        bh_oos = nets['BH'][sp:]
        b_oos = nets[best][sp:]
        ar, sh_, mdd_, cal = metrics(b_oos)
        bar, bsh, bmdd, bcal = metrics(bh_oos)
        expo = S[best][sp:].mean() * 100

        print(f"\n  -- 成本{cost}bp --")
        print(f"    样本内夏普最优: {best:<18} 在市率{expo:>5.1f}%")
        print(f"      择时 : 年化{ar:>8.2f}%  夏普{sh_:>6.3f}  回撤{mdd_:>7.2f}%  Calmar{cal:>6.3f}")
        print(f"      BH   : 年化{bar:>8.2f}%  夏普{bsh:>6.3f}  回撤{bmdd:>7.2f}%  Calmar{bcal:>6.3f}")

        if cost in [0, 20]:
            # 配对检验: 夏普改善 & 回撤改善
            dsh, p_sh = paired_sharpe_test(b_oos, bh_oos, seed=21)
            ddd, p_dd = paired_dd_test(b_oos, bh_oos, seed=22)
            print(f"      配对检验: Δ夏普={dsh:+.3f} (p={p_sh:.3f} "
                  f"{'显著' if p_sh<0.05 else '不显著'})  "
                  f"Δ回撤={ddd:+.2f}% (p={p_dd:.3f} "
                  f"{'显著变小' if p_dd<0.05 and ddd<0 else '不显著'})")

    # Reality Check on Sharpe
    print(f"\n  【Reality Check · 夏普】校正{len(names)}个策略多重挑选:")
    for cost in [0, 20]:
        nets = {nm: backtest(S[nm], ret, cost) for nm in names}
        is_sh = {nm: metrics(nets[nm][:sp])[1] for nm in names}
        best = max(is_sh, key=is_sh.get)
        mat = np.array([nets[nm][sp:] for nm in names])
        bi = names.index(best)
        ob, p = reality_check_sharpe(mat, bi, seed=31)
        print(f"    成本{cost:>2}bp | 最优择时 {best:<18} 样本外夏普={ob:>6.3f} "
              f"RC p={p:.3f} ({'显著' if p<0.05 else '不显著'})")

    # 各策略样本外回撤一览(成本20bp)
    nets = {nm: backtest(S[nm], ret, 20) for nm in names}
    is_sh = {nm: metrics(nets[nm][:sp])[1] for nm in names}
    print(f"\n  【样本外回撤对比】(成本20bp, 按样本内夏普排序前8):")
    print(f"    {'策略':<20}{'在市率':>8}{'年化':>10}{'夏普':>8}{'回撤':>9}{'Calmar':>8}")
    for nm in sorted(is_sh, key=lambda x: -is_sh[x])[:8]:
        a, s_, d_, c_ = metrics(nets[nm][sp:])
        e = S[nm][sp:].mean() * 100
        print(f"    {nm:<20}{e:>7.1f}%{a:>9.2f}%{s_:>8.3f}{d_:>8.2f}%{c_:>8.3f}")
    a, s_, d_, c_ = metrics(nets['BH'][sp:])
    print(f"    {'BH(始终持多)':<20}{100.0:>7.1f}%{a:>9.2f}%{s_:>8.3f}{d_:>8.2f}%{c_:>8.3f}")
    print(f"    (用时 {time.time()-t0:.0f}s)")


print("=" * 100)
print("择时检验 (在市/空仓, 只做多) —— 重点看【夏普与回撤】, 不只是收益")
print("=" * 100)
for s, p in FILES.items():
    try:
        analyze(s, p)
    except Exception as e:
        import traceback
        print(f"[!] {s}: {e}")
        traceback.print_exc()
