import numpy as np
D=np.load('seq2.npz')
C0=10000.0; NCOIN=7; YEARS=3.0; BUDGET=YEARS*8760.0

def sim(Rarr,Harr,f,T,BUST,NSIM,seed,stop_goal=None,maxshop=99):
    """stop_goal: 累计落袋达此值即永久停止(None=一直玩下去)"""
    rng=np.random.default_rng(seed)
    N=len(Rarr); mh=np.median(Harr)
    max_steps=min(int(BUDGET/(mh/NCOIN)*1.6)+200,200000)
    W=np.full(NSIM,C0); G=np.zeros(NSIM); tu=np.zeros(NSIM)
    dead=np.zeros(NSIM,bool); stopped=np.zeros(NSIM,bool)
    ever=np.zeros(NSIM,bool); t_ev=np.full(NSIM,np.nan); shops=np.ones(NSIM)
    for step in range(max_steps):
        act=(~dead)&(~stopped)&(tu<BUDGET)
        if not act.any(): break
        ia=np.where(act)[0]
        idx=rng.integers(0,N,size=len(ia))
        r=Rarr[idx]; h=Harr[idx]/NCOIN
        W[ia]=W[ia]+np.minimum(f*C0,W[ia])*r; tu[ia]+=h
        bd=W[ia]<=BUST*C0
        if bd.any():
            bi=ia[bd]; G[bi]+=W[bi]
            if maxshop>1:
                can=(G[bi]>=C0)&(shops[bi]<maxshop); re=bi[can]
                G[re]-=C0; W[re]=C0; shops[re]+=1; dead[bi[~can]]=True
            else: dead[bi]=True
            ia=ia[~bd]
            if len(ia)==0: continue
        hv=W[ia]-C0>=T
        if hv.any(): hi=ia[hv]; G[hi]+=W[hi]-C0; W[hi]=C0
        nw=(~ever[ia])&(G[ia]>=C0)
        if nw.any(): ever[ia[nw]]=True; t_ev[ia[nw]]=tu[ia[nw]]
        if stop_goal is not None:
            st=G[ia]>=stop_goal
            if st.any(): stopped[ia[st]]=True
    G+=W*(~dead)
    G_final=G.copy()
    return dict(P_ever=ever.mean(), P_final=(G>=C0).mean(), medG=np.median(G_final),
                bust=dead.mean(), medT=np.nanmedian(t_ev) if np.isfinite(t_ev).any() else np.nan)

NS=600
R=D['brk20_flip_R']; H=D['brk20_flip_H']; mu0=R.mean()
print("="*100)
print("【决定性检验1】收割后'停止' vs '继续开店'  (f=2%, T=100%, 爆仓线20%)")
print("="*100)
print(f"  {'模式':<30}{'曾赚回%':>9}{'最终>=本金%':>13}{'最终落袋中位':>13}{'爆仓%':>8}")
print("  "+"-"*76)
for lab,sg,ms in [('一直玩(无限开店)',None,99),('赚回本金即停',C0,99),('赚回2倍本金即停',2*C0,99),('单店(不开新店)',None,1)]:
    r=sim(R,H,0.02,1.0*C0,0.20,NS,seed=3,stop_goal=sg,maxshop=ms)
    print(f"  {lab:<30}{r['P_ever']*100:>8.1f}%{r['P_final']*100:>12.1f}%{r['medG']:>13.0f}{r['bust']*100:>7.1f}%")

print("\n"+"="*100)
print("【决定性检验2】零edge基准 — 收割结构凭空制造多少'成功率'?")
print("="*100)
print("  理论: 固定注+双边障碍, 零漂移时 P(先到2倍)= (C0-爆仓线C0)/(2C0-爆仓线C0)")
print(f"  {'真实E[R]':>10}{'曾赚回%':>9}{'最终>=本金%':>13}{'最终落袋中位':>13}{'爆仓%':>8}{'EV估算':>10}")
print("  "+"-"*74)
for shrink in [1.0,0.7,0.5,0.3,0.0]:
    E=mu0*shrink; Rs=R-(mu0-E)
    r=sim(Rs,H,0.02,1.0*C0,0.20,NS,seed=3,stop_goal=C0,maxshop=99)
    # EV: 成功+10000, 失败-8000 (近似)
    ev=r['P_final']*1.0+(1-r['P_final'])*(-0.8)
    print(f"  {E:>+10.4f}{r['P_ever']*100:>8.1f}%{r['P_final']*100:>12.1f}%{r['medG']:>13.0f}"
          f"{r['bust']*100:>7.1f}%{ev*C0:>+10.0f}")

print("\n"+"="*100)
print("【检验3】爆仓线扫描 — 障碍几何如何改变'成功率'(零edge对照)")
print("="*100)
print(f"  {'爆仓线':>8}{'理论P(零edge)':>14}{'实测P(零edge)':>14}{'实测P(满E)':>12}{'失败亏损':>10}{'零edge EV':>11}")
print("  "+"-"*72)
for BL in [0.10,0.20,0.35,0.50]:
    th=(1-BL)/(2-BL)
    r0=sim(R-(mu0-0),H,0.02,1.0*C0,BL,NS,seed=3,stop_goal=C0,maxshop=99)
    r1=sim(R,H,0.02,1.0*C0,BL,NS,seed=3,stop_goal=C0,maxshop=99)
    ev0=r0['P_final']*1.0+(1-r0['P_final'])*(-(1-BL))
    print(f"  {BL*100:>7.0f}%{th*100:>13.1f}%{r0['P_final']*100:>13.1f}%{r1['P_final']*100:>11.1f}%"
          f"{-(1-BL)*C0:>10.0f}{ev0*C0:>+11.0f}")
print("\n"+"="*100)
