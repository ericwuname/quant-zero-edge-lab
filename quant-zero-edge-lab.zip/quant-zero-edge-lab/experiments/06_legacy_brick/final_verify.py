"""
【最终验证】mom_5+fixed 是否经得起"选择过程"的检验?
============================================================
【问题】
  池化结果 mom_5+fixed: E=+0.064R, t=+2.03 (显著)
  但这个"选择"是在看完全部12个组合后挑的 -> 选择偏差!
  Bonferroni(12次): 阈值 t≈2.87, 2.03 不过

【walk-forward 修正】
  阶段1(前1/3): 扫描12个组合, 选出最优
  阶段2(中1/3): 用选出的组合验证
  阶段3(后1/3): 再验证
  -> 若阶段2/3都为正 -> 选择稳健
  -> 若只阶段1好 -> 过拟合

【同时】
  分品种看 mom_5+fixed 是否一致(不能靠单一品种)
  分年度看是否稳定
"""
import numpy as np
import pandas as pd
from scipy import stats

HOURLY = {'DOGE': '/data/inputs/DOGEUSDT_1h.csv',
          'DOT':  '/data/inputs/DOTUSDT_1h.csv',
          'CRV':  '/data/inputs/CRVUSDT_1h.csv',
          'DASH': '/data/inputs/DASHUSDT_1h.csv'}
exec(open('/data/workspace/brick/fix_scale_bug.py').read()
     .split('data = load()')[0].split('import numpy as np')[1]
     .join(['import numpy as np', ''])) if False else None


def load():
    out = {}
    for k, p in HOURLY.items():
        d = pd.read_csv(p)
        out[k] = dict(high=d['high'].values, low=d['low'].values,
                      close=d['close'].values)
    return out


def momentum_signal(cl, w):
    n = len(cl)
    s = np.zeros(n)
    s[w:] = np.sign(cl[w:] / np.maximum(cl[:-w], 1e-9) - 1)
    return s


def build_entries(D):
    cl = D['close']; n = len(cl)
    S = {}
    ret = np.zeros(n); ret[1:] = cl[1:] / np.maximum(cl[:-1], 1e-9) - 1
    vol = pd.Series(np.abs(ret)).rolling(48).mean().values
    vq = np.nanpercentile(vol[~np.isnan(vol)], [33, 67])
    S['mom_60'] = momentum_signal(cl, 60)
    S['mom_5'] = momentum_signal(cl, 5)
    S['vol_mid'] = np.where((vol > vq[0]) & (vol < vq[1]), momentum_signal(cl, 60), 0.0)
    S['vol_mid_mom5'] = np.where((vol > vq[0]) & (vol < vq[1]), momentum_signal(cl, 5), 0.0)
    return S


def run_trades(D, signal, s, R, cost_bp=2, max_hold=800,
               exit_mode='fixed', scale_frac=0.5, start=0, end=None):
    hi, lo, cl = D['high'], D['low'], D['close']
    n = len(cl) if end is None else min(end, len(cl))
    cost_R = 2 * cost_bp / 1e4 / s * (2 if exit_mode == 'scale' else 1)
    net = []
    i = max(start, 120)
    while i < n - 2:
        sg = signal[i]
        if sg == 0:
            i += 1; continue
        direction = 1 if sg > 0 else -1
        entry = cl[i]
        out_R = None; j = i; scaled = False; peak = 0.0; be = False
        for jj in range(i + 1, min(i + max_hold, n)):
            if direction == 1:
                fav = hi[jj] / entry - 1; adv = lo[jj] / entry - 1
            else:
                fav = 1 - lo[jj] / entry; adv = 1 - hi[jj] / entry
            peak = max(peak, fav)
            if exit_mode == 'fixed':
                if adv <= -s: out_R = -1.0; j = jj; break
                if fav >= R * s: out_R = R; j = jj; break
            elif exit_mode == 'breakeven':
                if fav >= R * s: be = True
                cur = 0.0 if be else -s
                if adv <= cur: out_R = 0.0 if be else -1.0; j = jj; break
                if fav >= R * s: out_R = R; j = jj; break
            elif exit_mode == 'scale':
                if not scaled:
                    if adv <= -s: out_R = -1.0; j = jj; break
                    if fav >= R * s: scaled = True; continue
                else:
                    stop_R = (peak - R * s) / s
                    if adv <= -s:
                        out_R = scale_frac * R + (1 - scale_frac) * (-1); j = jj; break
                    if (adv / s) <= stop_R:
                        out_R = scale_frac * R + (1 - scale_frac) * stop_R; j = jj; break
        if out_R is None:
            j = min(i + max_hold, n - 1)
            mv = (cl[j] / entry - 1) * direction
            out_R = mv / s
        net.append(out_R - cost_R)
        i = j + 1
    return np.array(net)


def stats_of(net):
    if len(net) < 30: return None
    E = net.mean()
    t = E / (net.std() / np.sqrt(len(net))) if net.std() > 0 else 0
    return dict(n=len(net), win=(net > 0).mean(), E_R=E, t=t)


data = load()
S_STOP, R_MULT = 0.05, 2.0
ENTRIES = ['mom_60', 'mom_5', 'vol_mid', 'vol_mid_mom5']
EXITS = ['fixed', 'breakeven', 'scale']

print("=" * 100)
print("【最终验证】mom_5+fixed 经得起选择偏差检验吗?")
print("=" * 100)

# ---------- 三段 walk-forward ----------
print(f"\n  【1】三段 walk-forward (选组合只用第1段)")
segs = [(0.00, 0.25), (0.25, 0.50), (0.50, 0.75), (0.75, 1.00)]
seg_names = ['第1段(选)', '第2段(验)', '第3段(验)', '第4段(验)']

# 在第1段选最优组合
best_combo = None
for enm in ENTRIES:
    for exm in EXITS:
        allnet = []
        for sym in ['DOGE', 'CRV', 'DOT', 'DASH']:
            D = data[sym]; S = build_entries(D)
            n = len(D['close'])
            a, b = int(n * segs[0][0]), int(n * segs[0][1])
            nt = run_trades(D, S[enm], S_STOP, R_MULT, cost_bp=2,
                            exit_mode=exm, start=a, end=b)
            if len(nt) >= 30: allnet.append(nt)
        if not allnet: continue
        st = stats_of(np.concatenate(allnet))
        if st and (best_combo is None or st['t'] > best_combo[2]['t']):
            best_combo = (enm, exm, st)

if best_combo:
    print(f"    第1段选出: {best_combo[0]} + {best_combo[1]} "
          f"(E={best_combo[2]['E_R']:+.3f}R, t={best_combo[2]['t']:+.2f})")
    print(f"\n  {'段':<12}{'笔数':>7}{'胜率':>9}{'E(R)':>10}{'t':>8}{'判定':>10}")
    print("  " + "-" * 58)
    for si, (a_, b_) in enumerate(segs):
        allnet = []
        for sym in ['DOGE', 'CRV', 'DOT', 'DASH']:
            D = data[sym]; S = build_entries(D)
            n = len(D['close'])
            a, b = int(n * a_), int(n * b_)
            nt = run_trades(D, S[best_combo[0]], S_STOP, R_MULT, cost_bp=2,
                            exit_mode=best_combo[1], start=a, end=b)
            if len(nt) >= 30: allnet.append(nt)
        if not allnet: continue
        st = stats_of(np.concatenate(allnet))
        if st is None: continue
        pv = '显著' if abs(st['t']) > 1.96 else ('正' if st['E_R'] > 0 else '负')
        print(f"  {seg_names[si]:<12}{st['n']:>7}{st['win']*100:>8.1f}%"
              f"{st['E_R']:>+10.3f}{st['t']:>+8.2f}{pv:>10}")

# ---------- 分品种一致性 (mom_5 + fixed) ----------
print(f"\n  【2】mom_5+fixed 分品种一致性 (样本外50%)")
print(f"  {'品种':<7}{'笔数':>7}{'胜率':>9}{'E(R)':>10}{'t':>8}{'判定':>8}")
print("  " + "-" * 50)
wins = 0
for sym in ['DOGE', 'CRV', 'DOT', 'DASH']:
    D = data[sym]; S = build_entries(D)
    n = len(D['close']); sp = n // 2
    nt = run_trades(D, S['mom_5'], S_STOP, R_MULT, cost_bp=2,
                    exit_mode='fixed', start=sp, end=n)
    st = stats_of(nt)
    if st is None: continue
    if st['E_R'] > 0: wins += 1
    pv = '★' if (st['t'] > 1.96 and st['E_R'] > 0) else ''
    print(f"  {sym:<7}{st['n']:>7}{st['win']*100:>8.1f}%{st['E_R']:>+10.3f}"
          f"{st['t']:>+8.2f}{pv:>8}")
print(f"    -> E>0 的品种: {wins}/4")

# ---------- 分年度 ----------
print(f"\n  【3】mom_5+fixed 分年度稳定性 (池化)")
print(f"  {'年份':>7}{'笔数':>7}{'胜率':>9}{'E(R)':>10}{'t':>8}")
print("  " + "-" * 44)
for yi in range(2, 6):
    allnet = []
    for sym in ['DOGE', 'CRV', 'DOT', 'DASH']:
        D = data[sym]; S = build_entries(D)
        n = len(D['close']); L = n // 6
        a, b = yi * L, min((yi + 1) * L, n)
        if b - a < 500: continue
        nt = run_trades(D, S['mom_5'], S_STOP, R_MULT, cost_bp=2,
                        exit_mode='fixed', start=a, end=b)
        if len(nt) >= 30: allnet.append(nt)
    if not allnet: continue
    st = stats_of(np.concatenate(allnet))
    if st is None: continue
    print(f"  {2020+yi:>7}{st['n']:>7}{st['win']*100:>8.1f}%"
          f"{st['E_R']:>+10.3f}{st['t']:>+8.2f}")

print("\n" + "=" * 100)
print("完成")
print("=" * 100)
