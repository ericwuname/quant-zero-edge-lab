"""
实例化交易世界 v4 —— 做市商改为库存型(被动), 修复AC(1)
==========================================================
【v3 失败根因】
  做市商被写成"偏离5日均线就反向" = 方向预测者
  它财富最大 -> 主导价格 -> 强反转 AC(1)=-0.25

【真实做市商的本质】
  被动: 挂双边报价, 因【库存偏斜】调价, 赚价差, 不预测方向
  需求 = -inventory * k   (持仓多了就降价卖, 持仓少了就提价买)
  这不是"预测会跌", 是"我要平掉库存风险"

【v4 修正】
  1. 做市商改为库存驱动 (被动做市, 非方向预测)
  2. 提高外生噪声占比, 让主体行为不主导价格
  3. 基本面改为慢速(长期锚定), 不产生短期反转
  4. 目标: AC(1) ≈ 0

【平衡的力量】
  趋势者   -> 正自相关
  反转者   -> 负自相关
  基本面   -> 长期锚定
  做市商   -> 库存平抑(提供流动性, 不改变方向结构)
  噪声     -> 无
"""
import numpy as np
from scipy import stats


class WorldV4:
    def __init__(self, seed=0, params=None):
        self.p = params or self.default_params()
        self.rng = np.random.default_rng(seed)
        self.value = self.p['p0']
        self.inventory = None      # 做市商库存

    @staticmethod
    def default_params():
        return dict(
            p0=100.0, n_agents=300, init_wealth=1.0,
            frac_fund=0.18, frac_trend=0.22, frac_contra=0.15,
            frac_mm=0.20, frac_noise=0.25,
            fund_speed=0.25, fund_value_vol=0.005,
            trend_lbs=(5, 20, 60), trend_scale=0.05,
            contra_lb=10, contra_scale=0.04, contra_thresh=0.02,
            mm_inv_k=0.5,          # 做市商库存平抑系数
            noise_vol=1.0,
            beta=0.0012,
            shock_vol=0.012,       # 外生噪声占比提高
            evol_speed=0.05,
            gamma=0.6, crowd_penalty=1.2, anchor=0.0015,
        )

    def setup(self):
        p = self.p; n = p['n_agents']
        nf=int(n*p['frac_fund']); nt=int(n*p['frac_trend'])
        nc=int(n*p['frac_contra']); nm=int(n*p['frac_mm'])
        nn=n-nf-nt-nc-nm
        self.kinds=np.array(['fund']*nf+['trend']*nt+['contra']*nc+['mm']*nm+['noise']*nn)
        self.wealth=np.ones(n)*p['init_wealth']
        self.inventory=np.zeros(n)          # 每个主体的持仓

    def demand(self, price, hist):
        p=self.p; rng=self.rng; kinds=self.kinds
        n=len(kinds); d=np.zeros(n)

        m=kinds=='fund'
        if m.sum():
            dev=(self.value-price)/max(price,1e-9)
            d[m]=np.tanh(dev/p['fund_speed'])

        m=kinds=='trend'
        if m.sum() and len(hist)>=max(p['trend_lbs']):
            sig=np.zeros(m.sum())
            for lb in p['trend_lbs']:
                if len(hist)>=lb:
                    mom=price/max(hist[-lb],1e-9)-1.0
                    sig+=np.tanh(mom/p['trend_scale'])
            d[m]=sig/len(p['trend_lbs'])

        m=kinds=='contra'
        if m.sum() and len(hist)>=p['contra_lb']:
            mom=price/max(hist[-p['contra_lb']],1e-9)-1.0
            if abs(mom)>p['contra_thresh']:
                d[m]=-np.tanh(mom/p['contra_scale'])

        # --- 做市商: 库存驱动(被动), 不是方向预测 ---
        m=kinds=='mm'
        if m.sum():
            # 库存越多 -> 越想卖 (负需求); 不预测方向
            d[m]=-np.tanh(self.inventory[m]*p['mm_inv_k'])

        m=kinds=='noise'
        if m.sum():
            d[m]=rng.normal(0,p['noise_vol'],m.sum())
        return d

    def run(self, n_steps=12000, true_drift=0.0, trend_strength=0.0,
            mean_revert_strength=0.0, record_every=100):
        p=self.p; rng=self.rng
        self.setup()
        kinds=self.kinds; n=len(kinds)
        price=p['p0']; hist=[price]; prices=[price]
        prev_d=np.zeros(n); wh=[]
        trend_comp=0.0

        for t in range(n_steps):
            self.value*=(1+rng.normal(0,p['fund_value_vol']))
            if trend_strength>0:
                trend_comp=0.98*trend_comp+0.02*rng.normal(0,1)
            else:
                trend_comp=0.0

            d=self.demand(price,np.array(hist))

            w_eff=np.power(np.maximum(self.wealth,1e-6),p['gamma'])
            shares={k: w_eff[kinds==k].sum()/max(w_eff.sum(),1e-9)
                    for k in ['fund','trend','contra','mm','noise']}
            crowd=np.zeros(n)
            for k in ['fund','trend','contra','mm']:
                crowd[kinds==k]=1.0/(1.0+p['crowd_penalty']*max(shares[k]-0.2,0))
            crowd[kinds=='noise']=1.0
            wf=w_eff*crowd
            net_d=(d*wf).sum()/max(wf.sum(),1e-9)

            shock=rng.normal(0,p['shock_vol'])
            anchor_r=-p['anchor']*np.log(price/max(self.value,1e-9))
            struct=trend_strength*trend_comp
            if mean_revert_strength>0 and len(hist)>=50:
                struct+=mean_revert_strength*(-(price/np.mean(hist[-50:])-1))

            r=p['beta']*net_d*50+true_drift+struct+anchor_r+shock
            price=max(price*(1+r),1e-6)
            prices.append(price); hist.append(price)
            if len(hist)>300: hist.pop(0)

            # 持仓更新: 需求=买入 -> 库存增加
            self.inventory=self.inventory*0.95+d*0.1

            gains=prev_d*r*n
            self.wealth=self.wealth+p['evol_speed']*gains
            self.wealth=np.maximum(self.wealth,0.2*p['init_wealth'])
            tw=self.wealth.sum()
            if tw>0:
                self.wealth=self.wealth/tw*(n*p['init_wealth'])
            prev_d=d

            if t%record_every==0:
                wh.append([self.wealth[kinds==k].sum()
                           for k in ['fund','trend','contra','mm','noise']])
        return np.array(prices),np.array(wh),kinds


def facts(prices):
    r=np.diff(prices)/prices[:-1]; r=r[np.isfinite(r)]
    if len(r)<500: return None
    ar=np.abs(r)
    def ac(x,k): return np.corrcoef(x[:-k],x[k:])[0,1] if len(x)>k+10 else np.nan
    def vr(k):
        v1=r.var()
        if v1<=0 or len(r)<k*20: return np.nan
        return np.array([r[i:i+k].sum() for i in range(0,len(r)-k,k)]).var()/(k*v1)
    return dict(n=len(r),mean=r.mean()*1e4,vol=r.std()*1e4,
                kurt=stats.kurtosis(r)+3.0,ac1=ac(r,1),ac5=ac(r,5),ac20=ac(r,20),
                aac1=ac(ar,1),aac5=ac(ar,5),vr5=vr(5),vr20=vr(20))


print("="*100)
print("实例化交易世界 v4 —— 做市商改为库存型(被动)")
print("="*100)

res_all=[]
for label,cfg in [("① 纯生态",{}),
                  ("② 趋势成分",dict(trend_strength=0.006)),
                  ("③ 均值回归",dict(mean_revert_strength=0.03))]:
    w=WorldV4(seed=42)
    prices,wh,kinds=w.run(n_steps=12000,**cfg)
    res=facts(prices)
    ok1=abs(res['ac1'])<0.10
    ok2=res['kurt']>3.0
    ok3=res['aac1']>0.03
    last=wh[-1]; mx=max(last)/sum(last)
    ok4=mx<0.50
    print(f"\n  【{label}】")
    print(f"    均值 {res['mean']:>7.2f}bp  波动 {res['vol']:>7.1f}bp  峰度 {res['kurt']:>6.2f} {'✓' if ok2 else '✗'}")
    print(f"    收益AC(1) {res['ac1']:>+7.4f} {'✓' if ok1 else '✗'}  AC(5/20) {res['ac5']:>+7.4f}/{res['ac20']:>+7.4f}")
    print(f"    |r|AC(1)  {res['aac1']:>+7.4f} {'✓' if ok3 else '✗'}  |r|AC(5) {res['aac5']:>+7.4f}")
    print(f"    方差比(5/20) {res['vr5']:>6.3f}/{res['vr20']:>6.3f}")
    print(f"    终局: 基本面{last[0]:.1f} 趋势{last[1]:.1f} 反转{last[2]:.1f} 做市{last[3]:.1f} 噪声{last[4]:.1f}  最大{mx*100:.1f}% {'✓' if ok4 else '✗'}")
    res_all.append((label,ok1 and ok2 and ok3 and ok4))

print("\n"+"="*100)
for lb,ok in res_all:
    print(f"  {lb}: {'✓ 合格' if ok else '✗ 不合格'}")
print(f"\n  世界可用性: {'✓ 可用于校准' if all(o for _,o in res_all) else '✗ 继续标定'}")
print("="*100)
