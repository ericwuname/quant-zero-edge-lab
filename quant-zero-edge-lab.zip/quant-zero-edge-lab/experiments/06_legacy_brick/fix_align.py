# -*- coding: utf-8 -*-
"""修正前视: sig[j]由close[j]决定 -> 必须在 open[j+1]成交 -> 赚 r[j+2] (而非r[j+1])"""
import sys, numpy as np, pandas as pd, warnings
sys.path.insert(0,'/data/workspace/brick')
warnings.filterwarnings('ignore')
from entry_lib import *

def sig_brk20(c):
    s=np.zeros(len(c)); hh=pd.Series(c).rolling(20).max().values; ll=pd.Series(c).rolling(20).min().values
    s[20:]=np.where(c[20:]>hh[:-20],1,np.where(c[20:]<ll[:-20],-1,0)); return np.where(np.isnan(s),0,s)
def sig_mom240(c):
    s=np.zeros(len(c)); s[240:]=np.sign(c[240:]/c[:-240]-1); return s
def sig_ma200(c):
    ma=pd.Series(c).rolling(200).mean().values; s=np.where(c>ma,1,-1); s[:200]=0
    return np.where(np.isnan(s),0,s)
def sig_long(c): return np.ones(len(c))

def run(fn,half,cost=0.0002,lag=2):
    out=[];expo=[]
    for sym in ALL13:
        df=load(sym); o=df['open'].values; c=df['close'].values
        n=len(o); cut=n//2; sig=fn(c)
        r=np.zeros(n); r[1:]=o[1:]/o[:-1]-1
        # 无前视: sig[j] 用close[j] -> 在open[j+1]成交 -> 收益从 open[j+1] 到 open[j+2] = r[j+2]
        pos=sig[:-lag]; ret=r[lag:]
        chg=np.zeros(len(pos)); chg[1:]=(np.abs(np.diff(pos))>0).astype(float)
        pnl=pos*ret-chg*2*cost
        a,b=(0,cut) if half=='first' else (cut,len(pos))
        out.append(pnl[a:b].mean()); expo.append(np.abs(pos[a:b]).mean())
    return np.mean(out)*1e4, np.mean(expo)

print('='*100)
print('修正前视后 (lag=2, 真正无前视)')
print('='*100)
print(f'{"信号":<16}{"前半bp/bar":>14}{"后半bp/bar":>14}{"平均暴露":>10}{"判定":>14}')
for nm,fn in [('始终做多',sig_long),('brk20',sig_brk20),('mom240',sig_mom240),('ma200',sig_ma200)]:
    f1,e1=run(fn,'first'); f2,e2=run(fn,'second')
    v='-' 
    if nm=='始终做多': v='基准'
    elif f2<=0: v='负 ✗'
    elif abs(f2)<abs(f1)*0.3: v='衰减严重'
    else: v='待验'
    print(f'{nm:<16}{f1:>14.3f}{f2:>14.3f}{e2:>10.1%}{v:>14}')

print()
print('='*100)
print('对照: 前视版本(lag=1) vs 无前视版本(lag=2) —— 差异即前视贡献')
print('='*100)
print(f'{"信号":<16}{"lag1(前视)后半":>16}{"lag2(无前视)后半":>18}{"前视贡献":>12}')
for nm,fn in [('brk20',sig_brk20),('mom240',sig_mom240),('ma200',sig_ma200)]:
    a,_=run(fn,'second',lag=1); b,_=run(fn,'second',lag=2)
    print(f'{nm:<16}{a:>16.3f}{b:>18.3f}{a-b:>12.3f}')

print()
print('='*100)
print('修正后: 收割制(不复利)重算 —— 用无前视序列')
print('='*100)
rng=np.random.default_rng(11)
def seq_of(fn,stop=0.05,R=2.0,cost=0.0002):
    """分段回测(与entry_lib一致: open[t+1]入场), 只用后半时间"""
    out=[]
    for sym in ALL13:
        df=load(sym); o=df['open'].values; h=df['high'].values; l=df['low'].values; c=df['close'].values
        n=len(o); cut=n//2; sig=fn(c); res=[]; i=cut
        while i<n-2:
            if sig[i]==0: i+=1; continue
            d=sig[i]; ep=o[i+1]           # 无前视: 信号在close[i]后, 于open[i+1]成交
            sp=ep*(1-stop*d); tp=ep*(1+stop*R*d)
            j=i+2; v=None
            while j<n:
                if d>0:
                    if l[j]<=sp: v=-1.0;break
                    if h[j]>=tp: v=R;break
                else:
                    if h[j]>=sp: v=-1.0;break
                    if l[j]<=tp: v=R;break
                if j+1<n and sig[j+1]==-d: v=(o[j+2]/ep-1)*d/stop if j+2<n else (o[j+1]/ep-1)*d/stop;break
                j+=1
            if v is None: v=(o[min(j,n-1)]/ep-1)*d/stop
            res.append(v-2*cost/stop); i=max(j,i+1)
        if len(res)>30: out.append(np.array(res))
    return out

def harvest(seqs,f,T=1.0,C0=10000,ruin=0.2,N=3000,B=1500):
    allR=np.concatenate([s[np.isfinite(s)] for s in seqs])
    if len(allR)<50: return None
    dr=rng.choice(allR,size=(B,N),replace=True); ok=0;ru=0;tot=[]
    for b in range(B):
        W=C0;ext=0.0;dead=False
        for k in range(N):
            if W<=ruin*C0: dead=True;break
            bet=min(f*C0,W); W+=bet*dr[b,k]
            if W>=C0*(1+T): ext+=W-C0; W=C0
        if ext>=C0: ok+=1
        if dead: ru+=1
        tot.append(ext+max(W,0)-C0)
    return ok/B,np.median(tot),ru/B

for nm,fn in [('brk20',sig_brk20),('mom240',sig_mom240),('ma200',sig_ma200)]:
    S=seq_of(fn)
    per=np.array([s.mean() for s in S])
    t=per.mean()/(per.std(ddof=1)/np.sqrt(len(per)))
    print(f'\n  【{nm}】 后半时间 E(R)={per.mean():+.4f}  品种级t={t:+.2f}  E>0比例={np.mean(per>0):.0%}')
    print(f'  {"仓位f":<8}{"P(赚回本金)":>14}{"最终盈亏中位":>14}{"爆仓率":>10}')
    for f in [0.01,0.02,0.03]:
        r=harvest(S,f)
        if r: print(f'  {f:<8.1%}{r[0]:>14.1%}{r[1]:>14.0f}{r[2]:>10.1%}')
    # 零期望对照
    Sz=[s-s.mean() for s in S]
    r0=harvest(Sz,0.02)
    if r0: print(f'  [E=0对照] f=2%: P={r0[0]:.1%} 盈亏中位={r0[1]:.0f} 爆仓={r0[2]:.1%}')
