import numpy as np, pandas as pd
FILES={'DOGE':'/data/inputs/DOGEUSDT_1h.csv','DOT':'/data/inputs/DOTUSDT_1h.csv',
       'CRV':'/data/inputs/CRVUSDT_1h.csv','DASH':'/data/inputs/DASHUSDT_1h.csv',
       'ETH':'/data/inputs/ETHUSDT_1h.csv','FIL':'/data/inputs/FILUSDT_1h.csv',
       'HBAR':'/data/inputs/HBARUSDT_1h.csv'}
def load():
    o={}
    for k,p in FILES.items():
        d=pd.read_csv(p);c={x.lower():x for x in d.columns}
        o[k]=dict(open=d[c['open']].values.astype(float),high=d[c['high']].values.astype(float),
                  low=d[c['low']].values.astype(float),close=d[c['close']].values.astype(float))
    return o
def s_mom(cl,w):
    n=len(cl);s=np.zeros(n);s[w:]=np.sign(cl[w:]/np.maximum(cl[:-w],1e-9)-1);return s

def run_diag(D,sg,s=0.05,R=2.0,cost_bp=2,slip_bp=5,max_hold=800,start=0,end=None):
    op,hi,lo,cl=D['open'],D['high'],D['low'],D['close']
    n=len(cl) if end is None else min(end,len(cl))
    cR=2*cost_bp/1e4/s; slipR=slip_bp/1e4/s; stopd=s+slip_bp/1e4
    recs=[]
    i=max(start,120)
    while i<n-3:
        d=1 if sg[i]>0 else (-1 if sg[i]<0 else 0)
        if d==0: i+=1;continue
        e=op[i+1];i0=i+1;out=None;j=i0;kind='timeout'
        for jj in range(i0,min(i0+max_hold,n)):
            adv=(lo[jj]/e-1) if d==1 else (1-hi[jj]/e)
            fav=(hi[jj]/e-1) if d==1 else (1-lo[jj]/e)
            if adv<=-stopd: out=-1.0-slipR;j=jj;kind='stop';break
            if fav>=R*s: out=R;j=jj;kind='target';break
            if sg[jj]*d<0: out=((cl[jj]/e-1)*d)/s;j=jj;kind='flip';break
        if out is None:
            j=min(i0+max_hold,n-1);out=((cl[j]/e-1)*d)/s;kind='timeout'
        recs.append(dict(kind=kind,gross=out,net=out-cR,hold=j-i0))
        i=j+1
    return pd.DataFrame(recs)

data=load()
print("="*100)
print("【诊断】为什么 R=2 胜率63% 而 E<0 ?  分解出场类型")
print("="*100)
for nm,inv in [('rev_5(反转)',True),('mom_5(动量)',False)]:
    frames=[]
    for k,D in data.items():
        n=len(D['close'])
        sg=s_mom(D['close'],5)
        if inv: sg=-sg
        f=run_diag(D,sg,s=0.05,R=2.0,start=n//2,end=n)
        if len(f)>=30: frames.append(f)
    df=pd.concat(frames,ignore_index=True)
    print(f"\n### {nm}  N={len(df)}")
    print(f"  整体: 胜率(net>0)={(df.net>0).mean()*100:.1f}%  E(net)={df.net.mean():+.4f}R")
    print(f"\n  {'出场类型':<10}{'占比':>8}{'次数':>8}{'平均gross(R)':>14}{'平均net(R)':>13}{'该类型胜率':>11}")
    print("  "+"-"*66)
    for kind in ['flip','stop','target','timeout']:
        sub=df[df.kind==kind]
        if len(sub)==0: continue
        print(f"  {kind:<10}{len(sub)/len(df)*100:>7.1f}%{len(sub):>8}{sub.gross.mean():>+14.4f}{sub.net.mean():>+13.4f}{(sub.net>0).mean()*100:>10.1f}%")
    print(f"\n  验算: E = Σ(占比 × 平均gross) - 成本")
    chk=(df.groupby('kind').size()/len(df)*df.groupby('kind').gross.mean()).sum()
    print(f"    加权gross={chk:+.4f}  成本cR={2*2e-4/0.05:+.4f}  合计={chk-2*2e-4/0.05:+.4f}  (实际E={df.net.mean():+.4f})")
print("\n"+"="*100)
