"""
【工程方案】三杠杆叠加 —— 把 0.4pp 的缺口补上
============================================================
【处境】
  p* = 33.6%, 实测胜率 ≈33.2%  -> 差 0.4pp
  N≈450 时胜率标准误 ±2.2pp -> 信噪比 0.18 (不可证实)

【三个可控工程杠杆】
  L1 提高N:     池化4品种 (450 -> ~1700笔), 标准误 ÷2
  L2 降成本:    maker(2bp) -> 返佣(0bp), p* 从33.6% -> 33.3%
  L3 入场优化:  vol_mid 等把胜率从33.3% -> 39.2%

【新增工程技巧(专门针对"胜率不够")】
  X1 保本移动:  浮盈达1R后止损移到保本 -> 剩余仓位"不可能亏"
                -> 把大量小亏转化为"打平/小赢" -> 提高胜率
  X2 分批止盈:  一半在1R了结, 一半追踪 -> 兼顾胜率与盈亏比
  X3 时间止损:  超过N根bar未达目标则平 -> 释放资金提高N

【关键: 都要样本外验证 + 池化统计】
"""
import numpy as np
import pandas as pd
from scipy import stats

HOURLY = {'DOGE': '/data/inputs/DOGEUSDT_1h.csv',
          'DOT':  '/data/inputs/DOTUSDT_1h.csv',
          'CRV':  '/data/inputs/CRVUSDT_1h.csv',
          'DASH': '/data/inputs/DASHUSDT_1h.csv'}


def load():
    out = {}
    for k, p in HOURLY.items():
        d = pd.read_csv(p)
        out[k] = dict(high=d['high'].values, low=d['low'].values,
                      close=d['close'].values)
    return out


def momentum_signal(cl, w):
    n = len(cl)
    s = np.zeros(n)
    s[w:] = np.sign(cl[w:] / np.maximum(cl[:-w], 1e-9) - 1)
    return s


def build_entries(D):
    cl = D['close']; hi = D['high']; lo = D['low']
    n = len(cl)
    S = {}
    ret = np.zeros(n); ret[1:] = cl[1:] / np.maximum(cl[:-1], 1e-9) - 1
    vol = pd.Series(np.abs(ret)).rolling(48).mean().values
    vq = np.nanpercentile(vol[~np.isnan(vol)], [33, 67])
    mom60 = momentum_signal(cl, 60)
    mom5 = momentum_signal(cl, 5)
    S['mom_60'] = mom60
    S['mom_5'] = mom5
    S['vol_mid'] = np.where((vol > vq[0]) & (vol < vq[1]), mom60, 0.0)
    S['vol_mid_mom5'] = np.where((vol > vq[0]) & (vol < vq[1]), mom5, 0.0)
    return S


def run_trades(D, signal, s, R, cost_bp=2, max_hold=800,
               tie='conservative', exit_mode='fixed',
               be_at=1.0, scale_frac=0.5, start=0, end=None):
    """exit_mode: fixed / breakeven / scale
    breakeven: 浮盈达 be_at*R 后止损移到保本(0)
    scale:     一半在 R 了结, 另一半追踪(回撤R*s)
    """
    hi, lo, cl = D['high'], D['low'], D['close']
    n = len(cl) if end is None else min(end, len(cl))
    cost_R = 2 * cost_bp / 1e4 / s if exit_mode == 'fixed' else \
             (2 * cost_bp / 1e4 / s) * (1 + scale_frac if exit_mode == 'scale' else 1)

    net = []
    i = max(start, 120)
    while i < n - 2:
        sg = signal[i]
        if sg == 0:
            i += 1; continue
        direction = 1 if sg > 0 else -1
        entry = cl[i]
        out_R = None
        j = i
        moved_be = False
        scaled = False
        peak = 0.0
        for jj in range(i + 1, min(i + max_hold, n)):
            mv = (cl[jj] / entry - 1) * direction
            hm = (hi[jj] / entry - 1) * direction
            lm = (lo[jj] / entry - 1) * direction
            peak = max(peak, hm)

            cur_sl = -s
            if exit_mode == 'breakeven' and moved_be:
                cur_sl = 0.0
            if exit_mode == 'breakeven' and not moved_be and hm >= be_at * R * s:
                moved_be = True
                cur_sl = 0.0

            if exit_mode == 'scale':
                if not scaled and hm >= R * s:
                    scaled = True
                    out_R = scale_frac * R + (1 - scale_frac) * 0
                    continue
                if scaled:
                    if lm <= peak - R * s:
                        out_R = scale_frac * R + (1 - scale_frac) * (peak - R * s) / s
                        j = jj; break
                    if lm <= -s:
                        out_R = scale_frac * R + (1 - scale_frac) * (-1)
                        j = jj; break
                    continue

            hs = lm <= cur_sl
            ht = hm >= R * s
            if hs and ht:
                out_R = -1.0 if tie == 'conservative' else R
                j = jj; break
            if hs:
                out_R = -1.0 if not moved_be else 0.0
                j = jj; break
            if ht:
                out_R = R; j = jj; break
        if out_R is None:
            j = min(i + max_hold, n - 1)
            mv = (cl[j] / entry - 1) * direction
            out_R = mv / s if exit_mode != 'scale' else \
                    (scale_frac * R if scaled else mv / s)
        net.append(out_R - cost_R)
        i = j + 1
    return np.array(net)


def stats_of(net):
    if len(net) < 30: return None
    E = net.mean()
    t = E / (net.std() / np.sqrt(len(net))) if net.std() > 0 else 0
    return dict(n=len(net), win=(net > 0).mean(), E_R=E, t=t)


def path_risk(net, f=0.01, init=10000.0):
    nav = np.empty(len(net) + 1); nav[0] = init
    for i, r in enumerate(net):
        nav[i + 1] = nav[i] * (1.0 + f * r)
        if nav[i + 1] <= 0: nav[i + 1:] = 0; break
    mc, cur = 0, 0
    for r in net:
        if r < 0: cur += 1; mc = max(mc, cur)
        else: cur = 0
    pk = np.maximum.accumulate(nav)
    return dict(final=nav[-1],
                mdd=-((nav - pk) / np.maximum(pk, 1e-12)).min() * 100,
                max_consec=mc)


data = load()
print("=" * 100)
print("【工程方案】三杠杆 + 出场技巧 —— 补上 0.4pp 缺口")
print("=" * 100)

S_STOP, R_MULT = 0.05, 2.0

# ---------- L2: 成本降低对 p* 的影响 ----------
print(f"\n  【L2】降成本 -> p* 下降")
print(f"  {'成本(bp)':>9}{'cost_R':>10}{'p*':>10}{'vs实测33.2%':>14}")
print("  " + "-" * 46)
for c in [2, 1, 0, -1]:
    cr = 2 * c / 1e4 / S_STOP
    ps = (1 + cr) / (1 + R_MULT)
    print(f"  {c:>9}{cr:>+10.4f}{ps*100:>9.2f}%{(ps-0.332)*100:>+13.2f}pp")

# ---------- 出场技巧 ----------
print(f"\n  【X】出场技巧 (DOGE样本外, mom_60, maker 2bp)")
print(f"  {'方式':<14}{'笔数':>7}{'胜率':>9}{'E(R)':>10}{'t':>8}{'回撤':>8}{'连亏':>7}")
print("  " + "-" * 66)
D = data['DOGE']; cl = D['close']; n = len(cl); sp = n // 2
S = build_entries(D)
for mode in ['fixed', 'breakeven', 'scale']:
    net = run_trades(D, S['mom_60'], S_STOP, R_MULT, cost_bp=2,
                     exit_mode=mode, start=sp, end=n)
    st = stats_of(net)
    if st is None: continue
    pr = path_risk(net)
    print(f"  {mode:<14}{st['n']:>7}{st['win']*100:>8.1f}%{st['E_R']:>+10.3f}"
          f"{st['t']:>+8.2f}{pr['mdd']:>7.1f}%{pr['max_consec']:>7}")

# ---------- L1: 池化4品种 ----------
print(f"\n  【L1+L3】池化4品种 (样本外, maker 2bp, s=5%, R=2)")
print(f"  {'入场':<14}{'出场':<11}{'总笔数':>8}{'胜率':>9}{'E(R)':>10}{'t':>8}{'判定':>8}")
print("  " + "-" * 68)

pool_results = {}
for enm in ['mom_60', 'mom_5', 'vol_mid', 'vol_mid_mom5']:
    for mode in ['fixed', 'breakeven', 'scale']:
        allnet = []
        for sym in ['DOGE', 'CRV', 'DOT', 'DASH']:
            D2 = data[sym]
            S2 = build_entries(D2)
            n2 = len(D2['close']); sp2 = n2 // 2
            nt = run_trades(D2, S2[enm], S_STOP, R_MULT, cost_bp=2,
                            exit_mode=mode, start=sp2, end=n2)
            if len(nt) >= 30:
                allnet.append(nt)
        if not allnet: continue
        cat = np.concatenate(allnet)
        st = stats_of(cat)
        if st is None: continue
        flag = '★显著' if (st['t'] > 1.96 and st['E_R'] > 0) else ''
        pool_results[(enm, mode)] = st
        print(f"  {enm:<14}{mode:<11}{st['n']:>8}{st['win']*100:>8.1f}%"
              f"{st['E_R']:>+10.3f}{st['t']:>+8.2f}{flag:>8}")

# ---------- 最优组合在 0 成本下 ----------
print(f"\n  【叠加 L2】最优组合 + 返佣(0bp)")
best = max(pool_results.items(), key=lambda x: x[1]['t']) if pool_results else None
for (enm, mode), st in sorted(pool_results.items(), key=lambda x: -x[1]['t'])[:3]:
    allnet = []
    for sym in ['DOGE', 'CRV', 'DOT', 'DASH']:
        D2 = data[sym]; S2 = build_entries(D2)
        n2 = len(D2['close']); sp2 = n2 // 2
        nt = run_trades(D2, S2[enm], S_STOP, R_MULT, cost_bp=0,
                        exit_mode=mode, start=sp2, end=n2)
        if len(nt) >= 30: allnet.append(nt)
    cat = np.concatenate(allnet)
    st0 = stats_of(cat)
    pr = path_risk(cat)
    if st0:
        print(f"  {enm:<14}{mode:<11} N={st0['n']:>5} 胜率{st0['win']*100:>5.1f}% "
              f"E={st0['E_R']:+.3f}R t={st0['t']:+.2f} 终值{pr['final']:.0f} "
              f"回撤{pr['mdd']:.1f}% 连亏{pr['max_consec']}")

print("\n" + "=" * 100)
print("完成")
print("=" * 100)
