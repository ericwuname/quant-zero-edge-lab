"""
【当下可实现】做市/挂单收价差 —— 唯一"有岗位"且可执行的路
================================================================
【为什么这是新东西】
  1. 不预测方向 -> 不受"方向不可预测"结论影响
  2. 双边挂单 -> 【对bar内路径不敏感】
     之前所有方向策略都死在"不知high/low谁先到"
     做市双边挂单: 只要两边都触及就赚2δ, 顺序无关!
  3. 10k可做 (现货, 不需要期货门槛)
  4. 用户有编程能力 -> 可实现自动化挂单
  5. 有经济学岗位: 提供流动性, 收价差 (不是猜方向)

【模拟设计】(用真实1h OHLC, 保守假设)
  每bar以开盘价为参考:
    bid = open*(1-δ), ask = open*(1+δ)
    若 low  <= bid -> 买入成交
    若 high >= ask -> 卖出成交
    双边成交 -> 赚 2δ
    单边成交 -> 库存变化 (承担方向风险)
  保守: 若双边都触及, 假设都成交(中性, 对做市合理)

【扫描】
  δ: 0.1% ~ 2%
  成本: maker 2bp 单边
  对比: 买入持有 (BH)
  指标: 夏普 (关键! 做市不承担beta, 看风险调整后)
"""
import numpy as np
import pandas as pd
from scipy import stats

HOURLY = {'DOGE': '/data/inputs/DOGEUSDT_1h.csv',
          'DOT':  '/data/inputs/DOTUSDT_1h.csv',
          'CRV':  '/data/inputs/CRVUSDT_1h.csv',
          'DASH': '/data/inputs/DASHUSDT_1h.csv'}
BARS_YR = 365 * 24
COST_BP = 2          # maker 单边成本


def load_hourly():
    out = {}
    for k, p in HOURLY.items():
        d = pd.read_csv(p)
        out[k] = pd.DataFrame({
            'open': d['open'].values, 'high': d['high'].values,
            'low': d['low'].values, 'close': d['close'].values,
        })
    return out


def market_make(df, delta, cost_bp=COST_BP, init_cash=0.5, inv_limit=3.0):
    """
    做市模拟
    init_cash: 初始现金比例 (0.5 = 半仓)
    inv_limit: 库存上限(相对初始资金)
    """
    o = df['open'].values
    h = df['high'].values
    l = df['low'].values
    c = df['close'].values
    n = len(o)

    cash = init_cash
    inv = 1.0 - init_cash          # 初始持仓
    p0 = c[0]
    unit = 0.2                      # 每笔成交的仓位单位

    trades = 0
    for t in range(n):
        bid = o[t] * (1 - delta)
        ask = o[t] * (1 + delta)
        hit_bid = l[t] <= bid       # 有人砸给我 -> 我买入
        hit_ask = h[t] >= ask       # 有人买我的 -> 我卖出

        if hit_bid and inv < inv_limit:
            # 我买入 (支付 bid)
            cost = bid * unit * (1 + cost_bp / 1e4)
            if cash >= cost:
                cash -= cost
                inv += unit
                trades += 1
        if hit_ask and inv > 0:
            # 我卖出 (收到 ask)
            qty = min(unit, inv)
            cash += ask * qty * (1 - cost_bp / 1e4)
            inv -= qty
            trades += 1

    # 最终按收盘价平仓
    final_cash = cash + inv * c[-1]
    # 净值序列 (逐bar重估)
    nav = np.zeros(n)
    cash_t, inv_t = init_cash, 1.0 - init_cash
    for t in range(n):
        bid = o[t] * (1 - delta)
        ask = o[t] * (1 + delta)
        if l[t] <= bid and inv_t < inv_limit:
            cost = bid * unit * (1 + cost_bp / 1e4)
            if cash_t >= cost:
                cash_t -= cost; inv_t += unit
        if h[t] >= ask and inv_t > 0:
            qty = min(unit, inv_t)
            cash_t += ask * qty * (1 - cost_bp / 1e4)
            inv_t -= qty
        nav[t] = cash_t + inv_t * c[t]

    ret = np.zeros(n)
    ret[1:] = nav[1:] / np.maximum(nav[:-1], 1e-12) - 1
    return ret, trades, nav


def sharpe(x, periods=BARS_YR):
    s = x.std()
    return x.mean() / s * np.sqrt(periods) if s > 1e-12 else 0.0


def ann_nav(x, periods=BARS_YR):
    nav = np.cumprod(1.0 + np.clip(x, -0.99, None))
    if len(nav) == 0 or nav[-1] <= 0:
        return -100.0
    return (nav[-1] ** (periods / len(x)) - 1) * 100


def mdd(x):
    nav = np.cumprod(1.0 + np.clip(x, -0.99, None))
    pk = np.maximum.accumulate(nav)
    return float(-((nav - pk) / np.maximum(pk, 1e-12)).min() * 100)


print("=" * 100)
print("【当下可实现】做市/挂单收价差 —— 不预测方向, 收流动性服务费")
print("=" * 100)
print("  结构性优势: 双边挂单 -> 对bar内路径【不敏感】(绕开一路的死穴)")
print(f"  成本假设: maker {COST_BP}bp 单边")

data = load_hourly()
print(f"\n  数据: {len(data)} 品种, 每品种 {len(data['DOGE'])} 根1小时线")

sp_frac = 0.5          # 样本外从50%开始
print(f"\n  【扫描】网格宽度 δ -> 样本外表现 (vs 买入持有)")
print(f"  {'品种':<7}{'δ':>7}{'年化':>11}{'夏普':>9}{'回撤':>9}"
      f"{'BH年化':>10}{'BH夏普':>9}{'BH回撤':>9}{'成交数':>8}")
print("  " + "-" * 80)

deltas = [0.001, 0.002, 0.005, 0.01, 0.02]
summary = []

for sym, df in data.items():
    n = len(df)
    sp = int(n * sp_frac)
    c = df['close'].values
    # BH
    bh_ret = np.zeros(n)
    bh_ret[1:] = c[1:] / np.maximum(c[:-1], 1e-12) - 1
    bh_oos = bh_ret[sp:]
    a_bh, s_bh, d_bh = ann_nav(bh_oos), sharpe(bh_oos), mdd(bh_oos)

    for d in deltas:
        ret, trades, nav = market_make(df, d, COST_BP)
        oos = ret[sp:]
        a, s, dd = ann_nav(oos), sharpe(oos), mdd(oos)
        print(f"  {sym:<7}{d*100:>6.1f}%{a:>10.2f}%{s:>9.3f}{dd:>8.2f}%"
              f"{a_bh:>9.2f}%{s_bh:>9.3f}{d_bh:>8.2f}%{trades:>8}")
        summary.append((sym, d, a, s, dd, a_bh, s_bh, d_bh, trades))

# ---------- 汇总 ----------
print(f"\n" + "=" * 100)
print(f"  【汇总】做市 vs 买入持有 (样本外)")
print(f"  {'δ':>7}{'做市年化':>11}{'做市夏普':>10}{'做市回撤':>10}"
      f"{'BH夏普':>9}{'夏普差':>9}{'回撤差':>9}{'做市胜?':>9}")
print("  " + "-" * 74)

for d in deltas:
    sub = [x for x in summary if x[1] == d]
    a_m = np.mean([x[2] for x in sub])
    s_m = np.mean([x[3] for x in sub])
    dd_m = np.mean([x[4] for x in sub])
    s_b = np.mean([x[6] for x in sub])
    dd_b = np.mean([x[7] for x in sub])
    win = '★是' if s_m > s_b else '否'
    print(f"  {d*100:>6.1f}%{a_m:>10.2f}%{s_m:>10.3f}{dd_m:>9.2f}%"
          f"{s_b:>9.3f}{s_m-s_b:>+9.3f}{dd_m-dd_b:>+8.2f}pp{win:>9}")

# ---------- 关键: 做市是否真的不预测方向? ----------
print(f"\n" + "=" * 100)
print(f"  【验证】做市收益与方向的相关性 (若≈0 -> 真不靠方向)")
print(f"  {'品种':<7}{'δ':>7}{'相关系数':>12}{'判定':>14}")

for sym, df in list(data.items())[:2]:
    c = df['close'].values
    n = len(c); sp = int(n * sp_frac)
    bh = np.zeros(n); bh[1:] = c[1:] / np.maximum(c[:-1], 1e-12) - 1
    for d in [0.005, 0.02]:
        ret, _, _ = market_make(df, d, COST_BP)
        oos = ret[sp:]
        rho = np.corrcoef(oos, bh[sp:])[0, 1]
        verdict = '✓低相关' if abs(rho) < 0.3 else '高相关(仍靠beta)'
        print(f"  {sym:<7}{d*100:>6.1f}%{rho:>+12.3f}{verdict:>14}")

print("\n" + "=" * 100)
print("完成")
print("=" * 100)
