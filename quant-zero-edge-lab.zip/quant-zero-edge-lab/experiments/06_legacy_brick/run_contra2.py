"""
矛盾论 v2 主实验 —— 检验重构是否有效
============================================
关键检验:
  0. 尺度分解本身对不对? (各市场的主导尺度应不同)
  1. 铁律: 随机游走(矛盾未分化) -> 扣成本后 <= 本金
  2. 抓主要矛盾: 各市场的主导尺度是否被正确识别?
  3. 度: 集中度阈值是否有效? (混沌市场集中度应低)
  4. 对比 v1(胜率择时/循环论证) vs v2(结构分析)
"""
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from zoo_tick import (brick_events, cont_returns, run_single, sig_const,
                      sig_stat_mom, INIT_CAP, TICKS_PER_HOUR, HOURS_PER_YEAR)
from contradiction2 import (gen_mkt, multi_scale, scale_energy,
                            run_contra2, run_contra_v1)

plt.rcParams['font.sans-serif'] = ['WenQuanYi Micro Hei', 'DejaVu Sans']
plt.rcParams['axes.unicode_minus'] = False

N = 60000
ANN = 0.20
SIG = ANN / np.sqrt(TICKS_PER_HOUR * HOURS_PER_YEAR)
NPATH = 8
A = 5 * SIG
YEARS = N / (TICKS_PER_HOUR * HOURS_PER_YEAR)

MKS = ['rw', 'weakmom', 'oscill', 'regime', 'compress']
MK_NAME = {'rw': '随机游走\n(混沌)', 'weakmom': '弱动量\n(趋势主导)',
           'oscill': '震荡\n(快尺度主导)', 'regime': '体制切换\n(矛盾转化)',
           'compress': '压缩-突破\n(量变到质变)'}

print("=" * 100)
print(f"矛盾论 v2: {YEARS:.1f}年  本金{INIT_CAP:.0f}  每笔风险1%  {NPATH}路径")
print("  v1 = 胜率择时(循环论证)  vs  v2 = 多尺度结构分析")
print("=" * 100)

# ============================================================
# 检验0: 尺度分解本身对不对?
# ============================================================
print("\n### 检验0: 多尺度分解 —— 各市场的主导尺度应该不同")
print("  (尺度索引: 0=快/震荡, 1=中, 3=慢/趋势)")
print(f"\n  {'市场':<16}{'快':>8}{'中':>8}{'慢':>8}{'集中度':>10}  主导尺度")

dom_stats = {}
for mk in MKS:
    doms, concs = [], []
    for s in range(5):
        px = gen_mkt(mk, N, SIG, seed=100 + s)
        comps = multi_scale(px)
        dom, conc = scale_energy(comps, win=500)
        valid = dom >= 0
        if valid.sum() > 0:
            doms.append(np.bincount(dom[valid], minlength=comps.shape[0]).argmax())
            concs.append(np.mean(conc[valid]))
    dom_stats[mk] = (np.mean(doms), np.mean(concs))
    label = ['快', '中', '中慢', '慢'][int(np.mean(doms))]
    print(f"  {MK_NAME[mk].split(chr(10))[0]:<16}"
          f"{'':>8}{'':>8}{'':>8}{np.mean(concs):>10.3f}  尺度{int(np.mean(doms))}({label})")

# ============================================================
# 检验1+2+3: 完整回测
# ============================================================
print("\n" + "=" * 100)
print("### 检验1-3: 完整回测 (中位终值, 本金 10000)")
print("=" * 100)

res = {}
for mk in MKS:
    res[mk] = {}
    fs_v2, dds_v2, skips = [], [], []
    fs_v1, dds_v1 = [], []
    concs_all = []
    for s in range(NPATH):
        px = gen_mkt(mk, N, SIG, seed=200 + s)
        # v2: 结构分析
        r2 = run_contra2(px, A, W_energy=500, conc_thr=0.40)
        fs_v2.append(r2['final']); dds_v2.append(r2['maxdd'])
        skips.append(r2['n_skip'])
        concs_all.append(r2['conc_mean'])
        # v1: 胜率择时(需要砖块事件)
        e = brick_events(px, A)
        if e is not None:
            b, lp = e
            if len(b) >= 400:
                cr = cont_returns(b, lp)
                r1 = run_contra_v1(cr, A)
                fs_v1.append(r1['final']); dds_v1.append(r1['maxdd'])
    res[mk]['v2'] = dict(f=np.array(fs_v2), med=float(np.median(fs_v2)),
                         dd=float(np.median(dds_v2)),
                         skip=float(np.mean(skips)),
                         conc=float(np.mean(concs_all)))
    if fs_v1:
        res[mk]['v1'] = dict(f=np.array(fs_v1), med=float(np.median(fs_v1)),
                             dd=float(np.median(dds_v1)))

print(f"\n  {'市场':<16}{'v2中位':>10}{'v2回撤':>9}{'v1中位':>10}{'v1回撤':>9}"
      f"{'集中度':>9}{'空仓率':>9}")
for mk in MKS:
    v2 = res[mk]['v2']
    v1 = res[mk].get('v1', {})
    v1m = v1.get('med', np.nan)
    v1d = v1.get('dd', np.nan)
    print(f"  {MK_NAME[mk].split(chr(10))[0]:<16}{v2['med']:>10.0f}{v2['dd']*100:>8.1f}%"
          f"{v1m:>10.0f}{v1d*100:>8.1f}%{v2['conc']:>9.3f}{v2['skip']/N*100:>8.0f}%")

print("\n  铁律: 随机游走(混沌)市场 v2 中位应 <= 10000 ->", end=" ")
print("OK" if res['rw']['v2']['med'] <= INIT_CAP * 1.05 else "违反")

print("\n" + "-" * 100)
print("稳健性排名 (按最差市场)")
print("-" * 100)
all_meds = {mk: res[mk]['v2']['med'] for mk in MKS}
rank = sorted(MKS, key=lambda m: -all_meds[m])
print(f"  {'排名':<5}{'市场':<16}{'v2中位':>10}{'收益':>10}")
for i, mk in enumerate(rank, 1):
    print(f"  {i:<5}{MK_NAME[mk].split(chr(10))[0]:<16}{all_meds[mk]:>10.0f}"
          f"{(all_meds[mk]/INIT_CAP-1)*100:>+9.1f}%")

worst = all_meds[rank[-1]]
print(f"\n  v2 最差市场: {MK_NAME[rank[-1]].split(chr(10))[0]} = {worst:.0f} "
      f"({(worst/INIT_CAP-1)*100:+.1f}%)")
print(f"  v2 全市场中位均值: {np.mean(list(all_meds.values())):.0f}")

# ============================================================
# 检验4: 度的扫描 (集中度阈值)
# ============================================================
print("\n" + "=" * 100)
print("### 检验4: 度 = 集中度阈值 conc_thr")
print("=" * 100)
print(f"  {'conc_thr':>9}" + "".join(f"{MK_NAME[m].split(chr(10))[0]:>11}" for m in MKS)
      + f"{'最差':>10}{'平均空仓率':>11}")

thr_rows = []
for thr in [0.0, 0.30, 0.35, 0.40, 0.50, 0.60, 0.75]:
    meds = {}
    skips = []
    for mk in MKS:
        fs, sk = [], []
        for s in range(NPATH):
            px = gen_mkt(mk, N, SIG, seed=200 + s)
            r = run_contra2(px, A, W_energy=500, conc_thr=thr)
            fs.append(r['final']); sk.append(r['n_skip'] / N)
        meds[mk] = float(np.median(fs))
        skips.append(np.mean(sk))
    worst = min(meds.values())
    thr_rows.append((thr, meds, worst, np.mean(skips)))
    print(f"  {thr:>9.2f}" + "".join(f"{meds[m]:>11.0f}" for m in MKS)
          + f"{worst:>10.0f}{np.mean(skips)*100:>10.0f}%")

best_thr = max(thr_rows, key=lambda r: r[2])
print(f"\n  最优度: conc_thr ≈ {best_thr[0]:.2f} (最差 {best_thr[2]:.0f}, "
      f"空仓率 {best_thr[3]*100:.0f}%)")
if best_thr[3] > 0.95:
    print("  ⚠ 若最优度仍对应'几乎完全空仓', 说明矛盾论仍未找到可抓的结构")
else:
    print("  ✓ 最优度伴随真实交易 -> 矛盾论找到了可抓的结构")

# ============================================================
# 图
# ============================================================
fig = plt.figure(figsize=(18, 11))
gs = fig.add_gridspec(2, 2, hspace=0.34, wspace=0.2)
fig.suptitle("矛盾论 v2：多尺度对立统一（结构分析，非胜率择时）",
             fontsize=15, fontweight='bold')

ax = fig.add_subplot(gs[0, 0])
xs = np.arange(len(MKS))
conc_v = [dom_stats[mk][1] for mk in MKS]
ax.bar(xs, conc_v, color=plt.cm.viridis(np.linspace(0.2, 0.9, len(MKS))))
ax.axhline(0.40, color='red', ls='--', lw=2, label='度的门槛 0.40')
ax.set_xticks(xs)
ax.set_xticklabels([MK_NAME[m] for m in MKS], fontsize=8.5)
ax.set_ylabel("能量集中度")
ax.set_title("① 矛盾的“度”：能量集中度\n低=混沌未分化(不该出手) 高=矛盾明确", fontsize=11)
ax.legend(fontsize=9)
ax.grid(alpha=.3, axis='y')
for i, v in enumerate(conc_v):
    ax.text(i, v + 0.01, f"{v:.3f}", ha='center', fontsize=9)

ax = fig.add_subplot(gs[0, 1])
x = np.arange(len(MKS))
w = 0.36
ax.bar(x - w / 2, [res[mk]['v2']['med'] for mk in MKS], w,
       label='v2 结构分析', color='steelblue')
ax.bar(x + w / 2, [res[mk].get('v1', {}).get('med', 0) for mk in MKS], w,
       label='v1 胜率择时', color='salmon')
ax.axhline(INIT_CAP, color='k', ls='--', lw=2, label='本金')
ax.set_xticks(x)
ax.set_xticklabels([MK_NAME[m].split("\n")[0] for m in MKS], fontsize=8.5, rotation=15)
ax.set_ylabel("中位终值 (元)")
ax.set_title("② v1(循环论证) vs v2(结构分析)", fontsize=11)
ax.legend(fontsize=9)
ax.grid(alpha=.3, axis='y')

ax = fig.add_subplot(gs[1, 0])
thrs = [r[0] for r in thr_rows]
for mk in MKS:
    ax.plot(thrs, [r[1][mk] for r in thr_rows], 'o-', lw=2,
            label=MK_NAME[mk].split("\n")[0])
ax.axhline(INIT_CAP, color='k', ls='--', lw=1.5)
ax.axvline(best_thr[0], color='green', ls=':', lw=2, label=f'最优 {best_thr[0]:.2f}')
ax.set_xlabel("度: 集中度阈值")
ax.set_ylabel("终值 (元)")
ax.set_title("③ 度的扫描：各市场 vs 集中度门槛", fontsize=11)
ax.legend(fontsize=8)
ax.grid(alpha=.3)

ax = fig.add_subplot(gs[1, 1])
skips_v = [thr_rows[i][3] * 100 for i in range(len(thr_rows))]
ax.plot(thrs, skips_v, 's-', color='purple', lw=2.4, ms=8)
ax.set_xlabel("度: 集中度阈值")
ax.set_ylabel("空仓率 %")
ax.set_title("④ 关键诊断：最优度是否=完全空仓?\n若最高点接近100% -> 策略不该存在", fontsize=11)
ax.grid(alpha=.3)
for i, v in enumerate(skips_v):
    ax.text(thrs[i], v + 2, f"{v:.0f}%", ha='center', fontsize=8.5)

plt.savefig("/data/workspace/brick/fig_contra2.png", dpi=130)
print("\n[已保存] fig_contra2.png")
