"""
【最终】当下可实现的方案 —— 混合配置 + 波动率防护
==========================================================
【上一轮发现】
  做市平均夏普 0.277 vs BH 0.350 (略输)
  BUT 回撤 55.96% vs 86.44% (低 30pp!)  <- 真实且显著
  且反例: CRV δ=0.5% 做市年化+13.89%/夏普0.631/回撤27.51%
          vs BH 年化-10.71%/夏普0.458/回撤86.72%  【大幅跑赢】

【本轮测试】(都是不预测方向、当下可执行的)
  A. 混合配置: 一部分持有(beta) + 一部分做市(降回撤)
     -> 扫描配比, 找最优
  B. 波动率防护: 高波动时暂停做市
     -> 这不是预测方向, 是【风险规避】
     -> 做市最怕趋势, 而高波动常伴随趋势
  C. 回撤优势稳健性: 分品种验证

【关键指标】
  不只是夏普, 还有 CALMAR = 年化/回撤
  -> 若做市/混合能提升 Calmar, 则是真实价值
"""
import numpy as np
import pandas as pd
from scipy import stats

HOURLY = {'DOGE': '/data/inputs/DOGEUSDT_1h.csv',
          'DOT':  '/data/inputs/DOTUSDT_1h.csv',
          'CRV':  '/data/inputs/CRVUSDT_1h.csv',
          'DASH': '/data/inputs/DASHUSDT_1h.csv'}
BARS_YR = 365 * 24
COST_BP = 2


def load_hourly():
    out = {}
    for k, p in HOURLY.items():
        d = pd.read_csv(p)
        out[k] = pd.DataFrame({
            'open': d['open'].values, 'high': d['high'].values,
            'low': d['low'].values, 'close': d['close'].values})
    return out


def market_make(df, delta, cost_bp=COST_BP, init_inv=0.5,
                inv_limit=3.0, vol_filter=None, vol_thresh=None):
    """做市/网格模拟
    vol_filter: 波动率数组, vol_thresh: 超过则不做市(持币不动)
    """
    o = df['open'].values; h = df['high'].values
    l = df['low'].values; c = df['close'].values
    n = len(o)
    cash = 1.0 - init_inv
    inv = init_inv
    unit = 0.2
    nav = np.zeros(n)
    for t in range(n):
        active = True
        if vol_filter is not None and vol_thresh is not None:
            active = vol_filter[t] <= vol_thresh
        if active:
            bid = o[t] * (1 - delta)
            ask = o[t] * (1 + delta)
            if l[t] <= bid and inv < inv_limit:
                cost = bid * unit * (1 + cost_bp / 1e4)
                if cash >= cost:
                    cash -= cost; inv += unit
            if h[t] >= ask and inv > 0:
                qty = min(unit, inv)
                cash += ask * qty * (1 - cost_bp / 1e4)
                inv -= qty
        nav[t] = cash + inv * c[t]
    ret = np.zeros(n)
    ret[1:] = nav[1:] / np.maximum(nav[:-1], 1e-12) - 1
    return ret


def sharpe(x):
    s = x.std()
    return x.mean() / s * np.sqrt(BARS_YR) if s > 1e-12 else 0.0


def ann_nav(x):
    nav = np.cumprod(1.0 + np.clip(x, -0.99, None))
    if len(nav) == 0 or nav[-1] <= 0:
        return -100.0
    return (nav[-1] ** (BARS_YR / len(x)) - 1) * 100


def mdd(x):
    nav = np.cumprod(1.0 + np.clip(x, -0.99, None))
    pk = np.maximum.accumulate(nav)
    return float(-((nav - pk) / np.maximum(pk, 1e-12)).min() * 100)


def calmar(x):
    d = mdd(x)
    return ann_nav(x) / d if d > 0.1 else 0.0


print("=" * 100)
print("【最终】当下可实现的方案: 混合配置 + 波动率防护")
print("=" * 100)
print("  关键: 不预测方向, 只做【配置】与【风险规避】")

data = load_hourly()
sp_frac = 0.5
DELTA = 0.005          # 用上一轮表现较稳的 0.5%

print(f"\n  【A】混合配置: 持有(beta) + 网格(降回撤)")
print(f"  {'配比(网格%)':>11}{'年化':>11}{'夏普':>9}{'回撤':>9}{'Calmar':>9}"
      f"{'判定':>12}")
print("  " + "-" * 62)

# 先算出各品种的 纯持有 与 纯网格 收益序列
series = {}
for sym, df in data.items():
    n = len(df); sp = int(n * sp_frac)
    c = df['close'].values
    bh = np.zeros(n); bh[1:] = c[1:] / np.maximum(c[:-1], 1e-12) - 1
    mm = market_make(df, DELTA, COST_BP)
    series[sym] = (bh[sp:], mm[sp:])

for w_mm in [0.0, 0.25, 0.5, 0.75, 1.0]:
    anns, shs, dds, cls = [], [], [], []
    for sym, (bh, mm) in series.items():
        mix = w_mm * mm + (1 - w_mm) * bh
        anns.append(ann_nav(mix)); shs.append(sharpe(mix))
        dds.append(mdd(mix)); cls.append(calmar(mix))
    a, s, d, cl = np.mean(anns), np.mean(shs), np.mean(dds), np.mean(cls)
    verdict = ''
    if w_mm == 0.0:
        verdict = '(基准:BH)'
    elif w_mm == 1.0:
        verdict = '(纯网格)'
    print(f"  {w_mm*100:>10.0f}%{a:>10.2f}%{s:>9.3f}{d:>8.2f}%{cl:>9.3f}{verdict:>12}")

# ---------- B. 波动率防护 ----------
print(f"\n" + "=" * 100)
print(f"  【B】波动率防护: 高波动时暂停网格(只避险, 不预测方向)")
print(f"  {'波动阈值':>11}{'年化':>11}{'夏普':>9}{'回撤':>9}{'Calmar':>9}"
      f"{'vs无防护':>11}")
print("  " + "-" * 62)

# 用滚动波动率
base_results = {}
for sym, df in data.items():
    c = df['close'].values
    n = len(c); sp = int(n * sp_frac)
    ret0 = np.zeros(n); ret0[1:] = c[1:] / np.maximum(c[:-1], 1e-12) - 1
    vol = pd.Series(ret0).rolling(100).std().values
    vol = np.where(np.isnan(vol), 0, vol)
    base_results[sym] = (df, vol, sp)

for vq in [1.0, 0.9, 0.75, 0.5, 0.25]:
    anns, shs, dds, cls = [], [], [], []
    for sym, (df, vol, sp) in base_results.items():
        if vq >= 1.0:
            mm = market_make(df, DELTA, COST_BP)
        else:
            thr = np.quantile(vol[~np.isnan(vol)], vq)
            mm = market_make(df, DELTA, COST_BP, vol_filter=vol, vol_thresh=thr)
        oos = mm[sp:]
        anns.append(ann_nav(oos)); shs.append(sharpe(oos))
        dds.append(mdd(oos)); cls.append(calmar(oos))
    a, s, d, cl = np.mean(anns), np.mean(shs), np.mean(dds), np.mean(cls)
    tag = '(无防护)' if vq >= 1.0 else f'(暂停{vq*100:.0f}%分位以上)'
    print(f"  {vq*100:>10.0f}%{a:>10.2f}%{s:>9.3f}{d:>8.2f}%{cl:>9.3f}{tag:>14}")

# ---------- C. 分品种: 网格 vs 持有 ----------
print(f"\n" + "=" * 100)
print(f"  【C】分品种: 网格(δ={DELTA*100}%) vs 持有")
print(f"  {'品种':<7}{'持有年化':>11}{'持有夏普':>10}{'持有回撤':>10}"
      f"{'网格年化':>11}{'网格夏普':>10}{'网格回撤':>10}{'网格胜?':>9}")
print("  " + "-" * 78)

wins = 0
for sym, (bh, mm) in series.items():
    a1, s1, d1 = ann_nav(bh), sharpe(bh), mdd(bh)
    a2, s2, d2 = ann_nav(mm), sharpe(mm), mdd(mm)
    win = '★是' if s2 > s1 else '否'
    if s2 > s1:
        wins += 1
    print(f"  {sym:<7}{a1:>10.2f}%{s1:>10.3f}{d1:>9.2f}%"
          f"{a2:>10.2f}%{s2:>10.3f}{d2:>9.2f}%{win:>9}")

print(f"\n  网格跑赢持有的品种: {wins}/{len(series)}")

# 回撤优势
dd_bh = np.mean([mdd(bh) for bh, mm in series.values()])
dd_mm = np.mean([mdd(mm) for bh, mm in series.values()])
print(f"  平均回撤: 持有 {dd_bh:.2f}%  网格 {dd_mm:.2f}%  "
      f"-> 网格低 {dd_bh-dd_mm:.2f}pp")

print("\n" + "=" * 100)
print("完成")
print("=" * 100)
