"""
决定性分解: 新6品种为何两套设计结论相反
1. 多空分解 (beta vs alpha)
2. 与同期买入持有对比
3. 跨批次异质性检验 (批次间方差 vs 批次内)
"""
import numpy as np, pandas as pd

OLD4 = ['DOGE', 'DOT', 'CRV', 'DASH']
NEW3 = ['ETH', 'FIL', 'HBAR']
NEW6 = ['TRX', 'UNI', 'XLM', 'XMR', 'XRP', 'ZEC']
ALL = OLD4 + NEW3 + NEW6


def load():
    o = {}
    for k in ALL:
        d = pd.read_csv(f'/data/inputs/{k}USDT_1h.csv')
        c = {x.lower(): x for x in d.columns}
        o[k] = dict(open=d[c['open']].values.astype(float), high=d[c['high']].values.astype(float),
                    low=d[c['low']].values.astype(float), close=d[c['close']].values.astype(float))
    return o


def s_brk(cl, w):
    n = len(cl)
    s = np.zeros(n)
    for i in range(w, n):
        h = cl[i - w:i].max()
        l = cl[i - w:i].min()
        if cl[i] > h:
            s[i] = 1
        elif cl[i] < l:
            s[i] = -1
    return s


def run_dir(D, sg, s, R, cost_bp, slip_bp, max_hold, start, end, mode):
    """返回带方向的记录"""
    op, hi, lo, cl = D['open'], D['high'], D['low'], D['close']
    n = len(cl) if end is None else min(end, len(cl))
    cR = 2 * cost_bp / 1e4 / s
    slipR = slip_bp / 1e4 / s
    stopd = s + slip_bp / 1e4
    recs = []
    i = max(start, 120)
    while i < n - 3:
        if sg[i] > 0:
            d = 1
        elif sg[i] < 0:
            d = -1
        else:
            i += 1
            continue
        e = op[i + 1]
        i0 = i + 1
        out = None
        j = i0
        kind = 'timeout'
        for jj in range(i0, min(i0 + max_hold, n)):
            adv = (lo[jj] / e - 1) if d == 1 else (1 - hi[jj] / e)
            fav = (hi[jj] / e - 1) if d == 1 else (1 - lo[jj] / e)
            if adv <= -stopd:
                out = -1.0 - slipR
                j = jj
                kind = 'stop'
                break
            if fav >= R * s:
                out = R
                j = jj
                kind = 'target'
                break
            if mode == 'flip' and sg[jj] * d < 0:
                out = ((cl[jj] / e - 1) * d) / s
                j = jj
                kind = 'flip'
                break
        if out is None:
            j = min(i0 + max_hold, n - 1)
            out = ((cl[j] / e - 1) * d) / s
            kind = 'timeout'
        recs.append((k0, 0, 0, 0)) if False else None
        recs.append((kind, out, out - cR, j - i0, d, i0, j))
        i = j + 1
    return pd.DataFrame(recs, columns=['kind', 'gross', 'net', 'hold', 'dir', 'i0', 'i1'])


data = load()
k0 = None

print("=" * 104)
print("决定性分解 1: 多空两侧分解 —— 收益是来自方向(alpha)还是市场暴露(beta)?")
print("=" * 104)

for mode in ['flip', 'target']:
    print(f"\n### {mode}")
    print(f"  {'品种':<7}{'批次':<7}{'多头N':>7}{'多头E':>9}{'空头N':>7}{'空头E':>9}{'多空差':>9}{'多头占比':>9}")
    print("  " + "-" * 76)
    rows = []
    for k in ALL:
        batch = '旧4' if k in OLD4 else ('新3' if k in NEW3 else '新6')
        D = data[k]
        sg = s_brk(D['close'], 20)
        n = len(D['close'])
        f = run_dir(D, sg, 0.05, 2.0, 2, 5, 800, n // 2, n, mode)
        lo_ = f[f.dir == 1]
        sh_ = f[f.dir == -1]
        el = lo_.net.mean() if len(lo_) > 20 else np.nan
        es = sh_.net.mean() if len(sh_) > 20 else np.nan
        longshare = len(lo_) / len(f)
        print(f"  {k:<7}{batch:<7}{len(lo_):>7}{(el if el==el else 0):>+9.4f}{len(sh_):>7}"
              f"{(es if es==es else 0):>+9.4f}{(el-es) if el==el and es==es else 0:>+9.4f}{longshare*100:>8.1f}%")
        rows.append((k, batch, el, es))
    print("  " + "-" * 76)
    df = pd.DataFrame(rows, columns=['k', 'b', 'el', 'es']).dropna()
    for lbl in ['旧4', '新3', '新6']:
        g = df[df.b == lbl]
        print(f"  【{lbl}】多头E={g.el.mean():+.4f}  空头E={g.es.mean():+.4f}  "
              f"差={g.el.mean()-g.es.mean():+.4f}  (若差≈0 → 无方向能力, 全靠beta)")

print("\n" + "=" * 104)
print("决定性分解 2: 与同期买入持有对比 (净E 是 alpha 还是 beta?)")
print("=" * 104)
print(f"  {'品种':<7}{'批次':<7}{'样本外BH年化':>13}{'flip净E':>10}{'target净E':>11}{'flip-BH符号':>13}")
print("  " + "-" * 70)
for k in ALL:
    batch = '旧4' if k in OLD4 else ('新3' if k in NEW3 else '新6')
    D = data[k]
    cl = D['close']
    n = len(cl)
    h = n // 2
    bh = cl[n - 1] / cl[h] - 1
    bh_ann = (1 + bh) ** (365 * 24 / (n - h)) - 1
    sg = s_brk(cl, 20)
    f1 = run_dir(D, sg, 0.05, 2.0, 2, 5, 800, h, n, 'flip')
    f2 = run_dir(D, sg, 0.05, 2.0, 2, 5, 800, h, n, 'target')
    # 策略在场时间占比 → 策略的beta暴露
    exp1 = (f1.i1 - f1.i0).sum() / (n - h)
    exp2 = (f2.i1 - f2.i0).sum() / (n - h)
    net_exposure = (f1.dir * (f1.i1 - f1.i0)).sum() / (n - h)
    print(f"  {k:<7}{batch:<7}{bh_ann*100:>12.1f}%{f1.net.mean():>+10.4f}{f2.net.mean():>+11.4f}"
          f"{np.sign(f1.net.mean())==np.sign(bh):>13}")

print("\n" + "=" * 104)
print("决定性分解 3: 跨批次异质性 —— 批次间差异 vs 统计噪声")
print("=" * 104)
for mode in ['flip', 'target']:
    print(f"\n[{mode}]")
    batchE = {}
    for lbl, keys in [('旧4', OLD4), ('新3', NEW3), ('新6', NEW6)]:
        frames = []
        for k in keys:
            D = data[k]
            sg = s_brk(D['close'], 20)
            n = len(D['close'])
            f = run_dir(D, sg, 0.05, 2.0, 2, 5, 800, n // 2, n, mode)
            frames.append(f)
        df = pd.concat(frames, ignore_index=True)
        batchE[lbl] = df.net.mean()
        se = df.net.std() / np.sqrt(len(df))
        print(f"  {lbl}: E={df.net.mean():+.4f}  SE={se:.4f}  N={len(df)}  95%CI=[{df.net.mean()-1.96*se:+.4f},{df.net.mean()+1.96*se:+.4f}]")
    vals = np.array(list(batchE.values()))
    print(f"  → 三批E的极差 = {vals.max()-vals.min():.4f}")
    print(f"  → 三批E的标准差 = {vals.std(ddof=1):.4f}  (批内SE约 0.02~0.03)")
    print(f"  → 结论: {'批次间差异 >> 批内噪声 → 结果由选哪批数据决定' if vals.std(ddof=1) > 0.025 else '批次间差异与噪声同量级'}")

print("\n" + "=" * 104)
print("决定性分解 4: 剔除异常品种 XMR 后的新6")
print("=" * 104)
for mode in ['flip', 'target']:
    for lbl, keys in [('新6全', NEW6), ('新6去XMR', [k for k in NEW6 if k != 'XMR'])]:
        frames = []
        for k in keys:
            D = data[k]
            sg = s_brk(D['close'], 20)
            n = len(D['close'])
            f = run_dir(D, sg, 0.05, 2.0, 2, 5, 800, n // 2, n, mode)
            frames.append(f)
        df = pd.concat(frames, ignore_index=True)
        se = df.net.std() / np.sqrt(len(df))
        print(f"  [{mode}] {lbl:<10} N={len(df):>5}  E={df.net.mean():+.4f}  t={df.net.mean()/se:+.2f}")

print("\n" + "=" * 104)
print("决定性分解 5: 全13品种合并 (最终总账)")
print("=" * 104)
for mode in ['flip', 'target']:
    frames = []
    for k in ALL:
        D = data[k]
        sg = s_brk(D['close'], 20)
        n = len(D['close'])
        f = run_dir(D, sg, 0.05, 2.0, 2, 5, 800, n // 2, n, mode)
        frames.append(f)
    df = pd.concat(frames, ignore_index=True)
    se = df.net.std() / np.sqrt(len(df))
    t = df.net.mean() / se
    print(f"  [{mode}] N={len(df):>6}  毛E={df.gross.mean():+.4f}  净E={df.net.mean():+.4f}  t={t:+.2f}  "
          f"95%CI=[{df.net.mean()-1.96*se:+.4f},{df.net.mean()+1.96*se:+.4f}]  "
          f"{'显著' if abs(t)>1.96 else '不显著'}")
