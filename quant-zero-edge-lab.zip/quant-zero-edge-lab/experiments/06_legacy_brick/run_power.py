"""
实验F: 最终判据 —— 需要多少笔交易, 才能确认"匹配"?
========================================================
核心公式(统计功效):
    W_req = ((z_alpha + z_beta) * sqrt(p*(1-p)) / delta)^2
    其中 delta = p_true - p*  (真实edge强度, 扣伪影扣成本后)
         z_alpha=1.645 (单边95%假阳性), z_beta=0.84 (80%检出功效)

判据:
    W_req < 你实际能获得的样本量  -> 可检测, 你知道自己是否匹配
    W_req > 你实际能获得的样本量  -> 不可检测 -> 即使有edge, 你也无法"知道"
                                    -> 这就是"必败"的精确数学条件
"""
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

plt.rcParams['font.sans-serif'] = ['WenQuanYi Micro Hei', 'DejaVu Sans']
plt.rcParams['axes.unicode_minus'] = False

Z_A, Z_B = 1.645, 0.84
PSTAR = 0.505


def w_required(delta, pstar=PSTAR, za=Z_A, zb=Z_B):
    if delta <= 1e-9:
        return np.inf
    return ((za + zb) * np.sqrt(pstar * (1 - pstar)) / delta) ** 2


print("=" * 88)
print("实验F: 检测灵敏度 —— 需要多少笔才能确认'匹配'?")
print("=" * 88)
print(f"  公式: W_req = ((1.645+0.84)*sqrt(p*(1-p))/delta)^2,  p*={PSTAR}")
print(f"\n  {'真实edge强度delta':>18} {'含义':>14} {'需要的交易笔数':>16} {'一年250笔要几年':>16}")

deltas = [0.10, 0.08, 0.06, 0.05, 0.04, 0.03, 0.02, 0.01, 0.0074, 0.005]
labels = ["极强", "很强", "强", "强", "中", "中", "弱", "很弱", "MOM实测", "几乎无"]
for d, lb in zip(deltas, labels):
    w = w_required(d)
    yrs = w / 250
    print(f"  {d:>18.4f} {lb:>14} {w:>16.0f} {yrs:>15.1f}年")

print("\n" + "=" * 88)
print("对照实测市场 (本轮实验的真实数据)")
print("=" * 88)
print(f"  {'市场':<12} {'p_true':>8} {'p*':>7} {'delta':>8} {'需要笔数':>11} {'实测可得砖数':>13} {'能否知道?':>12}")

mk_data = [
    ("TRENDVOL", 0.6011, 977, "能(强edge)"),
    ("MOM", 0.5124, 977, "不能(太弱)"),
    ("MR", 0.4903, 977, "不能(反向)"),
    ("RW", 0.5032, 977, "不能(无edge)"),
]
avail = 977
for name, ptru, _, note in mk_data:
    d = ptru - PSTAR
    w = w_required(abs(d)) if d > 0 else np.inf
    can = "是" if (d > 0 and w < avail) else "否"
    print(f"  {name:<12} {ptru:>8.4f} {PSTAR:>7.3f} {d:>+8.4f} {w:>11.0f} {avail:>13} {can:>12}  {note}")

print("\n" + "=" * 88)
print("结论: 你能'知道是否匹配'的条件")
print("=" * 88)
print("  W_req(delta) < 实际可得样本量")
print("")
print("  - 强edge (delta≈0.10, 如TRENDVOL): 需~167笔  -> 一天几笔, 几个月就能确认 ✓")
print("  - 弱edge (delta≈0.007, 如AR1弱动量): 需~28000笔 -> 100年, 永远确认不了 ✗")
print("")
print("  所以: 不是'有没有edge'的问题, 是'edge强到能在你生命内被确认吗'的问题。")
print("        弱edge = 客观存在但不可知 = 对你而言等同于不存在。")

# ============================================================
# 图
# ============================================================
fig, axes = plt.subplots(1, 2, figsize=(15.5, 5.4))
fig.suptitle("“我怎么知道是否匹配？”—— 检测灵敏度：需要多少笔交易才能确认？",
             fontsize=14, fontweight='bold')

ax = axes[0]
ds = np.linspace(0.004, 0.11, 200)
ws = [w_required(d) for d in ds]
ax.semilogy(ds * 100, ws, lw=2.6, color='darkblue')
ax.axhline(avail, color='red', ls='--', lw=2, label=f'实际可得样本量 ≈ {avail} 笔')
ax.axhline(250 * 5, color='orange', ls=':', lw=1.8, label='5年(1250笔)')
ax.axhline(250 * 30, color='green', ls=':', lw=1.8, label='30年(7500笔)')
ax.set_xlabel("真实 edge 强度 delta = p_true − p*  (%)")
ax.set_ylabel("需要的交易笔数（对数）")
ax.set_title("① 检测门槛：edge 越弱，需要的样本量爆炸式增长", fontsize=11)
ax.legend(fontsize=8.5)
ax.grid(alpha=.3, which='both')

for d, nm, c in [(0.096, 'TRENDVOL\n(强)', 'green'), (0.0074, 'MOM\n(弱动量)', 'red')]:
    w = w_required(d)
    ax.plot([d * 100], [w], 'o', ms=11, color=c, zorder=5)
    ax.annotate(f"{nm}\n{w:.0f}笔", (d * 100, w), textcoords="offset points",
                xytext=(12, 18 if d > 0.05 else -38), fontsize=9, color=c, fontweight='bold')

ax = axes[1]
names = ['TRENDVOL\n(强edge)', 'MOM\n(弱动量)', 'MR\n(反向)', 'RW\n(无edge)']
dvals = [0.096, 0.0074, -0.005, -0.002]
wvals = [w_required(abs(d)) if d > 0 else 1e9 for d in dvals]
cols = ['green' if (d > 0 and w_required(d) < avail) else 'salmon' for d in dvals]
ax.bar(range(4), [min(w, 1e6) for w in wvals], color=cols)
ax.axhline(avail, color='red', ls='--', lw=2, label=f'可得 {avail} 笔')
ax.set_yscale('log')
ax.set_xticks(range(4))
ax.set_xticklabels(names, fontsize=9)
ax.set_ylabel("确认所需的交易笔数（对数）")
ax.set_title("② 各市场：能否在可得样本内确认？\n绿=能确认(你知道匹配) 红=确认不了(即使有edge也不可知)",
             fontsize=11)
ax.legend(fontsize=9)
ax.grid(alpha=.3, axis='y')
for i, (w, d) in enumerate(zip(wvals, dvals)):
    if w < 1e6:
        ax.text(i, w * 1.3, f"{w:.0f}", ha='center', fontsize=9, fontweight='bold')
    else:
        ax.text(i, 2e5, "∞ 不可知", ha='center', fontsize=8.5, color='darkred', fontweight='bold')

plt.tight_layout(rect=[0, 0, 1, 0.92])
plt.savefig("/data/workspace/brick/fig_power.png", dpi=130)
print("\n[已保存] fig_power.png")
