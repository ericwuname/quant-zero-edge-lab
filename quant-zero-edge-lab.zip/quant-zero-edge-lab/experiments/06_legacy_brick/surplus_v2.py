import numpy as np, pandas as pd
FILES={'DOGE':'/data/inputs/DOGEUSDT_1h.csv','DOT':'/data/inputs/DOTUSDT_1h.csv',
       'CRV':'/data/inputs/CRVUSDT_1h.csv','DASH':'/data/inputs/DASHUSDT_1h.csv',
       'ETH':'/data/inputs/ETHUSDT_1h.csv','FIL':'/data/inputs/FILUSDT_1h.csv',
       'HBAR':'/data/inputs/HBARUSDT_1h.csv'}
def load():
    o={}
    for k,p in FILES.items():
        d=pd.read_csv(p);c={x.lower():x for x in d.columns}
        o[k]=dict(open=d[c['open']].values.astype(float),high=d[c['high']].values.astype(float),
                  low=d[c['low']].values.astype(float),close=d[c['close']].values.astype(float))
    return o
def s_brk(cl,w):
    n=len(cl);s=np.zeros(n)
    for i in range(w,n):
        h=cl[i-w:i].max();l=cl[i-w:i].min()
        if cl[i]>h:s[i]=1
        elif cl[i]<l:s[i]=-1
    return s
def run(D,sg,s,R,cost_bp,slip_bp,max_hold,start,end,mode='flip'):
    op,hi,lo,cl=D['open'],D['high'],D['low'],D['close']
    n=len(cl) if end is None else min(end,len(cl))
    cR=2*cost_bp/1e4/s; slipR=slip_bp/1e4/s; stopd=s+slip_bp/1e4
    net=[];i=max(start,120)
    while i<n-3:
        d=1 if sg[i]>0 else (-1 if sg[i]<0 else 0)
        if d==0:i+=1;continue
        e=op[i+1];i0=i+1;out=None;j=i0
        for jj in range(i0,min(i0+max_hold,n)):
            adv=(lo[jj]/e-1) if d==1 else (1-hi[jj]/e)
            fav=(hi[jj]/e-1) if d==1 else (1-lo[jj]/e)
            if adv<=-stopd: out=-1.0-slipR;j=jj;break
            if fav>=R*s: out=R;j=jj;break
            if mode=='flip' and sg[jj]*d<0: out=((cl[jj]/e-1)*d)/s;j=jj;break
        if out is None:
            j=min(i0+max_hold,n-1);out=((cl[j]/e-1)*d)/s
        net.append(out-cR);i=j+1
    return np.array(net)

data=load()
alln=[]
for k,D in data.items():
    n=len(D['close'])
    nt=run(D,s_brk(D['close'],20),0.05,2.0,2,5,800,n//2,n,'flip')
    if len(nt)>=30: alln.append(nt)
R=np.concatenate(alln)
mu,sd=R.mean(),R.std()
fstar=2*mu/sd**2
print("="*104)
print(f"【控制时间一致】基准 E[R]={mu:+.4f} σ={sd:.3f}  临界仓位 f*={fstar*100:.2f}%")
print("="*104)
W0=10000.0; BUST=0.20; NSIM=1500; HORIZON=3000

def sim(rng,f,q,period,mode):
    """mode: 'compound' | 'withdraw' | 'multishop'
       所有模式总笔数固定=HORIZON"""
    Rs=rng.choice(R,HORIZON,replace=True)
    if mode=='compound':
        W=W0;G=0.0;peak=W0;mdd=0;bk=False
        for r in Rs:
            W*=(1+f*r); peak=max(peak,W); mdd=max(mdd,(peak-W)/peak)
            if W<W0*BUST: bk=True;break
        return dict(total=W,wd=0,lf=W,bk=bk,mdd=mdd,win=(W>W0))
    elif mode=='withdraw':
        W=W0;G=0.0;peak=W0;mdd=0;bk=False;fw=None
        for i,r in enumerate(Rs):
            W*=(1+f*r); peak=max(peak,W); mdd=max(mdd,(peak-W)/peak)
            if W<W0*BUST: bk=True;break
            if (i+1)%period==0 and W>W0:
                d=(W-W0)*q; W-=d; G+=d; peak=W
            if fw is None and G>W0: fw=i+1
        return dict(total=W+G,wd=G,lf=W,bk=bk,mdd=mdd,win=(G>W0),fw=fw)
    else: # multishop: 总HORIZON笔分给多店, 每店HORIZON/nshop笔
        nshop=4; per=HORIZON//nshop
        G=0.0; bk_any=False; fw=None; done=0
        for sh in range(nshop):
            if sh==0: cap=W0
            else:
                if G>=W0: cap=W0;G-=W0
                else: break
            Rs=rng.choice(R,per,replace=True)
            W=cap;peak=cap;mdd=0
            for i,r in enumerate(Rs):
                W*=(1+f*r); peak=max(peak,W); mdd=max(mdd,(peak-W)/peak)
                if W<cap*BUST: bk_any=True;break
                if (i+1)%period==0 and W>cap:
                    d=(W-cap)*q; W-=d; G+=d; peak=W
                if fw is None and G>W0: fw=done+i+1
            G+=W; done+=len(Rs)
        return dict(total=G,wd=G,lf=0,bk=bk_any,mdd=mdd,win=(G>W0),fw=fw)

rng=np.random.default_rng(7)
print(f"\n  全部模式: 总笔数={HORIZON} (时间一致), 本金{W0:.0f}, 爆仓线{int(BUST*100)}%")
print(f"\n  {'仓位f':<8}{'模式':<26}{'总资产中位':>11}{'落袋中位':>10}{'爆仓%':>8}{'真赚到%':>9}{'回撤':>8}{'判定':>16}")
print("  "+"-"*100)
for f in [0.01,0.03,0.05,0.08,0.12]:
    tag='超临界(复利归零)' if f>fstar else '安全区'
    for mode,q,per,lab in [('compound',0,200,'A 纯复利'),
                           ('withdraw',1.0,100,'B 提取100% 每100笔'),
                           ('multishop',1.0,100,'C 四店 提取100%')]:
        res=[sim(rng,f,q,per,mode) for _ in range(NSIM)]
        tot=np.array([x['total'] for x in res]); wd=np.array([x['wd'] for x in res])
        bk=np.array([x['bk'] for x in res]); win=np.array([x['win'] for x in res])
        md=np.array([x['mdd'] for x in res])
        print(f"  {f*100:<7.0f}%{lab:<26}{np.median(tot):>11.0f}{np.median(wd):>10.0f}"
              f"{bk.mean()*100:>7.1f}%{win.mean()*100:>8.1f}%{np.median(md)*100:>7.1f}%{tag:>16}")
    print("  "+"-"*100)
print("\n"+"="*104)
