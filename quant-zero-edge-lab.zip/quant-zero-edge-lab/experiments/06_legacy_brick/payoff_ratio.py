"""
【盈亏比维度】改变 R:R 能否创造正期望?
=============================================
【用户质疑】
  我是不是一直用 1:1 在找? 如果放大盈亏比呢?

【数学核心(关键)】
  对无漂移随机游走, 由可选停时定理(鞅性):
    触及 +R 与 -1 的概率:  p = 1/(1+R)
    期望 = p*R - (1-p)*1
         = R/(1+R) - R/(1+R) = 0   【精确为零!】

  => 任何【固定】盈亏比都无法在无漂移市场创造正期望
  => 胜率会被R反向调整, 两者不可独立设定!
  => 这是为什么"设盈亏比"是个幻觉

【但有两种情况会打破它】
  1. 有漂移/趋势 -> p ≠ 1/(1+R), 大的R可能有利
  2. 【移动止损/追踪止盈】 -> 不是固定R:R, 能捕获肥尾
     -> 这才是真正的"截断亏损, 让盈利奔跑"

【本实验】用真实数据测三种出场方式
  A. 固定止损+固定止盈 (扫描 R = 0.5/1/2/3/5)
  B. 固定止损 + 追踪止盈 (让盈利奔跑)
  C. 固定止损 + 时间出场
  对照: 买入持有
  并验证 p 是否真的 ≈ 1/(1+R)
"""
import numpy as np
import pandas as pd
from scipy import stats

HOURLY = {'DOGE': '/data/inputs/DOGEUSDT_1h.csv',
          'DOT':  '/data/inputs/DOTUSDT_1h.csv',
          'CRV':  '/data/inputs/CRVUSDT_1h.csv',
          'DASH': '/data/inputs/DASHUSDT_1h.csv'}
DAILY = {'BTC': '/data/inputs/BTCUSDT_1d.csv',
         'BNB': '/data/inputs/BNBUSDT_1d.csv',
         'BCH': '/data/inputs/BCHUSDT_1d.csv'}


def load(kind='1h'):
    src = HOURLY if kind == '1h' else DAILY
    out = {}
    for k, p in src.items():
        d = pd.read_csv(p)
        out[k] = d['close'].values.astype(float)
    return out


def trades_fixed_rr(px, risk, R, cost_bp=2):
    """固定止损(-risk) + 固定止盈(+risk*R)
    随机入场(每次出场后重新随机入场) -> 测纯出场规则的价值
    返回每笔的净收益(比例)
    """
    n = len(px)
    results = []
    i = 0
    rng = np.random.default_rng(42)
    while i < n - 2:
        entry = px[i]
        # 随机方向 (不预测)
        direction = rng.choice([-1, 1])
        sl = entry * (1 - risk) if direction == 1 else entry * (1 + risk)
        tp = entry * (1 + risk * R) if direction == 1 else entry * (1 - risk * R)
        exit_i = None
        for j in range(i + 1, min(i + 500, n)):
            if direction == 1:
                if px[j] <= sl:
                    exit_i = j; break
                if px[j] >= tp:
                    exit_i = j; break
            else:
                if px[j] >= sl:
                    exit_i = j; break
                if px[j] <= tp:
                    exit_i = j; break
        if exit_i is None:
            # 超时按最后价平
            exit_i = min(i + 500, n - 1)
        ret = (px[exit_i] / entry - 1) * direction
        ret -= 2 * cost_bp / 1e4      # 往返成本
        results.append(ret)
        i = exit_i + 1
    return np.array(results)


def trades_trailing(px, risk, trail, cost_bp=2):
    """固定止损(-risk) + 追踪止盈(回撤trail即平) -> 让盈利奔跑"""
    n = len(px)
    results = []
    i = 0
    rng = np.random.default_rng(42)
    while i < n - 2:
        entry = px[i]
        direction = rng.choice([-1, 1])
        sl = entry * (1 - risk) if direction == 1 else entry * (1 + risk)
        peak = entry
        exit_i = None
        for j in range(i + 1, min(i + 1000, n)):
            p = px[j]
            if direction == 1:
                peak = max(peak, p)
                if p <= sl:
                    exit_i = j; break
                if p <= peak * (1 - trail):     # 追踪止盈
                    exit_i = j; break
            else:
                peak = min(peak, p)
                if p >= sl:
                    exit_i = j; break
                if p >= peak * (1 + trail):
                    exit_i = j; break
        if exit_i is None:
            exit_i = min(i + 1000, n - 1)
        ret = (px[exit_i] / entry - 1) * direction
        ret -= 2 * cost_bp / 1e4
        results.append(ret)
        i = exit_i + 1
    return np.array(results)


def stats_of(rets, risk, R=None):
    if len(rets) < 30:
        return None
    p_win = (rets > 0).mean()
    avg_win = rets[rets > 0].mean() if (rets > 0).any() else 0
    avg_loss = -rets[rets < 0].mean() if (rets < 0).any() else 0
    E = rets.mean()
    # t 检验
    t = rets.mean() / (rets.std() / np.sqrt(len(rets))) if rets.std() > 0 else 0
    return dict(n=len(rets), win_rate=p_win, avg_win=avg_win,
                avg_loss=avg_loss, E=E, t=t,
                E_bp=E * 1e4)


print("=" * 100)
print("【盈亏比维度】固定 R:R vs 移动止盈 —— 能否创造正期望?")
print("=" * 100)
print("  数学: 无漂移随机游走, p_hit(TP) = 1/(1+R)")
print("        E = p*R - (1-p)*1 = 0  【精确为零, 与R无关】")
print("  => 若实测 E ≈ 0(扣成本前), 则验证: 设盈亏比是幻觉")

data = load('1h')
RISK = 0.02          # 2% 止损

print(f"\n  止损固定 {RISK*100:.0f}%, 随机方向入场(不预测), 成本 2bp单边")
print(f"\n  【A】固定盈亏比扫描")
print(f"  {'品种':<7}{'R':>5}{'笔数':>7}{'胜率':>9}{'理论1/(1+R)':>13}"
      f"{'均盈':>9}{'均亏':>9}{'实际R':>8}{'E(bp)':>10}{'t值':>8}")
print("  " + "-" * 90)

for sym in ['DOGE', 'CRV']:
    px = data[sym]
    for R in [0.5, 1, 2, 3, 5]:
        rets = trades_fixed_rr(px, RISK, R)
        st = stats_of(rets, RISK, R)
        if st is None:
            continue
        theo = 1.0 / (1.0 + R)
        act_R = st['avg_win'] / st['avg_loss'] if st['avg_loss'] > 0 else 0
        print(f"  {sym:<7}{R:>5}{st['n']:>7}{st['win_rate']*100:>8.1f}%"
              f"{theo*100:>12.1f}%{st['avg_win']*100:>8.2f}%"
              f"{st['avg_loss']*100:>8.2f}%{act_R:>8.2f}"
              f"{st['E_bp']:>+10.1f}{st['t']:>+8.2f}")

print(f"\n  【B】追踪止盈(让盈利奔跑) —— 真正的非1:1")
print(f"  {'品种':<7}{'止损':>6}{'追踪':>7}{'笔数':>7}{'胜率':>9}"
      f"{'均盈':>9}{'均亏':>9}{'实际R':>8}{'E(bp)':>10}{'t值':>8}")
print("  " + "-" * 80)

for sym in ['DOGE', 'CRV', 'DOT', 'DASH']:
    px = data[sym]
    for trail in [0.01, 0.02, 0.05]:
        rets = trades_trailing(px, RISK, trail)
        st = stats_of(rets, RISK)
        if st is None:
            continue
        act_R = st['avg_win'] / st['avg_loss'] if st['avg_loss'] > 0 else 0
        print(f"  {sym:<7}{RISK*100:>5.0f}%{trail*100:>6.0f}%{st['n']:>7}"
              f"{st['win_rate']*100:>8.1f}%{st['avg_win']*100:>8.2f}%"
              f"{st['avg_loss']*100:>8.2f}%{act_R:>8.2f}"
              f"{st['E_bp']:>+10.1f}{st['t']:>+8.2f}")

print("\n" + "=" * 100)
print("完成")
print("=" * 100)
