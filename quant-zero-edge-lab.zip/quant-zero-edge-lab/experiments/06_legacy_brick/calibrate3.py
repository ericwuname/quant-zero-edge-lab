"""
【阶段3】把校准出的检测门槛, 与真实数据对照
================================================
校准给出: 50%检出率 需要【真实结构强度 L1夏普 ≈ 0.673】

本脚本:
  1. 测出真实数据上各策略的 L1 等价强度
  2. 与该门槛对比 -> 判断"找不到"是市场没有, 还是我测不出
  3. 策略生态演化: 不同类型主体在世界里的命运
"""
import numpy as np
import pandas as pd
from scipy import stats
import sys
sys.path.insert(0, '/data/workspace/brick')
from world_v5 import World

DAYS_YR = 365
COST_BP = 10
CRITICAL_SHARPE = 0.673        # 校准出的50%检出门槛

DAILY = {'BTC': '/data/inputs/BTCUSDT_1d.csv',
         'BNB': '/data/inputs/BNBUSDT_1d.csv',
         'BCH': '/data/inputs/BCHUSDT_1d.csv'}
HOURLY = {'DOGE': '/data/inputs/DOGEUSDT_1h.csv',
          'DOT': '/data/inputs/DOTUSDT_1h.csv',
          'CRV': '/data/inputs/CRVUSDT_1h.csv',
          'DASH': '/data/inputs/DASHUSDT_1h.csv'}


def load():
    px = {}
    for k, p in DAILY.items():
        d = pd.read_csv(p)
        px[k] = pd.Series(d['close'].values,
                          index=pd.to_datetime(d['timestamp'], unit='ms').dt.normalize())
        px[k] = px[k][~px[k].index.duplicated()]
    for k, p in HOURLY.items():
        d = pd.read_csv(p)
        s = pd.Series(d['close'].values,
                      index=pd.to_datetime(d['timestamp'], unit='ms'))
        px[k] = s.resample('1D').last().dropna()
    return pd.DataFrame(px).dropna()


def sharpe(x):
    s = x.std()
    return x.mean() / s * np.sqrt(DAYS_YR) if s > 1e-12 else 0.0


def build_signals(prices):
    T = len(prices) - 1
    P = prices[:T]
    S = {}
    for w in [5, 10, 20, 60]:
        if T > w + 1:
            mom = np.zeros(T)
            mom[w:] = P[w:] / np.maximum(P[:-w], 1e-9) - 1
            S[f'mom_{w}'] = np.sign(mom)
            S[f'rev_{w}'] = -np.sign(mom)
    for w in [10, 30]:
        if T > w + 1:
            ma = pd.Series(P).rolling(w).mean().values
            sig = np.where(P > ma, 1.0, -1.0)
            sig[:w] = 0.0
            S[f'ma_{w}'] = sig
    return S


def backtest(sig, r, cost_bp):
    T = len(r)
    pnl = np.zeros(T)
    pnl[:-1] = sig[:-1] * r[1:]
    turn = np.abs(np.diff(np.concatenate([[0.0], sig])))
    return pnl - turn * (2 * cost_bp / 1e4)


print("=" * 100)
print("【阶段3】真实数据 vs 校准门槛")
print("=" * 100)
print(f"  校准出的50%检出门槛: 真实结构强度(夏普) ≈ {CRITICAL_SHARPE}")

df = load()
port = df.pct_change().fillna(0).mean(axis=1)
r = port.values
# prices 长度必须 = len(r)+1, 使 r[t] 表示 prices[t]->prices[t+1]
prices = np.empty(len(r) + 1)
prices[0] = 100.0
prices[1:] = 100.0 * np.cumprod(1.0 + r)
T = len(r)
sp = T // 2

S = build_signals(prices)
print(f"\n  真实数据 (7品种等权组合, {T}天)")
print(f"\n  {'策略':<12}{'全样本夏普':>12}{'样本外夏普':>12}{'vs门槛':>12}{'判定':>16}")
best_oos = -9
best_nm = None
for nm in sorted(S.keys()):
    pnl = backtest(S[nm], r, COST_BP)
    sh_all = sharpe(pnl)
    sh_oos = sharpe(pnl[sp:])
    if sh_oos > best_oos:
        best_oos, best_nm = sh_oos, nm
    gap = sh_oos - CRITICAL_SHARPE
    verdict = '远超门槛' if sh_oos > CRITICAL_SHARPE * 1.5 else (
        '接近门槛' if sh_oos > CRITICAL_SHARPE * 0.7 else '远低于门槛')
    print(f"  {nm:<12}{sh_all:>12.3f}{sh_oos:>12.3f}{gap:>+12.3f}{verdict:>16}")

# 买入持有
bh = r.copy()
sh_bh = sharpe(bh[sp:])
print(f"  {'买入持有':<12}{sharpe(bh):>12.3f}{sh_bh:>12.3f}"
      f"{sh_bh-CRITICAL_SHARPE:>+12.3f}{'(beta非alpha)':>16}")

print(f"\n  ★ 真实数据最优策略: {best_nm}, 样本外夏普 {best_oos:.3f}")
print(f"  ★ 校准门槛: {CRITICAL_SHARPE:.3f}")
print(f"  ★ 比值: {best_oos/CRITICAL_SHARPE*100:.0f}%")

print("\n  " + "=" * 80)
if best_oos < CRITICAL_SHARPE * 0.5:
    print("  结论: 真实数据的最优策略强度, 远低于检测门槛的一半")
    print("        -> 即使市场真有edge, 我也【几乎不可能】可靠检出")
    print("        -> 两种可能都无法区分: (a)没有edge (b)有但太弱")
elif best_oos < CRITICAL_SHARPE:
    print("  结论: 真实数据强度低于门槛 -> 检出概率 <50%")
else:
    print("  结论: 真实数据强度超过门槛 -> 若有edge应能检出, 测不到说明真没有")
print("  " + "=" * 80)

# ============ 策略生态演化 ============
print("\n" + "=" * 100)
print("【阶段4】策略生态演化 —— 什么主体在什么世界活下来?")
print("=" * 100)
print("  在不同世界参数下, 看5类主体的终局财富占比")
print(f"\n  {'世界类型':<18}" + "".join(f"{k:>10}" for k in
      ['基本面', '趋势', '反转', '做市', '噪声']))
print("  " + "-" * 68)

worlds = [
    ("无结构(纯噪声)", dict()),
    ("趋势主导", dict(trend_strength=0.05)),
    ("均值回归主导", dict(mean_revert_strength=0.10)),
    ("趋势+回归混合", dict(trend_strength=0.03, mean_revert_strength=0.06)),
]

for label, cfg in worlds:
    final_shares = []
    for seed in [3000, 3001, 3002]:
        w = World(seed=seed, beta=0.0005)
        prices, wh, kinds = w.run(n_steps=10000, **cfg)
        if len(wh) > 0:
            last = wh[-1]
            final_shares.append(np.array(last) / sum(last))
    if not final_shares:
        continue
    avg = np.mean(final_shares, axis=0) * 100
    print(f"  {label:<18}" + "".join(f"{v:>9.1f}%" for v in avg))

print("\n  判读: 主体的命运由【世界结构】决定, 不由策略优劣决定")
print("        -> 不存在'普遍最优'的策略, 只有'与环境匹配'的策略")
print("        -> 这印证了: 期望来自匹配, 不来自策略本身")

print("\n" + "=" * 100)
print("全部阶段完成")
print("=" * 100)
