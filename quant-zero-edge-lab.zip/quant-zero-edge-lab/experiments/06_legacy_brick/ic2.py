import numpy as np, pandas as pd
FILES={'DOGE':'/data/inputs/DOGEUSDT_1h.csv','DOT':'/data/inputs/DOTUSDT_1h.csv',
       'CRV':'/data/inputs/CRVUSDT_1h.csv','DASH':'/data/inputs/DASHUSDT_1h.csv',
       'ETH':'/data/inputs/ETHUSDT_1h.csv','FIL':'/data/inputs/FILUSDT_1h.csv',
       'HBAR':'/data/inputs/HBARUSDT_1h.csv'}
print("="*98)
print("【决定性 A】信号预测力 IC = corr(过去5bar收益, 未来h bar收益)")
print("="*98)
print(f"  {'品种':<7}"+"".join(f"{'h='+str(h):>10}" for h in [1,5,10,20,60]))
print("  "+"-"*58)
store={h:[] for h in [1,5,10,20,60]}
for k,p in FILES.items():
    d=pd.read_csv(p); c={x.lower():x for x in d.columns}
    cl=d[c['close']].values.astype(float); n=len(cl)
    print(f"  {k:<7}",end="")
    for h in [1,5,10,20,60]:
        L=n-h-5
        sig=cl[5:5+L]/np.maximum(cl[0:L],1e-9)-1
        fut=cl[5+h:5+h+L]/np.maximum(cl[5:5+L],1e-9)-1
        m=np.isfinite(sig)&np.isfinite(fut)&(np.abs(sig)>1e-12)
        if m.sum()<1000: print(f"{'NA':>10}",end="");continue
        ic=np.corrcoef(sig[m],fut[m])[0,1]
        store[h].append(ic); print(f"{ic:>+10.4f}",end="")
    print()
print(f"  {'均值':<7}"+"".join(f"{np.mean(store[h]):>+10.4f}" for h in [1,5,10,20,60]))
print(f"\n  判据: |均值|<0.01 或 各品种符号不一致 => 无预测力")

print("\n"+"="*98)
print("【重验 B】随机方向入场, 实测触及胜率 vs 随机理论 1/(1+R)")
print("="*98)
def touch(D,R,s=0.05,max_hold=800,n_trial=3000,seed=1):
    d2=pd.read_csv(FILES[D]); c={x.lower():x for x in d2.columns}
    hi=d2[c['high']].values.astype(float);lo=d2[c['low']].values.astype(float)
    op=d2[c['open']].values.astype(float);n=len(op)
    rng=np.random.default_rng(seed)
    idx=rng.choice(np.arange(120,n-2),min(n_trial,n-122),replace=False)
    res=[]
    for i in idx:
        dr=rng.choice([-1,1]); e=op[i+1]; out=0.0
        for jj in range(i+1,min(i+max_hold,n)):
            adv=(lo[jj]/e-1) if dr==1 else (1-hi[jj]/e)
            fav=(hi[jj]/e-1) if dr==1 else (1-lo[jj]/e)
            if adv<=-s: out=-1.0;break
            if fav>=R*s: out=R;break
        res.append(out)
    return np.array(res)
for R in [1,2,3,5]:
    th=1/(1+R)
    print(f"\n  R=1:{R}  理论胜率={th*100:.1f}%")
    print(f"  {'品种':<7}{'实测':>9}{'差值':>10}{'t':>8}")
    for k in FILES:
        r=touch(k,R); w=(r>0).mean()
        se=np.sqrt(w*(1-w)/len(r)); t=(w-th)/se if se>0 else 0
        print(f"  {k:<7}{w*100:>8.1f}%{(w-th)*100:>+9.1f}pp{t:>+8.2f}")
