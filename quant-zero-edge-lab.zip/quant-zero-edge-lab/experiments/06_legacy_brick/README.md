# 06 · 早期探索（矛盾论 / alpha / 校准）

本目录是项目早期的探索记录，105 个脚本。

**主题**：矛盾强度、alpha 检验、beta 中性、盲测、跨截面、成本前沿、校准、实例化交易世界等。

**⚠️ 注意**：这里的许多结论后来被修正或证伪。保留它是为了记录**思路演化过程**——包括错误路径。

**几个有代表性的脚本**
| 脚本 | 主题 |
|---|---|
| `alpha_1h.py` / `alpha_test.py` | alpha 检验 |
| `beta_neutral.py` | beta 中性化 |
| `cost_frontier.py` | 成本前沿 |
| `contradiction*.py` | 矛盾强度 |
| `blind2.py` | 盲测 |
| `cross_section_test.py` | 横截面 |
| `brick_engine.py` | 早期引擎 |

**教训**：这一层的大量"发现"，后来都在前视 bug 修复后塌陷。
