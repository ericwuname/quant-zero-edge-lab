"""扫描结果分析：各择时策略的【方向贡献】+ 五组(A/B/C/D1/D2) + 随机择时零分布RC校正"""
import sys, numpy as np, pandas as pd
sys.path.insert(0, '/data/workspace/subjective2')
from core2 import xsec_t, OLD7, NEW6

COST_R = 0.008
d22 = pd.read_csv('/data/workspace/subjective2/scan22.csv')
d5  = pd.read_csv('/data/workspace/subjective2/scan5.csv')
d22['sym2'] = d22.sym.str.replace('USDT','',regex=False)
d5['sym2']  = d5.sym.str.replace('USDT','',regex=False)

# ---------- 1) 2x2：每品种每 cell 的均值（跨 seed 平均） ----------
per = d22.groupby(['sym2','timing','cell']).r.mean().reset_index()
piv = per.pivot_table(index=['sym2','timing'], columns='cell', values='r').reset_index()

real_t = sorted([t for t in piv.timing.unique() if not t.startswith('randT')])
null_t = sorted([t for t in piv.timing.unique() if t.startswith('randT')])

def contrib(sub):
    base = sub['randT/randD']; dirc = sub['randT/timeD'] - base
    timc = sub['timeT/randD'] - base; A = sub['timeT/timeD']
    return base, dirc, timc, A, (A - base)

rows = []
for t in real_t:
    s = piv[piv.timing == t]
    base, dirc, timc, A, tot = contrib(s)
    m_d, t_d, _ = xsec_t(dirc.values)
    m_tm, t_tm, _ = xsec_t(timc.values)
    m_A, t_A, _ = xsec_t(tot.values)
    m_Aabs, t_Aabs, _ = xsec_t(A.values)
    rows.append(dict(timing=t, base=base.mean(), dir_c=m_d, t_dir=t_d,
                     tim_c=m_tm, t_tim=t_tm, A=A.mean(), t_A=t_Aabs,
                     A_minus_base=m_A, t_Abase=t_A,
                     pos_dir=int((dirc>0).sum()), n=len(dirc)))
R = pd.DataFrame(rows).sort_values('t_dir', ascending=False)

print('===== 各择时策略的 2x2 分解（跨品种，毛E R/笔）=====')
print('基线=随机时点+随机方向(应≈0)；方向贡献=随机时点下用择时方向替代随机方向')
print('净E = 毛E - 0.008(maker)\n')
print(f"{'择时':<12}{'基线':>8}{'方向贡献':>10}{'t':>7}{'为正':>6}{'时机贡献':>10}{'A(择时)':>9}{'t(A)':>7}{'A-基线':>9}{'t':>7}")
for _, r in R.iterrows():
    print(f"{r.timing:<12}{r.base:>8.4f}{r.dir_c:>+10.4f}{r.t_dir:>7.2f}{r.pos_dir:>4d}/{r['n']:<2}"
          f"{r.tim_c:>+10.4f}{r.A:>9.4f}{r.t_A:>7.2f}{r.A_minus_base:>+9.4f}{r.t_Abase:>7.2f}")

print('\n净E(方向贡献) = 方向贡献 - 0.008 :')
for _, r in R.iterrows():
    print(f"  {r.timing:<12} 净 {r.dir_c - COST_R:+.4f}   {'正' if r.dir_c-COST_R>0 else '负'}")

# ---------- 2) 随机择时零分布 & RC ----------
nrows = []
for t in null_t:
    s = piv[piv.timing == t]
    base, dirc, timc, A, tot = contrib(s)
    m_d, t_d, _ = xsec_t(dirc.values)
    m_A, t_A, _ = xsec_t(tot.values)
    nrows.append(dict(timing=t, dir_c=m_d, t_dir=t_d, A_minus_base=m_A, t_Abase=t_A))
NR = pd.DataFrame(nrows)
print(f'\n===== 随机择时零分布（{len(NR)} 个）=====')
print(f"方向贡献 t : 均值{NR.t_dir.mean():+.2f}  sd{NR.t_dir.std(ddof=1):.2f}  "
      f"[{NR.t_dir.min():+.2f},{NR.t_dir.max():+.2f}]")
print(f"A-基线  t : 均值{NR.t_Abase.mean():+.2f}  sd{NR.t_Abase.std(ddof=1):.2f}  "
      f"[{NR.t_Abase.min():+.2f},{NR.t_Abase.max():+.2f}]")

# 对"从14个真实择时里挑最强"做 RC：自助抽样 max t
rng = np.random.default_rng(7)
obs_max_dir = R.t_dir.max(); obs_max_A = R.t_Abase.max()
nb = 5000
mx_d = np.array([NR.t_dir.sample(14, replace=True, random_state=int(rng.integers(1e9))).max() for _ in range(nb)])
mx_A = np.array([NR.t_Abase.sample(14, replace=True, random_state=int(rng.integers(1e9))).max() for _ in range(nb)])
print(f'\n最强真实择时(方向贡献) t={obs_max_dir:.2f} ({R.iloc[0].timing})  '
      f'RC p = {(mx_d >= obs_max_dir).mean():.3f}')
print(f'最强真实择时(A-基线)  t={obs_max_A:.2f}  RC p = {(mx_A >= obs_max_A).mean():.3f}')

# ---------- 3) 五组 ----------
print('\n\n===== 五组 A/B/C/D1/D2（主观判断=ma50，锚点=各择时策略）=====')
print('单位：毛E(R/笔)；D1-D2 = 在"不一致"时点上坚持主观 vs 服从锚点（无偏方向能力）\n')
p5 = d5.groupby(['sym2','timing','jud','grp']).r.mean().reset_index()
out5 = []
for t in real_t:
    s = p5[(p5.timing == t) & (p5.jud == 'ma50')]
    if len(s) == 0: continue
    g = s.pivot_table(index='sym2', columns='grp', values='r').reindex(columns=['A','B','C','D1','D2'])
    if g['D1'].isna().all() or g['D2'].isna().all():
        # 退化（锚点==判断）
        A = g['A'].mean() if 'A' in g else np.nan
        out5.append(dict(timing=t, A=A, B=np.nan, C=np.nan, D1=np.nan, D2=np.nan,
                         BA=np.nan, tBA=np.nan, D1D2=np.nan, tD1D2=np.nan, note='退化(锚点=判断)'))
        continue
    dif_ba = (g['B'] - g['A']).dropna(); dif_d = (g['D1'] - g['D2']).dropna()
    m1, t1, _ = xsec_t(dif_ba.values); m2, t2, _ = xsec_t(dif_d.values)
    out5.append(dict(timing=t, A=g['A'].mean(), B=g['B'].mean(), C=g['C'].mean(),
                     D1=g['D1'].mean(), D2=g['D2'].mean(), BA=m1, tBA=t1,
                     D1D2=m2, tD1D2=t2, note=''))
O5 = pd.DataFrame(out5)
print(f"{'择时':<12}{'A锚点':>8}{'B主观':>8}{'C一致':>8}{'D1坚持':>9}{'D2服从':>9}{'B-A':>8}{'t':>7}{'D1-D2':>9}{'t':>7}")
for _, r in O5.iterrows():
    if r.note: print(f"{r.timing:<12}{r.A:>8.4f}   {r.note}")
    else:
        print(f"{r.timing:<12}{r.A:>8.4f}{r.B:>8.4f}{r.C:>8.4f}{r.D1:>9.4f}{r.D2:>9.4f}"
              f"{r.BA:>+8.4f}{r.tBA:>7.2f}{r.D1D2:>+9.4f}{r.tD1D2:>7.2f}")

# rev20 对照
print('\n--- 主观判断=rev20（反转类）D1-D2 ---')
out5b = []
for t in real_t:
    s = p5[(p5.timing == t) & (p5.jud == 'rev20')]
    if len(s) == 0: continue
    g = s.pivot_table(index='sym2', columns='grp', values='r').reindex(columns=['A','B','C','D1','D2'])
    if g['D1'].isna().all() or g['D2'].isna().all(): continue
    dif_d = (g['D1'] - g['D2']).dropna()
    m2, t2, _ = xsec_t(dif_d.values)
    out5b.append(dict(timing=t, D1D2=m2, t=t2))
print(f"{'择时':<12}{'D1-D2':>9}{'t':>7}")
for r in out5b:
    print(f"{r['timing']:<12}{r['D1D2']:>+9.4f}{r['t']:>7.2f}")

# ---------- 4) OLD7 vs NEW6（方向贡献） ----------
print('\n--- 方向贡献 分 OLD7(参与挑选) / NEW6(干净) ---')
for t in R.timing.head(8):
    s = piv[piv.timing == t]
    base, dirc, *_ = contrib(s)
    for lab, S in [('OLD7', OLD7), ('NEW6', NEW6)]:
        S2 = {x.replace('USDT','') for x in S}
        v = dirc[dirc.index.isin(S2)] if hasattr(dirc,'index') else None
        # dirc 是 Series，index=sym2
        v = dirc[dirc.index.isin(S2)]
        m, tt, k = xsec_t(v.values)
        print(f'  {t:<12} {lab} n={k} 方向贡献{m:+.4f} t={tt:+.2f} 为正{int((v>0).sum())}/{k}')

R.to_csv('/data/workspace/subjective2/scan_summary.csv', index=False)
O5.to_csv('/data/workspace/subjective2/scan_five.csv', index=False)
print('\nsaved scan_summary.csv / scan_five.csv')
