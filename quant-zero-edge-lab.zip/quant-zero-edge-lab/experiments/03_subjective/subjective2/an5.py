"""五组 A/B/C/D1/D2 分析（择时=brk500 + 随机间隔执行）"""
import sys, numpy as np, pandas as pd
sys.path.insert(0,'/data/workspace/subjective2')
from core2 import xsec_t, OLD7, NEW6

COST_R = 0.008
TKEY = sys.argv[1] if len(sys.argv)>1 else 'brk500'
d = pd.read_csv(f'/data/workspace/subjective2/r5_{TKEY}.csv')
d['sym2'] = d.sym.str.replace('USDT','',regex=False)
d = d[d.grp != 'AGREE']

per = d.groupby(['sym2','jud','grp']).r.agg(['mean','count']).reset_index()

print(f'===== 五组（择时={TKEY} + 随机间隔执行）=====')
print('毛E(R/笔)。净 = 毛 - 0.008(maker)\n')
print(f"{'判断':<9}{'A锚点':>8}{'B主观':>8}{'C一致':>8}{'D1坚持':>9}{'D2服从':>9}{'B-A':>8}{'t(B-A)':>8}{'C-D2':>8}{'t(C-D2)':>9}")
rows=[]
for jn in sorted(per.jud.unique()):
    s = per[per.jud==jn]
    g = {k: s[s.grp==k].set_index('sym2')['mean'] for k in ['A','B','C','D1','D2']}
    dif_ba = (g['B']-g['A']).dropna(); dif_cd = (g['C']-g['D2']).dropna()
    m1,t1,_ = xsec_t(dif_ba.values); m2,t2,_ = xsec_t(dif_cd.values)
    rows.append(dict(jud=jn, A=g['A'].mean(), B=g['B'].mean(), C=g['C'].mean(),
                     D1=g['D1'].mean(), D2=g['D2'].mean(), BA=m1, tBA=t1, CD=m2, tCD=t2))
    print(f"{jn:<9}{g['A'].mean():>8.4f}{g['B'].mean():>8.4f}{g['C'].mean():>8.4f}{g['D1'].mean():>9.4f}{g['D2'].mean():>9.4f}{m1:>+8.4f}{t1:>8.2f}{m2:>+8.4f}{t2:>9.2f}")

R = pd.DataFrame(rows)
print()
print('--- 一致率（主观与择时方向相同的比例）---')
ag = d.groupby(['sym2','jud']).apply(lambda x: np.nan)
print('(AGGREE 行已单独存)')

print()
print('--- 逐品种 C-D2（ma50）---')
s = per[(per.jud=='ma50')]
pv = s.pivot_table(index='sym2', columns='grp', values='mean')
dif = (pv['C']-pv['D2']).sort_values()
print(dif.round(4).to_string())
print()
print('--- 分 OLD7 / NEW6 （C-D2）---')
for lab,S in [('OLD7',OLD7),('NEW6',NEW6)]:
    S2 = {x.replace('USDT','') for x in S}
    for jn in ['ma50','mom20','rev20','brk500']:
        s = per[per.jud==jn]; pv = s.pivot_table(index='sym2',columns='grp',values='mean')
        if 'D2' not in pv.columns: 
            print(f'  {lab} {jn:<8} (无不一致样本，跳过)'); continue
        dif = (pv['C']-pv['D2'])
        v = dif[dif.index.isin(S2)].dropna()
        m,t,k = xsec_t(v.values)
        print(f'  {lab} {jn:<8} 均值{m:+.4f} t={t:+.2f} 为正{int((v>0).sum())}/{k}')
