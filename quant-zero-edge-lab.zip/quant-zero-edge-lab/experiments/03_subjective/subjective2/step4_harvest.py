"""Step4: 不复利 + 盈余公积收割制（固定注、翻倍即收割、净值重置、20%爆仓线）
比较 A(纯锚点) / B(ma50主观) / C(一致) / D1(坚持) / D2(服从) 与 零期望对照
"""
import sys, numpy as np, pandas as pd
sys.path.insert(0,'/data/workspace/subjective2')
from core2 import *

STOP,R,MAXH,COST_R = 0.05,2.0,480,0.008
GAPBAR=(24,480)
TKEY = sys.argv[1] if len(sys.argv)>1 else 'brk500'
data=load(); names=sorted(data)

seqs={}
for nm in names:
    d=data[nm]; o,h,l,c=d.open.values,d.high.values,d.low.values,d.close.values
    a=TIMING[TKEY](c,h,l); win=np.where(a!=0)[0]; n=len(c)
    rng=np.random.default_rng(1000)
    out=[];target=win[0];p=0
    while True:
        while p<len(win) and win[p]<target: p+=1
        if p>=len(win): break
        out.append(win[p]); target=win[p]+int(rng.integers(*GAPBAR))
    idx=np.array(out,int); dr=a[idx]; fr=idx/n
    j=JUD['ma50'](c,h,l); jt=j[idx]
    ag=(jt==dr)&(jt!=0); ds=(jt!=dr)&(jt!=0)
    for lab,ii,dd in [('A',idx,dr),('B',idx,np.where(jt!=0,jt,dr)),
                      ('C',idx[ag],dr[ag]),('D1',idx[ds],jt[ds]),('D2',idx[ds],dr[ds])]:
        if len(ii)==0: continue
        rr=trades_vec(o,h,l,c,ii,dd,STOP,R,MAXH)[0]
        seqs.setdefault(lab,[]).append(pd.DataFrame(dict(r=rr-COST_R, t=ii[0:len(rr)]/n)))

for k in seqs:
    seqs[k]=pd.concat(seqs[k]).sort_values('t').r.values
print('组\t笔数\t毛均\t净均')
for k,v in seqs.items(): print(f'{k}\t{len(v)}\t{v.mean()+COST_R:+.4f}\t{v.mean():+.4f}')

def harvest(R, f, C0=10000.0, T=1.0, bl=0.2, nsim=400, seed=7):
    rng=np.random.default_rng(seed); n=len(R)
    P=[];FIN=[];BUST=[]
    for _ in range(nsim):
        order=rng.permutation(n); rs=R[order]
        W=C0; taken=0.0; bust=False
        for x in rs:
            bet=f*C0
            W+=bet*x
            if W<=bl*C0: bust=True; break
            if W-C0>=T*C0:
                taken+=W-C0; W=C0
        if not bust and W-C0>0: taken+=W-C0
        P.append(taken>=C0); FIN.append(taken+W-C0); BUST.append(bust)
    return np.mean(P), np.median(FIN), np.mean(BUST)

print(f'\n===== 收割制（本金1万，翻倍即收割，20%爆仓线）=====')
print(f"{'组':<6}{'f':>6}{'P(赚回本金)':>13}{'盈亏中位':>11}{'爆仓率':>9}")
for f in [0.01,0.02,0.03]:
    for lab in ['A','B','C','D1','D2']:
        if lab not in seqs: continue
        p,fin,bu=harvest(seqs[lab],f)
        print(f'{lab:<6}{f:>6.2f}{p:>13.3f}{fin:>11.0f}{bu:>9.3f}')
    print()

print('--- 零期望对照（把各组序列均值移到0，保留形状）---')
for f in [0.01,0.02,0.03]:
    for lab in ['A','B']:
        z=seqs[lab]-seqs[lab].mean()
        p,fin,bu=harvest(z,f)
        print(f'{lab}(零期望) f={f:.2f}  P={p:.3f}  盈亏中位{fin:.0f}  爆仓{bu:.3f}')
    print()

print('--- 成本敏感性（B组 = ma50主观，f=2%）---')
for c in [0.008,0.02,0.03,0.04,0.05,0.10]:
    adj=seqs['B']+COST_R-c
    p,fin,bu=harvest(adj,0.02)
    print(f'  cost_R={c:<6} P={p:.3f}  盈亏中位{fin:.0f}  爆仓{bu:.3f}')

print()
print('=== E 衰减压力测试（B组=ma50主观，f=1%）===')
print('回测E不可外推：把均值按倍率缩放，看P如何塌')
for lab in ['A','B']:
    R0=seqs[lab]; mu=R0.mean()
    for k in [1.0,0.7,0.5,0.3,0.0]:
        adj=R0-mu+k*mu
        p,fin,bu=harvest(adj,0.01)
        print(f'  {lab} E×{k:<4} 净均{adj.mean():+.4f}  P={p:.3f}  盈亏中位{fin:>7.0f}  爆仓{bu:.3f}')
    print()
