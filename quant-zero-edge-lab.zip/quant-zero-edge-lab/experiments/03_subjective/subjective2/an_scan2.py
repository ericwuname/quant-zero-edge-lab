import sys, numpy as np, pandas as pd
sys.path.insert(0,'/data/workspace/subjective2')
from core2 import xsec_t, OLD7, NEW6
d22 = pd.read_csv('scan22.csv')
d22['sym2'] = d22.sym.str.replace('USDT','',regex=False)
per = d22.groupby(['sym2','timing','cell']).r.mean().reset_index()
piv = per.pivot_table(index=['sym2','timing'], columns='cell', values='r').reset_index()

print('===== 方向贡献 分 OLD7 / NEW6（干净样本外推）=====')
for t in ['macd','pos240','ma200','vwap168','ma50','pos20','brk500','rsi14','mom240']:
    s = piv[piv.timing==t].set_index('sym2')
    if 'randT/randD' not in s.columns: continue
    dirc = s['randT/timeD'] - s['randT/randD']
    base = s['randT/randD']; A = s['timeT/timeD']
    line=f'{t:<10}'
    for lab,S in [('OLD7',OLD7),('NEW6',NEW6)]:
        S2={x.replace('USDT','') for x in S}
        v=dirc[dirc.index.isin(S2)]
        m,tt,k=xsec_t(v.values)
        line+=f'  {lab} n={k} 方向贡献{m:+.4f} t={tt:+.2f} 为正{int((v>0).sum())}/{k}'
    print(line)

print('\n===== 绝对水平 A（择时策略本身）分 OLD7/NEW6 =====')
for t in ['macd','ma50','pos240']:
    s = piv[piv.timing==t].set_index('sym2'); A=s['timeT/timeD']
    line=f'{t:<10}'
    for lab,S in [('OLD7',OLD7),('NEW6',NEW6)]:
        S2={x.replace('USDT','') for x in S}
        v=A[A.index.isin(S2)]; m,tt,k=xsec_t(v.values)
        line+=f'  {lab} A(毛){m:+.4f} t={tt:+.2f}'
    print(line)

print('\n===== 成本敏感性（方向贡献 & A，毛->净）=====')
print(f"{'择时':<10}{'毛(方向贡献)':>12}{'maker2bp':>10}{'5bp':>9}{'taker10bp':>11}{'20bp':>8}   | {'A毛':>7}{'maker':>8}{'taker':>8}")
for t in ['macd','pos240','ma200','vwap168','ma50']:
    s = piv[piv.timing==t].set_index('sym2')
    dirc=(s['randT/timeD']-s['randT/randD']); A=s['timeT/timeD']
    md=xsec_t(dirc.values)[0]; mA=xsec_t(A.values)[0]
    print(f"{t:<10}{md:>+12.4f}{md-0.008:>10.4f}{md-0.02:>9.4f}{md-0.04:>11.4f}{md-0.08:>8.4f}   | {mA:>7.4f}{mA-0.008:>8.4f}{mA-0.04:>8.4f}")

print('\n===== 方向贡献逐品种（macd / ma50 对照）=====')
for t in ['macd','ma50','rsi14']:
    s=piv[piv.timing==t].set_index('sym2')
    dirc=(s['randT/timeD']-s['randT/randD']).sort_values()
    print(f'--- {t} ---'); print(dirc.round(4).to_string())
