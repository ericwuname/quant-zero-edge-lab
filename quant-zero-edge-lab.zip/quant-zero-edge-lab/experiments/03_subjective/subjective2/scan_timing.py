"""扫描多种【择时策略】作为锚点（提供方向 + 圈定可交易窗口），
随机间隔执行节点不变，其余与上一实验完全一致（五组 A/B/C/D1/D2，主观判断=ma50/rev20）。
新增：随机择时零分布（rand timing）=> 多重检验 Reality Check
"""
import sys, numpy as np, pandas as pd
sys.path.insert(0, '/data/workspace/subjective2')
from core2 import *
from core2 import _lag, _mom

STOP, R, MAXH, COST_R = 0.05, 2.0, 480, 0.008
SEEDS = list(range(10))
GAPBAR = (24, 480)
JUDGES = ['ma50', 'rev20']

# ---------------- 扩展择时信号（全部为"常驻状态"，保证方向处处可用） ----------------
def _rsi(c, w=14):
    delta = np.diff(c, prepend=c[0])
    up = np.where(delta > 0, delta, 0.0)
    dn = np.where(delta < 0, -delta, 0.0)
    ru = pd.Series(up).ewm(alpha=1.0/w, adjust=False).mean().values
    rd = pd.Series(dn).ewm(alpha=1.0/w, adjust=False).mean().values
    rs = ru / np.where(rd == 0, np.nan, rd)
    return np.nan_to_num(100 - 100/(1+rs), nan=50.0)

def sig_macd(c, h, l):
    e12 = pd.Series(c).ewm(span=12, adjust=False).mean().values
    e26 = pd.Series(c).ewm(span=26, adjust=False).mean().values
    return _lag(np.nan_to_num(np.sign(e12 - e26), nan=0.0))

def sig_rsi14(c, h, l):
    return _lag(np.sign(50.0 - _rsi(c, 14)))          # 反向：RSI>50 做空

def sig_posw(c, h, l, w):
    H = hh(h, w); L = ll(l, w)
    rng = np.where(H - L > 0, H - L, np.nan)
    return _lag(np.nan_to_num(np.sign((c - (H+L)/2) / rng), nan=0.0))

def sig_xab(c, h, l):
    m50 = ma(c, 50); m200 = ma(c, 200)
    return _lag(np.where(np.isnan(m50) | np.isnan(m200), 0.0, np.sign(m50 - m200)))

TIMING2 = dict(TIMING)
TIMING2['ma200']     = lambda c,h,l: sig_ma(c, 200)
TIMING2['xab50_200'] = sig_xab
TIMING2['mom20']     = lambda c,h,l: _lag(np.nan_to_num(_mom(c, 20), nan=0.0))
TIMING2['mom240']    = lambda c,h,l: _lag(np.nan_to_num(_mom(c, 240), nan=0.0))
TIMING2['rev20']     = lambda c,h,l: _lag(-np.nan_to_num(_mom(c, 20), nan=0.0))
TIMING2['rev240']    = lambda c,h,l: _lag(-np.nan_to_num(_mom(c, 240), nan=0.0))
TIMING2['pos240']    = lambda c,h,l: sig_posw(c, h, l, 240)
TIMING2['pos20']     = lambda c,h,l: sig_posw(c, h, l, 20)
TIMING2['vwap168']   = lambda c,h,l: _lag(np.nan_to_num(np.sign(c - ma((h+l+c)/3.0, 168)), nan=0.0))
TIMING2['macd']      = sig_macd
TIMING2['rsi14']     = sig_rsi14

data = load(); names = sorted(data)
print(f'loaded {len(names)} symbols', flush=True)

def pick(win, rng, gapbar):
    if len(win) == 0: return np.array([], int)
    out = []; target = win[0]; p = 0
    while True:
        while p < len(win) and win[p] < target: p += 1
        if p >= len(win): break
        out.append(win[p]); target = win[p] + int(rng.integers(gapbar[0], gapbar[1]+1))
    return np.array(out, int)

def run_block(o,h,l,c, a, win, n, rng, TKEY_label, rows22, rows5, nm, sd, judges=JUDGES):
    idx_t = pick(win, rng, GAPBAR)
    if len(idx_t) < 5: return
    idx_r = rand_times(n, rng, GAPBAR[0], GAPBAR[1], start=int(win[0]))
    dr_t = a[idx_t]; dr_rand_t = rng.choice([-1.0, 1.0], size=len(idx_t))
    a_r = a[idx_r];  d_rr = rng.choice([-1.0, 1.0], size=len(idx_r))
    def rv(idx, dire): return trades_vec(o,h,l,c, idx, dire, STOP, R, MAXH)[0]
    cells = {
        'randT/randD': rv(idx_r, d_rr),
        'randT/timeD': rv(idx_r, a_r),
        'timeT/randD': rv(idx_t, dr_rand_t),
        'timeT/timeD': rv(idx_t, dr_t),
    }
    for k, v in cells.items():
        if len(v): rows22.append(dict(sym=nm, seed=sd, timing=TKEY_label, cell=k, r=v.mean(), n=len(v)))
    for jn in judges:
        j = JUD[jn](c,h,l); jt = j[idx_t]
        ag = (jt == dr_t) & (jt != 0); ds = (jt != dr_t) & (jt != 0)
        groups = {
            'A':  rv(idx_t, dr_t),
            'B':  rv(idx_t, np.where(jt != 0, jt, dr_t)),
            'C':  rv(idx_t[ag], dr_t[ag]),
            'D1': rv(idx_t[ds], jt[ds]),
            'D2': rv(idx_t[ds], dr_t[ds]),
        }
        for g, v in groups.items():
            if len(v): rows5.append(dict(sym=nm, seed=sd, timing=TKEY_label, jud=jn, grp=g, r=v.mean(), n=len(v)))

rows22, rows5 = [], []
# 1) 真实择时策略
for TKEY in TIMING2:
    for nm in names:
        d = data[nm]
        o,h,l,c = d.open.values, d.high.values, d.low.values, d.close.values
        a = TIMING2[TKEY](c,h,l); win = np.where(a != 0)[0]; n = len(c)
        if len(win) < 100: continue
        for sd in SEEDS:
            rng = np.random.default_rng(1000+sd)
            run_block(o,h,l,c, a, win, n, rng, TKEY, rows22, rows5, nm, sd)
    print(f'  done {TKEY}', flush=True)

# 2) 随机择时零分布（方向随机、常驻）=> 用于 RC 校正
NR = 20
for k in range(NR):
    for nm in names:
        d = data[nm]
        o,h,l,c = d.open.values, d.high.values, d.low.values, d.close.values
        n = len(c)
        a = rand_jud(n, 50000+k)          # 随机方向，处处非0
        win = np.where(a != 0)[0]
        for sd in SEEDS:
            rng = np.random.default_rng(1000+sd)
            run_block(o,h,l,c, a, win, n, rng, f'randT{k}', rows22, rows5, nm, sd, judges=[])
print('  done rand timing null', flush=True)

pd.DataFrame(rows22).to_csv('/data/workspace/subjective2/scan22.csv', index=False)
pd.DataFrame(rows5).to_csv('/data/workspace/subjective2/scan5.csv', index=False)
print('saved scan22/scan5', len(rows22), len(rows5))
