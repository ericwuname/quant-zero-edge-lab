"""Step2: 基线诊断 —— 随机时点+随机方向的 +0.016 是什么？是否只是牛市漂移？
并加 BH(全做多/全做空) 对照，看择时逻辑是否优于无脑做多
"""
import sys, numpy as np, pandas as pd
sys.path.insert(0,'/data/workspace/subjective2')
from core2 import *

STOP, R, MAXH = 0.05, 2.0, 480
GAPBAR = (24, 480)
SEEDS = list(range(10))
TKEY = sys.argv[1] if len(sys.argv)>1 else 'brk500'

data = load(); names = sorted(data)
rows = []
diag = []
for nm in names:
    d = data[nm]
    o,h,l,c = d.open.values, d.high.values, d.low.values, d.close.values
    a = TIMING[TKEY](c,h,l)
    win = np.where(a!=0)[0]
    n = len(c)
    for sd in SEEDS:
        rng = np.random.default_rng(1000+sd)
        # 与 step1 完全一致的 pick
        out=[]; target=win[0]; p=0
        while True:
            while p<len(win) and win[p]<target: p+=1
            if p>=len(win): break
            out.append(win[p]); target = win[p]+int(rng.integers(GAPBAR[0],GAPBAR[1]+1))
        idx_t = np.array(out,int)
        idx_r = rand_times(n, rng, GAPBAR[0], GAPBAR[1], start=int(win[0]))
        if len(idx_t)<5: continue
        rr_rand = rng.choice([-1.0,1.0], size=len(idx_t))
        for lab, idx, dire in [
            ('A_择时', idx_t, a[idx_t]),
            ('BH_long', idx_t, np.ones(len(idx_t))),
            ('BH_short', idx_t, -np.ones(len(idx_t))),
            ('timeT_randD', idx_t, rr_rand),
            ('randT_randD', idx_r, rng.choice([-1.0,1.0],size=len(idx_r))),
        ]:
            r = trades_vec(o,h,l,c, idx, dire, STOP, R, MAXH)[0]
            # 记录时间位置（用于分段诊断）
            frac = (idx/n).mean()
            rows.append(dict(sym=nm, seed=sd, lab=lab, r=r.mean(), n=len(r), tf=frac))
        # 分段：把 randT_randD 按年份位置分 4 段
        r = trades_vec(o,h,l,c, idx_r, rng.choice([-1.0,1.0],size=len(idx_r)), STOP,R,MAXH)[0]
        seg = np.minimum((idx_r/n*4).astype(int),3)
        for k in range(4):
            m = seg==k
            if m.sum()>3: diag.append(dict(sym=nm, seed=sd, seg=k, r=r[m].mean()))

df = pd.DataFrame(rows); dd = pd.DataFrame(diag)
df['sym2']=df.sym.str.replace('USDT','',regex=False)
print(f'===== 基线诊断 & BH 对照（择时={TKEY}）=====')
print()
print('--- 毛E(R/笔) 跨品种 ---')
for lab in ['A_择时','BH_long','BH_short','timeT_randD','randT_randD']:
    sub = df[df.lab==lab].groupby('sym2').r.mean()
    m,t,k = xsec_t(sub.values)
    print(f'  {lab:<13} 均值{m:+.4f}  t={t:+.2f}  为正{int((sub>0).sum())}/{k}')
print()
print('--- 关键对比（跨品种配对）---')
pv = df.pivot_table(index=['sym2','seed'], columns='lab', values='r')
for a_,b_ in [('A_择时','BH_long'),('A_择时','randT_randD'),('A_择时','timeT_randD'),('BH_long','BH_short')]:
    dif = (pv[a_]-pv[b_]).groupby('sym2').mean()
    m,t,k = xsec_t(dif.values)
    print(f'  {a_} - {b_:<12} 均值{m:+.4f}  t={t:+.2f}  为正{int((dif>0).sum())}/{k}')
print()
print('--- 基线(随机时点+随机方向) 按时间四等分 ---')
for k in range(4):
    sub = dd[dd.seg==k].groupby('sym').r.mean()
    m,t,_ = xsec_t(sub.values)
    print(f'  第{k+1}/4 段: 毛E {m:+.4f}  t={t:+.2f}')
print()
print('--- 各品种 A vs BH_long ---')
sub = (pv['A_择时']-pv['BH_long']).groupby('sym2').mean().sort_values()
print(sub.round(4).to_string())
