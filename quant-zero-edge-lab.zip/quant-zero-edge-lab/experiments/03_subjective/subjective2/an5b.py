"""最终分析：主指标 D1-D2（同时点、只换方向 = 无偏方向能力）
零分布用 30 个随机判断校准
"""
import sys, numpy as np, pandas as pd
sys.path.insert(0,'/data/workspace/subjective2')
from core2 import xsec_t, OLD7, NEW6

COST_R = 0.008
TKEY = sys.argv[1] if len(sys.argv)>1 else 'brk500'
d = pd.read_csv(f'/data/workspace/subjective2/r5_{TKEY}.csv')
d['sym2']=d.sym.str.replace('USDT','',regex=False)
d = d[d.grp!='AGREE']
rd = pd.read_csv(f'/data/workspace/subjective2/rand_{TKEY}.csv')

# 按 sym+seed 聚合（保留配对结构）
g = d.groupby(['sym2','seed','jud','grp']).r.mean().unstack('grp')
g['D1_D2'] = g['D1']-g['D2']; g['C_D2'] = g['C']-g['D2']; g['B_A'] = g['B']-g['A']
g = g.reset_index()

# 一致率
ag = pd.read_csv(f'/data/workspace/subjective2/r5_{TKEY}.csv')
ag = ag[ag.grp=='AGREE'].groupby(['jud']).r.mean()

rr = rd.copy(); rr['D1_D2']=rr.D1-rr.D2; rr['C_D2']=rr.C-rr.D2
null_d = rr.groupby('jud')[['D1_D2','C_D2']].mean()

print(f'===== 最终判定（择时={TKEY} + 随机间隔执行）=====')
print('主指标 D1-D2：在"主观与锚点不一致"的同一批时点上，坚持主观 vs 服从锚点')
print('（同时点、只换方向 => 无偏的方向能力估计）\n')
print(f"{'判断':<9}{'一致率':>7}{'A锚点':>8}{'B主观':>8}{'C':>8}{'D1':>8}{'D2':>8}"
      f"{'D1-D2':>8}{'t':>7}{'z(null)':>9}{'RC':>7}")
res=[]
for jn in sorted(g.jud.unique()):
    s = g[g.jud==jn]
    if s.D1_D2.isna().all(): 
        print(f'{jn:<9}{ag.get(jn,float("nan")):>7.3f}   (无不一致时点)'); continue
    dif = s.groupby('sym2').D1_D2.mean()
    m,t,k = xsec_t(dif.values)
    z = (m - null_d.D1_D2.mean())/null_d.D1_D2.std(ddof=1)
    rc = (null_d.D1_D2 >= m).mean()
    res.append(dict(jud=jn, m=m, t=t, z=z, rc=rc, k=k))
    print(f"{jn:<9}{ag.get(jn,float('nan')):>7.3f}{s.A.mean():>8.4f}{s.B.mean():>8.4f}{s.C.mean():>8.4f}"
          f"{s.D1.mean():>8.4f}{s.D2.mean():>8.4f}{m:>+8.4f}{t:>7.2f}{z:>9.2f}{rc:>7.3f}")

print()
print(f"零分布(30随机判断): D1-D2 均值{null_d.D1_D2.mean():+.4f} sd{null_d.D1_D2.std(ddof=1):.4f} "
      f"max{null_d.D1_D2.max():+.4f}")
print()

print('--- 分 OLD7 / NEW6 (D1-D2) ---')
for lab,S in [('OLD7',OLD7),('NEW6',NEW6)]:
    S2={x.replace('USDT','') for x in S}
    for jn in ['ma50','mom20','vwap168','pos240','ma200','mom240','brk100','rev20','rev240']:
        s=g[g.jud==jn]
        if s.D1_D2.isna().all(): continue
        v=s.groupby('sym2').D1_D2.mean(); v=v[v.index.isin(S2)].dropna()
        if len(v)<2: continue
        m,t,k=xsec_t(v.values)
        print(f'  {lab} {jn:<8} 均值{m:+.4f} t={t:+.2f} 为正{int((v>0).sum())}/{k}')

print()
print('--- 族层面：趋势族 vs 反转族 (D1-D2 跨品种) ---')
TREND=['ma50','ma200','mom20','mom240','pos240','vwap168','brk100']
REV=['rev20','rev240']
for lab,J in [('趋势族',TREND),('反转族',REV)]:
    vv=[]
    for jn in J:
        s=g[g.jud==jn]
        if s.D1_D2.isna().all(): continue
        vv.append(s.groupby('sym2').D1_D2.mean())
    M=pd.concat(vv,axis=1); fm=M.mean(axis=1)
    m,t,k=xsec_t(fm.values)
    print(f'  {lab:<6} 均值{m:+.4f} t={t:+.2f} n={k} 为正{int((fm>0).sum())}/{k}')

print()
print('--- 成本敏感性（ma50 的 D1-D2，净）---')
s=g[g.jud=='ma50']; v=s.groupby('sym2').D1_D2.mean(); m,t,k=xsec_t(v.values)
for c in [0.008,0.02,0.04,0.05]:
    print(f'  cost_R={c:<6} 净 {m-c:+.4f}  {"正" if m-c>0 else "负"}')
