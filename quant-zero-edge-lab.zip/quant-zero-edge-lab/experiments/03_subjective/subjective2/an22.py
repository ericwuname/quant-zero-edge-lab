import sys, numpy as np, pandas as pd
sys.path.insert(0,'/data/workspace/subjective2')
from core2 import xsec_t, OLD7, NEW6

TKEY = sys.argv[1] if len(sys.argv)>1 else 'brk500'
COST_R = 0.008
d = pd.read_csv(f'/data/workspace/subjective2/r22_{TKEY}.csv')
d['sym2'] = d.sym.str.replace('USDT','',regex=False)

print(f'===== 2x2 分解（择时={TKEY}）=====')
print('单位：R/笔（毛），净 = 毛 - cost_R(0.008)')
print()
per = d.groupby(['sym2','timing','direction']).r.agg(['mean','count']).reset_index()
piv = per.pivot_table(index='sym2', columns=['timing','direction'], values='mean')
print('--- 各品种毛E(R/笔) ---')
print(piv.round(4).to_string())
print()

print('--- 2x2 汇总（跨品种 t，保守口径）---')
hdr = f"{'单元格':<16}{'毛E':>9}{'净E':>9}{'t':>8}{'N':>9}"
print(hdr)
cells = [('randT','randD'),('randT','timeD'),('timeT','randD'),('timeT','timeD')]
res = {}
for tk,dk in cells:
    sub = per[(per.timing==tk)&(per.direction==dk)]
    m,t,k = xsec_t(sub['mean'].values)
    res[(tk,dk)] = m
    print(f'{tk+"/"+dk:<16}{m:>9.4f}{m-COST_R:>9.4f}{t:>8.2f}{int(sub["count"].sum()):>9}')

print()
print('--- 分解贡献 ---')
base = res[('randT','randD')]
dir_c = res[('randT','timeD')] - base
tim_c = res[('timeT','randD')] - base
tot   = res[('timeT','timeD')] - base
print(f'  基线(随机时点+随机方向) : {base:+.4f}   <- 鞅性检验，应≈0')
print(f'  【方向】贡献 : {dir_c:+.4f}    = 随机时点下，用择时方向替代随机方向')
print(f'  【时机】贡献 : {tim_c:+.4f}    = 随机方向下，用择时时点替代随机时点')
print(f'  合计(A-基线) : {tot:+.4f}    交互项 = {tot-dir_c-tim_c:+.4f}')
print()

# 方向贡献的显著性：逐品种差值
p1 = per[(per.timing=='randT')].pivot_table(index='sym2',columns='direction',values='mean')
p2 = per[(per.timing=='timeT')].pivot_table(index='sym2',columns='direction',values='mean')
dif_d = (p1['timeD']-p1['randD']); dif_t = (p2['timeD']-p2['randD'])
dif_time = (p2['randD']-p1['randD'])
for nm,v in [('方向贡献(随机时点)',dif_d),('方向贡献(择时时点)',dif_t),('时机贡献(随机方向)',dif_time)]:
    m,t,k = xsec_t(v.values)
    print(f'  {nm:<22} 均值{m:+.4f}  t={t:+.2f}  n={k}')
print()
print('--- 逐品种方向贡献（随机时点：择时方向 - 随机方向）---')
print(dif_d.round(4).sort_values().to_string())
print()
print('--- 分 OLD7 / NEW6 ---')
for lab,S in [('OLD7(参与过挑选)',OLD7),('NEW6(干净)',NEW6)]:
    S2 = {s.replace('USDT','') for s in S}
    v = dif_d[dif_d.index.isin(S2)]
    m,t,k = xsec_t(v.values)
    print(f'  {lab:<18} n={k} 均值{m:+.4f} t={t:+.2f} 为正{int((v>0).sum())}/{k}')
