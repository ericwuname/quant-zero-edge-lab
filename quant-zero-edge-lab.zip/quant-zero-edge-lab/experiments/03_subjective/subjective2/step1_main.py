"""Step1: 固定择时(brk500/brk100/ma50) 圈定可交易窗口 + 窗口内随机间隔执行
2x2 分解（时机 vs 方向）+ 五组 A/B/C/D1/D2
"""
import sys, numpy as np, pandas as pd
sys.path.insert(0, '/data/workspace/subjective2')
from core2 import *

STOP, R, MAXH, COST_R = 0.05, 2.0, 480, 0.008
SEEDS = list(range(10))
GAPBAR = (24, 480)     # 随机间隔 24~480 根 bar（1~20天）
JUDGES = ['ma50','ma200','brk500','brk100','mom20','mom240','rev20','rev240','pos240','vwap168']
TKEY = sys.argv[1] if len(sys.argv) > 1 else 'brk500'

data = load()
names = sorted(data)
print(f'=== 择时={TKEY} 品种{len(names)} STOP={STOP} R={R} cost_R={COST_R} gapbar={GAPBAR} seeds={len(SEEDS)} ===')

pre = {}
for nm in names:
    d = data[nm]
    c = d.close.values; h = d.high.values; l = d.low.values
    a = TIMING[TKEY](c, h, l)
    win = np.where(a != 0)[0]                 # 择时圈定的可交易窗口
    nfl = len(opp_flips(a))
    pre[nm] = dict(o=d.open.values, h=h, l=l, c=c, a=a, win=win, nfl=nfl)
print('  窗口占比 & 翻转次数:')
for nm in names:
    P = pre[nm]
    print(f'    {nm}: 窗口bar {len(P["win"])} ({len(P["win"])/len(P["c"])*100:.0f}%)  信号翻转 {P["nfl"]}')


def pick(win, rng, gapbar):
    """在择时窗口内随机间隔游走：每次跳 gap ~ U(bar) 根"""
    if len(win) == 0: return np.array([], int)
    out = []; target = win[0]
    p = 0
    while True:
        while p < len(win) and win[p] < target: p += 1
        if p >= len(win): break
        out.append(win[p])
        target = win[p] + int(rng.integers(gapbar[0], gapbar[1]+1))
    return np.array(out, int)


rows_22, rows_5 = [], []
for nm in names:
    P = pre[nm]
    o, h, l, c, a, win = P['o'], P['h'], P['l'], P['c'], P['a'], P['win']
    n = len(c)
    for sd in SEEDS:
        rng = np.random.default_rng(1000+sd)
        idx_t = pick(win, rng, GAPBAR)
        if len(idx_t) < 5: continue
        idx_r = rand_times(n, rng, GAPBAR[0], GAPBAR[1], start=int(win[0]))
        dr_t = a[idx_t]
        dr_rand = rng.choice([-1.0, 1.0], size=len(idx_t))
        a_r = a[idx_r]
        d_rr = rng.choice([-1.0, 1.0], size=len(idx_r))

        def run(idx, dire):
            return trades_vec(o, h, l, c, idx, dire, STOP, R, MAXH)[0]

        for (tk, dk), v in {
            ('randT','randD'): run(idx_r, d_rr),
            ('randT','timeD'): run(idx_r, a_r),
            ('timeT','randD'): run(idx_t, dr_rand),
            ('timeT','timeD'): run(idx_t, dr_t),
        }.items():
            for x in v:
                rows_22.append(dict(sym=nm, seed=sd, timing=tk, direction=dk, r=x))

        for jn in JUDGES:
            j = JUD[jn](c, h, l); jt = j[idx_t]
            ag = (jt == dr_t) & (jt != 0)
            ds = (jt != dr_t) & (jt != 0)
            for g, v in {
                'A':  run(idx_t, dr_t),
                'B':  run(idx_t, np.where(jt != 0, jt, dr_t)),
                'C':  run(idx_t[ag], dr_t[ag]),
                'D1': run(idx_t[ds], jt[ds]),
                'D2': run(idx_t[ds], dr_t[ds]),
            }.items():
                for x in v:
                    rows_5.append(dict(sym=nm, seed=sd, jud=jn, grp=g, r=x))

pd.DataFrame(rows_22).to_csv(f'r22_{TKEY}.csv', index=False)
pd.DataFrame(rows_5).to_csv(f'r5_{TKEY}.csv', index=False)
print('saved', len(rows_22), len(rows_5))
