"""实验2：固定择时逻辑（含方向）产生交易机会 + 随机间隔执行节点 + 主观判断
相对实验1的关键变化：锚点不再是"随机时点+随机方向"，而是"择时筛选的时点+择时方向"
=> 可额外做 2x2 分解：把【入场时机】与【方向】的贡献彻底分开
2x2:
              随机方向          择时方向
  随机时点     基线(≈0)         → 方向贡献
  择时时点     → 时机贡献        A组(总贡献)
五组（在随机间隔抽样的执行节点上）:
  A  = 执行锚点方向(择时方向)
  B  = 执行主观方向
  C  = 只在主观==锚点时执行
  D1 = 只在主观!=锚点时，执行主观（坚持自己）
  D2 = 只在主观!=锚点时，执行锚点（服从锚点 = -主观）
注意：本设计中"一致/不一致"不再是随机二分（两个真实信号相关），
      故 C-D2 混杂了时点质量差异；用 rand 判断做 null 基线来分离。
"""
import numpy as np, pandas as pd, glob, os, pickle

DATA = '/data/inputs'
OLD7 = {'CRVUSDT','DASHUSDT','DOGEUSDT','DOTUSDT','ETHUSDT','FILUSDT','HBARUSDT'}
NEW6 = {'TRXUSDT','UNIUSDT','XLMUSDT','XMRUSDT','XRPUSDT','ZECUSDT'}
CACHE = '/data/workspace/subjective2/cache.pkl'


def load():
    out = {}
    for p in sorted(glob.glob(DATA+'/*_1h.csv')):
        nm = os.path.basename(p).replace('_1h.csv','')
        d = pd.read_csv(p)
        cols = {c.lower(): c for c in d.columns}
        if not all(k in cols for k in ('open','high','low','close')):
            continue
        d = d[[cols[k] for k in ('open','high','low','close')]].copy()
        d.columns = ['open','high','low','close']
        d = d.dropna().astype(float)
        d = d[(d.open>0)&(d.high>0)&(d.low>0)&(d.close>0)]
        if len(d) < 5000:
            continue
        out[nm] = d.reset_index(drop=True)
    return out


# ---------------- 信号（全部内部滞后1根，可在 open[i] 合法使用） ----------------
def _lag(x):
    return np.r_[0.0, x[:-1]]

def ma(x, w):
    return pd.Series(x).rolling(w, min_periods=w).mean().values

def hh(x, w):
    return pd.Series(x).rolling(w, min_periods=w).max().values

def ll(x, w):
    return pd.Series(x).rolling(w, min_periods=w).min().values

def _mom(c, w):
    prev = np.r_[np.full(w, np.nan), c[:-w]]
    return np.sign(c - prev)


def sig_brk(c, h, l, w):
    """唐奇安通道突破（真正的状态机：只有突破才翻转，通道内保持前值）
    旧写法 sign(c-H) 在通道内恒为 -1 => 退化成"几乎全做空"，是 bug"""
    # 通道 = 前 w 根（不含当前 bar），突破用当前 bar 的 high/low
    H = np.r_[np.full(1, np.nan), hh(h, w)[:-1]]
    L = np.r_[np.full(1, np.nan), ll(l, w)[:-1]]
    ok = ~(np.isnan(H) | np.isnan(L))
    ev = np.where(ok & (h > H), 1.0, np.where(ok & (l < L), -1.0, np.nan))
    st = pd.Series(ev).ffill().fillna(0.0).values     # 状态机 = ffill
    return _lag(st)


def sig_ma(c, w):
    m = ma(c, w)
    s = np.where(np.isnan(m), 0.0, np.sign(c - m))
    return _lag(s)


TIMING = {
    # 最常用的唐奇安突破（中周期 w=500≈21天；另给短周期 w=100 对照）
    'brk500': lambda c,h,l: sig_brk(c,h,l,500),
    'brk100': lambda c,h,l: sig_brk(c,h,l,100),
    'ma50':   lambda c,h,l: sig_ma(c,50),
}

JUD = {
    'ma50':    lambda c,h,l: sig_ma(c,50),
    'ma200':   lambda c,h,l: sig_ma(c,200),
    'brk500':  lambda c,h,l: sig_brk(c,h,l,500),
    'brk100':  lambda c,h,l: sig_brk(c,h,l,100),
    'mom20':   lambda c,h,l: _lag(_mom(c,20)),
    'mom240':  lambda c,h,l: _lag(_mom(c,240)),
    'rev20':   lambda c,h,l: _lag(-_mom(c,20)),
    'rev240':  lambda c,h,l: _lag(-_mom(c,240)),
    'pos240':  lambda c,h,l: _lag(np.sign((c - (hh(h,240)+ll(l,240))/2) /
                                          np.where(hh(h,240)-ll(l,240) > 0, hh(h,240)-ll(l,240), np.nan))),
    'vwap168': lambda c,h,l: _lag(np.sign(c - ma((h+l+c)/3.0, 168))),
}


def rand_jud(n, seed):
    rng = np.random.default_rng(seed)
    return rng.choice([-1.0, 1.0], size=n)


# ---------------- 独立交易引擎（复用实验1，已验证） ----------------
def trades_vec(o, h, l, c, idx, direction, stop_pct, R, max_hold=480, slip_bp=0.0):
    """每个 idx 一笔独立交易（不共享持仓）=> 时点完全外生"""
    o = np.asarray(o, float); h = np.asarray(h, float)
    l = np.asarray(l, float); c = np.asarray(c, float)
    idx = np.asarray(idx, int); d = np.asarray(direction, float)
    n = len(o); m = len(idx)
    if m == 0:
        return np.array([]), np.array([], int)
    entry = o[idx]; sp = entry*(1 - d*stop_pct); tp = entry*(1 + d*R*stop_pct)
    pos = (d > 0)
    res = np.full(m, np.nan); typ = np.full(m, -1)
    hs = np.where(pos, l[idx] <= sp, h[idx] >= sp)
    ht = np.where(pos, h[idx] >= tp, l[idx] <= tp)
    done = hs | ht
    res = np.where(done, np.where(hs, -1.0, float(R)), np.nan)
    typ = np.where(done, np.where(hs, 0, 1), -1)
    pend = np.where(~done)[0]
    if len(pend) > 0:
        K = max_hold
        ii = idx[pend][:, None] + 1 + np.arange(K)[None, :]
        mask = ii < n
        iic = np.clip(ii, 0, n-1)
        dd = d[pend][:, None]; p2 = pos[pend][:, None]
        advpad = dd*1e18; favpad = -dd*1e18
        aw = np.where(mask, np.where(p2, l[iic], h[iic]), advpad)
        fw = np.where(mask, np.where(p2, h[iic], l[iic]), favpad)
        spp = sp[pend][:, None]; tpp = tp[pend][:, None]
        shw = np.where(p2, aw <= spp, aw >= spp)
        thw = np.where(p2, fw >= tpp, fw <= tpp)
        has_s = shw.any(1); has_t = thw.any(1)
        fs = np.where(has_s, np.argmax(shw, 1), K+1)
        ft = np.where(has_t, np.argmax(thw, 1), K+2)
        take_s = has_s & (fs <= ft)
        take_t = has_t & (ft < fs)
        kk = np.where(take_s, np.minimum(fs, K), np.where(take_t, np.minimum(ft, K), K))
        ex = np.where(take_s, sp[pend]*(1 - np.sign(d[pend])*slip_bp/1e4),
              np.where(take_t, tp[pend], o[np.minimum(idx[pend]+1+kk, n-1)]))
        rr = (ex - entry[pend])*d[pend]/np.abs(entry[pend])/stop_pct
        ty2 = np.where(take_s, 0, np.where(take_t, 1, -1))
        res[pend] = rr; typ[pend] = ty2
    return res, typ


def opp_flips(sig):
    """交易机会 = 信号翻转点（新方向确立的那根 bar）"""
    s = np.asarray(sig, float)
    prev = np.r_[0.0, s[:-1]]
    return np.where((s != 0) & (s != prev))[0]


def exec_nodes(opp, rng, gap_lo=1, gap_hi=3):
    """随机间隔执行：在机会序列上随机游走，跳过的机会数 ~ U[gap_lo, gap_hi]"""
    opp = np.asarray(opp, int)
    if len(opp) == 0:
        return np.array([], int)
    out = []
    p = int(rng.integers(0, gap_hi))
    while p < len(opp):
        out.append(opp[p])
        p += int(rng.integers(gap_lo, gap_hi+1))
    return np.array(out, int)


def rand_times(n, rng, gap_lo=60, gap_hi=480, start=None):
    """随机时点（基线）。start 必须与择时时点的起点一致，否则会伪造"时机贡献" """
    idx = []
    i = int(start if start is not None else rng.integers(200, max(201, n-600)))
    while i < n-1:
        idx.append(i)
        i += int(rng.integers(gap_lo, gap_hi+1))
    return np.array(idx, int)


def xsec_t(vals):
    """跨品种 t 值（以品种为单位，保守口径）"""
    v = np.asarray(vals, float)
    v = v[~np.isnan(v)]
    if len(v) < 3:
        return np.nan, np.nan, len(v)
    m = v.mean(); sd = v.std(ddof=1)
    return m, (m/(sd/np.sqrt(len(v))) if sd > 0 else np.nan), len(v)
