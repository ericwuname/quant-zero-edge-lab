"""Step3: 随机判断零分布 —— 校准 D1-D2（同时点纯方向差）与 C-D2
D1/D2 在完全相同的不一致时点集上，仅方向不同 => D1-D2 是无偏的方向能力估计
随机判断与真实信号独立 => 其 D1-D2 应为 0，提供精确零分布
"""
import sys, numpy as np, pandas as pd
sys.path.insert(0,'/data/workspace/subjective2')
from core2 import *

STOP, R, MAXH = 0.05, 2.0, 480
GAPBAR = (24, 480)
SEEDS = list(range(10))
TKEY = sys.argv[1] if len(sys.argv)>1 else 'brk500'
NRAND = 30

data = load(); names = sorted(data)
rows = []
for nm in names:
    d = data[nm]
    o,h,l,c = d.open.values, d.high.values, d.low.values, d.close.values
    a = TIMING[TKEY](c,h,l)
    win = np.where(a!=0)[0]
    for sd in SEEDS:
        rng = np.random.default_rng(1000+sd)
        out=[]; target=win[0]; p=0
        while True:
            while p<len(win) and win[p]<target: p+=1
            if p>=len(win): break
            out.append(win[p]); target=win[p]+int(rng.integers(GAPBAR[0],GAPBAR[1]+1))
        idx = np.array(out,int)
        if len(idx)<5: continue
        dr = a[idx]
        # 30 个随机判断
        for k in range(NRAND):
            jt = rng.choice([-1.0,1.0], size=len(idx))
            ag = (jt==dr); ds = ~ag
            res = {}
            for g, ii, dd in [('C', idx[ag], dr[ag]), ('D1', idx[ds], jt[ds]), ('D2', idx[ds], dr[ds])]:
                if len(ii)==0: continue
                res[g] = trades_vec(o,h,l,c, ii, dd, STOP, R, MAXH)[0].mean()
            if 'C' in res and 'D1' in res and 'D2' in res:
                rows.append(dict(sym=nm, seed=sd, jud=f'rand{k}', C=res['C'], D1=res['D1'], D2=res['D2'],
                                 agree=ag.mean()))
df = pd.DataFrame(rows)
df['sym2']=df.sym.str.replace('USDT','',regex=False)
df.to_csv(f'rand_{TKEY}.csv', index=False)
print(f'saved {len(df)} 随机判断样本 (择时={TKEY})')
print('一致率(随机判断) 均值 %.4f (理论 0.5)' % df.agree.mean())

# 跨品种聚合
per = df.groupby('jud')[['C','D1','D2']].mean()
per['D1_D2'] = per.D1 - per.D2
per['C_D2'] = per.C - per.D2
print()
print('--- 随机判断的 D1-D2 与 C-D2 分布（零分布）---')
for col in ['D1_D2','C_D2']:
    v = per[col].values
    print(f'  {col}: 均值{v.mean():+.5f}  sd{v.std(ddof=1):.5f}  '
          f'[{np.percentile(v,5):+.4f},{np.percentile(v,95):+.4f}]  max{v.max():+.4f}')
