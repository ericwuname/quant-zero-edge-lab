"""ma50 的最终验证：族层面一致性 / OLD7-NEW6外推 / 成本曲线 / 收割制(不复利+盈余公积)"""
import numpy as np, pandas as pd, core, pickle
d=core.load(); SYMS=sorted(d.keys()); STOP=0.05;R=2.0;MAXH=480
SEEDS=range(12); PRE=pickle.load(open('/data/workspace/subjective/cacheA.pkl','rb'))
OLD={'CRV','DASH','DOGE','DOT','ETH','FIL','HBAR'}; NEW={'TRX','UNI','XLM','XMR','XRP','ZEC'}
def grp(k): return 'OLD7' if k.replace('USDT','') in OLD else ('NEW6' if k.replace('USDT','') in NEW else '?')

def per_symbol_BA(nm):
    out={}
    for k in SYMS:
        df=d[k]; o,h,l,c=df.open.values,df.high.values,df.low.values,df.close.values
        if nm.startswith('rand'): j=np.sign(np.random.default_rng(7000+int(nm[4:])).standard_normal(len(c)))
        elif nm=='cheat': j=core.jud_cheat(c,h,l,o)
        else: j=core.JUDS[nm](c,h,l,o)
        bs=[];as_=[]
        for sd in SEEDS:
            idx,s,rA=PRE[(k,sd)]; jj=j[idx]; ok=np.isfinite(jj)&(jj!=0)
            if ok.sum()<20: continue
            rB,_=core.trades_vec(o,h,l,c,idx[ok],jj[ok],STOP,R,MAXH)
            bs.append(rB.mean()); as_.append(rA[ok].mean())
        out[k]=np.mean(bs)-np.mean(as_)
    return pd.Series(out)

print("=== 1. 族层面：趋势类 vs 反转类 ===")
TREND=['ma50','ma200','mom20','mom240','pos240','vwap168','brk500','brk100']
REV=['rev20','rev240']
tv=np.mean([per_symbol_BA(n).values for n in TREND],axis=0)
rv=np.mean([per_symbol_BA(n).values for n in REV],axis=0)
ct=lambda v: v.mean()/(v.std(ddof=1)/np.sqrt(len(v)))
print(f"  趋势族(8个平均) B-A={tv.mean():+.4f} t={ct(tv):+.2f} 为正={np.sum(tv>0)}/13")
print(f"  反转族(2个平均) B-A={rv.mean():+.4f} t={ct(rv):+.2f} 为正={np.sum(rv>0)}/13")
print(f"  趋势-反转差     ={tv.mean()-rv.mean():+.4f}")

print("\n=== 2. ma50 外推：OLD7 vs NEW6（品种外推）===")
v=per_symbol_BA('ma50'); og=v[[k for k in v.index if grp(k)=='OLD7']]; ng=v[[k for k in v.index if grp(k)=='NEW6']]
print(f"  OLD7: {og.mean():+.4f} (为正{np.sum(og>0)}/7)   NEW6: {ng.mean():+.4f} (为正{np.sum(ng>0)}/6)")
print(f"  外推保留率 = {ng.mean()/og.mean()*100:.0f}%" if og.mean()!=0 else "  n/a")

print("\n=== 3. 成本敏感性 (ma50, B-A毛=+0.0345) ===")
g=0.0345
for nm,bp in [('maker 2bp',2),('3bp',3),('taker 10bp',10),('20bp',20)]:
    cr=2*bp/(5*100)
    print(f"  {nm:12s} cost_R={cr:.4f} 净B-A={g-cr:+.4f} {'正' if g>cr else '负'}")

# ---------- 4. 收割制：不复利 + 盈余公积 ----------
print("\n=== 4. 收割制（本金1万，固定注，翻倍即收割，20%爆仓线）===")
def seqs(nm):
    """按时间排序的R序列（每品种一个序列）"""
    out={}
    for k in SYMS:
        df=d[k]; o,h,l,c=df.open.values,df.high.values,df.low.values,df.close.values
        if nm=='ANCHOR': j=None
        elif nm.startswith('rand'): j=np.sign(np.random.default_rng(7000+int(nm[4:])).standard_normal(len(c)))
        elif nm=='cheat': j=core.jud_cheat(c,h,l,o)
        else: j=core.JUDS[nm](c,h,l,o)
        ts=[];rs=[]
        for sd in SEEDS:
            idx,s,rA=PRE[(k,sd)]
            if nm=='ANCHOR': ok=np.ones(len(idx),bool); jj=None
            else: jj=j[idx]; ok=np.isfinite(jj)&(jj!=0)
            r = rA[ok] if nm=='ANCHOR' else core.trades_vec(o,h,l,c,idx[ok],jj[ok],STOP,R,MAXH)[0]
            ts.append(idx[ok]); rs.append(r)
        t=np.concatenate(ts); r=np.concatenate(rs); o2=np.argsort(t)
        out[k]=r[o2]
    return out

def harvest(sq,f,C0=10000,nb=400,rng=None):
    """按品种分块自助；返回 P(赚回本金), 盈亏中位, 爆仓率"""
    ks=list(sq.keys()); succ=[];pnl=[];bk=[]
    for b in range(nb):
        pick=rng.choice(len(ks),len(ks),replace=True)
        pool=np.concatenate([sq[ks[i]][rng.integers(0,len(sq[ks[i]]),len(sq[ks[i]]))] for i in pick])
        net=float(C0); ex=0.0; dead=False
        for r in pool:
            net+=r*f*C0
            if net>=2*C0: ex+=net-C0; net=float(C0)
            if net<=0.2*C0: dead=True; break
        succ.append(ex>=C0); pnl.append(ex+net-C0); bk.append(dead)
    return np.mean(succ),np.median(pnl),np.mean(bk)

rng=np.random.default_rng(42)
S={nm:seqs(nm) for nm in ['ANCHOR','ma50','mom20','rev20','rand1']}
for f in [0.01,0.02]:
    print(f"\n  仓位 f={f*100:.0f}%:")
    print(f"    {'模式':10s} {'P(赚回本金)':>12s} {'盈亏中位':>10s} {'爆仓率':>8s}")
    for nm in ['ANCHOR','ma50','mom20','rev20','rand1']:
        p,m,b=harvest(S[nm],f,rng=rng)
        print(f"    {nm:10s} {p:12.3f} {m:+10.0f} {b:8.3f}")
