"""主观判断实验核心：随机锚点(外生时点) + 主观判断(方向) 的干净分离
关键结构：锚点方向 s 随机 => "一致/不一致"是时点的随机划分
=> C组(做 j) 与 D2组(做 -j) 的时点分布相同 => C-D2 消除时点效应，只剩方向能力
"""
import numpy as np, pandas as pd, glob, os

DATA='/data/inputs'
OLD7={'CRV','DASH','DOGE','DOT','ETH','FIL','HBAR'}
NEW6={'TRX','UNI','XLM','XMR','XRP','ZEC'}

def load():
    out={}
    for p in sorted(glob.glob(DATA+'/*_1h.csv')):
        nm=os.path.basename(p).replace('_1h.csv','')
        d=pd.read_csv(p)
        cols={c.lower():c for c in d.columns}
        if not all(k in cols for k in ('open','high','low','close')): continue
        d=d[[cols[k] for k in ('open','high','low','close')]].copy()
        d.columns=['open','high','low','close']
        d=d.dropna().astype(float)
        d=d[(d.open>0)&(d.high>0)&(d.low>0)&(d.close>0)]
        if len(d)<5000: continue
        out[nm]=d.reset_index(drop=True)
    return out

def bracket_idx(o,h,l,c,sig,stop_pct,R,slip_bp=0.0,max_hold=480):
    """返回 (R收益数组, 入场索引数组, 出场类型) 1=止盈 0=止损 -1=超时/强平
    sig[i]!=0 -> 在 open[i] 建仓；sig 只能依赖 bar<=i-1（调用方保证）"""
    n=len(o); tr=[]; ei_list=[]; ty=[]
    cur=0.0; entry=0.0; stop_px=0.0; tgt_px=0.0; ei=0
    def close(px,kind):
        tr.append((px-entry)*cur/abs(entry)/stop_pct); ei_list.append(ei); ty.append(kind); return 0.0
    for i in range(1,n):
        closed=False
        if cur!=0:
            if cur>0: hs,ht = l[i]<=stop_px, h[i]>=tgt_px
            else:     hs,ht = h[i]>=stop_px, l[i]<=tgt_px
            if hs:
                px=stop_px*(1-np.sign(cur)*slip_bp/1e4); cur=close(px,0); closed=True
            elif ht: cur=close(tgt_px,1); closed=True
            elif (i-ei)>=max_hold: cur=close(o[i],-1); closed=True
            elif i==n-1: cur=close(c[i],-1); closed=True
        if cur==0.0 and not closed and sig[i]!=0 and i<n-1:
            cur=float(np.sign(sig[i])); entry=o[i]; ei=i
            stop_px=entry*(1-cur*stop_pct); tgt_px=entry*(1+cur*R*stop_pct)
            if cur>0: hs,ht = l[i]<=stop_px, h[i]>=tgt_px
            else:     hs,ht = h[i]>=stop_px, l[i]<=tgt_px
            if hs: px=stop_px*(1-cur*slip_bp/1e4); cur=close(px,0)
            elif ht: cur=close(tgt_px,1)
    if cur!=0:
        tr.append((c[-1]-entry)*cur/abs(entry)/stop_pct); ei_list.append(ei); ty.append(-1)
    return np.asarray(tr), np.asarray(ei_list), np.asarray(ty)

# ---------- 主观判断族：全部基于 bar<=i-1（函数内部自行滞后） ----------
def _lag(x):
    """把基于 close[i] 的信号后移1根 -> 在 open[i+1] 才可用"""
    return np.r_[0.0, x[:-1]]

def ma(x,w):
    return pd.Series(x).rolling(w,min_periods=w).mean().values

def hh(x,w):
    return pd.Series(x).rolling(w,min_periods=w).max().values

def ll(x,w):
    return pd.Series(x).rolling(w,min_periods=w).min().values

def jud_ma200(c,h,l,o):   return _lag(np.sign(c-ma(c,200)))
def jud_ma50(c,h,l,o):    return _lag(np.sign(c-ma(c,50)))
def jud_brk500(c,h,l,o):
    H=hh(np.r_[c,h].reshape(2,-1).max(0),500) if False else hh(h,500)
    L=ll(l,500)
    s=np.sign(c-H); s=np.where(c<L,-1.0,s)
    return _lag(s)
def jud_brk100(c,h,l,o):
    H=hh(h,100); L=ll(l,100)
    s=np.sign(c-H); s=np.where(c<L,-1.0,s)
    return _lag(s)
def jud_mom20(c,h,l,o):   return _lag(np.sign(c/np.r_[np.nan,c[:-1]]*0+c - 0))  # placeholder
def _mom(c,w):
    prev=np.r_[np.full(w,np.nan),c[:-w]]
    return np.sign(c-prev)
def jud_mom20f(c,h,l,o):  return _lag(_mom(c,20))
def jud_mom240(c,h,l,o):  return _lag(_mom(c,240))
def jud_rev20(c,h,l,o):   return _lag(-_mom(c,20))
def jud_rev240(c,h,l,o):  return _lag(-_mom(c,240))
def jud_pos240(c,h,l,o):
    H=hh(h,240); L=ll(l,240); rng=np.where(H-L>0,H-L,np.nan)
    return _lag(np.sign((c-(H+L)/2)/rng))
def jud_vwap168(c,h,l,o):
    # 用 typ 价格近似 (无成交量)
    typ=(h+l+c)/3.0
    v=pd.Series(typ).rolling(168,min_periods=168).mean().values
    return _lag(np.sign(c-v))
def jud_rand_factory(seed):
    def f(c,h,l,o):
        rng=np.random.default_rng(seed)
        return np.sign(rng.standard_normal(len(c)))
    return f
def jud_cheat(c,h,l,o):
    """正对照：用未来10根收益（前视，仅验证框架灵敏度，非策略）"""
    fut=np.r_[c[10:],np.full(10,np.nan)]
    return np.sign(fut-c)

JUDS={
 'ma200':jud_ma200,'ma50':jud_ma50,'brk500':jud_brk500,'brk100':jud_brk100,
 'mom20':jud_mom20f,'mom240':jud_mom240,'rev20':jud_rev20,'rev240':jud_rev240,
 'pos240':jud_pos240,'vwap168':jud_vwap168,
}

def anchor(n,gap_lo,gap_hi,rng):
    """随机间隔 + 随机方向；返回信号数组（其余为0）"""
    sig=np.zeros(n); i=int(rng.integers(200,n-600))
    while i<n-1:
        sig[i]=float(rng.choice([-1.0,1.0]))
        i+=int(rng.integers(gap_lo,gap_hi+1))
    return sig

# ---------- 向量化独立交易引擎：每个锚点产生一笔独立交易，时点完全外生 ----------
def trades_vec(o,h,l,c,idx,direction,stop_pct,R,max_hold=480,slip_bp=0.0):
    """每个锚点一笔独立交易（不共享持仓状态）=> 锚点100%外生，C/D划分严格随机
    返回 (R收益数组, 出场类型) 1=止盈 0=止损 -1=超时"""
    o=np.asarray(o,float);h=np.asarray(h,float);l=np.asarray(l,float);c=np.asarray(c,float)
    idx=np.asarray(idx,int); d=np.asarray(direction,float); n=len(o); m=len(idx)
    entry=o[idx]; sp=entry*(1-d*stop_pct); tp=entry*(1+d*R*stop_pct)
    pos=(d>0)
    #  adverse(不利方向价格) / favorable(有利方向价格)
    res=np.full(m,np.nan); typ=np.full(m,-1)
    # --- 同bar检查（入场bar自身，保守：双触及判止损）---
    hs=np.where(pos, l[idx]<=sp, h[idx]>=sp)
    ht=np.where(pos, h[idx]>=tp, l[idx]<=tp)
    done=hs|ht
    res=np.where(done, np.where(hs,-1.0,float(R)), np.nan)
    typ=np.where(done, np.where(hs,0,1), -1)
    # --- 窗口搜索 ---
    pend=np.where(~done)[0]
    if len(pend)>0:
        K=max_hold
        ii=idx[pend][:,None]+1+np.arange(K)[None,:]
        mask=ii<n
        iic=np.clip(ii,0,n-1)
        dd=d[pend][:,None]; p2=pos[pend][:,None]
        advpad=dd*1e18; favpad=-dd*1e18
        aw=np.where(mask, np.where(p2, l[iic], h[iic]), advpad)
        fw=np.where(mask, np.where(p2, h[iic], l[iic]), favpad)
        spp=sp[pend][:,None]; tpp=tp[pend][:,None]
        shw=np.where(p2, aw<=spp, aw>=spp)
        thw=np.where(p2, fw>=tpp, fw<=tpp)
        has_s=shw.any(1); has_t=thw.any(1)
        fs=np.where(has_s, np.argmax(shw,1), K+1)
        ft=np.where(has_t, np.argmax(thw,1), K+2)
        # 比较谁先；同k判止损
        take_s=has_s&(fs<=ft)
        take_t=has_t&(ft<fs)
        kk=np.where(take_s, np.minimum(fs,K), np.where(take_t,np.minimum(ft,K), K))
        ex=np.where(take_s, sp[pend]*(1-np.sign(d[pend])*slip_bp/1e4),
            np.where(take_t, tp[pend], o[np.minimum(idx[pend]+1+kk, n-1)]))
        rr=(ex-entry[pend])*d[pend]/np.abs(entry[pend])/stop_pct
        ty2=np.where(take_s,0,np.where(take_t,1,-1))
        res[pend]=rr; typ[pend]=ty2
    return res, typ

def anchor_idx(n,gap_lo,gap_hi,rng,seed_offset=0):
    """返回 (索引数组, 方向数组)"""
    idx=[]; dire=[]
    i=int(rng.integers(200, max(201, gap_hi+300)))
    while i<n-1:
        idx.append(i); dire.append(float(rng.choice([-1.0,1.0])))
        i+=int(rng.integers(gap_lo,gap_hi+1))
    return np.array(idx,int), np.array(dire,float)
