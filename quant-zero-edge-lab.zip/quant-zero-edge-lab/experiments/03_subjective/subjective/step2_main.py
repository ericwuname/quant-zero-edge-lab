"""主实验：随机锚点(外生时点) + 主观判断(方向) 的分离
组定义（全部在相同锚点时点集合上）：
  A  = 全部锚点, 执行锚点方向 s          -> 基线（无主观）
  B  = 全部锚点, 执行主观判断 j          -> 完全主观
  C  = s==j 子集, 执行 j(=s)             -> 只做与主观一致的
  D1 = s!=j 子集, 执行 j(=-s)            -> 只做不一致, 且坚持主观
  D2 = s!=j 子集, 执行 s(=-j)            -> 只做不一致, 且服从锚点
关键: C 做 j, D2 做 -j, 且时点是同一随机二分 => C-D2 = 2 x 方向信息量(时点效应抵消)
"""
import numpy as np, pandas as pd, core
d=core.load(); STOP=0.05; R=2.0; MAXH=480; COST=0.008  # maker 2bp双边/5%止损
SEEDS=range(12); GAP=(60,480)

def stat(rs, kinds):
    r=np.concatenate(rs); n=len(r); e=r.mean(); se=r.std(ddof=1)/np.sqrt(n)
    return dict(N=n, E=e, net=e-COST, t=e/se, dp=np.mean(r>0)-1/(1+R),
                win=np.mean(r>0))

def build_jud(k, df, name):
    o,h,l,c=df.open.values,df.high.values,df.low.values,df.close.values
    if name.startswith('rand'):
        sd=int(name[4:]); rng=np.random.default_rng(7000+sd)
        return np.sign(rng.standard_normal(len(c)))
    if name=='cheat': return core.jud_cheat(c,h,l,o)
    return core.JUDS[name](c,h,l,o)

NAMES=list(core.JUDS.keys())+['rand1','rand2','cheat']
rows=[]
for nm in NAMES:
    B=[];C=[];D1=[];D2=[];A=[]; per={}
    for k,df in d.items():
        o,h,l,c=df.open.values,df.high.values,df.low.values,df.close.values
        j=build_jud(k,df,nm)
        for sd in SEEDS:
            rng=np.random.default_rng(1000+sd)
            idx,s=core.anchor_idx(len(o),GAP[0],GAP[1],rng)
            jj=j[idx]
            ok=np.isfinite(jj)&(jj!=0)
            idx,s,jj=idx[ok],s[ok],jj[ok]
            if len(idx)<10: continue
            # A: 执行 s ; B: 执行 j
            rA,_=core.trades_vec(o,h,l,c,idx,s,STOP,R,MAXH)
            rB,_=core.trades_vec(o,h,l,c,idx,jj,STOP,R,MAXH)
            A.append(rA); B.append(rB)
            agree=(s==jj)
            if agree.sum()>5:  C.append(rA[agree])      # C 执行 s == j
            if (~agree).sum()>5:
                D1.append(rB[~agree])                   # D1 执行 j == -s
                D2.append(rA[~agree])                   # D2 执行 s == -j
    rec={'jud':nm}
    for tag,arr in [('A',A),('B',B),('C',C),('D1',D1),('D2',D2)]:
        st=stat(arr,nm); rec[tag+'_N']=st['N']; rec[tag+'_net']=st['net']
        rec[tag+'_dp']=st['dp']; rec[tag+'_t']=st['t']
    # 跨品种一致性
    rows.append(rec)
    print(f"{nm:9s} A_net={rec['A_net']:+.4f} | B_net={rec['B_net']:+.4f}(t={rec['B_t']:+.2f}) "
          f"| C={rec['C_net']:+.4f} | D1={rec['D1_net']:+.4f} | D2={rec['D2_net']:+.4f} "
          f"| C-D2={rec['C_net']-rec['D2_net']:+.4f}")
df=pd.DataFrame(rows); df.to_csv('/data/workspace/subjective/main.csv',index=False)
print("\nsaved main.csv")
