"""决定性：30个随机对照的Reality Check + 收割制(不复利+盈余公积)
优化：A组(纯锚点)对每个(品种,seed)固定，预计算复用"""
import numpy as np, pandas as pd, core, pickle, os
d=core.load(); SYMS=sorted(d.keys()); STOP=0.05;R=2.0;MAXH=480;COST=0.008
SEEDS=range(12)
CACHE='/data/workspace/subjective/cacheA.pkl'

# --- 预计算 A 组的 (idx, s, rA) ---
if os.path.exists(CACHE):
    PRE=pickle.load(open(CACHE,'rb'))
else:
    PRE={}
    for k in SYMS:
        df=d[k]; o,h,l,c=df.open.values,df.high.values,df.low.values,df.close.values
        for sd in SEEDS:
            rng=np.random.default_rng(1000+sd)
            idx,s=core.anchor_idx(len(o),60,480,rng)
            rA,_=core.trades_vec(o,h,l,c,idx,s,STOP,R,MAXH)
            PRE[(k,sd)]=(idx,s,rA)
    pickle.dump(PRE,open(CACHE,'wb'))
print("预计算完成:",len(PRE))

def eval_jud(nm, jfun=None):
    """返回 每品种 B-A 均值 数组"""
    out=[]
    for k in SYMS:
        df=d[k]; o,h,l,c=df.open.values,df.high.values,df.low.values,df.close.values
        if nm.startswith('rand'):
            j=np.sign(np.random.default_rng(7000+int(nm[4:])).standard_normal(len(c)))
        elif nm=='cheat': j=core.jud_cheat(c,h,l,o)
        else: j=core.JUDS[nm](c,h,l,o)
        bs=[];as_=[]
        for sd in SEEDS:
            idx,s,rA=PRE[(k,sd)]
            jj=j[idx]; ok=np.isfinite(jj)&(jj!=0)
            if ok.sum()<20: continue
            ii,ss,jj2=idx[ok],s[ok],jj[ok]
            rB,_=core.trades_vec(o,h,l,c,ii,jj2,STOP,R,MAXH)
            bs.append(rB.mean()); as_.append(rA[ok].mean())
        out.append(np.mean(bs)-np.mean(as_))
    return np.array(out)

def ct(v): return v.mean()/(v.std(ddof=1)/np.sqrt(len(v)))

REAL=list(core.JUDS.keys())
NR=30
print(f"\n运行 {NR} 个随机对照 + {len(REAL)} 个真实判断 ...")
rts=[]
for i in range(1,NR+1):
    rts.append(ct(eval_jud(f'rand{i}')))
rts=np.array(rts)
print(f"rand零分布(B-A跨品种t): 均值={rts.mean():+.2f} sd={rts.std(ddof=1):.2f} "
      f"max={rts.max():+.2f} 95%={np.percentile(rts,95):+.2f} 99%={np.percentile(rts,99):+.2f}")

res={}
print("\n=== Reality Check (30个随机对照) ===")
for nm in REAL:
    v=eval_jud(nm); t=ct(v); pv=(np.sum(rts>=t)+1)/(len(rts)+1)
    res[nm]=(v.mean(),t,pv,np.sum(v>0))
    print(f"  {nm:9s} B-A={v.mean():+.4f} 净={v.mean()-COST:+.4f} t={t:+.2f} p_RC={pv:.4f} "
          f"为正={np.sum(v>0)}/13 {'**显著' if pv<0.05 else ('*边缘' if pv<0.10 else '')}")
v=eval_jud('cheat'); print(f"  {'cheat':9s} B-A={v.mean():+.4f} t={ct(v):+.2f} (正对照)")
pickle.dump({'rts':rts,'res':res},open('/data/workspace/subjective/rc30.pkl','wb'))
