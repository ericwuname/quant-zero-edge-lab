"""调试：D1-C 为何系统性为正？检查 agree 比例、笔数、以及是否与 j 的符号偏斜有关"""
import numpy as np, core
d=core.load(); k='DOGEUSDT'; df=d[k]
o,h,l,c=df.open.values,df.high.values,df.low.values,df.close.values
STOP=0.05;R=2.0;MAXH=480
for nm in ['ma50','cheat','rand8']:
    j = core.JUDS[nm](c,h,l,o) if nm in core.JUDS else (core.jud_cheat(c,h,l,o) if nm=='cheat' else np.sign(np.random.default_rng(7008).standard_normal(len(c))))
    print(f"\n--- {nm} ---  j中+1占比={np.mean(j[j!=0]>0):.3f} (非0比例={np.mean(np.isfinite(j)&(j!=0)):.3f})")
    for sd in [0,1,2]:
        rng=np.random.default_rng(1000+sd)
        idx,s=core.anchor_idx(len(o),60,480,rng)
        jj=j[idx]; ok=np.isfinite(jj)&(jj!=0); idx,s,jj=idx[ok],s[ok],jj[ok]
        rA,_=core.trades_vec(o,h,l,c,idx,s,STOP,R,MAXH)
        rB,_=core.trades_vec(o,h,l,c,idx,jj,STOP,R,MAXH)
        ag=(s==jj)
        # 验证 ag 时 rA==rB
        same=np.allclose(rA[ag],rB[ag])
        print(f" sd={sd} N={len(idx)} agree率={ag.mean():.3f} | C(rA[ag])={rA[ag].mean():+.4f} D1(rB[~ag])={rB[~ag].mean():+.4f} "
              f"D1-C={(rB[~ag].mean()-rA[ag].mean()):+.4f} | B={rB.mean():+.4f} | ag时rA==rB? {same}")
        # 关键：按 j 符号拆分，看 agree 子集内 j 的分布
        for jsign in [1,-1]:
            m=(jj==jsign)
            if m.sum()>10:
                print(f"    j={jsign:+d}: 占比={m.mean():.3f} rB均值={rB[m].mean():+.4f} "
                      f"| 其中agree占比={ag[m].mean():.3f} C部分={rA[m&ag].mean() if (m&ag).sum()>3 else np.nan:+.4f} "
                      f"D1部分={rB[m&~ag].mean() if (m&~ag).sum()>3 else np.nan:+.4f}")
