"""收割制(不复利+盈余公积) 严谨版：单seed真实路径 + 10个随机判断零分布"""
import numpy as np, core, pickle
d=core.load(); SYMS=sorted(d.keys()); STOP=0.05;R=2.0;MAXH=480
PRE=pickle.load(open('/data/workspace/subjective/cacheA.pkl','rb'))
SD=0  # 单seed = 一条真实历史路径
def seq_of(nm):
    out={}
    for k in SYMS:
        df=d[k]; o,h,l,c=df.open.values,df.high.values,df.low.values,df.close.values
        idx,s,rA=PRE[(k,SD)]
        if nm=='ANCHOR': r=rA; keep=np.ones(len(idx),bool)
        else:
            if nm.startswith('rand'): j=np.sign(np.random.default_rng(7000+int(nm[4:])).standard_normal(len(c)))
            else: j=core.JUDS[nm](c,h,l,o)
            jj=j[idx]; keep=np.isfinite(jj)&(jj!=0)
            r=core.trades_vec(o,h,l,c,idx[keep],jj[keep],STOP,R,MAXH)[0]
        out[k]=r
    return out
def harvest(sq,f,C0=10000,nb=600,rng=None):
    ks=list(sq.keys()); sc=[];pn=[];bk=[]
    for b in range(nb):
        pick=rng.integers(0,len(ks),len(ks))
        pool=np.concatenate([sq[ks[i]][rng.integers(0,len(sq[ks[i]]),len(sq[ks[i]]))] for i in pick])
        net=float(C0); ex=0.0; dead=False
        for r in pool:
            net+=r*f*C0
            if net>=2*C0: ex+=net-C0; net=float(C0)
            if net<=0.2*C0: dead=True; break
        sc.append(ex>=C0); pn.append(ex+net-C0); bk.append(dead)
    return np.mean(sc),np.median(pn),np.mean(bk)
rng=np.random.default_rng(7)
names=['ANCHOR','ma50','mom20','pos240','rev20']+[f'rand{i}' for i in range(1,11)]
S={n:seq_of(n) for n in names}
N0=sum(len(v) for v in S['ma50'].values()); print(f"单seed总笔数={N0} (真实可交易路径)")
for f in [0.01,0.02,0.03]:
    print(f"\n=== 仓位 f={f*100:.0f}% ===")
    print(f"  {'模式':9s} {'笔数':>6s} {'E(毛)':>8s} {'P(赚回本金)':>12s} {'盈亏中位':>10s} {'爆仓率':>8s}")
    rows={}
    for n in names:
        pool=np.concatenate([S[n][k] for k in SYMS])
        p,m,b=harvest(S[n],f,rng=rng); rows[n]=(p,m,b)
        tag='  <-随机对照' if n.startswith('rand') else ''
        print(f"  {n:9s} {len(pool):6d} {pool.mean():+8.4f} {p:12.3f} {m:+10.0f} {b:8.3f}{tag}")
    rp=[rows[f'rand{i}'][0] for i in range(1,11)]
    print(f"  >> rand零分布P: 均值={np.mean(rp):.3f} sd={np.std(rp,ddof=1):.3f} max={np.max(rp):.3f} "
          f"95%={np.percentile(rp,95):.3f}")
    for n in ['ma50','mom20','pos240','rev20']:
        pv=(np.sum(np.array(rp)>=rows[n][0])+1)/11
        print(f"     {n:7s} P={rows[n][0]:.3f} p_RC={pv:.3f} {'*显著' if pv<0.05 else ''}")
