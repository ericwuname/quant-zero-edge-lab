"""最终判据：B-A (相同时点, 只换方向) —— 最干净的方向能力度量
+ 趋势类 vs 反转类的对照 + Reality Check(rand零分布)"""
import numpy as np, core
exec(open('/data/workspace/subjective/step3_rigorous.py').read().split('NAMES=')[0].replace("import numpy as np, pandas as pd, core","import numpy as np, pandas as pd, core"))
NAMES=list(core.JUDS.keys())+[f'rand{i}' for i in range(1,9)]+['cheat']
res={}
for nm in NAMES:
    res[nm]=np.array([[run_one(k,nm)[g] for g in ['A','B','C','D1','D2']] for k in SYMS])
np.save('/data/workspace/subjective/res2.npy',np.array([res[n] for n in NAMES]))

def ct(v):  # 跨品种 t
    return v.mean()/(v.std(ddof=1)/np.sqrt(len(v)))

print("=== B-A: 主观判断 vs 纯随机锚点（相同时点，只换方向）===")
print(f"{'jud':9s} {'B-A(毛)':>9s} {'跨品种t':>8s} {'为正':>6s} {'净(B-A-COST)':>12s}")
ba={}
for nm in NAMES:
    p=res[nm]; v=p[:,1]-p[:,0]; ba[nm]=v
    print(f"{nm:9s} {v.mean():+9.4f} {ct(v):+8.2f} {np.sum(v>0):>4d}/13 {v.mean()-0.008:+12.4f}")
rBA=np.array([ct(ba[f'rand{i}']) for i in range(1,9)])
print(f"\nrand零分布(B-A跨品种t): {np.round(np.sort(rBA),2)}")
print(f"  均值={rBA.mean():+.2f} sd={rBA.std(ddof=1):.2f} max={rBA.max():+.2f}")
print("\n=== Reality Check: 真jud vs rand零分布 ===")
for nm in core.JUDS.keys():
    t=ct(ba[nm]); pv=(np.sum(rBA>=t)+1)/(len(rBA)+1)
    print(f"  {nm:9s} B-A={ba[nm].mean():+.4f} t={t:+.2f} p_RC={pv:.3f} {'*' if pv<0.05 else ''}")
print(f"  {'cheat':9s} B-A={ba['cheat'].mean():+.4f} t={ct(ba['cheat']):+.2f} (正对照)")

print("\n=== 趋势类 vs 反转类 (C-D2, 应精确反号) ===")
for a,b in [('mom20','rev20'),('mom240','rev240')]:
    ca=res[a][:,2]-res[a][:,4]; cb=res[b][:,2]-res[b][:,4]
    print(f"  {a}:{ca.mean():+.4f}  {b}:{cb.mean():+.4f}  和={ca.mean()+cb.mean():+.6f} (应≈0)")
print("\n=== D1 vs C（都执行j，检验'一致性'是否有额外信息）===")
for nm in list(core.JUDS.keys())[:5]+['rand8','cheat']:
    p=res[nm]; print(f"  {nm:9s} C={p[:,2].mean():+.4f} D1={p[:,3].mean():+.4f} D1-C={(p[:,3]-p[:,2]).mean():+.4f}")
