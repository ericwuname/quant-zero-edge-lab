"""前提检验：独立交易模型下，随机方向的毛E必须为0（可选停时定理）
若不为0，则后续所有"主观判断贡献"的度量都有偏"""
import numpy as np, core, sys
d=core.load(); STOP=0.05; R=2.0; MAXH=480
allr=[]; per={}
for k,df in d.items():
    o,h,l,c=df.open.values,df.high.values,df.low.values,df.close.values
    rs=[]
    for sd in range(12):
        rng=np.random.default_rng(1000+sd)
        idx,dr=core.anchor_idx(len(o),60,480,rng)
        r,_=core.trades_vec(o,h,l,c,idx,dr,STOP,R,MAXH)
        rs.append(r)
    r=np.concatenate(rs); per[k]=(len(r),r.mean(),r.std(),np.mean(r>0))
    allr.append(r)
    print(f"{k:9s} N={len(r):6d} 毛E={r.mean():+.4f} 胜率={np.mean(r>0):.4f} sd={r.std():.3f}")
allr=np.concatenate(allr)
n=len(allr); m=allr.mean(); se=allr.std()/np.sqrt(n)
print(f"\n=== 池化 ===\nN={n}  毛E={m:+.5f} +/- {1.96*se:.5f} (95%CI)  t={m/se:+.3f}")
print(f"胜率={np.mean(allr>0):.4f}  理论保本={1/(1+R):.4f}  Δp={np.mean(allr>0)-1/(1+R):+.4f}")
# 跨品种 t
ms=np.array([per[k][1] for k in per]); ks=len(ms)
print(f"跨品种: 均值={ms.mean():+.5f} t={ms.mean()/(ms.std(ddof=1)/np.sqrt(ks)):+.3f} (n={ks}) 为正={np.sum(ms>0)}/{ks}")
print(f"\n判定: {'鞅性成立' if abs(m/se)<1.96 else '!!! 鞅性不成立，模型有偏 !!!'}")
