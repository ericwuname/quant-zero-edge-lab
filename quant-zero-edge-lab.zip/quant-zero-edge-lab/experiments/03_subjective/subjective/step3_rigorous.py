"""严谨版：跨品种t(n=13) + 随机判断零分布(Reality Check)
修正：池化t把同一品种内高度相关的交易当独立样本 => 严重高估显著性
      rand(零信息)也跑出t=3.71 即为证据
零分布：8个独立随机jud的 C-D2 跨品种均值 -> 真jud必须超过其95分位
"""
import numpy as np, pandas as pd, core
d=core.load(); STOP=0.05; R=2.0; MAXH=480; COST=0.008
SEEDS=range(12); GAP=(60,480)
SYMS=sorted(d.keys())

def build_jud(k,df,name):
    o,h,l,c=df.open.values,df.high.values,df.low.values,df.close.values
    if name.startswith('rand'):
        rng=np.random.default_rng(7000+int(name[4:])); return np.sign(rng.standard_normal(len(c)))
    if name=='cheat': return core.jud_cheat(c,h,l,o)
    return core.JUDS[name](c,h,l,o)

def run_one(k,nm):
    df=d[k]; o,h,l,c=df.open.values,df.high.values,df.low.values,df.close.values
    j=build_jud(k,df,nm)
    A=[];B=[];C=[];D1=[];D2=[]
    for sd in SEEDS:
        rng=np.random.default_rng(1000+sd)
        idx,s=core.anchor_idx(len(o),GAP[0],GAP[1],rng)
        jj=j[idx]; ok=np.isfinite(jj)&(jj!=0)
        idx,s,jj=idx[ok],s[ok],jj[ok]
        if len(idx)<20: continue
        rA,_=core.trades_vec(o,h,l,c,idx,s,STOP,R,MAXH)
        rB,_=core.trades_vec(o,h,l,c,idx,jj,STOP,R,MAXH)
        A.append(rA); B.append(rB)
        ag=(s==jj)
        if ag.sum()>5: C.append(rA[ag])
        if (~ag).sum()>5: D1.append(rB[~ag]); D2.append(rA[~ag])
    f=lambda L: np.concatenate(L).mean() if L else np.nan
    return dict(A=f(A),B=f(B),C=f(C),D1=f(D1),D2=f(D2))

NAMES=list(core.JUDS.keys())+[f'rand{i}' for i in range(1,9)]+['cheat']
res={}
for nm in NAMES:
    per=np.array([[run_one(k,nm)[g] for g in ['A','B','C','D1','D2']] for k in SYMS])
    res[nm]=per  # shape (13,5)
    mu=per.mean(0); sd=per.std(0,ddof=1); t=mu/(sd/np.sqrt(len(SYMS)))
    cd2=per[:,2]-per[:,4]; t_cd2=cd2.mean()/(cd2.std(ddof=1)/np.sqrt(len(SYMS)))
    print(f"{nm:9s} A={mu[0]:+.4f} B={mu[1]:+.4f}(t={t[1]:+.2f}) C={mu[2]:+.4f} "
          f"D1={mu[3]:+.4f} D2={mu[4]:+.4f} | C-D2={cd2.mean():+.4f}(t={t_cd2:+.2f}) "
          f"| 为正={np.sum(cd2>0)}/13")
np.save('/data/workspace/subjective/res.npy', np.array([res[n] for n in NAMES]))
pd.Series(NAMES).to_csv('/data/workspace/subjective/names.csv',index=False)

# Reality Check: rand 零分布
print("\n=== Reality Check (C-D2 跨品种t, 零分布来自8个rand) ===")
rr=[]
for i in range(1,9):
    p=res[f'rand{i}']; cd=p[:,2]-p[:,4]
    rr.append(cd.mean()/(cd.std(ddof=1)/np.sqrt(13)))
rr=np.array(rr)
print("rand 的 C-D2 跨品种t:", np.round(np.sort(rr),3))
print(f"零分布: 均值={rr.mean():+.3f} sd={rr.std(ddof=1):.3f} max={rr.max():+.3f} 95分位≈{np.percentile(rr,95):+.3f}")
print("\n真jud vs 零分布:")
for nm in core.JUDS.keys():
    p=res[nm]; cd=p[:,2]-p[:,4]; t=cd.mean()/(cd.std(ddof=1)/np.sqrt(13))
    pv=(np.sum(rr>=t)+1)/(len(rr)+1)
    print(f"  {nm:9s} t={t:+.3f}  p_RC={pv:.3f} {'*显著' if pv<0.05 else ''}")
p=res['cheat']; cd=p[:,2]-p[:,4]; t=cd.mean()/(cd.std(ddof=1)/np.sqrt(13))
print(f"  {'cheat':9s} t={t:+.3f} (正对照,应极显著)")
