"""
决定性检验：对数-算术凸性
价格是对数过程，但止损止盈用算术百分比设 -> 障碍在对数空间不对称
多头：止盈对数距离 log(1+Rs) < Rs，止损对数距离 |log(1-s)| > s
      => 止盈"更近" => p > 1/(1+R) => 多头天然正期望
空头：完全镜像 => 天然负期望
多空平均：几乎精确抵消（这是关键！）
"""
import numpy as np, pandas as pd, glob, os

DATA='/data/inputs'
NEW6={'TRX','UNI','XLM','XMR','XRP','ZEC'}
OLD7={'CRV','DASH','DOGE','DOT','ETH','FIL','HBAR'}

def load():
    out={}
    for p in sorted(glob.glob(DATA+'/*_1h.csv')):
        nm=os.path.basename(p).replace('_1h.csv','')
        d=pd.read_csv(p); cols={c.lower():c for c in d.columns}
        if not all(k in cols for k in ('open','high','low','close')): continue
        d=d[[cols[k] for k in ('open','high','low','close')]].copy()
        d.columns=['open','high','low','close']
        d=d.dropna().astype(float)
        d=d[(d['open']>0)&(d['high']>0)&(d['low']>0)&(d['close']>0)]
        if len(d)<5000: continue
        out[nm]=d.reset_index(drop=True)
    return out

def theory_E(R,s):
    """零漂移下，纯凸性带来的理论 E（R倍数），多头/空头"""
    a=float(np.log(1+R*s)); b=abs(float(np.log(1-s)))   # 多头：a=盈利对数距离 b=亏损对数距离
    pL=b/(a+b); EL=(R+1)*pL-1
    # 空头：亏损方向对数距离 log(1+s)，盈利方向 |log(1-Rs)|
    bl=float(np.log(1+s)); aw=abs(float(np.log(1-R*s)))
    pS=bl/(bl+aw); ES=(R+1)*pS-1
    return pL,EL,pS,ES

def bracket(o,h,l,c,sig,stop_pct,R,slip_bp=0.0):
    """严格OHLC；同bar双触及判止损先触发(保守)；sig[i]!=0 在 open[i] 建仓"""
    o=np.asarray(o,float);h=np.asarray(h,float);l=np.asarray(l,float);c=np.asarray(c,float)
    n=len(o); tr=[]; cur=0.0; entry=0.0; sp=0.0; tp=0.0
    for i in range(1,n):
        if cur!=0 and i<n-1:
            if cur>0: hs,ht = l[i]<=sp, h[i]>=tp
            else:     hs,ht = h[i]>=sp, l[i]<=tp
            if hs:
                px=sp*(1-np.sign(cur)*slip_bp/1e4)
                tr.append((px-entry)*cur/abs(entry)/stop_pct); cur=0.0
            elif ht:
                tr.append((tp-entry)*cur/abs(entry)/stop_pct); cur=0.0
        if cur==0.0 and sig[i]!=0 and i<n-1:
            cur=float(np.sign(sig[i])); entry=o[i]
            sp=entry*(1-cur*stop_pct); tp=entry*(1+cur*R*stop_pct)
            if cur>0: hs,ht = l[i]<=sp, h[i]>=tp
            else:     hs,ht = h[i]>=sp, l[i]<=tp
            if hs:
                px=sp*(1-cur*slip_bp/1e4)
                tr.append((px-entry)*cur/abs(entry)/stop_pct); cur=0.0
            elif ht:
                tr.append((tp-entry)*cur/abs(entry)/stop_pct); cur=0.0
    return np.asarray(tr)

def gbm(n,sigma,seed):
    """零漂移 GBM（对数），用于验证凸性理论"""
    rng=np.random.default_rng(seed)
    lr=rng.normal(0,sigma,n); c=100*np.exp(np.cumsum(lr))
    # 造 OHLC：open=前收，close=c，high/low 含bar内噪声
    o=np.concatenate([[100],c[:-1]])
    hi=np.maximum(o,c)*(1+abs(rng.normal(0,sigma*0.5,n)))
    lo=np.minimum(o,c)*(1-abs(rng.normal(0,sigma*0.5,n)))
    return o,hi,lo,c

print("="*78)
print("实验1：凸性理论 vs 合成零漂移GBM实测（无漂移、无成本）")
print("="*78)
print(f"{'R':>5} {'s%':>6} | {'理论pL':>8} {'理论EL':>9} {'实测EL':>9} | {'理论ES':>9} {'实测ES':>9} | {'理论均':>9}")
for R in [0.25,0.5,1.0,2.0,5.0]:
    for s in [0.02,0.05]:
        pL,EL,pS,ES=theory_E(R,s)
        ELs=[];ESs=[]
        for sd in range(20):
            o,hi,lo,c=gbm(20000,0.002,sd)
            ELs.append(bracket(o,hi,lo,c,np.ones(len(o)),s,R).mean())
            ESs.append(bracket(o,hi,lo,c,-np.ones(len(o)),s,R).mean())
        print(f"{R:>5} {s*100:>5.0f} | {pL:>8.4f} {EL:>+9.4f} {np.mean(ELs):>+9.4f} | {ES:>+9.4f} {np.mean(ESs):>+9.4f} | {(EL+ES)/2:>+9.4f}")
