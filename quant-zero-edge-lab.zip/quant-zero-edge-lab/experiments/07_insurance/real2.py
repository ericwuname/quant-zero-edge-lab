import numpy as np, pandas as pd, glob, os, sys
sys.path.insert(0,'/data/workspace/coin')
from eng import bracket2   # 已修 bug#7：平仓后同bar不再入场

DATA='/data/inputs'
NEW6={'TRXUSDT','UNIUSDT','XLMUSDT','XMRUSDT','XRPUSDT','ZECUSDT'}
OLD7={'CRVUSDT','DASHUSDT','DOGEUSDT','DOTUSDT','ETHUSDT','FILUSDT','HBARUSDT'}
def load():
    out={}
    for p in sorted(glob.glob(DATA+'/*_1h.csv')):
        nm=os.path.basename(p).replace('_1h.csv','')
        d=pd.read_csv(p); cols={c.lower():c for c in d.columns}
        if not all(k in cols for k in ('open','high','low','close')): continue
        d=d[[cols[k] for k in ('open','high','low','close')]].copy()
        d.columns=['open','high','low','close']; d=d.dropna().astype(float)
        d=d[(d['open']>0)&(d['high']>0)&(d['low']>0)&(d['close']>0)]
        if len(d)<5000: continue
        out[nm]=d.reset_index(drop=True)
    return out

D=load()
def run(sig,s,R,d):
    tr,_=bracket2(d['open'].values,d['high'].values,d['low'].values,d['close'].values,sig,s,R)
    return tr

print("="*88)
print("实验2（修正引擎）：真实数据 全多 / 全空 / 随机双向  —— R=2, 止损5%, 零成本")
print("="*88)
print(f"{'品种':>8} {'批次':>5} {'N':>6} | {'全多E':>9} {'全空E':>9} {'随机E':>9} | {'多空均':>9} {'凸性E':>9} | {'BH%':>10}")
rows={}
for nm,d in D.items():
    o=d['open'].values; n=len(o)
    one=np.ones(n)
    L=run(one,0.05,2.0,d); S=run(-one,0.05,2.0,d)
    rng=np.random.default_rng(11); Bs=[]
    for k in range(12):
        sgn=np.sign(rng.normal(size=n)); Bs.append(run(sgn,0.05,2.0,d).mean())
    bh=(d['close'].values[-1]/d['close'].values[0]-1)*100
    g='NEW6' if nm in NEW6 else 'OLD7'
    conv=(L.mean()+S.mean())/2 - np.mean(Bs)   # 凸性 = 恒定方向均值 - 随机方向均值
    rows[nm]=(L.mean(),S.mean(),np.mean(Bs),(L.mean()+S.mean())/2,conv,bh,g)
    print(f"{nm:>8} {g:>5} {len(L):>6} | {L.mean():>+9.4f} {S.mean():>+9.4f} {np.mean(Bs):>+9.4f} | {(L.mean()+S.mean())/2:>+9.4f} {conv:>+9.4f} | {bh:>+10.1f}")

print()
nms=list(rows.keys())
bh=np.array([rows[n][5] for n in nms])
lo=np.array([rows[n][0] for n in nms]); sh=np.array([rows[n][1] for n in nms])
rd=np.array([rows[n][2] for n in nms]); cv=np.array([rows[n][4] for n in nms])
def cr(a,b): return np.corrcoef(a,b)[0,1]
print("="*88); print("实验3：相关性与批次分解"); print("="*88)
print(f"corr(全多E, BH%)  = {cr(lo,bh):+.3f}")
print(f"corr(全空E, BH%)  = {cr(sh,bh):+.3f}")
print(f"corr(多空差, BH%) = {cr(lo-sh,bh):+.3f}")
print(f"corr(凸性E, BH%)  = {cr(cv,bh):+.3f}")
print()
for g in ['OLD7','NEW6','ALL']:
    if g=='ALL': idx=list(range(len(nms)))
    else: idx=[i for i,n in enumerate(nms) if rows[n][6]==g]
    print(f"  {g:>5}: 全多{lo[idx].mean():+.4f} 全空{sh[idx].mean():+.4f} 随机{rd[idx].mean():+.4f} 凸性{cv[idx].mean():+.4f} (t={cv[idx].mean()/(cv[idx].std(ddof=1)/np.sqrt(len(idx))):+.2f})")
