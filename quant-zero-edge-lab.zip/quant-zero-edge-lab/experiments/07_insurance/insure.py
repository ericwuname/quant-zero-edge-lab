"""
卖保险(R<1)能否提升到正期望？—— 核心是"定价能力"
保险公司赚钱靠精算：知道真实概率，对手不知道。
交易里的对应：能预测未来波动 -> 据此定价障碍距离 / 过滤交易时机
"""
import numpy as np, pandas as pd, glob, os, sys
sys.path.insert(0,'/data/workspace/coin')
from eng import bracket2
DATA='/data/inputs'
NEW6={'TRXUSDT','UNIUSDT','XLMUSDT','XMRUSDT','XRPUSDT','ZECUSDT'}
OLD7={'CRVUSDT','DASHUSDT','DOGEUSDT','DOTUSDT','ETHUSDT','FILUSDT','HBARUSDT'}
def load():
    out={}
    for p in sorted(glob.glob(DATA+'/*_1h.csv')):
        nm=os.path.basename(p).replace('_1h.csv','')
        d=pd.read_csv(p); cols={c.lower():c for c in d.columns}
        if not all(k in cols for k in ('open','high','low','close')): continue
        d=d[[cols[k] for k in ('open','high','low','close')]].copy()
        d.columns=['open','high','low','close']; d=d.dropna().astype(float)
        d=d[(d['open']>0)&(d['high']>0)&(d['low']>0)&(d['close']>0)]
        if len(d)<5000: continue
        out[nm]=d.reset_index(drop=True)
    return out
D=load()

# ---------- 1. 波动率可预测性（定价能力的基础）----------
print("="*80); print("实验A：波动率可预测性 —— 历史波动 vs 未来已实现波动（IC）"); print("="*80)
print(f"{'品种':>8} {'W=24':>9} {'W=168':>9} {'W=672':>9}   (Spearman IC, 预测horizon=24)")
ics={}
for nm,d in D.items():
    c=d['close'].values; lr=np.diff(np.log(c))
    n=len(lr)
    def rv(x,W):
        s=pd.Series(np.abs(x)).rolling(W).mean().values
        return s
    fut=pd.Series(np.abs(lr)).rolling(24).mean().shift(-24).values   # 未来24bar平均|ret|
    row=[]
    for W in [24,168,672]:
        est=rv(lr,W)
        m=~np.isnan(est)&~np.isnan(fut)
        ic=pd.Series(est[m]).corr(pd.Series(fut[m]),method='spearman')
        row.append(ic)
    ics[nm]=row
    print(f"{nm:>8} {row[0]:>9.3f} {row[1]:>9.3f} {row[2]:>9.3f}")
A=np.array([ics[n] for n in D])
print(f"{'均值':>8} {A[:,0].mean():>9.3f} {A[:,1].mean():>9.3f} {A[:,2].mean():>9.3f}")
for j,W in enumerate([24,168,672]):
    t=A[:,j].mean()/(A[:,j].std(ddof=1)/np.sqrt(len(A)))
    print(f"  W={W}: 均值IC={A[:,j].mean():+.3f}  跨品种t={t:+.2f}  为正{int((A[:,j]>0).sum())}/{len(A)}")
