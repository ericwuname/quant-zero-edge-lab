import numpy as np, pandas as pd, glob, os, sys
sys.path.insert(0,'/data/workspace/coin')
from eng import bracket2
DATA='/data/inputs'
def load():
    out={}
    for p in sorted(glob.glob(DATA+'/*_1h.csv')):
        nm=os.path.basename(p).replace('_1h.csv','')
        d=pd.read_csv(p); cols={c.lower():c for c in d.columns}
        if not all(k in cols for k in ('open','high','low','close')): continue
        d=d[[cols[k] for k in ('open','high','low','close')]].copy()
        d.columns=['open','high','low','close']; d=d.dropna().astype(float)
        d=d[(d['open']>0)&(d['high']>0)&(d['low']>0)&(d['close']>0)]
        if len(d)<5000: continue
        out[nm]=d.reset_index(drop=True)
    return out
D=load()
rng=np.random.default_rng(2024)

def volseries(c,W=168):
    """只依赖 bar<=t 的历史波动估计（前视安全）"""
    lr=np.diff(np.log(c)); lr=np.concatenate([[0.0],lr])
    v=pd.Series(np.abs(lr)).rolling(W).mean().values
    v=np.nan_to_num(v,nan=np.nanmean(v))
    return v

print("="*92)
print("实验B：卖保险(R<1) + 波动率过滤 —— 随机方向(纯保险卖家, alpha=0)，止损2%")
print("="*92)
print(f"{'R':>5} {'过滤':>10} | {'N':>7} {'毛E':>9} {'胜率':>8} {'净E@2bp':>9} {'净E@5bp':>9} {'跨品种t':>9}")
for R in [0.25,0.5]:
    for fl,lab in [(None,'不过滤'),(0.5,'低50%'),(0.25,'低25%')]:
        per={}
        for nm,d in D.items():
            c=d['close'].values; v=volseries(c)
            thr=np.quantile(v,fl) if fl else -1
            n=len(c); sgn=np.sign(rng.normal(size=n))
            sig=np.where((v<thr)|(fl is None),sgn,0.0)
            tr,_=bracket2(d['open'].values,d['high'].values,d['low'].values,d['close'].values,sig,0.02,R)
            if len(tr)<30: continue
            per[nm]=(len(tr),tr.mean(),(tr>0).mean())
        nms=list(per.keys()); N=np.mean([per[k][0] for k in nms])
        g=np.array([per[k][1] for k in nms]); w=np.array([per[k][2] for k in nms])
        t=g.mean()/(g.std(ddof=1)/np.sqrt(len(g)))
        cost2=2*2/(0.02*1e4); cost5=2*5/(0.02*1e4)
        print(f"{R:>5} {lab:>10} | {N:>7.0f} {g.mean():>+9.4f} {w.mean():>8.2%} {g.mean()-cost2:>+9.4f} {g.mean()-cost5:>+9.4f} {t:>+9.2f}")

print()
print("="*92)
print("实验C：自适应障碍定价 s_t = k * 预测波动（真正的'按风险定价'）vs 固定止损")
print("="*92)
print(f"{'模式':>14} {'R':>5} | {'N':>7} {'毛E':>9} {'胜率':>8} {'平均s%':>8} {'cost_R':>8} {'净E':>9} {'t':>7}")
for R in [0.5,1.0,2.0]:
    for mode in ['固定2%','自适应']:
        per={}; savg=[]
        for nm,d in D.items():
            c=d['close'].values; v=volseries(c); n=len(c)
            sgn=np.sign(rng.normal(size=n))
            if mode=='固定2%':
                tr,_=bracket2(d['open'].values,d['high'].values,d['low'].values,d['close'].values,sgn,0.02,R)
                savg.append(0.02)
            else:
                s_arr=np.clip(v*3.0,0.005,0.10)      # s = 3 * 预测(|ret|均值)，带上下限
                # 逐段模拟：把 s 近似为常数分段（用中位数代表该品种的平均s）
                sm=np.median(s_arr)
                tr,_=bracket2(d['open'].values,d['high'].values,d['low'].values,d['close'].values,sgn,float(sm),R)
                savg.append(sm)
            if len(tr)<30: continue
            per[nm]=(len(tr),tr.mean(),(tr>0).mean())
        nms=list(per.keys()); N=np.mean([per[k][0] for k in nms])
        g=np.array([per[k][1] for k in nms]); w=np.array([per[k][2] for k in nms])
        sm=np.mean(savg); cr=2*2/(sm*1e4)
        t=g.mean()/(g.std(ddof=1)/np.sqrt(len(g)))
        print(f"{mode:>14} {R:>5} | {N:>7.0f} {g.mean():>+9.4f} {w.mean():>8.2%} {sm*100:>7.2f}% {cr:>8.4f} {g.mean()-cr:>+9.4f} {t:>+7.2f}")
