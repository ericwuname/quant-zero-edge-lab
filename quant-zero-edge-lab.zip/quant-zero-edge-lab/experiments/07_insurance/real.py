import numpy as np, pandas as pd, glob, os
exec(open('convex.py').read().split('print("="*78)')[0])

D=load()
print("="*84)
print("实验2：真实数据 —— 全多 / 全空 / 双向（无成本，R=2，止损5%）")
print("="*84)
print(f"{'品种':>6} {'批次':>5} {'N':>6} | {'全多E':>9} {'全空E':>9} {'双向E':>9} | {'多+空':>9} | {'BH%':>9}")
res={}
for nm,d in D.items():
    o=d['open'].values;h=d['high'].values;l=d['low'].values;c=d['close'].values
    L=bracket(o,h,l,c,np.ones(len(o)),0.05,2.0)
    S=bracket(o,h,l,c,-np.ones(len(o)),0.05,2.0)
    rng=np.random.default_rng(7); B=[]
    for k in range(10):
        sgn=np.sign(rng.normal(size=len(o)))
        B.append(bracket(o,h,l,c,sgn,0.05,2.0).mean())
    bh=(c[-1]/c[0]-1)*100
    grp='NEW6' if nm in NEW6 else 'OLD7'
    res[nm]=(L.mean(),S.mean(),np.mean(B),bh,grp)
    print(f"{nm:>6} {grp:>5} {len(L):>6} | {L.mean():>+9.4f} {S.mean():>+9.4f} {np.mean(B):>+9.4f} | {(L.mean()+S.mean())/2:>+9.4f} | {bh:>+9.1f}")

print()
print("="*84)
print("实验3：全多/全空 与 品种涨跌幅(BH) 的相关性 —— 检验'凸性'还是'漂移'")
print("="*84)
import itertools
nms=list(res.keys())
bh=np.array([res[n][3] for n in nms])
lo=np.array([res[n][0] for n in nms])
sh=np.array([res[n][1] for n in nms])
def corr(a,b):
    a=np.asarray(a);b=np.asarray(b);m=(np.abs(a)>0)&(np.abs(b)>0)
    return np.corrcoef(a,b)[0,1]
print(f"corr(全多E, BH%)   = {corr(lo,bh):+.3f}")
print(f"corr(全空E, BH%)   = {corr(sh,bh):+.3f}")
print(f"corr(多空差, BH%)  = {corr(lo-sh,bh):+.3f}")
print()
print("分批次均值：")
for g in ['OLD7','NEW6']:
    idx=[i for i,n in enumerate(nms) if res[n][4]==g]
    print(f"  {g}: 全多 {lo[idx].mean():+.4f}  全空 {sh[idx].mean():+.4f}  多空均 {(lo[idx].mean()+sh[idx].mean())/2:+.4f}  BH% {bh[idx].mean():+.1f}")
