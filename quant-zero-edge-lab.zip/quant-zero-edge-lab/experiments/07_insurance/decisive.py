"""
决定性对照：波动率可预测 vs 收益可预测
保险公司赚钱需要"定价能力"= 估计真实赔付概率
交易里：赔付概率 p 取决于 漂移/波动 之比（而非波动本身）
若波动可预测(IC高) 但收益不可预测(IC≈0) => 能测量风险，不能给风险定价
"""
import numpy as np, pandas as pd, glob, os, sys
sys.path.insert(0,'/data/workspace/coin')
from eng import bracket2
DATA='/data/inputs'
def load():
    out={}
    for p in sorted(glob.glob(DATA+'/*_1h.csv')):
        nm=os.path.basename(p).replace('_1h.csv','')
        d=pd.read_csv(p); cols={c.lower():c for c in d.columns}
        if not all(k in cols for k in ('open','high','low','close')): continue
        d=d[[cols[k] for k in ('open','high','low','close')]].copy()
        d.columns=['open','high','low','close']; d=d.dropna().astype(float)
        d=d[(d['open']>0)&(d['high']>0)&(d['low']>0)&(d['close']>0)]
        if len(d)<5000: continue
        out[nm]=d.reset_index(drop=True)
    return out
D=load()

print("="*86)
print("实验D：决定性对照 —— 同一批特征，预测'波动' vs 预测'收益'")
print("="*86)
print(f"{'品种':>8} | {'IC(预测|ret|)':>13} {'IC(预测收益符号)':>17} {'IC(预测收益大小)':>17}")
rows=[]
for nm,d in D.items():
    c=d['close'].values; lr=np.diff(np.log(c)); lr=np.concatenate([[0.0],lr])
    H=24
    # 特征：过去168bar平均|ret|（只依赖过去）
    feat=pd.Series(np.abs(lr)).rolling(168).mean().values
    # 目标1：未来H bar 平均|ret|  （波动）
    tgt_vol=pd.Series(np.abs(lr)).rolling(H).mean().shift(-H).values
    # 目标2：未来H bar 收益符号   （方向）
    fut_ret=pd.Series(lr).rolling(H).sum().shift(-H).values
    tgt_dir=np.sign(fut_ret)
    m=~np.isnan(feat)&~np.isnan(tgt_vol)&~np.isnan(fut_ret)
    ic_vol=pd.Series(feat[m]).corr(pd.Series(tgt_vol[m]),method='spearman')
    ic_dir=pd.Series(feat[m]).corr(pd.Series(tgt_dir[m]),method='spearman')
    ic_mag=pd.Series(feat[m]).corr(pd.Series(np.abs(fut_ret)[m]),method='spearman')
    rows.append((ic_vol,ic_dir,ic_mag))
    print(f"{nm:>8} | {ic_vol:>13.3f} {ic_dir:>17.3f} {ic_mag:>17.3f}")
A=np.array(rows)
print()
for j,lab in enumerate(['IC(预测波动)','IC(预测方向)','IC(预测收益幅度)']):
    v=A[:,j]; t=v.mean()/(v.std(ddof=1)/np.sqrt(len(v)))
    print(f"  {lab:>16}: 均值{v.mean():+.4f}  跨品种t={t:+.2f}  为正{int((v>0).sum())}/13")

print()
print("="*86)
print("实验E：波动率过滤对'形状'的影响（即使不能转正，能否改善可承受性）")
print("="*86)
rng=np.random.default_rng(99)
print(f"{'R':>5} {'过滤':>8} | {'N':>7} {'毛E':>9} {'最大连亏':>9} {'连亏P95':>8} {'E/σ':>8}")
for R in [0.5]:
    for fl,lab in [(None,'不过滤'),(0.5,'低50%'),(0.25,'低25%')]:
        Ns=[];Es=[];ML=[];SR=[]
        for nm,d in D.items():
            c=d['close'].values
            v=pd.Series(np.abs(np.concatenate([[0.0],np.diff(np.log(c))]))).rolling(168).mean().values
            v=np.nan_to_num(v,nan=np.nanmean(v))
            thr=np.quantile(v,fl) if fl else -1
            n=len(c); sgn=np.sign(rng.normal(size=n))
            sig=np.where((v<thr)|(fl is None),sgn,0.0)
            tr,_=bracket2(d['open'].values,d['high'].values,d['low'].values,d['close'].values,sig,0.02,R)
            if len(tr)<30: continue
            Ns.append(len(tr)); Es.append(tr.mean())
            r=np.where(tr>0,1,0); mc=0;cur=0;mx=0
            for x in r:
                if x==0: cur+=1; mx=max(mx,cur)
                else: cur=0
            ML.append(mx); SR.append(tr.mean()/tr.std() if tr.std()>0 else 0)
        print(f"{R:>5} {lab:>8} | {np.mean(Ns):>7.0f} {np.mean(Es):>+9.4f} {np.mean(ML):>9.1f} {np.percentile(ML,95):>8.1f} {np.mean(SR):>8.4f}")
