"""分位数检验：真实 Agent 在「同占空比随机 Agent」分布中的位置
   + Reality Check: 随机 Agent 里挑最强的能到多少"""
import numpy as np, pandas as pd, sys, warnings, argparse
warnings.filterwarnings('ignore')
sys.path.insert(0, '/data/workspace/agent_lab')
from eng import *

ap = argparse.ArgumentParser()
ap.add_argument('--lo', type=int, default=0); ap.add_argument('--hi', type=int, default=9)
A = ap.parse_args()

YEARS = 3; CAP = 10000; FEE = 2; N = 40; K = 0.35; NSEED = 24

AGENTS = [
    ('rvq_0.35_lo',   '低波动分位(震荡)开'),
    ('rvq_0.35_hi',   '高波动开'),
    ('adx_25.0_lo',   'ADX<25 开(无趋势)'),
    ('pos240_0.35_lo','价格在通道下沿开'),
    ('momabs_0.20_hi','|动量|大开(趋势)'),
]

DATA = {}
for s in SYMS:
    d = load(s, YEARS); DATA[s] = (d, features(d))

rows = []
for aname, desc in AGENTS[A.lo:A.hi]:
    for s in SYMS:
        d, f = DATA[s]
        o = d['open'].values; h = d['high'].values
        l = d['low'].values;  c = d['close'].values
        m = make_mask(aname, f, c); duty = m.mean()
        r_agt = sim_mask(o, h, l, c, CAP, FEE, N, k=K, mask=m)
        # 同占空比随机 mask，24 seed
        ra = []
        for sd in range(NSEED):
            rng = np.random.default_rng(7000+sd)
            rm = rng.random(len(c)) < duty
            rm[:720] = False
            ra.append(sim_mask(o, h, l, c, CAP, FEE, N, k=K, mask=rm)['ann'])
        ra = np.array(ra)
        pct = (ra < r_agt['ann']).mean()          # 真实 Agent 的百分位
        rows.append(dict(agent=aname, desc=desc, sym=s, duty=duty,
                         ann_agt=r_agt['ann'], pctile=pct,
                         rand_med=np.median(ra), rand_max=ra.max(),
                         rand_mean=ra.mean(), rand_std=ra.std()))
    print("  done:", aname, flush=True)

R = pd.DataFrame(rows)
R.to_csv('/data/workspace/agent_lab/quant_%d_%d.csv' % (A.lo, A.hi), index=False)

print("\n" + "="*92)
print("真实 Agent 在同占空比随机 Agent 分布中的百分位（0.5=与随机无异, >0.95=有效）")
print("="*92)
g = R.groupby(['agent','desc']).agg(
    duty=('duty','median'),
    年化_Agent=('ann_agt','median'),
    随机中位=('rand_med','median'),
    随机最强=('rand_max','median'),
    Agent百分位=('pctile','median'),
    百分位gt95=('pctile', lambda x: (x > 0.95).mean()),
    百分位lt5=('pctile', lambda x: (x < 0.05).mean()),
).round(4)
print(g.to_string())
