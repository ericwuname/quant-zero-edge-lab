"""Reality Check: 在同一危险率下，随机离场 Agent 挑最强能到多少？
   对照：真实 Agent 的 (ret - 随机中位) vs 随机 Agent 的 (max - 中位)"""
import numpy as np, pandas as pd, sys, warnings, argparse
warnings.filterwarnings('ignore')
sys.path.insert(0, '/data/workspace/agent_lab')
from eng import *
WARM = 720

ap = argparse.ArgumentParser()
ap.add_argument('--lo', type=int, default=0); ap.add_argument('--hi', type=int, default=9)
A = ap.parse_args()

YEARS = 3; CAP = 10000; FEE = 2; N = 40; K = 0.35
NRAND = 25

def sim_exit(o, h, l, c, capital, fee_bp, N, k, exit_t, init_frac=0.5):
    """网格跑到 exit_t 时全部清仓离场（exit_t=None 表示跑到最后）"""
    T = len(c); fee = fee_bp/1e4
    m = capital/float(N)
    inv = init_frac*capital/o[0]; cash = capital - init_frac*capital
    avg = o[0]; realized = 0.0; nfill = 0
    peak = capital; maxdd = 0.0
    lv = levels_make(o[0], k, N, 'geom')
    prev = np.concatenate([[o[0]], c[:-1]])
    end = T if exit_t is None else min(exit_t, T)
    for t in range(T):
        if t >= end:
            eq = cash + inv*c[t]
            if eq > peak: peak = eq
            dd = (peak-eq)/peak if peak > 0 else 0
            if dd > maxdd: maxdd = dd
            continue
        a = np.searchsorted(lv, l[t], 'left')
        b = np.searchsorted(lv, min(prev[t], h[t]), 'left')
        for L in lv[a:b][::-1]:
            u = m/L; cost = m; f = cost*fee
            if cash >= cost+f:
                cash -= (cost+f); avg = (avg*inv+cost)/(inv+u) if inv > 0 else cost
                inv += u; nfill += 1
        d = np.searchsorted(lv, prev[t], 'right')
        e = np.searchsorted(lv, h[t], 'right')
        for L in lv[d:e]:
            u = m/L; proc = m; f = proc*fee
            if inv >= u-1e-12:
                realized += (proc-avg*u); cash += (proc-f); inv -= u; nfill += 1
        eq = cash + inv*c[t]
        if eq > peak: peak = eq
        dd = (peak-eq)/peak if peak > 0 else 0
        if dd > maxdd: maxdd = dd
    # 清仓
    px = c[end-1] if end > 0 else c[0]
    cash += inv*px*(1-fee); inv = 0.0
    final = cash
    yrs = T/(365*24.0)
    return dict(final=final, ret=final/capital-1,
                ann=(final/capital)**(1/yrs)-1 if final > 0 and yrs > 0 else -1.0,
                maxdd=maxdd, nfill=nfill, exit_t=end, yrs=yrs)




AGENTS = [
    ('rvq_0.35_lo','x'),('rvq_0.35_hi','x'),('adx_25.0_hi','ADX>25离场'),('adx_30.0_hi','ADX>30离场'),('rvq_0.80_hi','波动>80分位离场'),('pos240_0.90_hi','价格顶部离场'),('momabs_0.30_hi','动量大离场'),
]

DATA = {}
for s in SYMS:
    d = load(s, YEARS); DATA[s] = (d, features(d))

rows = []
for aname, desc in AGENTS[A.lo:A.hi]:
    for s in SYMS:
        d, f = DATA[s]
        o = d['open'].values; h = d['high'].values
        l = d['low'].values;  c = d['close'].values
        T = len(c)
        q = f[aname.split('_')[0]]
        thr = float(aname.split('_')[1]); direc = aname.split('_')[2]
        cond = np.zeros(T, bool); ok = ~np.isnan(q)
        cond[ok] = q[ok] < thr if direc == 'lo' else q[ok] > thr
        cond[:WARM] = False
        CONF, MINHOLD = 48, 720
        run = 0; t_a = T
        for i in range(WARM, T):
            if cond[i]:
                run += 1
                if run >= CONF and i >= MINHOLD:
                    t_a = i; break
            else:
                run = 0
        r_agt = sim_exit(o, h, l, c, CAP, FEE, N, K, t_a)
        span = max(t_a - WARM, 1); haz = 1.0/span
        # 同一危险率下 NRAND 个随机离场
        rr = []
        for sd in range(NRAND):
            rng = np.random.default_rng(9000+sd)
            u = rng.random(T-WARM)
            hit = np.where(u < haz)[0]
            t_r = WARM+int(hit[0]) if len(hit) else T
            rr.append(sim_exit(o, h, l, c, CAP, FEE, N, K, t_r)['ret'])
        rr = np.array(rr)
        med = np.median(rr)
        rows.append(dict(agent=aname, desc=desc, sym=s, t_agt=t_a,
                         ret_agt=r_agt['ret'],
                         rand_med=med, rand_max=rr.max(),
                         d_agt=r_agt['ret']-med,        # 真实 Agent 超额
                         d_randmax=rr.max()-med,        # 随机挑最强的超额
                         pct=(rr < r_agt['ret']).mean()))
    print("  done:", aname, flush=True)

R = pd.DataFrame(rows)
R['win'] = R['d_agt'] > R['d_randmax']
R.to_csv('/data/workspace/agent_lab/rc_%d_%d.csv' % (A.lo, A.hi), index=False)

print("\n" + "="*92)
print("Reality Check：真实 Agent 超额 vs 随机挑最强超额（同一危险率，%d 个随机）" % NRAND)
print("="*92)
g = R.groupby(['agent','desc']).agg(
    离场时刻=('t_agt','median'),
    真实Agent超额=('d_agt','median'),
    随机挑最强超额=('d_randmax','median'),
    真实Agent百分位=('pct','median'),
    胜过随机最强比例=('win','mean'),
).round(4)
print(g.to_string())
