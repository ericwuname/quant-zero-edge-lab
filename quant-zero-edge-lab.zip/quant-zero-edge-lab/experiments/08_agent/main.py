"""Agent 开关 vs 随机开关（同占空比）—— 剥离"少交易=省成本"的伪装"""
import numpy as np, pandas as pd, sys, warnings
warnings.filterwarnings('ignore')
sys.path.insert(0, '/data/workspace/agent_lab')
from eng import *

import argparse
ap=argparse.ArgumentParser(); ap.add_argument('--lo',type=int,default=0); ap.add_argument('--hi',type=int,default=99)
A=ap.parse_args()
YEARS = 3; CAP = 10000; FEE = 2; N = 40; K = 0.35
DATA = {}
BASE = {}
for s in SYMS:
    d = load(s, YEARS)
    DATA[s] = (d, features(d))

AGENTS = [
    ('rvq_0.35_lo',   '低波动分位(震荡)开'),
    ('rvq_0.50_lo',   '波动<中位开'),
    ('rvq_0.65_lo',   '波动<65分位开'),
    ('rvq_0.35_hi',   '高波动开(反向对照)'),
    ('adx_20.0_lo',   'ADX<20 开(无趋势)'),
    ('adx_25.0_lo',   'ADX<25 开'),
    ('adx_30.0_lo',   'ADX<30 开'),
    ('adx_25.0_hi',   'ADX>25 开(反向对照)'),
    ('pos240_0.35_lo','价格在通道下沿开'),
    ('pos240_0.65_hi','价格在通道上沿开'),
    ('momabs_0.20_lo','|动量|小开(震荡)'),
    ('momabs_0.20_hi','|动量|大开(趋势)'),
]

print("加载完成，品种数 =", len(SYMS))
print("网格参数: N=%d, k=%.2f, 成本=%dbp, 本金=%d, 样本=%d年\n" % (N, K, FEE, CAP, YEARS))

rows = []
for aname, desc in AGENTS[A.lo:A.hi]:
    for s in SYMS:
        d, f = DATA[s]
        o = d['open'].values; h = d['high'].values
        l = d['low'].values;  c = d['close'].values
        m = make_mask(aname, f, c)
        duty = m.mean()
        if duty < 0.02 or duty > 0.98:
            continue
        r_agt = sim_mask(o, h, l, c, CAP, FEE, N, k=K, mask=m)
        if s not in BASE:
            BASE[s] = sim_mask(o, h, l, c, CAP, FEE, N, k=K, mask=np.ones(len(c), bool))
        r_base = BASE[s]
        # 随机开关，占空比完全相同，20 seed
        rr = []
        for sd in range(8):
            rng = np.random.default_rng(1000+sd)
            rm = rng.random(len(c)) < duty
            rm[:720] = False
            rr.append(sim_mask(o, h, l, c, CAP, FEE, N, k=K, mask=rm))
        rows.append(dict(
            agent=aname, desc=desc, sym=s, duty=duty,
            ann_agt=r_agt['ann'], dd_agt=r_agt['maxdd'], nf_agt=r_agt['nfill'],
            ann_base=r_base['ann'], dd_base=r_base['maxdd'], nf_base=r_base['nfill'],
            ann_rand=np.median([x['ann'] for x in rr]),
            dd_rand=np.median([x['maxdd'] for x in rr]),
            nf_rand=np.median([x['nfill'] for x in rr]),
        ))
    print("  done:", aname)

R = pd.DataFrame(rows)
R['d_vs_base'] = R['ann_agt'] - R['ann_base']
R['d_vs_rand'] = R['ann_agt'] - R['ann_rand']      # 真正的 Agent 价值
R.to_csv('/data/workspace/agent_lab/part_%d_%d.csv'%(A.lo,A.hi), index=False)

print("\n" + "="*100)
print("Agent 开关效果汇总（年化中位数，13 品种）")
print("="*100)
g = R.groupby(['agent','desc']).agg(
    duty=('duty','median'),
    年化_Agent=('ann_agt','median'),
    年化_永远开=('ann_base','median'),
    年化_随机同占空比=('ann_rand','median'),
    Agent减基线=('d_vs_base','median'),
    Agent减随机=('d_vs_rand','median'),
    为正比例=('d_vs_rand', lambda x: (x > 0).mean()),
).round(4)
print(g.sort_values('Agent减随机', ascending=False).to_string())
