"""Agent 决策层测试引擎：网格 + 外部开关(mask)"""
import numpy as np, pandas as pd, warnings
warnings.filterwarnings('ignore')

SYMS = ['DOGE','ETH','CRV','DASH','DOT','FIL','HBAR','TRX','UNI','XLM','XMR','XRP','ZEC']
OLD7 = ['DOGE','ETH','CRV','DASH','DOT','FIL','HBAR']
NEW6 = ['TRX','UNI','XLM','XMR','XRP','ZEC']

def load(sym, years=3):
    df = pd.read_csv(f'/data/inputs/{sym}USDT_1h.csv')
    df = df[['timestamp','open','high','low','close','quoteVolume']].dropna()
    df = df[(df[['open','high','low','close']] > 0).all(axis=1)].reset_index(drop=True)
    n = int(365*24*years)
    return df.iloc[-n:].reset_index(drop=True) if len(df) > n else df


def levels_make(P0, k, N, gtype='geom'):
    lo = P0*(1-k); hi = P0*(1+k)
    if gtype == 'geom':
        return lo*(hi/lo)**(np.arange(N+1)/float(N))
    return np.linspace(lo, hi, N+1)


def sim_mask(o, h, l, c, capital, fee_bp, N, k=0.25, mask=None,
             gtype='geom', init_frac=0.5):
    """网格引擎。mask[t]=True 才允许成交（Agent 开关）。关闭时保留已有持仓。"""
    T = len(c)
    if mask is None:
        mask = np.ones(T, bool)
    fee = fee_bp/1e4
    m = capital/float(N)
    inv = 0.0; cash = capital
    avg = 0.0; realized = 0.0; fees = 0.0; nfill = 0
    peak = capital; maxdd = 0.0
    lv = None; started = False
    prev = np.concatenate([[o[0]], c[:-1]])

    for t in range(T):
        if not mask[t]:
            eq = cash + inv*c[t]
            if eq > peak: peak = eq
            dd = (peak-eq)/peak if peak > 0 else 0
            if dd > maxdd: maxdd = dd
            continue
        if not started:                      # 首个允许成交的 bar 建仓
            lv = levels_make(o[t], k, N, gtype)
            inv = init_frac*capital/o[t]
            cash = capital - init_frac*capital
            avg = o[t] if inv > 0 else 0.0
            started = True
            prev[t] = o[t]
        # 买入：价格下穿格线
        a = np.searchsorted(lv, l[t], 'left')
        b = np.searchsorted(lv, min(prev[t], h[t]), 'left')
        for L in lv[a:b][::-1]:
            u = m/L; cost = m; f = cost*fee
            if cash >= cost+f:
                cash -= (cost+f); fees += f
                avg = (avg*inv+cost)/(inv+u) if inv > 0 else cost
                inv += u; nfill += 1
        # 卖出：价格上穿格线
        d = np.searchsorted(lv, prev[t], 'right')
        e = np.searchsorted(lv, h[t], 'right')
        for L in lv[d:e]:
            u = m/L; proc = m; f = proc*fee
            if inv >= u-1e-12:
                fees += f; realized += (proc-avg*u); cash += (proc-f); inv -= u; nfill += 1
        eq = cash + inv*c[t]
        if eq > peak: peak = eq
        dd = (peak-eq)/peak if peak > 0 else 0
        if dd > maxdd: maxdd = dd

    final = cash + inv*c[-1]
    yrs = T/(365*24.0)
    return dict(final=final, ret=final/capital-1,
                ann=(final/capital)**(1/yrs)-1 if final > 0 and yrs > 0 else -1.0,
                maxdd=maxdd, nfill=nfill, fees=fees, realized=realized,
                duty=mask.mean())


# ---------- Agent 可观测状态量（全部只用 t 及之前的数据） ----------
def roll_std(x, p):
    s = pd.Series(x)
    return s.rolling(p, min_periods=p).std().shift(1).values   # shift(1): 只用历史

def roll_mean(x, p):
    s = pd.Series(x)
    return s.rolling(p, min_periods=p).mean().shift(1).values

def roll_q(x, p, q=None):
    """滚动分位：当前值在过去 p 根中的分位（只用历史，含当前）"""
    s = pd.Series(x)
    return s.rolling(p, min_periods=p).apply(lambda v: (v[:-1] < v[-1]).mean(), raw=True).values

def adx(h, l, c, n=14):
    up = np.diff(h, prepend=h[0]); dn = -np.diff(l, prepend=l[0])
    tr = np.maximum(h-l, np.maximum(abs(h-np.roll(c,1)), abs(l-np.roll(c,1))))
    tr[0] = h[0]-l[0]
    pdm = np.where((up > dn) & (up > 0), up, 0.0)
    ndm = np.where((dn > up) & (dn > 0), dn, 0.0)
    def wma(x, p):
        a = np.full(len(x), np.nan); prev = np.nan
        for i in range(1, len(x)):
            prev = x[i] if np.isnan(prev) else (prev*(p-1)+x[i])/p
            a[i] = prev
        return a
    atr = wma(tr, n); sp = wma(pdm, n); sn = wma(ndm, n)
    with np.errstate(divide='ignore', invalid='ignore'):
        pdi = 100*sp/atr; ndi = 100*sn/atr
        dx = 100*np.abs(pdi-ndi)/(pdi+ndi)
    out = np.full(len(c), np.nan); prev = np.nan
    for i in range(n, len(c)):
        prev = dx[i] if np.isnan(prev) else (prev*(n-1)+dx[i])/n
        out[i] = prev
    return out


def features(df):
    o = df['open'].values; h = df['high'].values
    l = df['low'].values;  c = df['close'].values
    ret = np.diff(np.log(c), prepend=np.log(c[0]))
    f = {}
    f['rv168'] = roll_std(ret, 168)                     # 已实现波动率
    f['rv24']  = roll_std(ret, 24)
    f['rvq']   = roll_q(f['rv168'], 720)                # 波动率在近一月分位
    f['adx']   = adx(h, l, c, 14)
    hi = pd.Series(c).rolling(240).max().values
    lo = pd.Series(c).rolling(240).min().values
    f['pos240'] = np.where(hi > lo, (c-lo)/(hi-lo), np.nan)
    f['mom240'] = c/np.roll(c, 240) - 1
    f['momabs'] = np.abs(f['mom240'])
    f['vol'] = df['quoteVolume'].values
    f['volq'] = roll_q(f['vol'], 720)
    return f


def make_mask(name, f, c, rng=None):
    """Agent 开关：返回 bool 数组"""
    n = len(c)
    if name == 'always':
        return np.ones(n, bool)
    if name.startswith('rand'):
        duty = float(name.split('_')[1]) if '_' in name else 0.6
        return rng.random(n) < duty

    q = f[name.split('_')[0]] if False else None
    kind, thr, direc = name.split('_')
    thr = float(thr)
    q = f[kind]
    mask = np.zeros(n, bool)
    ok = ~np.isnan(q)
    if direc == 'lo':
        mask[ok] = q[ok] < thr
    else:
        mask[ok] = q[ok] > thr
    mask[:720] = False                    # 预热期不交易
    return mask
