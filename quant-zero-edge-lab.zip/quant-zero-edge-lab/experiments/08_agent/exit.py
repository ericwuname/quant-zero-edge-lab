"""Agent 作为「离场判断」：提前识别单边行情，主动清仓
   对照: 危险率匹配的随机离场（期望离场时刻相同）"""
import numpy as np, pandas as pd, sys, warnings, argparse
warnings.filterwarnings('ignore')
sys.path.insert(0, '/data/workspace/agent_lab')
from eng import *

ap = argparse.ArgumentParser()
ap.add_argument('--lo', type=int, default=0); ap.add_argument('--hi', type=int, default=9)
A = ap.parse_args()
if __name__ != '__main__': A.lo, A.hi = 0, 0

YEARS = 3; CAP = 10000; FEE = 2; N = 40; K = 0.35; NSEED = 16
WARM = 720


def sim_exit(o, h, l, c, capital, fee_bp, N, k, exit_t, init_frac=0.5):
    """网格跑到 exit_t 时全部清仓离场（exit_t=None 表示跑到最后）"""
    T = len(c); fee = fee_bp/1e4
    m = capital/float(N)
    inv = init_frac*capital/o[0]; cash = capital - init_frac*capital
    avg = o[0]; realized = 0.0; nfill = 0
    peak = capital; maxdd = 0.0
    lv = levels_make(o[0], k, N, 'geom')
    prev = np.concatenate([[o[0]], c[:-1]])
    end = T if exit_t is None else min(exit_t, T)
    for t in range(T):
        if t >= end:
            eq = cash + inv*c[t]
            if eq > peak: peak = eq
            dd = (peak-eq)/peak if peak > 0 else 0
            if dd > maxdd: maxdd = dd
            continue
        a = np.searchsorted(lv, l[t], 'left')
        b = np.searchsorted(lv, min(prev[t], h[t]), 'left')
        for L in lv[a:b][::-1]:
            u = m/L; cost = m; f = cost*fee
            if cash >= cost+f:
                cash -= (cost+f); avg = (avg*inv+cost)/(inv+u) if inv > 0 else cost
                inv += u; nfill += 1
        d = np.searchsorted(lv, prev[t], 'right')
        e = np.searchsorted(lv, h[t], 'right')
        for L in lv[d:e]:
            u = m/L; proc = m; f = proc*fee
            if inv >= u-1e-12:
                realized += (proc-avg*u); cash += (proc-f); inv -= u; nfill += 1
        eq = cash + inv*c[t]
        if eq > peak: peak = eq
        dd = (peak-eq)/peak if peak > 0 else 0
        if dd > maxdd: maxdd = dd
    # 清仓
    px = c[end-1] if end > 0 else c[0]
    cash += inv*px*(1-fee); inv = 0.0
    final = cash
    yrs = T/(365*24.0)
    return dict(final=final, ret=final/capital-1,
                ann=(final/capital)**(1/yrs)-1 if final > 0 and yrs > 0 else -1.0,
                maxdd=maxdd, nfill=nfill, exit_t=end, yrs=yrs)


AGENTS = [
    ('adx_30.0_hi',   'ADX>30(趋势来了)离场'),
    ('adx_25.0_hi',   'ADX>25 离场'),
    ('rvq_0.80_hi',   '波动>80分位离场'),
    ('pos240_0.90_hi','价格到通道顶部离场'),
    ('momabs_0.30_hi','|动量|大离场'),
]

DATA = {}
for s in SYMS:
    d = load(s, YEARS); DATA[s] = (d, features(d))

rows = []
for aname, desc in AGENTS[A.lo:A.hi]:
    for s in SYMS:
        d, f = DATA[s]
        o = d['open'].values; h = d['high'].values
        l = d['low'].values;  c = d['close'].values
        T = len(c)
        q = f[aname.split('_')[0]]
        thr = float(aname.split('_')[1]); direc = aname.split('_')[2]
        # Agent 离场时刻
        cond = np.zeros(T, bool); ok = ~np.isnan(q)
        cond[ok] = q[ok] < thr if direc == 'lo' else q[ok] > thr
        cond[:WARM] = False
        # 连续 CONF 根满足 + 最短持仓 MINHOLD
        CONF, MINHOLD = 48, 720
        run = 0; t_a = T
        for i in range(WARM, T):
            if cond[i]:
                run += 1
                if run >= CONF and i >= MINHOLD:
                    t_a = i; break
            else:
                run = 0
        r_agt = sim_exit(o, h, l, c, CAP, FEE, N, K, t_a)
        # 基线：跑到最后
        r_base = sim_exit(o, h, l, c, CAP, FEE, N, K, None)
        # 危险率匹配的随机离场
        span = max(t_a - WARM, 1); haz = 1.0/span
        ra = []
        for sd in range(NSEED):
            rng = np.random.default_rng(3000+sd)
            u = rng.random(T-WARM)
            hit = np.where(u < haz)[0]
            t_r = WARM+int(hit[0]) if len(hit) else T
            ra.append(sim_exit(o, h, l, c, CAP, FEE, N, K, t_r))
        ra_ann = np.array([x['ret'] for x in ra])
        ra_dd  = np.array([x['maxdd'] for x in ra])
        ra_t   = np.array([x['exit_t'] for x in ra])
        rows.append(dict(agent=aname, desc=desc, sym=s,
                         t_agt=t_a, t_rand=np.median(ra_t),
                         ret_agt=r_agt['ret'], ann_agt=r_agt['ann'], dd_agt=r_agt['maxdd'],
                         ret_base=r_base['ret'], ann_base=r_base['ann'], dd_base=r_base['maxdd'],
                         ann_rand=np.median(ra_ann), dd_rand=np.median(ra_dd),
                         pct=(ra_ann < r_agt['ret']).mean(),
                         d_rand=r_agt['ret']-np.median(ra_ann),
                         d_base=r_agt['ann']-r_base['ann']))
    print("  done:", aname, flush=True)

R = pd.DataFrame(rows)
R.to_csv('/data/workspace/agent_lab/exit_%d_%d.csv' % (A.lo, A.hi), index=False)

print("\n" + "="*96)
print("Agent 离场判断（对照=危险率匹配的随机离场）")
print("="*96)
g = R.groupby(['agent','desc']).agg(
    Agent离场时刻=('t_agt','median'), 随机离场时刻=('t_rand','median'),
    总收益_Agent=('ret_agt','median'), 总收益_跑到底=('ret_base','median'), 总收益_随机离场=('ann_rand','median'),
    Agent减随机=('d_rand','median'), Agent减跑到底=('d_base','median'),
    回撤_Agent=('dd_agt','median'), 回撤_跑到底=('dd_base','median'), 回撤_随机=('dd_rand','median'),
    百分位=('pct','median'), 为正比例=('d_rand', lambda x: (x > 0).mean()),
).round(4)
print(g.to_string())
