"""
固定参数优先 —— 消除参数海
=================================
【固定参数（直接锚定，不测）】
  R = 2                      盈亏比
  1R = 止损距离               定义使然
  cost_R ∈ {0.05, 0.10}      成本/风险比（现实口径）
  cost_bp ∈ {2(maker), 10(taker)}
  不复利 = 固定注
  盈余公积 = 翻倍即收割 + 净值重置
  C0=1万, 爆仓线20%, T=100%

【反解（因变量，非自由参数）】
  s = 2*cost_bp / (cost_R*1e4)

【唯一自由参数：入场信号】
"""
import numpy as np, pandas as pd, sys, pickle, os
sys.path.insert(0, '/data/workspace/coin')
from eng import bracket2
from coin import load, OLD7, NEW6
from harvest import sim

R = 2.0


def coin_sig2(n, gap_lo, gap_hi, rng):
    """修正起点：固定小起点，保证全样本可用（原版随机起点导致样本只剩1/6）"""
    sig = np.zeros(n)
    i = 100
    while i < n - 1:
        sig[i] = float(rng.choice([-1.0, 1.0]))
        i += int(rng.integers(gap_lo, gap_hi + 1))
    return sig


def sig_vwap168(d):
    tp = (d['high'].values + d['low'].values + d['close'].values) / 3
    if 'volume' in d.columns:
        vv = d['volume'].values
        num = pd.Series(tp * vv).rolling(168, min_periods=168).sum().values
        den = pd.Series(vv).rolling(168, min_periods=168).sum().values
        ref = np.where(den > 0, num / np.maximum(den, 1e-12), np.nan)
    else:
        ref = pd.Series(tp).rolling(168, min_periods=168).mean().values
    return np.nan_to_num(np.sign(d['close'].values - ref))


def sig_brk50(d):
    h, l = d['high'].values, d['low'].values
    hh_p = np.concatenate([[np.nan], pd.Series(h).rolling(50, min_periods=50).max().values[:-1]])
    ll_p = np.concatenate([[np.nan], pd.Series(l).rolling(50, min_periods=50).min().values[:-1]])
    s = np.where(h > hh_p, 1.0, np.where(l < ll_p, -1.0, 0.0))
    return np.nan_to_num(s)


def sig_mom(d, w):
    return np.nan_to_num(np.sign(pd.Series(d['close'].values).pct_change(w).values))


def sig_ma(d, w):
    c = d['close'].values
    return np.nan_to_num(np.sign(c - pd.Series(c).rolling(w, min_periods=w).mean().values))


def sig_bh(d):
    return np.ones(len(d))


SIGS = {
    'coin(零期望基准)': None,
    'vwap_tr168': lambda d: sig_vwap168(d),
    'brk50': lambda d: sig_brk50(d),
    'mom240': lambda d: sig_mom(d, 240),
    'ma200': lambda d: sig_ma(d, 200),
    'BH(持有)': lambda d: sig_bh(d),
}


def build(s, nm, nseed=3):
    """返回该信号在止损 s 下的毛 R 序列（池化全品种）"""
    D = load()
    trs = []
    for sd in range(nseed):
        for k, v in D.items():
            if nm == 'coin(零期望基准)':
                rng = np.random.default_rng(sd * 137 + abs(hash(k)) % 997)
                sg = coin_sig2(len(v), 20, 240, rng)
            else:
                sg = SIGS[nm](v)
                sg = np.concatenate([[0.0], sg[:-1]])   # 关键：消除 off-by-one 前视
            t, _ = bracket2(v['open'].values, v['high'].values,
                            v['low'].values, v['close'].values, sg, s, R)
            trs.append(t)
    return np.concatenate(trs)


if __name__ == '__main__':
    combos = []
    for cb, cname in [(2.0, 'maker2bp'), (10.0, 'taker10bp')]:
        for cr in [0.05, 0.10]:
            combos.append((cname, cb, cr, 2 * cb / (cr * 1e4)))

    print('=' * 100)
    print('STEP 1  固定参数反解  s = 2*cost_bp/(cost_R*1e4)')
    print('=' * 100)
    for cname, cb, cr, s in combos:
        print('  %-11s cost_R=%.2f -> 止损 s=%.2f%%  止盈 %.2f%%' % (cname, cr, s * 100, s * R * 100))
    sys.stdout.flush()

    cache = {}
    print('\n' + '=' * 100)
    print('STEP 2  唯一自由参数 = 入场信号（跨13品种池化）')
    print('=' * 100)
    for cname, cb, cr, s in combos:
        print('\n--- %s | cost_R=%.2f | 止损 %.2f%% ---' % (cname, cr, s * 100))
        rows = []
        for nm in SIGS:
            key = (nm, s)
            if key not in cache:
                cache[key] = build(s, nm)
            x = cache[key]
            xn = x - cr
            t = xn.mean() / xn.std(ddof=1) * np.sqrt(len(xn))
            rows.append(dict(signal=nm, n=len(xn), E_net=xn.mean(), t=t,
                             winrate=(x > 0).mean(),
                             verdict='✓显著正' if t > 1.96 else ('✗显著负' if t < -1.96 else '—不显著')))
        print(pd.DataFrame(rows).to_string(index=False, float_format=lambda x: '%9.4f' % x))
        sys.stdout.flush()

    print('\n' + '=' * 100)
    print('STEP 3  收割制：固定注 + 翻倍即收割 + 净值重置 + 20%爆仓线')
    print('=' * 100)
    for cname, cb, cr, s in [combos[0], combos[3]]:
        print('\n--- %s | cost_R=%.2f | 止损 %.2f%% ---' % (cname, cr, s * 100))
        rows = []
        for nm in SIGS:
            x = cache[(nm, s)] - cr
            for f in [0.01, 0.02]:
                o = sim(x, f, T=1.0, n_path=1000, seed=11, n_target=5000)
                rows.append(dict(signal=nm, f=f, E=x.mean(), P=o['P'],
                                 pnl_med=o['pnl_med'], bust=o['bust'],
                                 trades_med=o['nb_med']))
        print(pd.DataFrame(rows).to_string(index=False, float_format=lambda x: '%9.3f' % x))
        sys.stdout.flush()
