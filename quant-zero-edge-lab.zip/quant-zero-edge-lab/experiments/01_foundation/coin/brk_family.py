"""
以 Δp = p - 1/(1+R) 为唯一判据, 系统扫描突破族
 Plateau检验: 若一片参数区都正(而非孤立尖峰) -> 真结构
 Clean检验: OLD7(参与挑选) vs NEW6(干净)
"""
import numpy as np, pandas as pd, sys
sys.path.insert(0,'/data/workspace/coin')
from eng import bracket2
from coin import load
STOP=0.05; CB=2.0; CR=2*CB/(STOP*1e4)
D=load(); NEW6={'TRXUSDT','UNIUSDT','XLMUSDT','XMRUSDT','XRPUSDT','ZECUSDT'}
def sig_brk(d,w):
    h,l=d['high'].values,d['low'].values
    hh=np.concatenate([[np.nan],pd.Series(h).rolling(w,min_periods=w).max().values[:-1]])
    ll=np.concatenate([[np.nan],pd.Series(l).rolling(w,min_periods=w).min().values[:-1]])
    return np.nan_to_num(np.where(h>hh,1.,np.where(l<ll,-1.,0.)))
def build(d,w,R):
    sg=np.concatenate([[0.0],sig_brk(d,w)[:-1]])
    return bracket2(d['open'].values,d['high'].values,d['low'].values,d['close'].values,sg,STOP,R,slip_bp=0.0)[0]
def grp(keys,w,R):
    trs=[build(D[k],w,R) for k in keys]; return np.concatenate(trs)
def dp(x,R):
    if len(x)<50: return np.nan,np.nan,np.nan
    theo=1/(1+R); p=(x>0).mean(); se=np.sqrt(theo*(1-theo)/len(x))
    return (p-theo)*100,(p-theo)/se,len(x)

WS=[20,30,50,80,120,200]; RS=[1.0,2.0,3.0,5.0]
print('='*110)
print('breakout family dp scan  stop=5pct maker2bp cost_R=%.4f'%CR); print('='*110)
print('breakeven required dp = cost_R/(R+1)*100 pp')
for R in RS: print('   R=%.0f -> %.3f pp'%(R, CR/(R+1)*100))

for tag,keys in [('OLD7(参与挑选)',[k for k in D if k not in NEW6]),('NEW6(干净)',[k for k in D if k in NEW6])]:
    print('\n### %s ###'%tag)
    print('%-6s'%'' + ''.join('%14s'%('R=%.0f'%R) for R in RS))
    for w in WS:
        line='%-6s'%('brk%d'%w)
        for R in RS:
            x=grp(keys,w,R); d,z,n=dp(x,R)
            line+='%14s'%('%+.2f(z%+.1f)'%(d,z) if not np.isnan(d) else 'na')
        print(line)
    sys.stdout.flush()

print('\n'+'='*110)
print('all 13 symbols + time split')
print('='*110)
for w in WS:
    for R in [2.0,3.0]:
        x=grp(list(D.keys()),w,R); d,z,n=dp(x,R)
        L=min(len(v) for v in D.values()); h=L//2
        x1=np.concatenate([build(D[k].iloc[:h].reset_index(drop=True),w,R) for k in D])
        x2=np.concatenate([build(D[k].iloc[h:L].reset_index(drop=True),w,R) for k in D])
        d1,z1,_=dp(x1,R); d2,z2,_=dp(x2,R)
        print('brk%-4d R=%.0f  n=%6d  Δp=%+.2fpp z=%+.2f | 前半%+.2f(z%+.1f) 后半%+.2f(z%+.1f)'%(
            w,R,n,d,z,d1,z1,d2,z2))
    sys.stdout.flush()
