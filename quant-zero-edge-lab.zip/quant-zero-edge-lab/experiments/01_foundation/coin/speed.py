import numpy as np, time, sys
sys.path.insert(0,'/data/workspace/coin')
from eng import bracket2
from coin import load
D=load()
k=list(D.keys())[0]; v=D[k]
print('symbol',k,'bars',len(v))
from coin import coin_sig
rng=np.random.default_rng(0)
sg=coin_sig(len(v),20,240,rng)
for s in [0.004,0.008,0.02,0.04,0.05]:
    t0=time.time()
    tr,ty=bracket2(v['open'].values,v['high'].values,v['low'].values,v['close'].values,sg,s,2.0)
    print('  s=%.2f%%  trades=%7d  time=%.2fs'%(s*100,len(tr),time.time()-t0))
