"""
对 vwap E=+0.11 做决定性验证 (三个独立检验, 任一不过即为幻觉)
1) beta对照: 同期BH是否同样为正 -> 正则说明赚的是beta不是alpha
2) 时间外推: 前半段/后半段是否都为正 -> 只一段正则为期间偏差
3) 多空分解: 多头E vs 空头E -> beta中性要求两者同号且接近
"""
import numpy as np, pandas as pd, sys
sys.path.insert(0,'/data/workspace/coin')
from eng import bracket2
from coin import load

R=2.0; S=0.05; CB=2.0; CR=2*CB/(S*1e4)
def sig_vwap168(d):
    tp=(d['high'].values+d['low'].values+d['close'].values)/3
    ref=pd.Series(tp).rolling(168,min_periods=168).mean().values
    return np.nan_to_num(np.sign(d['close'].values-ref))
def sig_bh(d): return np.ones(len(d))
def sig_coin(n,rng):
    s=np.zeros(n); i=100
    while i<n-1:
        s[i]=float(rng.choice([-1.,1.])); i+=int(rng.integers(20,241))
    return s

D=load()
def run(nm, sl, drop_tail=0):
    trs=[];sides=[]
    for sym,v in D.items():
        d=v.iloc[:len(v)-drop_tail].reset_index(drop=True) if drop_tail else v
        if nm=='BH': sg=sig_bh(d)
        elif nm=='coin': sg=sig_coin(len(d),np.random.default_rng(abs(hash(sym))%997))
        else: sg=np.concatenate([[0.0],sig_vwap168(d)[:-1]])
        t,ty=bracket2(d['open'].values,d['high'].values,d['low'].values,d['close'].values,sg,S,R)
        sd=np.sign(sg)
        # 记录每笔方向
        trs.append(t); sides.append(sd[:len(t)] if len(sd)>=len(t) else np.zeros(len(t)))
    return np.concatenate(trs), np.concatenate(sides)

print('='*104)
print('配置: stop=5pct target=10pct maker2bp cost_R=%.4f'%CR)
print('='*104)

# 检验1: beta对照
print('\n[检验1] 同期 beta 对照  —— vwap 的正E是否只是牛市beta?')
for nm in ['vwap_tr168','BH','coin']:
    x,_=run(nm,None)
    xn=x-CR
    t=xn.mean()/xn.std(ddof=1)*np.sqrt(len(xn))
    print('  %-12s n=%7d  E=%+.4f  t=%+7.2f'%(nm,len(xn),xn.mean(),t))
sys.stdout.flush()

# 检验2: 时间外推 (前半/后半)
print('\n[检验2] 时间切分  —— 是否只在某一段成立?')
L=min(len(v) for v in D.values())
half=L//2
for nm in ['vwap_tr168','BH']:
    for tag,sl in [('前半',slice(0,half)),('后半',slice(half,L))]:
        trs=[]
        for sym,v in D.items():
            d=v.iloc[sl].reset_index(drop=True)
            sg=sig_bh(d) if nm=='BH' else np.concatenate([[0.0],sig_vwap168(d)[:-1]])
            t,_=bracket2(d['open'].values,d['high'].values,d['low'].values,d['close'].values,sg,S,R)
            trs.append(t)
        x=np.concatenate(trs)-CR
        t=x.mean()/x.std(ddof=1)*np.sqrt(len(x))
        print('  %-12s %s  n=%7d  E=%+.4f  t=%+7.2f'%(nm,tag,len(x),x.mean(),t))
sys.stdout.flush()

# 检验3: 多空分解
print('\n[检验3] 多空分解  —— beta中性? (多头E与空头E应同号且接近)')
for nm in ['vwap_tr168']:
    x,sd=run(nm,None)
    xn=x-CR
    for lab,m in [('多头',sd>0),('空头',sd<0)]:
        z=xn[m]
        if len(z)>50:
            t=z.mean()/z.std(ddof=1)*np.sqrt(len(z))
            print('  %s n=%7d 占比%.1f%%  E=%+.4f  t=%+7.2f'%(lab,len(z),m.mean()*100,z.mean(),t))
    print('  多空差 = %+.4f'%(xn[sd>0].mean()-xn[sd<0].mean()))
