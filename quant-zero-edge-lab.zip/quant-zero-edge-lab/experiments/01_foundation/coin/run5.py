"""决定性对照：抛硬币 / vwap_tr168 / 同暴露买入持有 / 零期望 —— 统一收割制"""
import numpy as np, pandas as pd, glob, os, sys
sys.path.insert(0,'/data/workspace/coin')
from eng import bracket2
from harvest import sim
from coin import coin_sig
def load():
    out={}
    for p in sorted(glob.glob('/data/inputs/*_1h.csv')):
        nm=os.path.basename(p).replace('_1h.csv','')
        d=pd.read_csv(p); cols={c.lower():c for c in d.columns}
        d=d[[cols[k] for k in ('open','high','low','close','volume')]].copy()
        d.columns=['open','high','low','close','volume']
        d=d.dropna().astype(float); d=d[(d['open']>0)&(d['close']>0)]
        if len(d)<5000: continue
        out[nm]=d.reset_index(drop=True)
    return out
def vwap_tr(df,w=168):
    h=df['high'].values;l=df['low'].values;c=df['close'].values;v=df['volume'].values
    tp=(h+l+c)/3.0
    num=pd.Series(tp*v).rolling(w,min_periods=w).sum().values
    den=pd.Series(v).rolling(w,min_periods=w).sum().values
    vw=np.where(den>0,num/np.where(den==0,1,den),np.nan)
    s=np.nan_to_num(np.sign(c-vw),nan=0.0)
    s=pd.Series(s).replace(0.0,np.nan).ffill().fillna(0.0).values
    return np.concatenate([[0.0],s[:-1]])
D=load(); S,R,CB=0.05,2.0,2.0; cost_R=2*CB/(S*1e4)

def barseq_coin(sd):
    out=[]
    for k,v in D.items():
        rng=np.random.default_rng(sd*100+abs(hash(k))%997)
        sig=coin_sig(len(v),20,240,rng)
        t,_=bracket2(v['open'].values,v['high'].values,v['low'].values,v['close'].values,sig,S,R)
        out.append(t-cost_R)
    return np.concatenate(out)
def barseq_vwap():
    out=[]
    for k,v in D.items():
        t,_=bracket2(v['open'].values,v['high'].values,v['low'].values,v['close'].values,vwap_tr(v),S,R)
        out.append(t-cost_R)
    return np.concatenate(out)
def barseq_bh():
    """同暴露买入持有：始终多，1单位暴露，按策略平均持仓切成 R 单位"""
    out=[]
    for k,v in D.items():
        o=v['open'].values; r=np.diff(o)/o[:-1]
        # 按 60bar(约vwap平均持仓) 聚合，换算成 R 单位(除以S)
        m=60; n=len(r)//m
        agg=(np.add.reduceat(r[:n*m],np.arange(0,n*m,m)))/S
        out.append(agg-cost_R*0)     # 买入持有换手极低，成本≈0
    return np.concatenate(out)

coin=np.concatenate([barseq_coin(s) for s in range(6)])
vwap=barseq_vwap(); bh=barseq_bh()
def st(x,nm):
    print(f'{nm:22s} n={len(x):6d}  E={x.mean():+.4f}R  sd={x.std(ddof=1):6.3f}  年≈{len(x)/5.5/6 if "coin" in nm else len(x)/5.5:.0f}笔')
print('='*100); print('序列统计 (已扣 maker 2bp)'); print('='*100)
st(coin,'抛硬币(6seed合并)'); st(vwap,'vwap_tr168'); st(bh,'同暴露买入持有')

print('\n'+'='*100)
print('统一收割制：固定注 + 翻倍即收割 + 20%爆仓线 (本金1万, bootstrap 8000笔)')
print('='*100)
rows=[]
for f in [0.01,0.02,0.03,0.05]:
    r={}
    for nm,seq in [('coin',coin),('vwap',vwap),('bh',bh),('zero',bh-bh.mean())]:
        r[nm]=sim(seq,f,T=1.0,n_path=3000,seed=11,n_target=8000)
    rows.append(dict(f=f,
        P_coin=r['coin']['P'],P_vwap=r['vwap']['P'],P_bh=r['bh']['P'],P_zero=r['zero']['P'],
        med_coin=r['coin']['pnl_med'],med_vwap=r['vwap']['pnl_med'],med_bh=r['bh']['pnl_med'],
        bust_bh=r['bh']['bust'],bust_vwap=r['vwap']['bust']))
df=pd.DataFrame(rows)
print(df.to_string(index=False,float_format=lambda x:f'{x:10.2f}'))
print('\n关键: 若 P_bh(简单持有+收割) >= P_vwap(复杂策略+收割) -> 策略无价值')
df.to_csv('/data/workspace/coin/final2.csv',index=False)
