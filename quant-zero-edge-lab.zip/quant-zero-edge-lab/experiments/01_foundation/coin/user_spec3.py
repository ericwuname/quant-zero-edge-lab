"""配对检验：信号 E 是否显著优于随机方向（同品种配对，跨品种t值）
+ 第一部分：ls_diff 是否由品种beta驱动
"""
import numpy as np, pandas as pd
from user_spec import load, SIGS, run, OLD7, NEW6

D = load(); names = sorted(D.keys())
OLD7 = [x for x in OLD7 if x in D]; NEW6 = [x for x in NEW6 if x in D]
SP, CD, R, CB = 0.020, 20, 2.0, 2.0

def E_of(sname, sym):
    r = run(D[sym], SIGS[sname](D[sym]), SP, R, CB, CD)
    return r['tr'].mean() if r else np.nan

def tstat(x):
    x = np.asarray(x, float); x = x[~np.isnan(x)]
    if len(x) < 2: return np.nan
    sd = x.std(ddof=1)
    return float(x.mean() / (sd / np.sqrt(len(x)))) if sd > 0 else np.nan

print('=' * 80)
print('第一部分：ls_diff(多头-空头) 是否由品种beta驱动')
print('=' * 80)
for sname in ['ma50', 'macd', 'rsi14_tr']:
    for grp, syms in [('OLD7', OLD7), ('NEW6', NEW6)]:
        rec = {}
        for sym in syms:
            r = run(D[sym], SIGS[sname](D[sym]), SP, R, CB, CD)
            if r is None: continue
            bh = D[sym]['close'].iloc[-1] / D[sym]['close'].iloc[0] - 1
            d = (r['lg'] - r['sg']) if not (np.isnan(r['lg']) or np.isnan(r['sg'])) else np.nan
            rec[sym] = dict(lg=r['lg'], sg=r['sg'], diff=d, bh=bh)
        df = pd.DataFrame(rec).T.astype(float).dropna(subset=['diff', 'bh'])
        corr = df['diff'].corr(df['bh']) if len(df) > 2 else np.nan
        print(f'{sname:9s} {grp}: 多头{df.lg.mean():+.4f} 空头{df.sg.mean():+.4f} '
              f'ls_diff{df["diff"].mean():+.4f} | corr(ls_diff,品种BH)={corr:+.3f}')
        print('          品种BH: ' + ', '.join(f'{k}={v:+.0%}' for k, v in df['bh'].items()))

print()
print('=' * 80)
print('第二部分：配对检验  信号E - 随机方向E（同品种配对，跨品种t）')
print('=' * 80)
rows = []
for sname in ['ma50', 'mom20', 'macd', 'pos240', 'vwap168', 'rsi14_tr', 'rev20', 'rev240']:
    for grp, syms in [('ALL', names), ('OLD7', OLD7), ('NEW6', NEW6)]:
        e_s, e_r, dif = [], [], []
        for sym in syms:
            a = E_of(sname, sym); b = E_of('rand', sym)
            if np.isnan(a) or np.isnan(b): continue
            e_s.append(a); e_r.append(b); dif.append(a - b)
        rows.append(dict(sig=sname, grp=grp, n=len(dif),
                         E_sig=float(np.mean(e_s)), E_rand=float(np.mean(e_r)),
                         diff=float(np.mean(dif)), t_diff=tstat(dif),
                         t_vs0=tstat(e_s), pos=int(np.sum(np.array(dif) > 0))))
df = pd.DataFrame(rows)
pd.set_option('display.width', 230)
print(df.round(4).to_string(index=False))
print('\n注：t_diff = 信号E减随机E 的跨品种t值（|t|>1.96 才显著）')
df.to_csv('/data/workspace/coin/paired.csv', index=False)
