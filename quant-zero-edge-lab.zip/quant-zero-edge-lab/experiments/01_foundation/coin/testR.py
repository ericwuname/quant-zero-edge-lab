"""
R<1 高胜率 是否更好?  固定止损5%(1R固定), 只改止盈距离 R
三条通路:  胜率 = 1/(1+R)  |  E = 0 (鞅)  |  换手 N 随 R 下降而暴增
关键权衡: 平滑度(方差↓,连亏↓)  vs  时间/成本(N↑→总损耗↑)
"""
import numpy as np, pandas as pd, sys, time
sys.path.insert(0,'/data/workspace/coin')
from eng import bracket2
from coin import load

STOP=0.05; CB=2.0; COST_R=2*CB/(STOP*1e4)
D=load()
LIM=15000
DATA={k:v.iloc[-LIM:].reset_index(drop=True) for k,v in D.items()}

def coin_sig(n,sd):
    rng=np.random.default_rng(sd); s=np.zeros(n); i=100
    while i<n-1:
        s[i]=float(rng.choice([-1.,1.])); i+=int(rng.integers(20,241))
    return s

def build(R):
    trs=[]
    for sym,v in DATA.items():
        sd=sum(ord(ch) for ch in sym)
        sg=coin_sig(len(v),sd)
        t,_=bracket2(v['open'].values,v['high'].values,v['low'].values,v['close'].values,sg,STOP,R,slip_bp=0.0)
        trs.append(t)
    return np.concatenate(trs)

def maxrun(x):
    # 最大连续亏损次数 & 累计R最大回撤
    cur=0; mx=0; eq=np.cumsum(x); peak=np.maximum.accumulate(eq); dd=(peak-eq).max()
    for r in x:
        cur = cur+1 if r<0 else 0
        mx=max(mx,cur)
    return mx, dd

def harvest(x,f,T=1.0,bust=0.2,C0=10000.0,n_path=500,block=50,seed=11):
    rng=np.random.default_rng(seed); n=len(x)
    if n<block*2: return dict(P=np.nan,med=np.nan,done=np.nan,bust=np.nan)
    nb=int(np.ceil(n/block)); nblk=nb
    Ps=[];meds=[];dones=[];bs=[]
    for _ in range(n_path):
        pick=rng.choice(nb,size=nblk,replace=True)
        seq=np.concatenate([x[p*block:(p+1)*block] for p in pick])
        bet=f*C0; W=C0; ext=0.0; done=0; bk=0
        for r in seq:
            W+=bet*r
            if W>=(1+T)*C0:
                ext+=W-C0; W=C0
                if ext>=C0: Ps.append(1);meds.append(ext+W-C0);dones.append(1);bs.append(0);done=1;break
            if W<=bust*C0:
                Ps.append(1 if ext>=C0 else 0);meds.append(ext+W-C0);dones.append(1);bs.append(1);done=1;break
        if not done:
            Ps.append(1 if ext>=C0 else 0);meds.append(ext+W-C0);dones.append(0);bs.append(0)
    return dict(P=np.mean(Ps),med=np.median(meds),done=np.mean(dones),bust=np.mean(bs))

RS=[0.25,0.5,0.75,1.0,1.5,2.0,3.0,5.0]
rows=[]
print('='*118)
print('R below 1 high winrate experiment  stop=5pct fixed  maker2bp  cost_R=%.4f'%COST_R)
print('='*118)
for R in RS:
    t0=time.time()
    x=build(R); xn=x-COST_R
    win=(x>0).mean(); theo=1/(1+R)
    mx,dd=maxrun(x)
    N=len(x)
    rows.append(dict(R=R,theo_win=theo,win=win,N=N,
                     E_gross=x.mean(),E_net=xn.mean(),
                     var=x.var(),maxlose_run=mx,maxDD_R=dd,
                     total_cost=N*COST_R, t_net=xn.mean()/xn.std(ddof=1)*np.sqrt(N)))
    print('R=%.2f win=%.1fpct(theory %.1fpct) N=%6d 毛E=%+.4f 净E=%+.4f 总损耗=%7.1fR 方差=%.3f 连亏=%d 回撤=%.0fR (%.0fs)'%(
        R,win*100,theo*100,N,x.mean(),xn.mean(),N*COST_R,x.var(),mx,dd,time.time()-t0))
    sys.stdout.flush()

df=pd.DataFrame(rows)
print('\n'+'='*118)
print('harvest: fixed bet, T=100pct, bust=20pct, path=whole period')
print('='*118)
for f in [0.02,0.03]:
    print('\n### f=%.0fpct ###'%(f*100))
    out=[]
    for R in RS:
        x=build(R)-COST_R
        o=harvest(x,f)
        out.append(dict(R=R,P=o['P'],med=o['med'],done=o['done'],bust=o['bust']))
    o=pd.DataFrame(out)
    print(o.to_string(index=False,float_format=lambda z:'%8.3f'%z))
    sys.stdout.flush()
