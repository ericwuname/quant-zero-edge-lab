"""
决定性: 真实数据上, 胜率偏离理论 是否统计显著?
用大样本 + 多信号 + 多R, 算 z = (win - theo)/SE
"""
import numpy as np, pandas as pd, sys
sys.path.insert(0,'/data/workspace/coin')
from eng import bracket2
from coin import load
STOP=0.05
D=load()
def sig_vwap(d):
    tp=(d['high'].values+d['low'].values+d['close'].values)/3
    return np.nan_to_num(np.sign(d['close'].values-pd.Series(tp).rolling(168,min_periods=168).mean().values))
def sig_brk50(d):
    h,l=d['high'].values,d['low'].values
    hh=np.concatenate([[np.nan],pd.Series(h).rolling(50,min_periods=50).max().values[:-1]])
    ll=np.concatenate([[np.nan],pd.Series(l).rolling(50,min_periods=50).min().values[:-1]])
    return np.nan_to_num(np.where(h>hh,1.,np.where(l<ll,-1.,0.)))
def sig_coin(n,sd):
    rng=np.random.default_rng(sd); s=np.zeros(n); i=100
    while i<n-1: s[i]=float(rng.choice([-1.,1.])); i+=int(rng.integers(20,241))
    return s
SIGS={'vwap168':sig_vwap,'brk50':sig_brk50,'coin':sig_coin}

print('='*100)
print('真实数据: 胜率 vs 理论 1/(1+R), 偏离显著性 (z>1.96 才算真偏离)')
print('='*100)
print('%-9s %-6s %8s %8s %8s %8s %8s'%('signal','R','N','理论','实测','偏离pp','z'))
rows=[]
for nm,fn in SIGS.items():
    for R in [0.25,0.5,1.0,2.0,3.0,5.0]:
        tall=[]
        for sym,v in D.items():
            if nm=='coin': sg=sig_coin(len(v),sum(ord(c) for c in sym))
            else: sg=np.concatenate([[0.0],fn(v)[:-1]])
            t,_=bracket2(v['open'].values,v['high'].values,v['low'].values,v['close'].values,sg,STOP,R,slip_bp=0.0)
            tall.append(t)
        x=np.concatenate(tall); N=len(x)
        w=(x>0).mean(); theo=1/(1+R)
        se=np.sqrt(theo*(1-theo)/N)
        z=(w-theo)/se
        rows.append(dict(signal=nm,R=R,N=N,theo=theo*100,win=w*100,dev=(w-theo)*100,z=z))
        print('%-9s %-6.2f %8d %8.2f %8.2f %+8.2f %+8.2f'%(nm,R,N,theo*100,w*100,(w-theo)*100,z))
    sys.stdout.flush()
df=pd.DataFrame(rows)
print('\n'+'='*100)
print('汇总: 偏离方向统计')
print('  负偏离个数: %d / %d'%((df.dev<0).sum(),len(df)))
print('  |z|>1.96 个数: %d / %d'%((df.z.abs()>1.96).sum(),len(df)))
print('  平均偏离: %+.3f pp'%df.dev.mean())
print('  平均 z  : %+.3f'%df.z.mean())
# 合并 z (若独立)
print('  合并z (sqrt(n)*mean_z): %+.2f'%(np.sqrt(len(df))*df.z.mean()))
