import numpy as np, pandas as pd, sys
sys.path.insert(0,'/data/workspace/coin')
from coin import load
D=load()
print('='*100)
print('机制诊断：止损宽度 vs 单根bar波动  ->  同bar双触及频率')
print('='*100)
rows=[]
for k,v in D.items():
    o=v['open'].values; h=v['high'].values; l=v['low'].values
    rng_bp=(h-l)/o*1e4   # 单根bar振幅(bp)
    rows.append(dict(sym=k, med=np.median(rng_bp), mean=rng_bp.mean(),
                     p90=np.percentile(rng_bp,90)))
df=pd.DataFrame(rows)
print(df.to_string(index=False,float_format=lambda x:'%8.1f'%x))
allr=np.concatenate([ (v['high'].values-v['low'].values)/v['open'].values*1e4 for v in D.values()])
print('\n全样本单根bar振幅: 中位 %.1f bp  均值 %.1f bp  90分位 %.1f bp'%(np.median(allr),allr.mean(),np.percentile(allr,90)))
print()
print('-'*100)
print('止损组合的总区间 = 止损s + 止盈R*s = s*(1+R) = 3s  (R=2)')
print('-'*100)
for cn,cb,cr,s in [('maker/0.05',2.0,0.05,0.008),('maker/0.10',2.0,0.10,0.004),
                   ('taker/0.05',10.0,0.05,0.04),('taker/0.10',10.0,0.10,0.02),
                   ('旧口径5%',2.0,0.008,0.05)]:
    span=s*3*1e4
    frac=(allr>span).mean()
    print('  %-12s 止损%.2f%% 总区间%.0fbp  单bar振幅>区间的比例 %.1f%%  -> 同bar双触及频繁度'%(cn,s*100,span,frac*100))
