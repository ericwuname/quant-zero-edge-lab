import numpy as np, pandas as pd, sys
sys.path.insert(0,'/data/workspace/coin')
from eng import bracket2
from coin import load
STOP=0.05; R=2.0; theo=1/(1+R)
D=load(); KEYS=list(D.keys())
NEW6={'TRXUSDT','UNIUSDT','XLMUSDT','XMRUSDT','XRPUSDT','ZECUSDT'}
def sig_brk(d,w):
    h,l=d['high'].values,d['low'].values
    hh=np.concatenate([[np.nan],pd.Series(h).rolling(w,min_periods=w).max().values[:-1]])
    ll=np.concatenate([[np.nan],pd.Series(l).rolling(w,min_periods=w).min().values[:-1]])
    return np.nan_to_num(np.where(h>hh,1.,np.where(l<ll,-1.,0.)))
def run(d,w,R=R):
    sg=np.concatenate([[0.0],sig_brk(d,w)[:-1]])
    return bracket2(d['open'].values,d['high'].values,d['low'].values,d['close'].values,sg,STOP,R,slip_bp=0.0)[0]
def dp(x):
    p=(x>0).mean(); se=np.sqrt(theo*(1-theo)/len(x)); return (p-theo)*100,(p-theo)/se
W=500
print('='*104); print('brk%d R=2 最终验证'%W); print('='*104)
print('[1] 逐品种')
tot=[];pos=0
for k in KEYS:
    x=run(D[k],W); d,z=dp(x); tot.append(x); pos+= (d>0)
    print('  %-9s %-5s n=%5d Δp=%+6.2f z=%+5.2f 净E=%+.4f'%(k,'NEW6'if k in NEW6 else 'OLD7',len(x),d,z,x.mean()-0.008))
x=np.concatenate(tot); print('  >> 为正 %d/13  合计 n=%d Δp=%+.2f z=%+.2f 净E=%+.4f'%(pos,len(x),*dp(x),x.mean()-0.008))
sys.stdout.flush()

print('\n[2] 时间5等分')
L=min(len(v) for v in D.values()); seg=L//5
for i in range(5):
    sl=slice(i*seg,(i+1)*seg)
    xx=np.concatenate([run(D[k].iloc[sl].reset_index(drop=True),W) for k in KEYS])
    d,z=dp(xx); print('  段%d n=%5d Δp=%+6.2f z=%+5.2f 净E=%+.4f'%(i+1,len(xx),d,z,xx.mean()-0.008))
sys.stdout.flush()

print('\n[3] 成本敏感性')
g=x.mean(); print('  毛E=%+.4f'%g)
for cb in [0,2,5,10,15,20,30]:
    cr=2*cb/(STOP*1e4); print('  %4.1fbp cost_R=%.4f 净E=%+.4f %s'%(cb,cr,g-cr,'POS' if g>cr else 'NEG'))
sys.stdout.flush()

print('\n[4] 不复利收割制 (固定注, 翻倍即收割, 爆仓线20%)')
def harvest(x,f,T=1.0,bust=0.2,C0=10000.,n_path=800,block=50,seed=3):
    rng=np.random.default_rng(seed); n=len(x); nb=n//block
    Ps=[];meds=[];bs=[]
    for _ in range(n_path):
        pk=rng.choice(nb,size=nb,replace=True)
        seq=np.concatenate([x[p*block:(p+1)*block] for p in pk])
        bet=f*C0; W=C0; ext=0.; fin=0
        for r in seq:
            W+=bet*r
            if W>=(1+T)*C0:
                ext+=W-C0; W=C0
                if ext>=C0: Ps.append(1);meds.append(ext+W-C0);bs.append(0);fin=1;break
            if W<=bust*C0:
                Ps.append(1 if ext>=C0 else 0);meds.append(ext+W-C0);bs.append(1);fin=1;break
        if not fin: Ps.append(1 if ext>=C0 else 0);meds.append(ext+W-C0);bs.append(0)
    return np.mean(Ps),np.median(meds),np.mean(bs)
xn=x-0.008
print('  %-6s %10s %12s %8s'%('f','P(赚回本金)','盈亏中位','爆仓率'))
for f in [0.005,0.01,0.02,0.03,0.05]:
    P,m,b=harvest(xn,f); print('  %-6.1f%% %10.1f%% %12.0f %8.1f%%'%(f*100,P*100,m,b*100))
sys.stdout.flush()
# 零期望对照
rng=np.random.default_rng(1)
x0=xn-xn.mean()
print('  --- 零期望对照 (同样波动形状) ---')
for f in [0.01,0.02,0.03]:
    P,m,b=harvest(x0,f); print('  f=%-5.1f%% %10.1f%% %12.0f %8.1f%%'%(f*100,P*100,m,b*100))
