"""
brk50 R=2 净E=+0.0241 的三重验证 (抓过7个bug, 必须验证)
1) 时间外推  2) 品种外推(OLD7 vs NEW6)  3) 多空分解
"""
import numpy as np, pandas as pd, sys
sys.path.insert(0,'/data/workspace/coin')
from eng import bracket2
from coin import load
STOP=0.05; R=2.0; CB=2.0; CR=2*CB/(STOP*1e4)
D=load()
NEW6={'TRXUSDT','UNIUSDT','XLMUSDT','XMRUSDT','XRPUSDT','ZECUSDT'}
def sig_brk50(d):
    h,l=d['high'].values,d['low'].values
    hh=np.concatenate([[np.nan],pd.Series(h).rolling(50,min_periods=50).max().values[:-1]])
    ll=np.concatenate([[np.nan],pd.Series(l).rolling(50,min_periods=50).min().values[:-1]])
    return np.nan_to_num(np.where(h>hh,1.,np.where(l<ll,-1.,0.)))
def build(d):
    sg=np.concatenate([[0.0],sig_brk50(d)[:-1]])
    return bracket2(d['open'].values,d['high'].values,d['low'].values,d['close'].values,sg,STOP,R,slip_bp=0.0)
def stat(x):
    xn=x-CR; return xn.mean(), xn.mean()/xn.std(ddof=1)*np.sqrt(len(xn)), len(xn)

print('='*100); print('brk50 R=2 三重验证  (净E = 毛E - %.4f)'%CR); print('='*100)

# 1 时间外推
print('\n[1] 时间外推')
L=min(len(v) for v in D.values()); half=L//2
for tag,sl in [('前半',slice(0,half)),('后半',slice(half,L))]:
    trs=[]
    for sym,v in D.items():
        t,_=build(v.iloc[sl].reset_index(drop=True)); trs.append(t)
    e,t,n=stat(np.concatenate(trs)); print('  %s  净E=%+.4f  t=%+.2f  n=%d'%(tag,e,t,n))
# 2 品种外推
print('\n[2] 品种外推')
for tag,ks in [('OLD7(参与过挑选)',[s for s in D if s not in NEW6]),('NEW6(干净)',[s for s in D if s in NEW6])]:
    trs=[]
    for sym in ks:
        t,_=build(D[sym]); trs.append(t)
    e,t,n=stat(np.concatenate(trs)); print('  %-18s 净E=%+.4f  t=%+.2f  n=%d'%(tag,e,t,n))
print('  --- 逐品种 ---')
for sym in D:
    t,_=build(D[sym]); e,tt,n=stat(t); print('    %-6s 净E=%+.4f  t=%+.2f  n=%d'%(sym,e,tt,n))
# 3 多空分解
print('\n[3] 多空分解 (beta中性检查)')
trs=[];sds=[]
for sym,v in D.items():
    sg=np.concatenate([[0.0],sig_brk50(v)[:-1]])
    t,_=bracket2(v['open'].values,v['high'].values,v['low'].values,v['close'].values,sg,STOP,R,slip_bp=0.0)
    trs.append(t); sds.append(np.sign(sg[:len(t)]) if len(sg)>=len(t) else np.zeros(len(t)))
x=np.concatenate(trs); sd=np.concatenate(sds)
for lab,m in [('多头',sd>0),('空头',sd<0)]:
    e,t,n=stat(x[m]); print('  %s 占比%.1f%%  净E=%+.4f  t=%+.2f'%(lab,m.mean()*100,e,t))
print('  多空差=%+.4f'%( (x[sd>0]-CR).mean()-(x[sd<0]-CR).mean() ))
