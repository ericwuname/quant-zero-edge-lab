"""
路线A：三个旋钮的联合最优
旋钮1 成本(已定,不可再动)  旋钮2 仓位f  旋钮3 收割规则(T, bust, 停止)
目标: 最大化 P(累计提取>=本金) 与 中位数盈亏
关键分野: E>0 时应"快玩"(多次数), E<=0 时应"慢玩"(少次数)
"""
import numpy as np, pandas as pd, sys
sys.path.insert(0,'/data/workspace/coin')
from eng import bracket2
from coin import load

R=2.0
def sig_vwap168(d):
    tp=(d['high'].values+d['low'].values+d['close'].values)/3
    ref=pd.Series(tp).rolling(168,min_periods=168).mean().values
    return np.nan_to_num(np.sign(d['close'].values-ref))
def sig_brk50(d):
    h,l=d['high'].values,d['low'].values
    hh=np.concatenate([[np.nan],pd.Series(h).rolling(50,min_periods=50).max().values[:-1]])
    ll=np.concatenate([[np.nan],pd.Series(l).rolling(50,min_periods=50).min().values[:-1]])
    return np.nan_to_num(np.where(h>hh,1.0,np.where(l<ll,-1.0,0.0)))
def sig_bh(d): return np.ones(len(d))
SIGS={'vwap_tr168':sig_vwap168,'brk50':sig_brk50,'BH':sig_bh}

def build(s,nm):
    D=load(); trs=[]
    for sym,v in D.items():
        sg=np.concatenate([[0.0],SIGS[nm](v)[:-1]])  # 消除off-by-one前视
        t,_=bracket2(v['open'].values,v['high'].values,v['low'].values,v['close'].values,sg,s,R)
        trs.append(t)
    return np.concatenate(trs)

def harvest(x,f,T,bust,C0=10000.0,stop_at_win=True,max_n=6000):
    bet=f*C0; W=C0; ext=0.0
    for r in x[:max_n]:
        W+=bet*r
        if W>=(1+T)*C0:
            ext+=W-C0; W=C0
            if stop_at_win and ext>=C0: return 1,ext+W-C0,0
        if W<=bust*C0: return (1 if ext>=C0 else 0),ext+W-C0,1
    return (1 if ext>=C0 else 0),ext+W-C0,0

def sim(x,f,T,bust,n_path=1200,block=50,seed=3,stop_at_win=True,max_n=6000):
    rng=np.random.default_rng(seed); n=len(x); nb=int(np.ceil(n/block))
    nblk=int(np.ceil(max_n/block)); res=[]
    for _ in range(n_path):
        pick=rng.choice(nb,size=nblk,replace=True)
        seq=np.concatenate([x[p*block:(p+1)*block] for p in pick])[:max_n]
        res.append(harvest(seq,f,T,bust,stop_at_win=stop_at_win,max_n=max_n))
    w=np.array([r[0] for r in res],float); p=np.array([r[1] for r in res]); b=np.array([r[2] for r in res],float)
    return dict(P=w.mean(),pnl_med=np.median(p),pnl_mean=p.mean(),bust=b.mean())

if __name__=='__main__':
    # 用旧口径宽止损(穿透可忽略)取得"干净"序列, 再用 cost_R 调到目标 E
    s=0.05; cb=2.0; cr=2*cb/(s*1e4)
    seqs={}
    for nm in SIGS:
        x=build(s,nm)-cr
        seqs[nm]=x
        print('%-12s n=%7d  E=%+.4f  sd=%.3f'%(nm,len(x),x.mean(),x.std()))
    sys.stdout.flush()

    # 以 vwap 序列为基底, 人为设定 E 档位 (保留真实波动形状)
    base=seqs['vwap_tr168']; sd=base.std()
    print('\n'+'='*104)
    print('扫描: 仓位f x 收割阈值T x 爆仓线bust   (序列=vwap真实形状, E被调到指定档)')
    print('='*104)
    for tag,Eset in [('E>0 (+0.02)',0.02),('E=0 (零期望)',0.0),('E<0 (-0.02)',-0.02)]:
        x=base-base.mean()+Eset
        rows=[]
        for f in [0.005,0.01,0.02,0.03,0.05]:
            for T in [0.3,0.5,1.0]:
                for bust in [0.2,0.5]:
                    o=sim(x,f,T,bust,n_path=800)
                    rows.append(dict(f=f,T=T,bust=bust,P=o['P'],med=o['pnl_med'],bust_rate=o['bust']))
        df=pd.DataFrame(rows).sort_values('P',ascending=False)
        print('\n### %s  (E=%+.3f, sd=%.3f) ###'%(tag,Eset,sd))
        print(df.head(8).to_string(index=False,float_format=lambda x:'%8.3f'%x))
        sys.stdout.flush()
