"""
brk200 R=2 决定性检验
1) Reality Check: 24组合网格选最大, 用符号置换零分布校正
2) 逐品种一致性
3) 多空分解(真beta检验): 只做多 vs 只做空
4) 成本敏感性
"""
import numpy as np, pandas as pd, sys
sys.path.insert(0,'/data/workspace/coin')
from eng import bracket2
from coin import load
STOP=0.05; R=2.0; theo=1/(1+R)
D=load(); NEW6={'TRXUSDT','UNIUSDT','XLMUSDT','XMRUSDT','XRPUSDT','ZECUSDT'}
KEYS=list(D.keys())
def sig_brk(d,w):
    h,l=d['high'].values,d['low'].values
    hh=np.concatenate([[np.nan],pd.Series(h).rolling(w,min_periods=w).max().values[:-1]])
    ll=np.concatenate([[np.nan],pd.Series(l).rolling(w,min_periods=w).min().values[:-1]])
    return np.nan_to_num(np.where(h>hh,1.,np.where(l<ll,-1.,0.)))
def trades(d,w,R,mode='both',flip=0):
    sg=np.concatenate([[0.0],sig_brk(d,w)[:-1]])
    if mode=='long': sg=np.where(sg>0,1.,0.)
    elif mode=='short': sg=np.where(sg<0,-1.,0.)
    if flip: sg=-sg
    return bracket2(d['open'].values,d['high'].values,d['low'].values,d['close'].values,sg,STOP,R,slip_bp=0.0)[0]
def dp(x):
    if len(x)<50: return np.nan,np.nan
    p=(x>0).mean(); se=np.sqrt(theo*(1-theo)/len(x)); return (p-theo)*100,(p-theo)/se

print('='*106)
print('[1] Reality Check over 24-combo grid (6 windows x 4 R)')
print('='*106)
WS=[20,30,50,80,120,200]; RS=[1.0,2.0,3.0,5.0]
# 真实最大
real={}
for w in WS:
    for r in RS:
        x=np.concatenate([trades(D[k],w,r) for k in KEYS]); real[(w,r)]=dp(x)
mxR=max(real.items(),key=lambda kv:kv[1][1])
print('  真实最强: brk%d R=%.0f  Δp=%+.2fpp  z=%+.2f'%(mxR[0][0],mxR[0][1],mxR[1][0],mxR[1][1]))
# 零分布: 每个品种独立随机翻转信号符号 -> 消除方向能力, 保留时序结构
rng=np.random.default_rng(7); NB=200; mxz=[]
for b in range(NB):
    best=-9
    for w in WS:
        for r in RS:
            fl={k:int(rng.integers(2)) for k in KEYS}
            x=np.concatenate([trades(D[k],w,r,flip=fl[k]) for k in KEYS])
            d,z=dp(x)
            if not np.isnan(z) and z>best: best=z
    mxz.append(best)
mxz=np.array(mxz)
print('  零分布 max|z|: 均值%+.2f  95%%分位%+.2f  99%%分位%+.2f'%(mxz.mean(),np.percentile(mxz,95),np.percentile(mxz,99)))
print('  Reality Check p = %.3f   -> %s'%((mxz>=mxR[1][1]).mean(),'显著' if (mxz>=mxR[1][1]).mean()<0.05 else '不显著'))
sys.stdout.flush()

print('\n'+'='*106)
print('[2] brk200 R=2 逐品种')
print('='*106)
tot=[]
for k in KEYS:
    x=trades(D[k],200,R); d,z=dp(x); tot.append(x)
    tag='NEW6'if k in NEW6 else 'OLD7'
    print('  %-9s %-5s n=%5d  Δp=%+6.2fpp  z=%+5.2f  净E=%+.4f'%(k,tag,len(x),d,z,x.mean()-2*2/(STOP*1e4)))
xa=np.concatenate(tot); d,z=dp(xa)
print('  合计 n=%d Δp=%+.2fpp z=%+.2f'%(len(xa),d,z))

print('\n'+'='*106)
print('[3] 多空分解 (真 beta 检验)')
print('='*106)
for mode in ['long','short','both']:
    x=np.concatenate([trades(D[k],200,R,mode=mode) for k in KEYS]); d,z=dp(x)
    print('  %-6s n=%5d  Δp=%+6.2fpp  z=%+5.2f  净E=%+.4f'%(mode,len(x),d,z,x.mean()-2*2/(STOP*1e4)))

print('\n'+'='*106)
print('[4] 成本敏感性 (brk200 R=2, Δp=%+.2fpp)'%dp(np.concatenate([trades(D[k],200,R) for k in KEYS]))[0])
print('='*106)
x=np.concatenate([trades(D[k],200,R) for k in KEYS]); g=x.mean()
for cb in [0,1,2,5,10,20]:
    cr=2*cb/(STOP*1e4)
    print('  单边%4.1fbp -> cost_R=%.4f  净E=%+.4f  %s'%(cb,cr,g-cr,'正' if g>cr else '负'))
