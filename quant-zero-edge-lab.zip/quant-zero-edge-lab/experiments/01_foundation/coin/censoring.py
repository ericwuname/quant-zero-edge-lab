"""
决定性: brk50 的胜率正偏离, 是真方向能力 还是 截断(censoring)假象?
口径A: 全部交易(含末尾强平)   口径B: 仅已完成(触止盈/止损)
若 B 塌向理论 -> 是截断假象; 若 B 仍正 -> 可能是真信号
同时算 E 验证: 胜率+1pp 对 E 的贡献 = (R+1)*0.01
"""
import numpy as np, pandas as pd, sys
sys.path.insert(0,'/data/workspace/coin')
from eng import bracket2
from coin import load
STOP=0.05
D=load()
def sig_brk50(d):
    h,l=d['high'].values,d['low'].values
    hh=np.concatenate([[np.nan],pd.Series(h).rolling(50,min_periods=50).max().values[:-1]])
    ll=np.concatenate([[np.nan],pd.Series(l).rolling(50,min_periods=50).min().values[:-1]])
    return np.nan_to_num(np.where(h>hh,1.,np.where(l<ll,-1.,0.)))
def sig_vwap(d):
    tp=(d['high'].values+d['low'].values+d['close'].values)/3
    return np.nan_to_num(np.sign(d['close'].values-pd.Series(tp).rolling(168,min_periods=168).mean().values))

print('='*112)
print('brk50 胜率正偏离: 真信号 还是 截断假象?')
print('='*112)
print('%-6s %8s | %8s %8s %8s | %8s %8s %8s | %8s'%(
  'R','理论','全胜率','已完成','截断%','全E','已完成E','截断均R','截断贡献'))
for nm,fn in [('brk50',sig_brk50),('vwap168',sig_vwap)]:
    print('\n--- %s ---'%nm)
    for R in [0.5,1.0,2.0,3.0,5.0]:
        tall=[];tty=[]
        for sym,v in D.items():
            sg=np.concatenate([[0.0],fn(v)[:-1]])
            t,ty=bracket2(v['open'].values,v['high'].values,v['low'].values,v['close'].values,sg,STOP,R,slip_bp=0.0)
            tall.append(t);tty.append(ty)
        x=np.concatenate(tall);ty=np.concatenate(tty)
        fin=ty>=0; cens=ty<0
        theo=1/(1+R)
        w_all=(x>0).mean(); w_fin=(x[fin]>0).mean() if fin.sum()>50 else np.nan
        se=np.sqrt(theo*(1-theo)/fin.sum())
        z_fin=(w_fin-theo)/se if fin.sum()>50 else np.nan
        print('%-6.2f %8.2f | %8.2f %8.2f %8.2f | %+8.4f %+8.4f %+8.4f | %+8.3f'%(
            R,theo*100,w_all*100,w_fin*100,cens.mean()*100,
            x.mean(),x[fin].mean() if fin.sum()>50 else np.nan,
            x[cens].mean() if cens.sum()>20 else np.nan,
            cens.mean()*(x[cens].mean()-x[fin].mean()) if cens.sum()>20 else 0))
        print('       z(已完成)=%+6.2f  n_fin=%d'%(z_fin,fin.sum()))
    sys.stdout.flush()
