"""诊断：(1)抛硬币多seed稳定性 (2)vwap_tr168 的 beta 暴露与真实alpha"""
import numpy as np, pandas as pd, glob, os, sys
sys.path.insert(0,'/data/workspace/coin')
from eng import bracket2
from coin import coin_sig
def load():
    out={}
    for p in sorted(glob.glob('/data/inputs/*_1h.csv')):
        nm=os.path.basename(p).replace('_1h.csv','')
        d=pd.read_csv(p); cols={c.lower():c for c in d.columns}
        d=d[[cols[k] for k in ('open','high','low','close','volume')]].copy()
        d.columns=['open','high','low','close','volume']
        d=d.dropna().astype(float); d=d[(d['open']>0)&(d['close']>0)]
        if len(d)<5000: continue
        out[nm]=d.reset_index(drop=True)
    return out
def vwap_tr(df,w=168):
    h=df['high'].values;l=df['low'].values;c=df['close'].values;v=df['volume'].values
    tp=(h+l+c)/3.0
    num=pd.Series(tp*v).rolling(w,min_periods=w).sum().values
    den=pd.Series(v).rolling(w,min_periods=w).sum().values
    vw=np.where(den>0,num/np.where(den==0,1,den),np.nan)
    s=np.nan_to_num(np.sign(c-vw),nan=0.0)
    s=pd.Series(s).replace(0.0,np.nan).ffill().fillna(0.0).values
    return np.concatenate([[0.0],s[:-1]])
D=load(); S,R,CB=0.05,2.0,2.0; cost_R=2*CB/(S*1e4)

print('='*100); print('诊断1：抛硬币 多seed稳定性 (理论 E=0)'); print('='*100)
Es=[]
for sd in range(12):
    trs=[]
    for k,v in D.items():
        rng=np.random.default_rng(sd*100+abs(hash(k))%997)
        t,ty=bracket2(v['open'].values,v['high'].values,v['low'].values,v['close'].values,
                      coin_sig(len(v),20,240,rng),S,R)
        trs.append(t)
    tr=np.concatenate(trs)-cost_R; Es.append(tr.mean())
Es=np.array(Es)
print(f'12个seed的 E(R): 均值={Es.mean():+.4f}  sd={Es.std(ddof=1):.4f}  范围[{Es.min():+.4f},{Es.max():+.4f}]')
print(f'理论(纯成本): {-cost_R:+.4f}   -> 毛E均值={Es.mean()+cost_R:+.4f}')
print(f'单seed标准误≈{Es.std(ddof=1):.4f}  => 之前两次运行差0.025 属抽样噪声')

print('\n'+'='*100); print('诊断2：vwap_tr168 的 beta 暴露 (关键)'); print('='*100)
longs=[];Es2=[];bhs=[]
for k,v in D.items():
    tr,ty=bracket2(v['open'].values,v['high'].values,v['low'].values,v['close'].values,vwap_tr(v),S,R)
    # 用 net_bar 口径算暴露不易，这里用信号方向占比代理 + 对比买入持有
    sig=vwap_tr(v); longs.append(float((sig>0).mean()))
    Es2.append(tr.mean()-cost_R)
    o=v['open'].values; bhs.append(o[-1]/o[0]-1.0)
longs=np.array(longs);Es2=np.array(Es2)
print(f'多头占比: 均值={longs.mean():.3f}  各品种={np.round(longs,2)}')
print(f'E(R) per symbol: {np.round(Es2,4)}')
print(f'跨品种 t = {Es2.mean()/Es2.std(ddof=1)*np.sqrt(len(Es2)):+.2f}')
print(f'样本期买入持有(全品种均值) = {np.mean(bhs)*100:+.1f}%  <- 大牛市beta')

# 时间切分
print('\n时间切分稳定性 (前半/后半):')
for k in ['BTCUSDT' if 'BTCUSDT' in D else list(D.keys())[0]]+list(D.keys())[:4]:
    v=D[k]; n=len(v); h1=n//2
    r1,_=bracket2(v['open'].values[:h1],v['high'].values[:h1],v['low'].values[:h1],v['close'].values[:h1],vwap_tr(v)[:h1],S,R)
    r2,_=bracket2(v['open'].values[h1:],v['high'].values[h1:],v['low'].values[h1:],v['close'].values[h1:],vwap_tr(v)[h1:],S,R)
    print(f'  {k:10s} 前半E={r1.mean()-cost_R:+.4f}(n={len(r1)})  后半E={r2.mean()-cost_R:+.4f}(n={len(r2)})')
