"""
经营效率 = 在 E≈0 的前提下, 让"同样的毛波动"留下更多净值
三条通路:  1)成本  2)换手(次数)  3)滑点(执行)
公式:  账户净期望 = N × (E_gross_per_trade) - N × cost - N × slippage + N²×0(无关)
关键: E_gross≈0 时, 净值损耗 = N × (cost+slip)  -> 与 N 成正比
      所以"效率"= 用最少的 N 拿到同样的暴露, 或同样的 N 付更少的费
"""
import numpy as np, pandas as pd, sys
sys.path.insert(0,'/data/workspace/coin')
from eng import bracket2
from coin import load
R=2.0
def sig_vwap168(d):
    tp=(d['high'].values+d['low'].values+d['close'].values)/3
    ref=pd.Series(tp).rolling(168,min_periods=168).mean().values
    return np.nan_to_num(np.sign(d['close'].values-ref))
def sig_bh(d): return np.ones(len(d))
D=load()
def build(s,nm,cb):
    trs=[]
    for sym,v in D.items():
        sg=sig_bh(v) if nm=='BH' else np.concatenate([[0.0],sig_vwap168(v)[:-1]])
        t,_=bracket2(v['open'].values,v['high'].values,v['low'].values,v['close'].values,sg,s,R,slip_bp=0.0)
        trs.append(t)
    x=np.concatenate(trs); return x-2*cb/(s*1e4)

print('='*100)
print('经营效率三条通路: 单位暴露的"年化损耗" = 交易次数 x 单次成本')
print('='*100)
rows=[]
for nm in ['vwap_tr168','BH']:
    for s in [0.02,0.05,0.08]:
        x0=build(s,nm,0.0)   # 毛
        for cb in [0.0,2.0,5.0,10.0]:
            x=build(s,nm,cb)
            # 年化: 假设1h数据, 每bar一次机会; 年交易次数按实际bar数/持仓bar数估算
            n_bar=sum(len(v) for v in D.values())
            avg_hold=max(len(x)/max(1,n_bar),1e-9)
            N_yr=n_bar/ (8760*len(D)) * len(D) / max(avg_hold,1e-6)
            rows.append(dict(signal=nm,stop=f'{s*100:.0f}%',cost_bp=cb,
                             n=len(x),E_net=x.mean(),E_gross=x0.mean(),
                             loss_per_trade=(x0.mean()-x.mean()),
                             total_loss_est=(x0.mean()-x.mean())*len(x)))
df=pd.DataFrame(rows)
for nm in ['vwap_tr168','BH']:
    d=df[df.signal==nm]
    print('\n### %s ###'%nm)
    print(d.to_string(index=False,float_format=lambda z:'%9.4f'%z))

print('\n'+'='*100)
print('通路1 成本: 单次损耗 = cost_R = 2*cost_bp/(stop*1e4)')
print('='*100)
print('通路1 成本: 单次损耗 cost_R = 2*cost_bp/(stop*1e4)')
print('='*100)
print('  stop=2pct : maker2bp->%.4f   taker10bp->%.4f'%(2*2/(0.02*1e4),2*10/(0.02*1e4)))
print('  stop=5pct : maker2bp->%.4f   taker10bp->%.4f'%(2*2/(0.05*1e4),2*10/(0.05*1e4)))
print('  stop=8pct : maker2bp->%.4f   taker10bp->%.4f'%(2*2/(0.08*1e4),2*10/(0.08*1e4)))
print('')
print('  止损从2pct放到8pct, 单次损耗降为 1/4 (成本通路)')
print('  但止损越宽 -> 单笔风险越大 -> 需更小仓位 -> 部分抵消')

print('')
print('='*100)
print('通路2 换手: E_gross=0 时, 总损耗 = N x (cost+slip)')
print('='*100)
for N in [100,300,1000,3000,10000]:
    for cb in [2.0,10.0]:
        for st in [0.02,0.05]:
            cr=2*cb/(st*1e4)
            print('  N=%5d cost=%4.1fbp stop=%.0fpct -> 总损耗 %+8.1f R = 本金的 %.2f 倍'%(
                N,cb,st*100, -N*cr, -N*cr*0.01))
print('')
print('  结论: N 与损耗线性相关。E=0 时, 少交易 = 直接省钱')
