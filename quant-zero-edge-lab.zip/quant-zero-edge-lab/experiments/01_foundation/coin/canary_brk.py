import numpy as np, pandas as pd, sys
sys.path.insert(0,'/data/workspace/coin')
from coin import load
D=load(); KEYS=list(D.keys())
def sig_brk(d,w):
    h,l=d['high'].values,d['low'].values
    hh=np.concatenate([[np.nan],pd.Series(h).rolling(w,min_periods=w).max().values[:-1]])
    ll=np.concatenate([[np.nan],pd.Series(l).rolling(w,min_periods=w).min().values[:-1]])
    return np.nan_to_num(np.where(h>hh,1.,np.where(l<ll,-1.,0.)))
def sig_cheat(d):  # 负对照: 故意用未来收益
    c=d['close'].values; f=np.concatenate([c[10:],c[-10:]])-c
    return np.sign(np.concatenate([f[1:],[0.]]))
print('='*100); print('canary 前视探测: 打乱 t 之后的数据, 看 signal[:t] 是否改变'); print('='*100)
for nm,fn in [('brk500',lambda d: sig_brk(d,500)),('cheat',sig_cheat)]:
    bad=0
    for k in KEYS[:6]:
        v=D[k].copy(); n=len(v)
        if nm=='cheat': v=v.iloc[:3000].reset_index(drop=True)
        s0=fn(v)
        t=len(v)//2
        v2=v.copy()
        rng=np.random.default_rng(0)
        for col in ['open','high','low','close']:
            a=v2[col].values.copy(); a[t:]=a[t:][::-1]*rng.uniform(0.9,1.1,size=n-t); v2[col]=a
        s1=fn(v2)
        L=min(len(s0),len(s1))
        chg=np.abs(s0[:t]-s1[:t]).sum()
        if chg>1e-9: bad+=1
    print('  %-8s 被判前视: %d/6  -> %s'%(nm,bad,'FAIL(有前视)' if (nm=='cheat' and bad) or (nm!='cheat' and bad) else 'PASS'))
print('\n判据: cheat(负对照)必须被抓到; brk500 必须干净')
