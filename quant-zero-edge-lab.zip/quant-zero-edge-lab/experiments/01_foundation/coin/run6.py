import numpy as np, pandas as pd, sys
sys.path.insert(0, '/data/workspace/coin')
from eng import bracket2
from coin import coin_sig, load

D = load()
S, R = 0.05, 2.0

print('=' * 100)
print('验证1：障碍几何 —— 证明 44% 是"赚100% vs 亏80%"不对称白送的，不是能力')
print('=' * 100)
trs = []
for sd in range(8):
    for k, v in D.items():
        rng = np.random.default_rng(sd * 100 + abs(hash(k)) % 997)
        t, _ = bracket2(v['open'].values, v['high'].values, v['low'].values,
                        v['close'].values, coin_sig(len(v), 20, 240, rng), S, R)
        trs.append(t)
tr = np.concatenate(trs)
n = len(tr)
se = tr.std(ddof=1) / np.sqrt(n)
lo = tr.mean() - 1.96 * se
hi = tr.mean() + 1.96 * se
print('抛硬币大样本: n=%d  毛E=%+.5f R  (理论0)  SE=%.5f' % (n, tr.mean(), se))
print('95%%CI = [%+.4f, %+.4f]  -> 包含0 => 鞅性成立' % (lo, hi))


def sym(x, bust_frac, up_frac, f, n_path=4000, seed=5, nt=8000):
    rng = np.random.default_rng(seed)
    nblk = int(np.ceil(nt / 50))
    nb = int(np.ceil(len(x) / 50))
    C0 = 10000.0
    bet = f * C0
    wins = []
    for _ in range(n_path):
        pick = rng.choice(nb, size=nblk, replace=True)
        seq = np.concatenate([x[p * 50:(p + 1) * 50] for p in pick])[:nt]
        W = C0 * 1.0
        done = 0
        for r in seq:
            W = W + bet * r
            if W >= (1 + up_frac) * C0:
                wins.append(1)
                done = 1
                break
            if W <= bust_frac * C0:
                wins.append(0)
                done = 1
                break
        if not done:
            wins.append(0)
    return float(np.mean(wins))


print('')
print('障碍几何 (抛硬币 E约0, f=2%):')
cases = [(0.2, 1.0, '亏80% vs 赚100%  [你的设定]'),
         (0.0, 1.0, '亏100% vs 赚100% [完全对称]'),
         (0.5, 1.0, '亏50%  vs 赚100%'),
         (0.2, 0.5, '亏80%  vs 赚50%'),
         (0.2, 2.0, '亏80%  vs 赚200%')]
for (b, u, tag) in cases:
    p = sym(tr, b, u, 0.02)
    th = (1 - b) / (1 - b + u)
    print('  %-28s 实测P=%5.1f%%   理论 (1-b)/(1-b+u) = %5.1f%%' % (tag, p * 100, th * 100))

print('')
print('=' * 100)
print('验证2：成本单调吞噬 P (f=2%, 障碍 亏80% vs 赚100%)')
print('=' * 100)
rows = []
for cb in [0.0, 0.5, 1.0, 2.0, 3.0, 5.0, 10.0]:
    x = tr - 2 * cb / (S * 1e4)
    rows.append(dict(cost_bp=cb, E=x.mean(), P=sym(x, 0.2, 1.0, 0.02, n_path=3000, seed=9)))
d = pd.DataFrame(rows)
print(d.to_string(index=False, float_format=lambda x: '%10.4f' % x))
d.to_csv('/data/workspace/coin/step6.csv', index=False)
