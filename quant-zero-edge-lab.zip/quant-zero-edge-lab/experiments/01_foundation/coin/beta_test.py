"""
决定性: brk大窗口的Δp 是真方向能力 还是 牛市beta?
1) 多空分解 (long vs short)
2) 反向信号 (fade) 是否亏钱
3) 暴露匹配买入持有 对照
"""
import numpy as np, pandas as pd, sys
sys.path.insert(0,'/data/workspace/coin')
from eng import bracket2
from coin import load
STOP=0.05; R=2.0; theo=1/(1+R)
D=load(); KEYS=list(D.keys())
def sig_brk(d,w):
    h,l=d['high'].values,d['low'].values
    hh=np.concatenate([[np.nan],pd.Series(h).rolling(w,min_periods=w).max().values[:-1]])
    ll=np.concatenate([[np.nan],pd.Series(l).rolling(w,min_periods=w).min().values[:-1]])
    return np.nan_to_num(np.where(h>hh,1.,np.where(l<ll,-1.,0.)))
def run(d,w,R=R,mode='both'):
    sg=np.concatenate([[0.0],sig_brk(d,w)[:-1]])
    if mode=='long': sg=np.where(sg>0,1.,0.)
    elif mode=='short': sg=np.where(sg<0,-1.,0.)
    elif mode=='fade': sg=-sg
    elif mode=='bh': sg=np.ones(len(sg))
    return bracket2(d['open'].values,d['high'].values,d['low'].values,d['close'].values,sg,STOP,R,slip_bp=0.0)[0]
def dp(x):
    if len(x)<50: return np.nan,np.nan
    p=(x>0).mean(); se=np.sqrt(theo*(1-theo)/len(x)); return (p-theo)*100,(p-theo)/se
print('='*108)
print('beta检验: long / short / fade / BH  (Δp 与 净E)')
print('='*108)
print('%-8s %-7s %6s %9s %7s %9s'%('window','mode','n','Δp pp','z','净E'))
for w in [150,200,300,500]:
    for mode in ['long','short','both','fade','bh']:
        x=np.concatenate([run(D[k],w,mode=mode) for k in KEYS]); d,z=dp(x)
        print('brk%-5d %-7s %6d %+9.2f %+7.2f %+9.4f'%(w,mode,len(x),d,z,x.mean()-0.008))
    print('-'*108)
    sys.stdout.flush()
print('\n判据: 若 long>>0 而 short<=0 -> 牛市beta; 若 long>0 且 short>0 -> 真方向能力')
print('      若 fade<0 -> 与信号一致(支持真信号); 若 fade>0 -> 反转更优')
