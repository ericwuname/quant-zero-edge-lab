"""
路线A可行域: 成本(cost_bp) x 止损宽度(s)  ->  E 与 中位数
核心链条: 成本↓ -> 可用止损↑(穿透↓) -> E↑ -> 中位数↑ -> 路线A成立
判据用中位数(典型路径), 不用P(被障碍几何决定)
"""
import numpy as np, pandas as pd, sys
sys.path.insert(0,'/data/workspace/coin')
from eng import bracket2
from coin import load

R=2.0
def sig_vwap168(d):
    tp=(d['high'].values+d['low'].values+d['close'].values)/3
    ref=pd.Series(tp).rolling(168,min_periods=168).mean().values
    return np.nan_to_num(np.sign(d['close'].values-ref))
def sig_brk50(d):
    h,l=d['high'].values,d['low'].values
    hh=np.concatenate([[np.nan],pd.Series(h).rolling(50,min_periods=50).max().values[:-1]])
    ll=np.concatenate([[np.nan],pd.Series(l).rolling(50,min_periods=50).min().values[:-1]])
    return np.nan_to_num(np.where(h>hh,1.0,np.where(l<ll,-1.0,0.0)))
SIGS={'vwap_tr168':sig_vwap168,'brk50':sig_brk50}

D=load()
# 降采样以提速: 每品种最多3万根
DATA={k:v.iloc[-30000:].reset_index(drop=True) for k,v in D.items()}

def build(s,nm):
    trs=[]
    for sym,v in DATA.items():
        sg=np.concatenate([[0.0],SIGS[nm](v)[:-1]])
        t,_=bracket2(v['open'].values,v['high'].values,v['low'].values,v['close'].values,sg,s,R)
        trs.append(t)
    return np.concatenate(trs)

def harvest_med(x,f,T=1.0,bust=0.2,C0=10000.0,n_path=800,block=50,seed=7,max_n=5000):
    rng=np.random.default_rng(seed); n=len(x); nb=int(np.ceil(n/block)); nblk=int(np.ceil(max_n/block))
    ps=[];ws=[]
    for _ in range(n_path):
        pick=rng.choice(nb,size=nblk,replace=True)
        seq=np.concatenate([x[p*block:(p+1)*block] for p in pick])[:max_n]
        bet=f*C0;W=C0;ext=0.0;done=0
        for r in seq:
            W+=bet*r
            if W>=(1+T)*C0:
                ext+=W-C0;W=C0
                if ext>=C0: ps.append(ext+W-C0);ws.append(1);done=1;break
            if W<=bust*C0:
                ps.append(ext+W-C0);ws.append(1 if ext>=C0 else 0);done=1;break
        if not done: ps.append(ext+W-C0);ws.append(1 if ext>=C0 else 0)
    return float(np.median(ps)),float(np.mean(ws))

rows=[]
for nm in SIGS:
    for s in [0.008,0.015,0.03,0.05,0.08]:
        x=build(s,nm)
        for cb in [0.0,2.0,5.0,10.0]:
            cr=2*cb/(s*1e4)
            xn=x-cr
            f=0.01 if xn.mean()>0 else 0.03
            med,P=harvest_med(xn,f)
            rows.append(dict(signal=nm,stop=f'{s*100:.1f}%',cost_bp=cb,cost_R=cr,
                             E=xn.mean(),med=med,P=P,
                             ok='✓可行' if (med>0 and xn.mean()>0) else '✗'))
df=pd.DataFrame(rows)
print('='*116)
print('路线A可行域: 成本 x 止损宽度   (判据: 中位数>0 且 E>0)')
print('='*116)
for nm in SIGS:
    d=df[df.signal==nm]
    print('\n### %s ###'%nm)
    print(d.pivot_table(index='stop',columns='cost_bp',values='E').to_string(float_format=lambda x:'%8.4f'%x))
    print('  -- 中位数(典型路径盈亏) --')
    print(d.pivot_table(index='stop',columns='cost_bp',values='med').to_string(float_format=lambda x:'%8.0f'%x))
    sys.stdout.flush()
print('\n'+'='*116)
print('可行(中位数>0且E>0)的组合:')
ok=df[(df.med>0)&(df.E>0)]
print(ok.to_string(index=False,float_format=lambda x:'%9.4f'%x) if len(ok) else '  无 —— 在测试范围内没有任何组合可行')
