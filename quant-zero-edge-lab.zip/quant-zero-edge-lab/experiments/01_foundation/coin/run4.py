"""最终对比：抛硬币 vs 真实信号(vwap_tr168) vs 零期望 —— 同一引擎/同一收割制"""
import numpy as np, pandas as pd, glob, os, sys
sys.path.insert(0,'/data/workspace/coin')
from eng import bracket2
from harvest import sim
from coin import coin_sig

def load():
    out={}
    for p in sorted(glob.glob('/data/inputs/*_1h.csv')):
        nm=os.path.basename(p).replace('_1h.csv','')
        d=pd.read_csv(p); cols={c.lower():c for c in d.columns}
        need=('open','high','low','close','volume')
        if not all(k in cols for k in need): continue
        d=d[[cols[k] for k in need]].copy(); d.columns=list(need)
        d=d.dropna().astype(float)
        d=d[(d['open']>0)&(d['high']>0)&(d['low']>0)&(d['close']>0)]
        if len(d)<5000: continue
        out[nm]=d.reset_index(drop=True)
    return out

def vwap_tr(df,w=168):
    h=df['high'].values;l=df['low'].values;c=df['close'].values;v=df['volume'].values
    tp=(h+l+c)/3.0
    num=pd.Series(tp*v).rolling(w,min_periods=w).sum().values
    den=pd.Series(v).rolling(w,min_periods=w).sum().values
    vw=np.where(den>0,num/np.where(den==0,1,den),np.nan)
    s=np.sign(c-vw); s=np.nan_to_num(s,nan=0.0)
    s=pd.Series(s).replace(0.0,np.nan).ffill().fillna(0.0).values
    return np.concatenate([[0.0],s[:-1]])       # shift(1): 只用 bar<=i-1

D=load(); print('symbols:',len(D))
S,R,CB=0.05,2.0,2.0
cost_R=2*CB/(S*1e4)

def seqs_for(seed=0):
    coin=[]; vwap=[]
    for k,v in D.items():
        rng=np.random.default_rng(seed+abs(hash(k))%10000)
        t,_=bracket2(v['open'].values,v['high'].values,v['low'].values,v['close'].values,
                     coin_sig(len(v),20,240,rng),S,R)
        coin.append(t)
        t2,_=bracket2(v['open'].values,v['high'].values,v['low'].values,v['close'].values,
                      vwap_tr(v),S,R)
        vwap.append(t2)
    coin=np.concatenate(coin)-cost_R; vwap=np.concatenate(vwap)-cost_R
    return coin,vwap

coin,vwap=seqs_for(0)
print(f'\n抛硬币   : n={len(coin):5d}  E={coin.mean():+.4f}R  sd={coin.std(ddof=1):.3f}  年≈{len(coin)/5.5:.0f}笔')
print(f'vwap_tr168: n={len(vwap):5d}  E={vwap.mean():+.4f}R  sd={vwap.std(ddof=1):.3f}  年≈{len(vwap)/5.5:.0f}笔')

print('\n'+'='*104)
print('最终对比：不复利固定注 + 翻倍即收割 + 20%爆仓线   (本金1万, maker 2bp, bootstrap 8000笔)')
print('='*104)
rows=[]
for f in [0.01,0.02,0.03,0.05]:
    zc=coin-coin.mean(); zv=vwap-vwap.mean()
    a=sim(coin,f,T=1.0,n_path=3000,seed=7,n_target=8000)
    b=sim(vwap,f,T=1.0,n_path=3000,seed=7,n_target=8000)
    c=sim(zc ,f,T=1.0,n_path=3000,seed=7,n_target=8000)
    rows.append(dict(f=f,
        P_coin=a['P'],P_vwap=b['P'],P_zero=c['P'],
        gain_pp=(b['P']-a['P'])*100,
        pnl_coin=a['pnl_med'],pnl_vwap=b['pnl_med'],
        bust_coin=a['bust'],bust_vwap=b['bust'],
        nb_vwap=b['nb_med'],yrs=b['nb_med']/(len(vwap)/5.5)))
df=pd.DataFrame(rows)
print(df.to_string(index=False,float_format=lambda x:f'{x:10.2f}'))
print('\ngain_pp = vwap真实信号 相对 抛硬币 的成功率提升(百分点) = edge的真实价值')
df.to_csv('/data/workspace/coin/final.csv',index=False)
