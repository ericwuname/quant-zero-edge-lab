import numpy as np, pandas as pd, sys
sys.path.insert(0,'/data/workspace/coin')
from coin import load, coin_sig
from eng import bracket2
from harvest import sim
D=load()
def get_seq(s,R,gap,seed,cb):
    trs=[]
    for k,v in D.items():
        rng=np.random.default_rng(seed+abs(hash(k))%10000)
        sig=coin_sig(len(v),gap[0],gap[1],rng)
        tr,ty=bracket2(v['open'].values,v['high'].values,v['low'].values,v['close'].values,sig,s,R)
        trs.append(tr)
    return np.concatenate(trs)-2*cb/(s*1e4)

base=get_seq(0.05,2.0,(20,240),0,2.0)
zero = base-base.mean()          # 零期望对照：同方差同分布，E 精确为 0
print('='*104)
print('第3步：修正后 · 抛硬币收割制 (本金1万, 固定注, 翻倍即收割, 20%爆仓线, bootstrap延长至8000笔)')
print('='*104)
print(f'实际序列: n={len(base)} E={base.mean():+.4f}R sd={base.std(ddof=1):.3f}  (年≈{len(base)/5.5:.0f}笔)')
print(f'零期望对照: E={zero.mean():+.6f}R  (用于分离"障碍几何白送"的部分)')
print('\n理论: 连续随机游走双障碍[0.2C0,2C0], P(先到2倍)=0.8/1.8=44.4%')

rows=[]
for f in [0.005,0.01,0.02,0.03,0.05,0.08]:
    a=sim(base,f,T=1.0,n_path=3000,seed=1,n_target=8000)
    b=sim(zero,f,T=1.0,n_path=3000,seed=1,n_target=8000)
    rows.append(dict(f=f,P=a['P'],P_zero=b['P'],edge_pp=(a['P']-b['P'])*100,
        pnl_med=a['pnl_med'],pnl_mean=a['pnl_mean'],bust=a['bust'],
        nb=a['nb_med'],yrs=a['nb_med']/(len(base)/5.5)))
df=pd.DataFrame(rows)
print('\n--- 仓位扫描 (T=100%, maker 2bp, 序列延长至8000笔) ---')
print(df.to_string(index=False,float_format=lambda x:f'{x:10.2f}'))
print('\nP_zero = 零期望时的成功率(纯几何白送)   edge_pp = 真实edge贡献的百分点')

print('\n--- 成本敏感性 (f=2%) ---')
rows=[]
for cb in [0.0,1.0,2.0,5.0,10.0]:
    s_=get_seq(0.05,2.0,(20,240),0,cb); z=s_-s_.mean()
    a=sim(s_,0.02,T=1.0,n_path=3000,seed=3,n_target=8000)
    b=sim(z,0.02,T=1.0,n_path=3000,seed=3,n_target=8000)
    rows.append(dict(cost_bp=cb,E=s_.mean(),P=a['P'],P_zero=b['P'],
                     pnl_med=a['pnl_med'],bust=a['bust']))
print(pd.DataFrame(rows).to_string(index=False,float_format=lambda x:f'{x:10.4f}'))
df.to_csv('/data/workspace/coin/step3.csv',index=False)
