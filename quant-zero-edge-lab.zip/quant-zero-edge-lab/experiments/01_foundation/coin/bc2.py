"""
经营效率 = 净断层成本 = 收手续费 - 付返佣
量化: 对每笔交易, 计算 maker可成交性 与 混合成本
"""
import numpy as np, pandas as pd, sys
sys.path.insert(0,'/data/workspace/coin')
from eng import bracket2
from coin import load
R=2.0
def sig_vwap168(d):
    tp=(d['high'].values+d['low'].values+d['close'].values)/3
    ref=pd.Series(tp).rolling(168,min_periods=168).mean().values
    return np.nan_to_num(np.sign(d['close'].values-ref))
def sig_bh(d): return np.ones(len(d))
D=load()
print('='*100)
print('经营效率 = 净断层成本: 收手续费 - 付返佣')
print('='*100)
# 分析每笔交易的持仓时长与换手率
for nm,fn in [('vwap_tr168',sig_vwap168),('BH',sig_bh)]:
    for s in [0.02,0.05]:
        holds=[]; n_tr=0; n_bar=0
        for sym,v in D.items():
            o,h,l,c=v['open'].values,v['high'].values,v['low'].values,v['close'].values
            sg=np.concatenate([[0.0],fn(v)[:-1]])
            t,ty=bracket2(o,h,l,c,sg,s,R,slip_bp=0.0)
            holds.append(t); n_tr+=len(t); n_bar+=len(v)
        x=np.concatenate(holds)
        # 年化换手次数 = 总交易数/(总bar数) * 8760/持仓时长中位数
        medhold=5.0  # 粗估
        yr_trades = n_tr/n_bar*8760
        print('%s stop=%.0f%%: 交易%d笔 年化%.0f次 换手率%.1f%%'%(
            nm,s*100,n_tr,yr_trades, yr_trades*2*100/8760))
print('')
print('单次成本测算 (往返):')
for cb in [2.0,10.0]:
    for s in [0.02,0.05]:
        cr=2*cb/(s*1e4)
        print('  cost=%.1fbp stop=%.0f%% -> cost_R=%.4f  年换手1000次损耗=%.1fR'%(cb,s*100,cr,1000*cr))
