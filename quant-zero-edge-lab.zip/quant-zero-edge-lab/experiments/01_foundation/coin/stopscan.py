"""
止损宽度扫描 —— 用"相对bar振幅倍数"(技术位置逻辑)代替固定百分比
分解两个效应：
  手续费效应: cost_R = 2*cost_bp/(s*1e4)   s↑ -> cost_R↓  (省手续费)
  穿透效应  : s↓ -> 单根bar穿越整个止损止盈区间 -> 保守判定全记亏损
两个效应都指向 s 应宽，扫描找最优点 + 验证引擎(coin基准应趋近 -cost_R)
"""
import numpy as np, pandas as pd, sys
sys.path.insert(0,'/data/workspace/coin')
from eng import bracket2
from coin import load

R=2.0
def coin_sig2(n,gap_lo,gap_hi,rng):
    sig=np.zeros(n); i=100
    while i<n-1:
        sig[i]=float(rng.choice([-1.0,1.0])); i+=int(rng.integers(gap_lo,gap_hi+1))
    return sig

def sig_vwap168(d):
    tp=(d['high'].values+d['low'].values+d['close'].values)/3
    if 'volume' in d.columns:
        vv=d['volume'].values
        num=pd.Series(tp*vv).rolling(168,min_periods=168).sum().values
        den=pd.Series(vv).rolling(168,min_periods=168).sum().values
        ref=np.where(den>0,num/np.maximum(den,1e-12),np.nan)
    else:
        ref=pd.Series(tp).rolling(168,min_periods=168).mean().values
    return np.nan_to_num(np.sign(d['close'].values-ref))

def sig_brk50(d):
    h,l=d['high'].values,d['low'].values
    hh_p=np.concatenate([[np.nan],pd.Series(h).rolling(50,min_periods=50).max().values[:-1]])
    ll_p=np.concatenate([[np.nan],pd.Series(l).rolling(50,min_periods=50).min().values[:-1]])
    return np.nan_to_num(np.where(h>hh_p,1.0,np.where(l<ll_p,-1.0,0.0)))

def sig_bh(d): return np.ones(len(d))

SIGS={'coin(零期望基准)':None,'vwap_tr168':sig_vwap168,'brk50':sig_brk50,'BH(持有)':sig_bh}

def run(k_mult, nm, cb, nseed=1):
    """止损 = k_mult × 该品种bar振幅中位数 (技术位置逻辑)"""
    D=load(); trs=[]; crs=[]
    for sd in range(nseed):
        for sym,v in D.items():
            o=v['open'].values; h=v['high'].values; l=v['low'].values; c=v['close'].values
            amp=np.median((h-l)/o)              # 该品种单根bar振幅中位数
            s=float(np.clip(k_mult*amp,0.002,0.30))
            if nm=='coin(零期望基准)':
                rng=np.random.default_rng(sd*137+abs(hash(sym))%997)
                sg=coin_sig2(len(v),20,240,rng)
            else:
                sg=np.concatenate([[0.0],SIGS[nm](v)[:-1]])   # 消除off-by-one前视
            t,_=bracket2(o,h,l,c,sg,s,R)
            if len(t)<20: continue
            trs.append(t)
            crs.append(np.full(len(t), 2*cb/(s*1e4)))
    x=np.concatenate(trs); cr=np.concatenate(crs)
    gross=x.mean(); cost=cr.mean()
    return dict(k=k_mult, n=len(x), E_gross=gross, cost_R=cost,
                E_net=gross-cost,
                t=(gross-cost)/ (x-cr).std(ddof=1)*np.sqrt(len(x)))

if __name__=='__main__':
    D=load()
    amps={sym:float(np.median((v['high'].values-v['low'].values)/v['open'].values)) for sym,v in D.items()}
    print('='*100)
    print('各品种单根bar振幅中位数:')
    print('  '+'  '.join('%s=%.2f%%'%(k,v*100) for k,v in sorted(amps.items())))
    print('  全样本中位 %.2f%%'%(np.median(list(amps.values()))*100))
    print('='*100)
    print('\n止损 = k × 品种bar振幅中位数  (技术位置逻辑, 每品种止损%不同但相对风险一致)')
    print('='*100)
    for cb,cn in [(2.0,'maker2bp'),(10.0,'taker10bp')]:
        print('\n### %s ###'%cn); sys.stdout.flush()
        rows=[]
        for k in [1.0,1.5,2.0,3.0,5.0,8.0,12.0]:
            for nm in SIGS:
                r=run(k,nm,cb)
                r['signal']=nm; rows.append(r)
        df=pd.DataFrame(rows)[['k','signal','n','E_gross','cost_R','E_net','t']]
        piv=df.pivot_table(index='k',columns='signal',values='E_net')
        print('\n-- 净E_net 透视 (行=k倍bar振幅, 列=信号) --')
        print(piv.to_string(float_format=lambda x:'%8.4f'%x))
        print('\n-- 明细 (cost_R 与 毛E 分解) --')
        print(df.to_string(index=False,float_format=lambda x:'%9.4f'%x))
        sys.stdout.flush()
