import numpy as np
rng=np.random.default_rng(0)
n=52957
i=int(rng.integers(100,n-100)); print('起点',i)
gaps=[]
cnt=0
while i<n-1:
    cnt+=1
    g=int(rng.integers(20,241)); gaps.append(g)
    i+=g
print('点数',cnt,'平均间隔',np.mean(gaps),'最大',max(gaps),'最小',min(gaps))
print('间隔前10',gaps[:10])
