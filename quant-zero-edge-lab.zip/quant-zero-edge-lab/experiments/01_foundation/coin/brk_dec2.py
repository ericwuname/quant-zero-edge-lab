import numpy as np, pandas as pd, sys, pickle, os
sys.path.insert(0,'/data/workspace/coin')
from eng import bracket2
from coin import load
STOP=0.05; D=load(); KEYS=list(D.keys())
NEW6={'TRXUSDT','UNIUSDT','XLMUSDT','XMRUSDT','XRPUSDT','ZECUSDT'}
def sig_brk(d,w):
    h,l=d['high'].values,d['low'].values
    hh=np.concatenate([[np.nan],pd.Series(h).rolling(w,min_periods=w).max().values[:-1]])
    ll=np.concatenate([[np.nan],pd.Series(l).rolling(w,min_periods=w).min().values[:-1]])
    return np.nan_to_num(np.where(h>hh,1.,np.where(l<ll,-1.,0.)))
def run(d,w,R,flip=False,mode='both'):
    sg=np.concatenate([[0.0],sig_brk(d,w)[:-1]])
    if mode=='long': sg=np.where(sg>0,1.,0.)
    elif mode=='short': sg=np.where(sg<0,-1.,0.)
    if flip: sg=-sg
    return bracket2(d['open'].values,d['high'].values,d['low'].values,d['close'].values,sg,STOP,R,slip_bp=0.0)[0]
WS=[20,30,50,80,120,200]; RS=[1.0,2.0,3.0,5.0]
CACHE='/data/workspace/coin/cache_brk.pkl'
if os.path.exists(CACHE):
    C=pickle.load(open(CACHE,'rb'))
else:
    C={}
    for w in WS:
        for R in RS:
            for k in KEYS:
                C[(w,R,k,0)]=run(D[k],w,R,flip=False)
                C[(w,R,k,1)]=run(D[k],w,R,flip=True)
            print('built w=%d R=%.0f'%(w,R)); sys.stdout.flush()
    pickle.dump(C,open(CACHE,'wb'))
def dp(x,R):
    if len(x)<50: return np.nan,np.nan
    theo=1/(1+R); p=(x>0).mean(); se=np.sqrt(theo*(1-theo)/len(x)); return (p-theo)*100,(p-theo)/se
def pool(w,R,flips):
    return np.concatenate([C[(w,R,k,flips[i])] for i,k in enumerate(KEYS)])

print('\n'+'='*100); print('[1] Reality Check over 24-combo grid'); print('='*100)
real={}
for w in WS:
    for R in RS:
        real[(w,R)]=dp(pool(w,R,[0]*len(KEYS)),R)
mx=max(real.items(),key=lambda kv:kv[1][1])
print('  真实最强 brk%d R=%.0f: Δp=%+.2fpp z=%+.2f'%(mx[0][0],mx[0][1],mx[1][0],mx[1][1]))
rng=np.random.default_rng(7); NB=300; mxz=[]
for b in range(NB):
    fl=[int(rng.integers(2)) for _ in KEYS]; best=-9
    for w in WS:
        for R in RS:
            d,z=dp(pool(w,R,fl),R)
            if not np.isnan(z) and z>best: best=z
    mxz.append(best)
mxz=np.array(mxz)
print('  零分布max z: mean%+.2f p95%+.2f p99%+.2f'%(mxz.mean(),np.percentile(mxz,95),np.percentile(mxz,99)))
print('  RC p = %.3f -> %s'%((mxz>=mx[1][1]).mean(),'SIG' if (mxz>=mx[1][1]).mean()<0.05 else 'NOT SIG'))

print('\n'+'='*100); print('[2] brk200 R=2 per symbol'); print('='*100)
tot=[]
for k in KEYS:
    x=C[(200,2.0,k,0)]; d,z=dp(x,2.0); tot.append(x)
    print('  %-9s %-5s n=%5d Δp=%+6.2fpp z=%+5.2f netE=%+.4f'%(k,'NEW6'if k in NEW6 else 'OLD7',len(x),d,z,x.mean()-0.008))
xa=np.concatenate(tot); print('  TOTAL n=%d Δp=%+.2f z=%+.2f'%(len(xa),*dp(xa,2.0)))

print('\n'+'='*100); print('[3] long/short decomposition (beta test)'); print('='*100)
for mode in ['long','short','both']:
    x=np.concatenate([run(D[k],200,2.0,mode=mode) for k in KEYS]); d,z=dp(x,2.0)
    print('  %-6s n=%5d Δp=%+6.2fpp z=%+5.2f netE=%+.4f'%(mode,len(x),d,z,x.mean()-0.008))

print('\n'+'='*100); print('[4] cost sensitivity brk200 R=2'); print('='*100)
g=np.concatenate([C[(200,2.0,k,0)] for k in KEYS]).mean()
print('  毛E=%+.4f'%g)
for cb in [0,1,2,5,10,20]:
    cr=2*cb/(STOP*1e4); print('  %4.1fbp cost_R=%.4f netE=%+.4f %s'%(cb,cr,g-cr,'POS' if g>cr else 'NEG'))
