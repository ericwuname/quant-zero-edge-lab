"""
抛硬币实验 —— 结构贡献的精确对照
理论：随机方向 + 固定止损止盈(R=2) 在无漂移下 E=0（可选停时定理）
      P(先触止盈) = 1/(1+R) = 1/3
目的：量化"不复利 + 盈余公积(翻倍即收割)"这套机制本身能产生什么
"""
import numpy as np, pandas as pd, glob, os, sys, pickle

DATA='/data/inputs'
NEW6 = {'TRX','UNI','XLM','XMR','XRP','ZEC'}
OLD7 = {'CRV','DASH','DOGE','DOT','ETH','FIL','HBAR'}

def load():
    out={}
    for p in sorted(glob.glob(DATA+'/*_1h.csv')):
        nm=os.path.basename(p).replace('_1h.csv','')
        d=pd.read_csv(p)
        cols={c.lower():c for c in d.columns}
        if not all(k in cols for k in ('open','high','low','close')): continue
        d=d[[cols[k] for k in ('open','high','low','close')]].copy()
        d.columns=['open','high','low','close']
        d=d.dropna().astype(float)
        d=d[(d['open']>0)&(d['high']>0)&(d['low']>0)&(d['close']>0)]
        if len(d)<5000: continue
        out[nm]=d.reset_index(drop=True)
    return out

def bracket(o,h,l,sig,stop_pct,R,slip_bp=0.0):
    """严格 OHLC 触及；同 bar 双触及判止损先触发(保守)。
    sig[i]!=0 时在 open[i] 建仓（sig 只能依赖 bar<=i-1）。返回 R 倍数序列。"""
    n=len(o); tr=[]; cur=0.0
    for i in range(1,n):
        if cur!=0 and i<n-1:
            if cur>0: hs,ht = l[i]<=cur*0+stop_px, h[i]>=tgt_px
            else:     hs,ht = h[i]>=stop_px, l[i]<=tgt_px
            if hs:
                px=stop_px*(1-np.sign(cur)*slip_bp/1e4)
                tr.append((px-entry)*cur/abs(entry)/stop_pct); cur=0.0
            elif ht:
                tr.append((tgt_px-entry)*cur/abs(entry)/stop_pct); cur=0.0
        if cur==0.0 and sig[i]!=0:
            cur=float(np.sign(sig[i])); entry=o[i]
            stop_px=entry*(1-cur*stop_pct); tgt_px=entry*(1+cur*R*stop_pct)
            if i<n-1:
                if cur>0: hs,ht = l[i]<=stop_px, h[i]>=tgt_px
                else:     hs,ht = h[i]>=stop_px, l[i]<=tgt_px
                if hs:
                    px=stop_px*(1-cur*slip_bp/1e4)
                    tr.append((px-entry)*cur/abs(entry)/stop_pct); cur=0.0
                elif ht:
                    tr.append((tgt_px-entry)*cur/abs(entry)/stop_pct); cur=0.0
    return np.asarray(tr) if tr else np.zeros(0)

def coin_sig(n, gap_lo, gap_hi, rng):
    """随机间隔抛硬币：纯随机，不使用任何价格信息 -> 天然无前视"""
    sig=np.zeros(n); i=int(rng.integers(100,n-100))
    while i<n-1:
        sig[i]=float(rng.choice([-1.0,1.0]))
        i+=int(rng.integers(gap_lo,gap_hi+1))
    return sig

if __name__=='__main__':
    print('loading...'); D=load(); print(len(D),'symbols', sorted(D.keys()))
