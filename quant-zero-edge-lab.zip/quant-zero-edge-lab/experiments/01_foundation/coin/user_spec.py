"""用户规格回测：固定%止损 + 冷却期 + 逐笔 + 限价成本
核心目标：检验"顺势"方向能力中，有多少是真方向能力（多空都行），有多少是 beta（只靠多头）。
无前视保证：signal[i] 只依赖 bar<=i-1，成交在 open[i]。
"""
import numpy as np, pandas as pd, glob, os, pickle, time

DATA = '/data/inputs/'
OLD7 = ['CRV','DASH','DOGE','DOT','ETH','FIL','HBAR']
NEW6 = ['TRX','UNI','XLM','XMR','XRP','ZEC']

def load():
    out = {}
    for f in sorted(glob.glob(DATA + '*_1h.csv')):
        nm = os.path.basename(f).split('_')[0].replace('USDT','')
        try:
            d = pd.read_csv(f)
        except Exception:
            continue
        cols = {c.lower(): c for c in d.columns}
        need = ['open','high','low','close']
        if not all(k in cols for k in need):
            continue
        d = d.rename(columns={cols[k]: k for k in need})
        d = d.dropna(subset=need).reset_index(drop=True)
        out[nm] = d
    return out

# ---------- 信号（基于 bar<=i-1，返回第 i 位用于 open[i] 成交）----------
def _shift(s):
    return s.shift(1)

def sig_ma(d, w=50):
    c = d['close']; return _shift(np.sign(c - c.rolling(w).mean()))

def sig_mom(d, w=20):
    c = d['close']; return _shift(np.sign(c / c.shift(w) - 1))

def sig_pos(d, w=240):
    c = d['close']; hi = c.rolling(w).max(); lo = c.rolling(w).min()
    return _shift(np.sign((c - lo) / (hi - lo + 1e-12) - 0.5))

def sig_vwap(d, w=168):
    c = d['close']
    v = d['volume'] if 'volume' in d.columns else pd.Series(1.0, index=c.index)
    pv = (c * v).rolling(w).sum(); vv = v.rolling(w).sum()
    return _shift(np.sign(c - pv / (vv + 1e-12)))

def sig_macd(d):
    c = d['close']
    e1 = c.ewm(span=12).mean(); e2 = c.ewm(span=26).mean()
    return _shift(np.sign(e1 - e2))

def sig_rsi_trend(d, w=14):
    """RSI>50 做多 = 顺势用法"""
    c = d['close']; dl = c.diff()
    up = dl.clip(lower=0).rolling(w).mean(); dn = (-dl.clip(upper=0)).rolling(w).mean()
    rsi = 100 - 100 / (1 + up / (dn + 1e-12))
    return _shift(np.sign(rsi - 50))

def sig_rev20(d, w=20):
    return -sig_mom(d, w)

def sig_rev240(d, w=240):
    return -sig_mom(d, w)

def sig_rand(d, seed=0):
    n = len(d); rng = np.random.default_rng(seed)
    return pd.Series(np.where(rng.random(n) < 0.5, -1.0, 1.0), index=d.index)

SIGS = {
    'ma50':       lambda d: sig_ma(d, 50),
    'mom20':      lambda d: sig_mom(d, 20),
    'macd':       lambda d: sig_macd(d),
    'pos240':     lambda d: sig_pos(d, 240),
    'vwap168':    lambda d: sig_vwap(d, 168),
    'rsi14_tr':   lambda d: sig_rsi_trend(d, 14),
    'rev20':      lambda d: sig_rev20(d, 20),
    'rev240':     lambda d: sig_rev240(d, 240),
    'rand':       lambda d: sig_rand(d, 0),
}
TREND = ['ma50','mom20','macd','pos240','vwap168','rsi14_tr']
REVERS = ['rev20','rev240']

# ---------- 引擎：逐笔 / 固定%止损止盈 / 冷却期 / 末尾强平 ----------
def run(d, sig, stop_pct, R, cost_bp, cooldown):
    o = d['open'].values.astype(float); h = d['high'].values.astype(float)
    l = d['low'].values.astype(float);   c = d['close'].values.astype(float)
    s = np.nan_to_num(np.asarray(sig, float), nan=0.0)
    n = len(o)
    tr = []; ty = []; sd = []
    cur = 0.0; entry = 0.0; stop_px = 0.0; tgt_px = 0.0
    last_exit = -10**9
    for i in range(1, n):
        closed = False
        if cur != 0:
            if cur > 0:
                hs, ht = l[i] <= stop_px, h[i] >= tgt_px
            else:
                hs, ht = h[i] >= stop_px, l[i] <= tgt_px
            if hs:
                tr.append(-1.0); ty.append('stop'); sd.append(cur)
                cur = 0.0; last_exit = i; closed = True
            elif ht:
                tr.append(R); ty.append('tgt'); sd.append(cur)
                cur = 0.0; last_exit = i; closed = True
            elif i == n - 1:
                r = (c[i] - entry) * cur / entry / stop_pct
                tr.append(r); ty.append('end'); sd.append(cur)
                cur = 0.0; last_exit = i; closed = True
        if cur == 0.0 and (not closed) and (i - last_exit) > cooldown and s[i] != 0 and i < n - 1:
            cur = float(np.sign(s[i])); entry = o[i]
            stop_px = entry * (1 - cur * stop_pct); tgt_px = entry * (1 + cur * R * stop_pct)
            if cur > 0:
                hs, ht = l[i] <= stop_px, h[i] >= tgt_px
            else:
                hs, ht = h[i] >= stop_px, l[i] <= tgt_px
            if hs:
                tr.append(-1.0); ty.append('stop'); sd.append(cur)
                cur = 0.0; last_exit = i
            elif ht:
                tr.append(R); ty.append('tgt'); sd.append(cur)
                cur = 0.0; last_exit = i
    if cur != 0:
        r = (c[-1] - entry) * cur / entry / stop_pct
        tr.append(r); ty.append('end'); sd.append(cur)
    tr = np.array(tr); sd = np.array(sd); ty = np.array(ty)
    if len(tr) == 0:
        return None
    cost_R = 2 * cost_bp / (stop_pct * 1e4)
    net = tr - cost_R
    m = sd > 0
    return dict(
        n=len(tr), gross=float(tr.mean()), net=float(net.mean()),
        win=float((tr > 0).mean()),
        lg=float(tr[m].mean()) if m.sum() > 0 else np.nan,
        sg=float(tr[~m].mean()) if (~m).sum() > 0 else np.nan,
        nl=int(m.sum()), ns=int((~m).sum()),
        endfrac=float((ty == 'end').mean()), cost_R=cost_R,
        tr=tr, sd=sd, ty=ty,
    )

# ---------- canary：验证信号只用历史 ----------
def canary(d, name, fn, probes=(5000, 15000, 25000, 35000, 45000)):
    """用 df[:i] 重算信号最后一位，与原始 sig[i] 对比（应完全一致）"""
    full = fn(d)
    bad = 0; tot = 0
    for i in probes:
        if i >= len(d) - 1:
            continue
        sub = d.iloc[:i + 1].reset_index(drop=True)
        v = fn(sub)
        a = np.nan_to_num(full.iloc[i], nan=0.0); b = np.nan_to_num(v.iloc[-1], nan=0.0)
        tot += 1
        if abs(a - b) > 1e-9:
            bad += 1
    return bad, tot

def main():
    t0 = time.time()
    D = load(); names = sorted(D.keys())
    print(f'品种 {len(names)}: {names}')
    # 成交额排序（活跃度）
    rows = []
    for nm in names:
        d = D[nm]
        if 'volume' in d.columns:
            qv = (d['close'] * d['volume']).mean()
        elif 'quote_volume' in d.columns:
            qv = d['quote_volume'].mean()
        else:
            qv = np.nan
        rows.append((nm, qv))
    qv = pd.DataFrame(rows, columns=['sym','adv']).sort_values('adv', ascending=False)
    print('\n===== 活跃度（平均成交额）排序 =====')
    print(qv.to_string(index=False))
    active = list(qv['sym'][:8])
    print(f'活跃前8: {active}')

    # canary
    print('\n===== canary 前视筛查 =====')
    for nm in ['ma50','macd','rev20','rsi14_tr']:
        bad, tot = canary(D['DOGE'], nm, SIGS[nm])
        print(f'  {nm:10s} 不一致 {bad}/{tot}  {"OK" if bad==0 else "FAIL"}')

    # 预计算信号缓存（避免重复 rolling 计算）
    print('\n预计算信号缓存...')
    cache = {}
    for sym in names:
        for sname, fn in SIGS.items():
            cache[(sym, sname)] = fn(D[sym])
    print('缓存完成')

    out = []
    for sname in list(SIGS.keys()):
        for sp in [0.015, 0.020]:
            for cd in [0, 20]:
                for grp, syms in [('ALL', names), ('OLD7', [x for x in OLD7 if x in D]),
                                  ('NEW6', [x for x in NEW6 if x in D]), ('ACT8', [x for x in active if x in D])]:
                    gs = []; ns = []; ws = []; lgs = []; sgs = []
                    nl = ns_ = 0
                    per = {}
                    for sym in syms:
                        r = run(D[sym], cache[(sym, sname)], sp, 2.0, 2.0, cd)
                        if r is None or r['n'] < 30:
                            continue
                        gs.append(r['gross']); ns.append(r['net']); ws.append(r['win'])
                        lgs.append(r['lg']); sgs.append(r['sg'])
                        nl += r['nl']; ns_ += r['ns']
                        per[sym] = r
                    if not gs:
                        continue
                    gs = np.array(gs); ns = np.array(ns)
                    lgs = np.array(lgs, float); sgs = np.array(sgs, float)
                    ok_l = ~np.isnan(lgs); ok_s = ~np.isnan(sgs)
                    def tstat(x):
                        x = x[~np.isnan(x)]
                        return float(np.mean(x) / (np.std(x, ddof=1) / np.sqrt(len(x)))) if len(x) > 1 and np.std(x, ddof=1) > 0 else np.nan
                    out.append(dict(sig=sname, stop=sp, cool=cd, grp=grp,
                                    gross=float(gs.mean()), net=float(ns.mean()),
                                    t_net=tstat(ns), win=float(np.mean(ws)),
                                    lg=float(np.nanmean(lgs)) if ok_l.any() else np.nan,
                                    sg=float(np.nanmean(sgs)) if ok_s.any() else np.nan,
                                    ls_diff=float(np.nanmean(lgs) - np.nanmean(sgs)) if (ok_l.any() and ok_s.any()) else np.nan,
                                    n=int(np.sum([p['n'] for p in per.values()])), npos=int((ns > 0).sum()), ntot=len(ns)))
    df = pd.DataFrame(out)
    df.to_csv('/data/workspace/coin/user_spec.csv', index=False)
    print('\n===== 汇总（stop=1.5%/2%, cool=0/20, 限价2bp, R=2）=====')
    show = df[df.grp == 'ALL'].copy()
    show = show[['sig','stop','cool','n','gross','net','t_net','win','lg','sg','ls_diff']]
    pd.set_option('display.width', 200)
    print(show.round(4).to_string(index=False))
    print(f'\n耗时 {time.time()-t0:.0f}s')

if __name__ == '__main__':
    main()
