"""抛硬币实验 第1步：鞅性验证 + 基础统计"""
import numpy as np, pandas as pd, sys
sys.path.insert(0,'/data/workspace/coin')
from coin import load, bracket, coin_sig

NEW6={'TRXUSDT','UNIUSDT','XLMUSDT','XMRUSDT','XRPUSDT','ZECUSDT'}
D=load()

def run(sym, df, s, R, cost_bp, gap, seed):
    rng=np.random.default_rng(seed)
    sig=coin_sig(len(df), gap[0], gap[1], rng)
    tr=bracket(df['open'].values, df['high'].values, df['low'].values, sig, s, R)
    if len(tr)<10: return None
    cost_R = 2*cost_bp/(s*1e4)          # 往返成本，R 单位
    net = tr - cost_R
    win = float((tr>R*0.9).mean())       # 触止盈比例（毛，成本前）
    return dict(sym=sym, n=len(tr), win=win, gross=float(tr.mean()),
                net=float(net.mean()), t=float(net.mean()/net.std(ddof=1)*np.sqrt(len(net))) if len(net)>2 else 0,
                cost_R=cost_R, tr=tr)

print('='*100)
print('第1步：鞅性验证 (理论: P(触止盈)=1/(1+R)=33.33%, 毛E=0)')
print('='*100)
rows=[]
for (s,R,cost_bp,gap,tag) in [(0.05,2.0,2.0,(20,240),'基准 s=5% R=2 maker'),
                              (0.05,2.0,10.0,(20,240),'taker'),
                              (0.02,2.0,2.0,(20,240),'s=2%'),
                              (0.03,2.0,2.0,(20,240),'s=3%'),
                              (0.08,2.0,2.0,(20,240),'s=8%'),
                              (0.05,1.0,2.0,(20,240),'R=1'),
                              (0.05,3.0,2.0,(20,240),'R=3'),
                              (0.05,2.0,2.0,(5,60),'间隔5-60'),
                              (0.05,2.0,2.0,(60,480),'间隔60-480')]:
    rs=[run(k,v,s,R,cost_bp,gap,0) for k,v in D.items()]
    rs=[r for r in rs if r]
    alltr=np.concatenate([r['tr'] for r in rs])
    cost_R=2*cost_bp/(s*1e4)
    net=alltr-cost_R
    n=len(alltr)
    win=float((alltr>R*0.9).mean())
    E=float(net.mean()); t=float(E/net.std(ddof=1)*np.sqrt(n))
    theory=1.0/(1.0+R)
    rows.append(dict(tag=tag,s=s,R=R,cost_bp=cost_bp,gap=str(gap),n=n,
                     win=win,theory_win=theory,dev=(win-theory)*100,
                     gross=float(alltr.mean()),net=E,t=t,cost_R=cost_R))

df=pd.DataFrame(rows)
pd.set_option('display.width',200)
print(df[['tag','n','win','theory_win','dev','gross','cost_R','net','t']].to_string(index=False,
      float_format=lambda x:f'{x:8.4f}'))
print()
print('判读：win vs theory_win 的偏差(dev,百分点)——若显著偏离0，说明鞅性被打破(有真动量/反转)')
print('      gross 应 ≈ 0；net = gross - cost_R 应为负（成本单向抽水）')
df.to_csv('/data/workspace/coin/step1.csv',index=False)
