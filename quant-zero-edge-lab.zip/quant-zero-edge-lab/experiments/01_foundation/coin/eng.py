"""修正版引擎：修复"未平仓交易被丢弃"的幸存者偏差 + 支持跳空滑点 + 最大持仓"""
import numpy as np

def bracket2(o,h,l,c,sig,stop_pct,R,slip_bp=0.0,max_hold=None):
    """
    sig[i]!=0 -> 在 open[i] 建仓（sig 只能依赖 bar<=i-1）
    出场：止损 / 止盈 / (可选)max_hold / 样本末尾强制平仓
    同 bar 双触及 -> 判止损先触发（保守）
    slip_bp: 止损成交滑点（跳空时按 stop_px*(1∓slip) 成交）
    返回 (R序列, 出场类型数组)  类型: 1=止盈 0=止损 -1=超时/强平
    """
    o=np.asarray(o,float); h=np.asarray(h,float)
    l=np.asarray(l,float); c=np.asarray(c,float)
    n=len(o); tr=[]; ty=[]
    cur=0.0; entry=0.0; stop_px=0.0; tgt_px=0.0; ei=0
    def close(px,kind):
        tr.append((px-entry)*cur/abs(entry)/stop_pct); ty.append(kind); return 0.0
    for i in range(1,n):
        closed_this_bar=False
        if cur!=0:
            if cur>0: hs,ht = l[i]<=stop_px, h[i]>=tgt_px
            else:     hs,ht = h[i]>=stop_px, l[i]<=tgt_px
            if hs:
                px=stop_px*(1-np.sign(cur)*slip_bp/1e4); cur=close(px,0); closed_this_bar=True
            elif ht:
                cur=close(tgt_px,1); closed_this_bar=True
            elif max_hold is not None and (i-ei)>=max_hold:
                cur=close(o[i],-1); closed_this_bar=True
            elif i==n-1:                      # 样本末尾强制平仓（修复丢弃偏差）
                cur=close(c[i],-1); closed_this_bar=True
        if cur==0.0 and not closed_this_bar and sig[i]!=0 and i<n-1:
            cur=float(np.sign(sig[i])); entry=o[i]; ei=i
            stop_px=entry*(1-cur*stop_pct); tgt_px=entry*(1+cur*R*stop_pct)
            if cur>0: hs,ht = l[i]<=stop_px, h[i]>=tgt_px
            else:     hs,ht = h[i]>=stop_px, l[i]<=tgt_px
            if hs:
                px=stop_px*(1-cur*slip_bp/1e4); cur=close(px,0)
            elif ht: cur=close(tgt_px,1)
    if cur!=0:                                 # 尾部兜底
        tr.append((c[-1]-entry)*cur/abs(entry)/stop_pct); ty.append(-1)
    return np.asarray(tr), np.asarray(ty)
