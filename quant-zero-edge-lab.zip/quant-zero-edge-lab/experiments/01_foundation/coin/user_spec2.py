"""用户规格 第8点：收割制模拟（不复利 + 盈余公积）— 向量化版
同时验证 ls_diff(多头-空头) 是否由品种beta驱动
"""
import numpy as np, pandas as pd
from user_spec import load, SIGS, run, OLD7, NEW6

D = load(); names = sorted(D.keys())
OLD7 = [x for x in OLD7 if x in D]; NEW6 = [x for x in NEW6 if x in D]

def collect(sname, sp, cool, syms, R=2.0, cost_bp=2.0):
    seqs = []; lsd = {}
    for sym in syms:
        r = run(D[sym], SIGS[sname](D[sym]), sp, R, cost_bp, cool)
        if r is None or r['n'] < 30:
            continue
        seqs.append(r['tr'])
        bh = D[sym]['close'].iloc[-1] / D[sym]['close'].iloc[0] - 1
        d = (r['lg'] - r['sg']) if not (np.isnan(r['lg']) or np.isnan(r['sg'])) else np.nan
        lsd[sym] = dict(lg=r['lg'], sg=r['sg'], diff=d, bh=bh)
    return np.concatenate(seqs), lsd

def harvest_v(seq, f, C0=10000.0, T=1.0, bust=0.2, nboot=500, seed=0):
    """向量化：同时跑 nboot 条路径。固定注 + 达标收割 + 爆仓线"""
    rng = np.random.default_rng(seed)
    n = len(seq)
    idx = rng.integers(0, n, size=(nboot, n), dtype=np.int32)
    S = (seq[idx] * (f * C0)).astype(np.float64)
    W = np.full(nboot, C0); taken = np.zeros(nboot); stopped = np.zeros(nboot, bool)
    bustline = bust * C0; tgt = C0 * (1 + T)
    for j in range(n):
        act = ~stopped
        if not act.any():
            break
        W[act] += S[act, j]
        b = act & (W <= bustline)
        stopped |= b
        h = act & (~b) & (W >= tgt)
        taken[h] += (W[h] - C0); W[h] = C0
    finals = W + taken
    got = taken >= C0
    return dict(P=float(got.mean()), bust=float(stopped.mean()),
                final_med=float(np.median(finals)), taken_med=float(np.median(taken)))

print('=' * 80)
print('第一部分：ls_diff(多头-空头) 是否由品种beta驱动')
print('=' * 80)
for sname in ['ma50', 'macd', 'rsi14_tr']:
    for grp, syms in [('OLD7', OLD7), ('NEW6', NEW6)]:
        seq, lsd = collect(sname, 0.020, 20, syms)
        df = pd.DataFrame(lsd).T
        for c in ['lg', 'sg', 'diff', 'bh']:
            df[c] = df[c].astype(float)
        ok = df.dropna(subset=['diff', 'bh'])
        corr = ok['diff'].corr(ok['bh']) if len(ok) > 2 else np.nan
        print(f'{sname:9s} {grp}: 多头{ok.lg.mean():+.4f} 空头{ok.sg.mean():+.4f} '
              f'ls_diff{ok["diff"].mean():+.4f} | corr(ls_diff,BH)={corr:+.3f}')
        print(f'          品种BH: ' + ', '.join(f'{k}={v:+.0%}' for k, v in ok['bh'].items()))

print()
print('=' * 80)
print('第二部分：收割制（固定注 + 翻倍即收割 + 20%爆仓线 + bootstrap500）')
print('=' * 80)
rows = []
for sname in ['ma50', 'macd', 'rsi14_tr', 'mom20', 'rev20', 'rand']:
    for grp, syms in [('ALL', names), ('NEW6', NEW6), ('OLD7', OLD7)]:
        seq, _ = collect(sname, 0.020, 20, syms)
        for f in [0.01, 0.02]:
            h = harvest_v(seq, f)
            h0 = harvest_v(seq - seq.mean(), f)     # 零期望对照（同波动）
            rows.append(dict(sig=sname, grp=grp, f=f, n=len(seq), E=float(seq.mean()),
                             P=h['P'], bust=h['bust'], final=h['final_med'],
                             P0=h0['P'], final0=h0['final_med'], edge=h['P'] - h0['P']))
        print(f'  done {sname} {grp}')
df = pd.DataFrame(rows)
pd.set_option('display.width', 230)
print()
print(df.round(4).to_string(index=False))
df.to_csv('/data/workspace/coin/user_harvest.csv', index=False)
print('\n已保存 user_harvest.csv')
