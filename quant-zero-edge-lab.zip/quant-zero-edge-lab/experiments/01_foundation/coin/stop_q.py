import numpy as np, pandas as pd, sys
sys.path.insert(0, '/data/workspace/coin')
from eng import bracket2
from coin import coin_sig, load
from harvest import sim

D = load()
R = 2.0

# ===== 1. 止损宽度 × 成本 的完整 cost_R 表 =====
print('=' * 104)
print('1. cost_R = 往返成本 / 止损距离   （单位：R）')
print('=' * 104)
rows = []
for s in [0.015, 0.02, 0.03, 0.05, 0.08]:
    d = dict(stop=f'{s*100:.1f}%')
    for cb, nm in [(2.0, 'maker2bp'), (5.0, 'mid5bp'), (10.0, 'taker10bp'), (20.0, 'slip20bp')]:
        d[nm] = 2 * cb / (s * 1e4)
    rows.append(d)
print(pd.DataFrame(rows).to_string(index=False, float_format=lambda x: '%10.4f' % x))
print()
print('你的预期 0.05R~0.1R  ->  对应 maker 下止损约 0.4%~0.8%，或 taker 下止损 2%~4%')
print('我一直在用 maker2bp + 止损5% = 0.008R  ->  比你的预期乐观 6~12 倍')


# ===== 2. 抛硬币：不同止损宽度下的 E 与 P =====
def coin_seq(s, cb, nseed=6):
    trs = []
    for sd in range(nseed):
        for k, v in D.items():
            rng = np.random.default_rng(sd * 100 + abs(hash(k)) % 997)
            t, _ = bracket2(v['open'].values, v['high'].values, v['low'].values,
                            v['close'].values, coin_sig(len(v), 20, 240, rng), s, R)
            trs.append(t)
    return np.concatenate(trs) - 2 * cb / (s * 1e4)


print()
print('=' * 104)
print('2. 抛硬币：止损宽度扫描 (maker 2bp)  —— 验证你的"以损定量"洞察')
print('=' * 104)
rows = []
for s in [0.015, 0.02, 0.03, 0.05, 0.08]:
    x = coin_seq(s, 2.0)
    cr = 2 * 2.0 / (s * 1e4)
    # 胜率（触止盈占比）
    rows.append(dict(stop=f'{s*100:.1f}%', n=len(x), cost_R=cr, E=x.mean(),
                     t=x.mean() / x.std(ddof=1) * np.sqrt(len(x))))
df = pd.DataFrame(rows)
print(df.to_string(index=False, float_format=lambda x: '%10.4f' % x))
print('注: 抛硬币毛E理论=0, 净E = -cost_R。止损越宽 cost_R越小 -> E越接近0')


# ===== 3. 按你的成本口径(0.05R / 0.1R) 重算 P =====
def sym(x, bust_frac, up_frac, f, n_path=4000, seed=5, nt=8000):
    rng = np.random.default_rng(seed)
    nblk = int(np.ceil(nt / 50))
    nb = int(np.ceil(len(x) / 50))
    C0 = 10000.0
    bet = f * C0
    wins = []
    for _ in range(n_path):
        pick = rng.choice(nb, size=nblk, replace=True)
        seq = np.concatenate([x[p * 50:(p + 1) * 50] for p in pick])[:nt]
        W = C0 * 1.0
        done = 0
        for r in seq:
            W = W + bet * r
            if W >= (1 + up_frac) * C0:
                wins.append(1)
                done = 1
                break
            if W <= bust_frac * C0:
                wins.append(0)
                done = 1
                break
        if not done:
            wins.append(0)
    return float(np.mean(wins))


print()
print('=' * 104)
print('3. 按你的成本口径重算：cost_R = 0.008 / 0.05 / 0.10  (f=2%, 亏80%vs赚100%)')
print('=' * 104)
base = coin_seq(0.05, 0.0)          # 毛序列（未扣成本）
rows = []
for cr in [0.008, 0.02, 0.04, 0.05, 0.08, 0.10]:
    x = base - cr
    rows.append(dict(cost_R=cr, E=x.mean(), P=sym(x, 0.2, 1.0, 0.02, n_path=3000, seed=9)))
print(pd.DataFrame(rows).to_string(index=False, float_format=lambda x: '%10.4f' % x))
print()
print('结论: cost_R 从 0.008 升到 0.05 -> P 从 ~54% 塌到多少，看上表')


# ===== 4. 固定百分比止损 vs 技术位置止损(ATR) =====
def atr_stop_seq(sl_mult, cb, nseed=4):
    """技术位置止损：止损距离 = ATR(48) * sl_mult，随行情浮动"""
    trs = []
    for sd in range(nseed):
        for k, v in D.items():
            rng = np.random.default_rng(sd * 100 + abs(hash(k)) % 997)
            sig = coin_sig(len(v), 20, 240, rng)
            h = v['high'].values
            l = v['low'].values
            c = v['close'].values
            pc = np.concatenate([[c[0]], c[:-1]])
            tr = np.maximum(h - l, np.abs(h - pc), np.abs(l - pc))
            atr = pd.Series(tr).rolling(48, min_periods=48).mean().values
            o = v['open'].values
            out = []
            cur = 0.0
            for i in range(1, len(o)):
                if np.isnan(atr[i]):
                    continue
                s_dist = atr[i] * sl_mult / o[i]      # 动态止损百分比
                if s_dist <= 0 or s_dist > 0.5:
                    continue
                if cur != 0:
                    hs = (l[i] <= stop_px) if cur > 0 else (h[i] >= stop_px)
                    ht = (h[i] >= tgt_px) if cur > 0 else (l[i] <= tgt_px)
                    if hs:
                        out.append(-1.0)
                        cur = 0.0
                    elif ht:
                        out.append(R)
                        cur = 0.0
                if cur == 0.0 and sig[i] != 0 and i < len(o) - 1:
                    cur = float(np.sign(sig[i]))
                    entry = o[i]
                    stop_px = entry * (1 - cur * s_dist)
                    tgt_px = entry * (1 + cur * R * s_dist)
                    hs = (l[i] <= stop_px) if cur > 0 else (h[i] >= stop_px)
                    ht = (h[i] >= tgt_px) if cur > 0 else (l[i] <= tgt_px)
                    if hs:
                        out.append(-1.0)
                        cur = 0.0
                    elif ht:
                        out.append(R)
                        cur = 0.0
            if out:
                a = np.asarray(out)
                # 成本按各自止损宽度：这里用平均止损宽度近似
                trs.append(a)
    return np.concatenate(trs) if trs else np.zeros(0)


print()
print('=' * 104)
print('4. 固定百分比止损 vs 技术位置(ATR)止损 —— 止损距离的分布差异')
print('=' * 104)
# 统计 ATR 止损距离的分布
dists = []
for k, v in list(D.items())[:6]:
    h = v['high'].values
    l = v['low'].values
    c = v['close'].values
    pc = np.concatenate([[c[0]], c[:-1]])
    tr = np.maximum(h - l, np.abs(h - pc), np.abs(l - pc))
    atr = pd.Series(tr).rolling(48, min_periods=48).mean().values
    o = v['open'].values
    m = ~np.isnan(atr)
    dists.append(atr[m] / o[m])
d = np.concatenate(dists)
for mult in [1.0, 1.5, 2.0, 3.0]:
    dd = d * mult
    print('  ATR×%.1f: 止损距离中位数 %.2f%%  均值 %.2f%%  5%%分位 %.2f%%  95%%分位 %.2f%%'
          % (mult, np.median(dd) * 100, dd.mean() * 100,
             np.percentile(dd, 5) * 100, np.percentile(dd, 95) * 100))
print('  固定5%%: 恒定 5.00%%  (无分布)')
print()
print('  -> ATR止损的距离随行情在很大范围内浮动，每笔风险金额不一致，')
print('     R单位失去可比性，"以损定量"的前提被破坏')
