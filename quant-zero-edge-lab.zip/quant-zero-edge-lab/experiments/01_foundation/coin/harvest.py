"""抛硬币 × 不复利收割制（盈余公积）  [修正版]"""
import numpy as np

def harvest(Rseq, f, T=1.0, C0=10000.0, bust=0.2, max_trades=100000):
    W=C0; ext=0.0; bet=f*C0
    for k,r in enumerate(Rseq):
        if k>=max_trades: break
        W += bet*r
        if W >= (1+T)*C0:
            ext += W-C0; W=C0                       # 提取盈余，净值重置回本金
            if ext>=C0:                             # 累计提取>=本金 = 真赚到
                return dict(win=True, ext=ext, W=W, nb=k+1, bust=False)
        if W <= bust*C0:
            return dict(win=(ext>=C0), ext=ext, W=W, nb=k+1, bust=True)
    return dict(win=(ext>=C0), ext=ext, W=W, nb=min(len(Rseq),max_trades), bust=False)

def sim(Rseq, f, T=1.0, C0=10000.0, n_path=3000, block=50, seed=0,
        n_target=None, max_trades=100000):
    rng=np.random.default_rng(seed); n=len(Rseq); nb=int(np.ceil(n/block))
    nt = n_target if n_target else n          # 目标序列长度（bootstrap 可外推）
    nblk=int(np.ceil(nt/block))
    out=[]
    for _ in range(n_path):
        pick=rng.choice(nb, size=nblk, replace=True)
        seq=np.concatenate([Rseq[p*block:(p+1)*block] for p in pick])[:nt]
        out.append(harvest(seq,f,T,C0,bust=0.2,max_trades=max_trades))
    wins=np.array([o['win'] for o in out],float)
    tot =np.array([o['ext']+o['W']-C0 for o in out])     # 总资产 - 本金
    bust=np.array([o['bust'] for o in out],float)
    nb_=np.array([o['nb'] for o in out],float)
    return dict(P=float(wins.mean()), pnl_med=float(np.median(tot)),
                pnl_mean=float(tot.mean()), bust=float(bust.mean()),
                nb_med=float(np.median(nb_)),
                p25=float(np.percentile(tot,25)), p75=float(np.percentile(tot,75)))
