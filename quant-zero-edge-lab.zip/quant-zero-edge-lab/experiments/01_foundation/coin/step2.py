import numpy as np, pandas as pd, sys
sys.path.insert(0,'/data/workspace/coin')
from fixed_params import build, SIGS, R
combos=[('maker2bp',2.0,0.05,2*2.0/(0.05*1e4)),('taker10bp',10.0,0.10,2*10.0/(0.10*1e4))]
print('='*100); print('固定参数反解  s = 2*cost_bp/(cost_R*1e4)'); print('='*100)
for cn,cb,cr,s in combos: print('  %-11s cost_R=%.2f -> 止损 s=%.2f%%  止盈 %.2f%%'%(cn,cr,s*100,s*R*100))
for cn,cb,cr,s in combos:
    print('\n--- %s | cost_R=%.2f | 止损 %.2f%% ---'%(cn,cr,s*100)); sys.stdout.flush()
    rows=[]
    for nm in SIGS:
        x=build(s,nm,nseed=1)-cr
        t=x.mean()/x.std(ddof=1)*np.sqrt(len(x))
        rows.append(dict(signal=nm,n=len(x),E_net=x.mean(),t=t,winrate=(x>0).mean(),
            verdict='✓显著正' if t>1.96 else ('✗显著负' if t<-1.96 else '—不显著')))
    print(pd.DataFrame(rows).to_string(index=False,float_format=lambda x:'%9.4f'%x)); sys.stdout.flush()
