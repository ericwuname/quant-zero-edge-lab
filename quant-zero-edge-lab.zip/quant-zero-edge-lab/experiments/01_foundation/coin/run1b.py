import numpy as np, pandas as pd, sys
sys.path.insert(0,'/data/workspace/coin')
from coin import load, coin_sig
from eng import bracket2
D=load()

def run(s,R,cost_bp,gap,seed,slip_bp=0.0,max_hold=None):
    trs=[];tys=[]
    for k,v in D.items():
        rng=np.random.default_rng(seed+hash(k)%10000)
        sig=coin_sig(len(v),gap[0],gap[1],rng)
        tr,ty=bracket2(v['open'].values,v['high'].values,v['low'].values,v['close'].values,
                       sig,s,R,slip_bp,max_hold)
        trs.append(tr);tys.append(ty)
    return np.concatenate(trs),np.concatenate(tys)

print('='*104)
print('第1步(修正后)：鞅性验证  理论 P(触止盈)=1/(1+R), 毛E=0')
print('='*104)
cfgs=[(0.05,2.0,2.0,(20,240),'基准 s=5% R=2 maker'),
      (0.05,2.0,10.0,(20,240),'taker 10bp'),
      (0.02,2.0,2.0,(20,240),'s=2%'),(0.03,2.0,2.0,(20,240),'s=3%'),
      (0.08,2.0,2.0,(20,240),'s=8%'),
      (0.05,1.0,2.0,(20,240),'R=1'),(0.05,3.0,2.0,(20,240),'R=3'),
      (0.05,2.0,2.0,(5,60),'间隔5-60'),(0.05,2.0,2.0,(60,480),'间隔60-480')]
rows=[]
for (s,R,cb,gap,tag) in cfgs:
    tr,ty=run(s,R,cb,gap,0)
    cost_R=2*cb/(s*1e4); net=tr-cost_R
    # 胜率只在"真正出场"的样本上算（超时/强平不计入止盈）
    fin=ty>=0
    win=float((ty==1).sum()/max(fin.sum(),1))
    th=1.0/(1.0+R)
    E=float(net.mean()); t=float(E/net.std(ddof=1)*np.sqrt(len(net)))
    rows.append(dict(tag=tag,n=len(tr),win=win,th=th,dev=(win-th)*100,
        gross=float(tr.mean()),cost_R=cost_R,net=E,t=t,timeout=float((ty<0).mean())*100))
df=pd.DataFrame(rows)
print(df[['tag','n','win','th','dev','gross','cost_R','net','t','timeout']].to_string(index=False,
      float_format=lambda x:f'{x:8.4f}'))
print('\ntimeout% = 未触及止损止盈、被强平/末尾平仓的比例（修复前这些被丢弃）')
df.to_csv('/data/workspace/coin/step1b.csv',index=False)
