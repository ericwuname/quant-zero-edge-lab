import numpy as np, sys
sys.path.insert(0,'/data/workspace/coin')
from eng import bracket2
from coin import load, coin_sig
D=load(); k=list(D.keys())[0]; v=D[k]
rng=np.random.default_rng(0)
sg=coin_sig(len(v),20,240,rng)
print('sig!=0 点数:',(sg!=0).sum(),' bar数:',len(v))
tr,ty=bracket2(v['open'].values,v['high'].values,v['low'].values,v['close'].values,sg,0.004,2.0)
print('s=0.4%% trades:',len(tr))
print('出场类型统计: 1=止盈 0=止损 -1=超时/强平')
import collections; print(collections.Counter(ty.tolist()))
# 平均持仓
print('平均R:',tr.mean(),' 胜率(触止盈):',(ty==1).mean())
