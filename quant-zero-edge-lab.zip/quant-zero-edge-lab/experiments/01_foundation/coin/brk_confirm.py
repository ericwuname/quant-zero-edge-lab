"""
独立确认: 用不在原扫描网格里的窗口 (150,250,300,400) + 逐年
若同样为正 -> brk200 不是网格挑选的产物
"""
import numpy as np, pandas as pd, sys
sys.path.insert(0,'/data/workspace/coin')
from eng import bracket2
from coin import load
STOP=0.05; R=2.0; theo=1/(1+R)
D=load(); KEYS=list(D.keys())
NEW6={'TRXUSDT','UNIUSDT','XLMUSDT','XMRUSDT','XRPUSDT','ZECUSDT'}
def sig_brk(d,w):
    h,l=d['high'].values,d['low'].values
    hh=np.concatenate([[np.nan],pd.Series(h).rolling(w,min_periods=w).max().values[:-1]])
    ll=np.concatenate([[np.nan],pd.Series(l).rolling(w,min_periods=w).min().values[:-1]])
    return np.nan_to_num(np.where(h>hh,1.,np.where(l<ll,-1.,0.)))
def run(d,w,R=R,sl=None):
    sg=np.concatenate([[0.0],sig_brk(d,w)[:-1]])
    dd=d if sl is None else d.iloc[sl].reset_index(drop=True)
    if sl is not None:
        sg=np.concatenate([[0.0],sig_brk(dd,w)[:-1]])
    return bracket2(dd['open'].values,dd['high'].values,dd['low'].values,dd['close'].values,sg,STOP,R,slip_bp=0.0)[0]
def dp(x):
    if len(x)<50: return np.nan,np.nan
    p=(x>0).mean(); se=np.sqrt(theo*(1-theo)/len(x)); return (p-theo)*100,(p-theo)/se

print('='*100); print('[A] 独立窗口确认 (不在原网格 20/30/50/80/120/200 内)'); print('='*100)
for w in [150,250,300,400,500]:
    x=np.concatenate([run(D[k],w) for k in KEYS]); d,z=dp(x)
    xn=np.concatenate([run(D[k],w) for k in KEYS])
    print('  brk%-4d n=%5d Δp=%+6.2fpp z=%+5.2f 净E=%+.4f'%(w,len(x),d,z,x.mean()-0.008))
    sys.stdout.flush()

print('\n'+'='*100); print('[B] 逐年 (brk200 R=2)'); print('='*100)
# 按年切分 (假设数据有日期列)
k0=KEYS[0]
print('  数据列:', list(D[k0].columns)[:8])
if 'date' in D[k0].columns or 'time' in D[k0].columns:
    col='date' if 'date' in D[k0].columns else 'time'
    yrs=sorted(set(pd.to_datetime(D[k0][col]).dt.year))
    for y in yrs:
        trs=[]
        for k in KEYS:
            m=pd.to_datetime(D[k][col]).dt.year==y
            if m.sum()>500: trs.append(run(D[k],200,sl=m.values))
        if trs:
            x=np.concatenate(trs); d,z=dp(x)
            print('  %d n=%5d Δp=%+6.2fpp z=%+5.2f 净E=%+.4f'%(y,len(x),d,z,x.mean()-0.008))
        sys.stdout.flush()
else:
    print('  无日期列, 用等分5段代替')
    L=min(len(v) for v in D.values()); seg=L//5
    for i in range(5):
        sl=slice(i*seg,(i+1)*seg)
        trs=[run(D[k],200,sl=sl) for k in KEYS]
        x=np.concatenate(trs); d,z=dp(x)
        print('  段%d n=%5d Δp=%+6.2fpp z=%+5.2f 净E=%+.4f'%(i+1,len(x),d,z,x.mean()-0.008))
        sys.stdout.flush()

print('\n'+'='*100); print('[C] NEW6 干净样本 独立窗口'); print('='*100)
NK=[k for k in KEYS if k in NEW6]
for w in [150,200,250,300]:
    x=np.concatenate([run(D[k],w) for k in NK]); d,z=dp(x)
    print('  brk%-4d NEW6 n=%5d Δp=%+6.2fpp z=%+5.2f 净E=%+.4f'%(w,len(x),d,z,x.mean()-0.008))
