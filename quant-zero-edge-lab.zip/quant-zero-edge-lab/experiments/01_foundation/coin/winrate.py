"""
实测胜率为何系统性低于理论 1/(1+R)?
三个候选: (A)成本 (B)末尾截断censoring (C)离散监测+跳空穿透
分离方法: 合成零漂移GBM(已知理论), 分口径统计
"""
import numpy as np, pandas as pd, sys
sys.path.insert(0,'/data/workspace/coin')
from eng import bracket2
from coin import load

STOP=0.05
RS=[0.25,0.5,1.0,2.0,3.0,5.0]

# ---- 合成零漂移 GBM, 用真实1h波动率 ----
D=load()
rets=[]
for sym,v in D.items():
    r=np.diff(np.log(v['close'].values)); r=r[np.isfinite(r)]
    rets.append(r)
allr=np.concatenate(rets)
SIG=float(np.std(allr[np.abs(allr)<np.percentile(np.abs(allr),99)]))
print('真实1h波动率 sigma=%.5f (%.2f%%)'%(SIG,SIG*100))
print('='*104)

def synth_trades(R, n_path=400, n_bar=6000, seed=0, sig=None, drift=0.0):
    rng=np.random.default_rng(seed)
    sig=SIG if sig is None else sig
    out=[]
    for p in range(n_path):
        lr=rng.normal(drift-0.5*sig**2, sig, n_bar)
        c=np.exp(np.cumsum(lr))
        o=c.copy(); h=c*(1+np.abs(rng.normal(0,sig*0.5,n_bar))); l=c*(1-np.abs(rng.normal(0,sig*0.5,n_bar)))
        h=np.maximum(h,np.maximum(o,c)); l=np.minimum(l,np.minimum(o,c))
        sg=np.zeros(n_bar); i=10
        while i<n_bar-1:
            sg[i]=float(rng.choice([-1.,1.])); i+=int(rng.integers(20,241))
        t,ty=bracket2(o,h,l,c,sg,STOP,R,slip_bp=0.0)
        if len(t)>0: out.append((t,ty))
    return out

print('\n[分离检验] 合成零漂移GBM (理论胜率应精确=1/(1+R), 理论E=0)')
print('='*104)
print('%-6s %8s %8s %8s | %10s %10s | %10s %10s'%(
    'R','理论胜率','已完成','含截断','已完成E','含截断E','截断占比','截断均R'))
rows=[]
for R in RS:
    out=synth_trades(R)
    tall=np.concatenate([o[0] for o in out]); tallty=np.concatenate([o[1] for o in out])
    # ty: 0=stop,1=target,-1=强制平仓/超时
    fin = tallty>=0          # 已完成(触止盈或止损)
    cens= tallty<0           # 末尾截断
    w_fin=(tall[fin]>0).mean() if fin.sum()>50 else np.nan
    w_all=(tall>0).mean()
    theo=1/(1+R)
    rows.append(dict(R=R,theo=theo,w_fin=w_fin,w_all=w_all,
                     E_fin=tall[fin].mean() if fin.sum()>50 else np.nan,
                     E_all=tall.mean(),
                     cens_frac=cens.mean(),
                     cens_mean=tall[cens].mean() if cens.sum()>20 else np.nan,
                     n=len(tall)))
    print('%-6.2f %8.1fpct %8.1fpct %8.1fpct | %+10.4f %+10.4f | %10.1fpct %+10.4f'%(
        R,theo*100,w_fin*100,w_all*100,
        tall[fin].mean(),tall.mean(),cens.mean()*100,
        tall[cens].mean() if cens.sum()>20 else np.nan))
    sys.stdout.flush()

print('\n'+'='*104)
print('[真实数据] 同样两口径 (vwap_tr168 信号, 与合成对照)')
print('='*104)
def sig_vwap168(d):
    tp=(d['high'].values+d['low'].values+d['close'].values)/3
    ref=pd.Series(tp).rolling(168,min_periods=168).mean().values
    return np.nan_to_num(np.sign(d['close'].values-ref))
print('%-6s %8s %8s %8s | %10s %10s | %10s'%('R','理论','已完成','含截断','已完成E','含截断E','截断占比'))
for R in RS:
    tall=[];tty=[]
    for sym,v in D.items():
        sg=np.concatenate([[0.0],sig_vwap168(v)[:-1]])
        t,ty=bracket2(v['open'].values,v['high'].values,v['low'].values,v['close'].values,sg,STOP,R,slip_bp=0.0)
        tall.append(t);tty.append(ty)
    tall=np.concatenate(tall);tty=np.concatenate(tty)
    fin=tty>=0; cens=tty<0
    print('%-6.2f %8.1fpct %8.1fpct %8.1fpct | %+10.4f %+10.4f | %10.1fpct'%(
        R,100/(1+R),(tall[fin]>0).mean()*100,(tall>0).mean()*100,
        tall[fin].mean(),tall.mean(),cens.mean()*100))
    sys.stdout.flush()
