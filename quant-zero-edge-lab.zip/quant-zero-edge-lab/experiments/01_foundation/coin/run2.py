import numpy as np, pandas as pd, sys
sys.path.insert(0,'/data/workspace/coin')
from coin import load, coin_sig
from eng import bracket2
from harvest import sim
D=load()

def get_seq(s,R,gap,seed,cb):
    trs=[]
    for k,v in D.items():
        rng=np.random.default_rng(seed+abs(hash(k))%10000)
        sig=coin_sig(len(v),gap[0],gap[1],rng)
        tr,ty=bracket2(v['open'].values,v['high'].values,v['low'].values,v['close'].values,sig,s,R)
        trs.append(tr)
    tr=np.concatenate(trs); return tr - 2*cb/(s*1e4)

print('='*104)
print('第2步：抛硬币 × 收割制（不复利 / 固定注 / 翻倍即收割 / 20%爆仓线）')
print('='*104)
base=get_seq(0.05,2.0,(20,240),0,2.0)
print(f'基准序列: n={len(base)}  E={base.mean():+.4f}R  sd={base.std(ddof=1):.4f}  '
      f'年笔数≈{len(base)/5.5:.0f}')

rows=[]
for f in [0.005,0.01,0.02,0.03,0.05,0.08]:
    r=sim(base,f,T=1.0,n_path=3000,seed=1)
    rows.append(dict(f=f,P=r['P'],pnl_med=r['pnl_med'],pnl_mean=r['pnl_mean'],
                     bust=r['bust'],nb=r['nb_med'],yrs=r['nb_med']/(len(base)/5.5)))
df=pd.DataFrame(rows)
print('\n--- 仓位扫描 (T=100% 翻倍即收割, maker 2bp) ---')
print(df.to_string(index=False,float_format=lambda x:f'{x:10.2f}'))

print('\n--- 收割阈值扫描 (f=1%) ---')
rows=[]
for T in [0.25,0.5,1.0,2.0,3.0]:
    r=sim(base,0.01,T=T,n_path=3000,seed=2)
    rows.append(dict(T=T,P=r['P'],pnl_med=r['pnl_med'],bust=r['bust'],nb=r['nb_med']))
print(pd.DataFrame(rows).to_string(index=False,float_format=lambda x:f'{x:10.2f}'))

print('\n--- 成本敏感性 (f=1%, T=100%) ---')
rows=[]
for cb in [0.0,1.0,2.0,5.0,10.0]:
    seq=get_seq(0.05,2.0,(20,240),0,cb)
    r=sim(seq,0.01,T=1.0,n_path=3000,seed=3)
    rows.append(dict(cost_bp=cb,E=seq.mean(),P=r['P'],pnl_med=r['pnl_med'],bust=r['bust']))
print(pd.DataFrame(rows).to_string(index=False,float_format=lambda x:f'{x:10.4f}'))

print('\n--- 止损宽度(成本占风险) f=1% T=100% maker---')
rows=[]
for s in [0.02,0.03,0.05,0.08]:
    seq=get_seq(s,2.0,(20,240),0,2.0)
    r=sim(seq,0.01,T=1.0,n_path=3000,seed=4)
    rows.append(dict(stop=s,E=seq.mean(),cost_R=2*2.0/(s*1e4),P=r['P'],pnl_med=r['pnl_med'],bust=r['bust']))
print(pd.DataFrame(rows).to_string(index=False,float_format=lambda x:f'{x:10.4f}'))
df.to_csv('/data/workspace/coin/step2.csv',index=False)
