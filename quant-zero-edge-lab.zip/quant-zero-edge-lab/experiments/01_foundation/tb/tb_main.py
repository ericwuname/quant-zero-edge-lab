"""可信平台主流程: canary筛查 -> 全样本排名 -> 严格外推验证"""
import numpy as np, pandas as pd, glob, os, time, json
import tb_core as T

DATA=T.DATA
OLD7=['CRV','DASH','DOGE','DOT','ETH','FIL','HBAR']     # 曾参与选择
NEW6=['TRX','UNI','XLM','XMR','XRP','ZEC']              # 从未参与任何选择(干净)

def signals():
    S={}
    for w in [2,3,5,10,20,60,120,240]: S[f'mom{w}']=lambda d,w=w:T._sig_mom(d,w)
    for w in [2,3,5,10,20,60,120,240]: S[f'rev{w}']=lambda d,w=w:T._sig_rev(d,w)
    for w in [10,20,50,100,200]:       S[f'brk{w}']=lambda d,w=w:T._sig_brk(d,w)
    for w in [20,50,100,200]:          S[f'ma{w}']=lambda d,w=w:T._sig_ma(d,w)
    for a,b in [(20,100),(50,200),(10,50),(20,50)]: S[f'xab{a}_{b}']=lambda d,a=a,b=b:T._sig_xab(d,a,b)
    for w in [7,14,21]:                S[f'rsi{w}']=lambda d,w=w:T._sig_rsi(d,w)
    S['cheat5']=lambda d:T._sig_cheat(d,5)   # 负对照: 必须被抓
    return S

def load():
    out={}
    for f in sorted(glob.glob(DATA+'*_1h.csv')):
        nm=os.path.basename(f).split('_')[0].replace('USDT','')
        out[nm]=pd.read_csv(f).dropna(subset=['open','high','low','close']).reset_index(drop=True)
    return out

def main():
    t0=time.time()
    D=load(); names=list(D.keys()); S=signals()
    print(f'品种{len(names)} 信号{len(S)}')

    # ---------- 阶段1: canary 前视筛查 ----------
    print('\n===== 阶段1 canary 前视筛查 (shuffle: 打乱未来, 看历史信号是否改变) =====')
    can={}
    probe=names[:4]
    for nm,fn in S.items():
        tot=0; bad=0
        for s in probe:
            d,m=T.canary_shuffle(fn, D[s], k_frac=0.5, seed=5)
            bad+=d; tot+=m
        can[nm]=(bad,tot)
    for nm,(b,t) in sorted(can.items(), key=lambda x:-x[1][0]):
        flag='❌前视' if b>0 else '✅干净'
        print(f'  {flag}  {nm:12s} diff={b}/{t}')
    dirty=[k for k,v in can.items() if v[0]>0]
    print(f'  -> 检出前视 {len(dirty)} 个: {dirty}')

    # ---------- 阶段2: 全样本排名 (干净信号) ----------
    print('\n===== 阶段2 全样本 E[net_R] 排名 (flip, s=5%, R=2, maker2bp) =====')
    clean=[k for k in S if k not in dirty]
    rows=[]
    for nm in clean:
        fn=S[nm]; es={}
        for s in names:
            tb=T.backtest(D[s], fn(D[s]), 0.05,2.0,2.0,'flip')
            es[s]=tb.net_R.mean() if len(tb) else np.nan
        e_old=np.nanmean([es[s] for s in OLD7]); e_new=np.nanmean([es[s] for s in NEW6])
        rows.append(dict(sig=nm, E_all=np.nanmean(list(es.values())), E_OLD7=e_old, E_NEW6=e_new,
                         pos=int(np.nansum([es[s]>0 for s in names]))))
    R=pd.DataFrame(rows).sort_values('E_all',ascending=False)
    print(R.head(15).to_string(index=False,float_format=lambda x:f'{x:+.4f}'))
    print('...')
    print(R.tail(5).to_string(index=False,float_format=lambda x:f'{x:+.4f}'))

    # ---------- 阶段3: 严格验证 top8 ----------
    print('\n===== 阶段3 严格验证 (top8) =====')
    top=list(R.head(6)['sig'])
    for nm in top:
        fn=S[nm]
        # 3a 时间外推: 前50%选, 后50%验
        first=[]; second=[]
        for s in names:
            df=D[s]; h=len(df)//2
            tb1=T.backtest(df.iloc[:h].reset_index(drop=True), fn(df.iloc[:h].reset_index(drop=True)),0.05,2.0,2.0,'flip')
            tb2=T.backtest(df.iloc[h:].reset_index(drop=True), fn(df.iloc[h:].reset_index(drop=True)),0.05,2.0,2.0,'flip')
            first.append(tb1.net_R.mean() if len(tb1) else np.nan)
            second.append(tb2.net_R.mean() if len(tb2) else np.nan)
        # 3b 品种外推: OLD7选 -> NEW6验
        e_new6=R[R.sig==nm]['E_NEW6'].iloc[0]
        # 3c 置换检验 (符号打乱)
        exceed=0; zs=[]
        for s in NEW6:
            df=D[s]; sg=fn(df)
            tb=T.backtest(df,sg,0.05,2.0,2.0,'flip')
            if len(tb)<50: continue
            e0=tb.net_R.mean()
            rng=np.random.default_rng(13); perm=[]
            for _ in range(15):
                v=sg.values.copy(); rng.shuffle(v)
                tp=T.backtest(df,pd.Series(v),0.05,2.0,2.0,'flip')
                perm.append(tp.net_R.mean() if len(tp) else np.nan)
            perm=np.array(perm); mu,sd=np.nanmean(perm),np.nanstd(perm)
            zs.append((e0-mu)/sd if sd>0 else 0)
            if e0>np.nanpercentile(perm,95): exceed+=1
        zs=np.array(zs)
        tstat=zs.mean()/(zs.std()/np.sqrt(len(zs))) if len(zs)>1 and zs.std()>0 else 0
        print(f'  {nm:12s} 前半E={np.nanmean(first):+.4f} 后半E={np.nanmean(second):+.4f} '
              f'衰减={np.nanmean(second)/np.nanmean(first)*100 if np.nanmean(first)!=0 else 0:.0f}%  '
              f'NEW6(干净)={e_new6:+.4f}  置换超越={exceed}/{len(zs)} 跨品种t={tstat:+.2f}')

    # ---------- 阶段4: 时段效应专项(时间泄漏检验) ----------
    print('\n===== 阶段4 时段效应: 时间泄漏检验 =====')
    def fit_hour(dfs, upto=0.5):
        agg=np.zeros(24); cnt=np.zeros(24)
        for s in dfs:
            df=D[s]; h=int(len(df)*upto); sl=df.iloc[:h]
            o=sl['open'].values
            r=np.zeros(len(o)); r[:-1]=o[1:]/o[:-1]-1
            hr=pd.to_datetime(sl['timestamp'].values,unit='ms').hour.values
            for k in range(24):
                m=(hr==k)&(np.arange(len(r))<len(r)-1)
                if m.sum(): agg[k]+=np.nansum(r[m]); cnt[k]+=m.sum()
        return {k:(1.0 if agg[k]>0 else -1.0) for k in range(24) if cnt[k]>0}
    tab=fit_hour(OLD7, 0.5)
    npos=sum(1 for v in tab.values() if v>0)
    print(f'  前50%拟合: {npos}多 / {24-npos}空 (天然市场中性)')
    res=[]
    for s in NEW6:
        df=D[s]; h=len(df)//2
        seg=[df.iloc[:h].reset_index(drop=True), df.iloc[h:].reset_index(drop=True)]
        for i,sl in enumerate(seg):
            tb=T.backtest(sl, T._sig_hour(sl,tab),0.05,2.0,2.0,'flip')
            res.append((s,'拟合期' if i==0 else '样本外', tb.net_R.mean() if len(tb) else np.nan))
    for a in res: print(f'    {a[0]:5s} {a[1]:5s} E={a[2]:+.4f}')
    fit=np.nanmean([r[2] for r in res if r[1]=='拟合期']); oos=np.nanmean([r[2] for r in res if r[1]=='样本外'])
    print(f'  -> 拟合期{fit:+.4f}  样本外{oos:+.4f}  结论: {"泄漏(样本外塌陷)" if oos<fit/2 else "未塌陷"}')

    print(f'\n总耗时 {time.time()-t0:.0f}s')

if __name__=='__main__': main()
