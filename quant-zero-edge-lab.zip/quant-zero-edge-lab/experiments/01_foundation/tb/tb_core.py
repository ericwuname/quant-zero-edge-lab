"""
可信回测平台 (Trustworthy Backtest Platform) — 核心引擎
设计原则: 不靠自觉, 靠"已知答案的测试"把引擎卡死

严格约定:
  signal[t] 只能使用 close[0..t]  (收盘后决策, 无前视)
  成交价 = open[t+1]              (信号bar的下一根开盘)
  bar内触及: 同bar双触及 -> 保守判为止损
"""
import numpy as np, pandas as pd, os, glob

DATA = '/data/inputs/'
COST_BP_MAKER = 2.0    # 单边 2bp (maker)
COST_BP_TAKER = 10.0   # 单边 10bp (taker)

# ---------------- 数据 ----------------
def load_all(freq='1h'):
    out = {}
    for f in sorted(glob.glob(DATA + f'*_{freq}.csv')):
        name = os.path.basename(f).split('_')[0].replace('USDT','')
        df = pd.read_csv(f)
        df = df.dropna(subset=['open','high','low','close']).reset_index(drop=True)
        out[name] = df
    return out

# ---------------- 信号库 (严格 point-in-time) ----------------
# 每个函数: 输入 df, 返回 sig (Series, 值 -1/0/+1), sig[t] 只用 close[:t+1]
def _sig_mom(df, w):
    c = df['close'].values
    s = np.zeros(len(c))
    s[w:] = np.sign(c[w:] / c[:-w] - 1.0)
    return pd.Series(s)

def _sig_rev(df, w):
    return -_sig_mom(df, w)

def _sig_brk(df, w):
    h = df['high'].values; l = df['low'].values
    hh = pd.Series(h).rolling(w).max().values   # 含当前bar -> 收盘后已知, 合法
    ll = pd.Series(l).rolling(w).min().values
    ok = ~np.isnan(hh)
    s = np.zeros(len(h))
    s[ok] = np.where(h[ok] >= hh[ok], 1.0, np.where(l[ok] <= ll[ok], -1.0, np.nan))
    # 首次出现nan前为0; 用前向填充保持仓位直到翻转
    out = pd.Series(s).replace(0.0, np.nan).ffill().fillna(0.0)
    return out

def _sig_ma(df, w):
    c = df['close'].values
    ma = pd.Series(c).rolling(w).mean().values
    s = np.zeros(len(c))
    ok = ~np.isnan(ma)
    s[ok] = np.sign(c[ok] - ma[ok])
    return pd.Series(s)

def _sig_xab(df, a, b):
    c = df['close'].values
    ma = pd.Series(c).rolling(a).mean().values
    mb = pd.Series(c).rolling(b).mean().values
    s = np.zeros(len(c))
    ok = ~(np.isnan(ma) | np.isnan(mb))
    s[ok] = np.sign(ma[ok] - mb[ok])
    return pd.Series(s)

def _sig_rsi(df, w):
    c = pd.Series(df['close'].values)
    d = c.diff()
    up = d.clip(lower=0).ewm(alpha=1/w, adjust=False).mean()
    dn = (-d.clip(upper=0)).ewm(alpha=1/w, adjust=False).mean()
    rs = up / dn.replace(0, np.nan)
    rsi = 100 - 100/(1+rs)
    s = np.zeros(len(c))
    v = rsi.values
    s[v < 30] = 1.0; s[v > 70] = -1.0
    return pd.Series(s).replace(0.0, np.nan).ffill().fillna(0.0)

def _sig_hour(df, table):
    """table: dict hour->dir  固定时段表 (由外部拟合传入, 这里只做查表)"""
    ts = df['timestamp'].values
    hr = pd.to_datetime(ts, unit='ms').hour.values
    s = np.zeros(len(hr))
    for h, d in table.items():
        s[hr == h] = d
    return pd.Series(s)

def _sig_flat(df):
    return pd.Series(np.zeros(len(df)))

def _sig_long(df):
    return pd.Series(np.ones(len(df)))

def _sig_cheat(df, k=5):
    """故意的前视信号 (仅用于测试 canary) — 用未来k根收益"""
    c = df['close'].values
    s = np.zeros(len(c))
    s[:-k] = np.sign(c[k:] / c[:-k] - 1.0)
    return pd.Series(s)

# ---------------- 回测引擎 ----------------
def backtest(df, sig, s=0.05, R=2.0, cost_bp=COST_BP_MAKER, mode='flip', slip_bp=0.0):
    """
    s: 止损幅度(小数)  R: 盈亏比  mode: 'flip'|'target'
    返回 trades DataFrame
    """
    o = df['open'].values; h = df['high'].values; l = df['low'].values
    sg = np.asarray(sig.values, dtype=float)
    n = len(o)
    cost_R = 2.0 * cost_bp / 1e4 / s          # 往返成本, 以R为单位
    slip = slip_bp / 1e4
    trades = []
    i = 0
    while i < n - 2:
        d = sg[i]
        if d == 0 or not np.isfinite(d):
            i += 1; continue
        entry = o[i+1]
        if not np.isfinite(entry) or entry <= 0:
            i += 1; continue
        stop = entry * (1 - s*d)
        targ = entry * (1 + R*s*d)
        j = i + 1
        etype = None; exit_px = np.nan
        while j < n - 1:
            if d > 0:
                hs = l[j] <= stop; ht = h[j] >= targ
            else:
                hs = h[j] >= stop; ht = l[j] <= targ
            if hs:                                  # 同bar双触及 -> 保守: 止损
                etype = 'stop'; exit_px = stop * (1 - slip*d); break
            if ht:
                etype = 'target'; exit_px = targ; break
            if mode == 'flip':
                nd = sg[j]
                if np.isfinite(nd) and nd != 0 and nd != d:
                    etype = 'flip'; exit_px = o[j+1]; break
            j += 1
        if etype is None:
            etype = 'eod'; exit_px = o[-1]; j = n - 1
        ret = (exit_px / entry - 1.0) * d
        trades.append(dict(entry_i=i, exit_i=j, dir=d, entry=entry, exit=exit_px,
                           etype=etype, hold=j-i, gross_R=ret/s, net_R=ret/s - cost_R))
        i = j + 1 if mode == 'flip' else j + 1
    return pd.DataFrame(trades)

# ---------------- 前视探测器 (canary) ----------------
def canary_shuffle(sig_fn, df, k_frac=0.5, seed=0, cols=('open','high','low','close','volume')):
    """打乱 k 之后的未来数据, 若 signal[:k] 改变 -> 前视"""
    k = int(len(df) * k_frac)
    rng = np.random.default_rng(seed)
    d2 = df.copy()
    idx = np.arange(k, len(df))
    perm = rng.permutation(idx)
    for c in cols:
        v = df[c].values.copy()
        v[k:] = v[k:][perm - k]
        d2[c] = v
    s1 = np.asarray(sig_fn(df).values, dtype=float)
    s2 = np.asarray(sig_fn(d2).values, dtype=float)
    m = min(k, len(s1), len(s2))
    diff = int(np.nansum(s1[:m] != s2[:m]))
    return diff, m

def canary_truncate(sig_fn, df, n_probe=40, seed=0, warmup=300):
    """gold standard: signal[t] 用 df[:t+1] 重算, 与全量结果比对"""
    s_full = np.asarray(sig_fn(df).values, dtype=float)
    n = len(df)
    rng = np.random.default_rng(seed)
    lo = min(warmup + 10, n - 2)
    pts = rng.choice(np.arange(lo, n - 1), size=min(n_probe, n - 1 - lo), replace=False)
    bad = 0; tot = 0
    for t in pts:
        st = np.asarray(sig_fn(df.iloc[:t+1]).values, dtype=float)
        if len(st) == 0: continue
        tot += 1
        if st[-1] != s_full[t]: bad += 1
    return bad, tot

def canary_shift(sig_fn, df, s=0.05, R=2.0, cost_bp=COST_BP_MAKER, mode='flip'):
    """信号整体后移1根: 若收益崩塌 -> 前视嫌疑"""
    sg = sig_fn(df)
    a = backtest(df, sg, s, R, cost_bp, mode)
    b = backtest(df, sg.shift(1).fillna(0), s, R, cost_bp, mode)
    ea = a['net_R'].mean() if len(a) else np.nan
    eb = b['net_R'].mean() if len(b) else np.nan
    return ea, eb, (ea - eb)
