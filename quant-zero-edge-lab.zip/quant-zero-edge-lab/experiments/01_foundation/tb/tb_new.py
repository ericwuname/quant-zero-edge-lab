"""
新增策略库 + 扩展引擎 — 基于可信回测平台 tb_core
新增此前从未测过的信号族:
  VWAP / K线形态 / 布林挤压(TTM) / 量能(OBV,CMF) / 连涨跌 / 开盘区间突破 / 窄幅整理
扩展出场模式: 'time'(纯时间出场), 'stop_time'(止损+时间出场)
"""
import numpy as np, pandas as pd, os, glob, sys
sys.path.insert(0, '/data/workspace/tb')
from tb_core import (DATA, load_all, backtest, canary_truncate, canary_shuffle,
                     COST_BP_MAKER, COST_BP_TAKER)

# ================= 指标 (全部 point-in-time) =================
def _vwap(df, w):
    h = df['high'].values; l = df['low'].values; c = df['close'].values
    v = pd.Series(df['volume'].values, dtype=float).fillna(0).values
    tp = (h + l + c) / 3.0
    num = pd.Series(tp * v).rolling(w, min_periods=w).sum()
    den = pd.Series(v).rolling(w, min_periods=w).sum()
    return (num / den.replace(0, np.nan)).values

def _atr(df, w):
    h = df['high'].values; l = df['low'].values; c = df['close'].values
    pc = np.concatenate([[c[0]], c[:-1]])
    tr = np.maximum(h - l, np.maximum(np.abs(h - pc), np.abs(l - pc)))
    return pd.Series(tr).ewm(alpha=1.0/w, adjust=False, min_periods=w).mean().values

def _bb(df, w=20, k=2.0):
    c = pd.Series(df['close'].values)
    mid = c.rolling(w, min_periods=w).mean()
    sd = c.rolling(w, min_periods=w).std(ddof=0)
    return (mid + k*sd).values, mid.values, (mid - k*sd).values

def _kc(df, w=20, k=1.5):
    c = pd.Series(df['close'].values)
    mid = c.ewm(span=w, adjust=False, min_periods=w).mean()
    a = _atr(df, w)
    return (mid + k*a).values, mid.values, (mid - k*a).values

def _obv(df):
    c = df['close'].values; v = pd.Series(df['volume'].values, dtype=float).fillna(0).values
    d = np.sign(np.diff(c, prepend=c[0]))
    return np.cumsum(d * v)

def _cmf(df, w=21):
    h = df['high'].values; l = df['low'].values; c = df['close'].values
    v = pd.Series(df['volume'].values, dtype=float).fillna(0).values
    rng = (h - l); rng = np.where(rng <= 0, np.nan, rng)
    mfm = ((c - l) - (h - c)) / rng
    mfv = np.nan_to_num(mfm) * v
    num = pd.Series(mfv).rolling(w, min_periods=w).sum()
    den = pd.Series(v).rolling(w, min_periods=w).sum()
    return (num / den.replace(0, np.nan)).values

# ================= 信号库 =================
def _ffill(raw):
    return pd.Series(raw).replace(0.0, np.nan).ffill().fillna(0.0)

def _vwap_mr(df, w=96, k=0.02):
    c = df['close'].values; vw = _vwap(df, w)
    dev = c / vw - 1.0
    s = np.where(dev > k, -1.0, np.where(dev < -k, 1.0, 0.0))
    return _ffill(s)

def _vwap_tr(df, w=96):
    c = df['close'].values; vw = _vwap(df, w)
    return _ffill(np.sign(c - vw))

def _engulf(df):
    o = df['open'].values; c = df['close'].values
    po = np.concatenate([[o[0]], o[:-1]]); pc = np.concatenate([[c[0]], c[:-1]])
    bull = (pc < po) & (c > o) & (c > po) & (o < pc)
    bear = (pc > po) & (c < o) & (c < po) & (o > pc)
    return _ffill(np.where(bull, 1.0, np.where(bear, -1.0, 0.0)))

def _hammer(df, mult=2.0):
    o = df['open'].values; h = df['high'].values; l = df['low'].values; c = df['close'].values
    body = np.abs(c - o); rng = np.where(h - l <= 0, np.nan, h - l)
    up = h - np.maximum(o, c); dn = np.minimum(o, c) - l
    ham = (dn > mult * np.maximum(body, 1e-12)) & (up < body) & (body < 0.5 * rng)
    star = (up > mult * np.maximum(body, 1e-12)) & (dn < body) & (body < 0.5 * rng)
    return _ffill(np.where(ham, 1.0, np.where(star, -1.0, 0.0)))

def _doji(df, th=0.1):
    o = df['open'].values; h = df['high'].values; l = df['low'].values; c = df['close'].values
    body = np.abs(c - o); rng = np.where(h - l <= 0, np.nan, h - l)
    d = body < th * rng
    pc = np.concatenate([[c[0]], c[:-1]])
    return _ffill(np.where(d, -np.sign(c - pc), 0.0))   # doji 后反向

def _harami(df):
    o = df['open'].values; c = df['close'].values
    po = np.concatenate([[o[0]], o[:-1]]); pc = np.concatenate([[c[0]], c[:-1]])
    pb_hi = np.maximum(po, pc); pb_lo = np.minimum(po, pc)
    inside = (np.maximum(o, c) <= pb_hi) & (np.minimum(o, c) >= pb_lo) & (np.abs(pc-po) > 0)
    return _ffill(np.where(inside, -np.sign(pc - po), 0.0))

def _inside(df):
    h = df['high'].values; l = df['low'].values
    ph = np.concatenate([[h[0]], h[:-1]]); pl = np.concatenate([[l[0]], l[:-1]])
    ins = (h <= ph) & (l >= pl)
    o = df['open'].values; c = df['close'].values
    return _ffill(np.where(ins, np.sign(c - o), 0.0))   # 内包后按实体方向突破

def _squeeze(df, w=20, kc_w=20):
    bu, bm, bl = _bb(df, w, 2.0); ku, km, kl = _kc(df, kc_w, 1.5)
    sq = (bu < ku) & (bl > kl)          # BB 在 KC 内 = 挤压
    c = df['close'].values
    fire = (~sq) & (np.concatenate([[False], sq[:-1]]))   # 挤压释放
    s = np.where(fire, np.sign(c - bm), 0.0)
    return _ffill(s)

def _bb_mr(df, w=20, k=2.0):
    bu, bm, bl = _bb(df, w, k); c = df['close'].values
    return _ffill(np.where(c > bu, -1.0, np.where(c < bl, 1.0, 0.0)))

def _bb_brk(df, w=20, k=2.0):
    bu, bm, bl = _bb(df, w, k); c = df['close'].values
    return _ffill(np.where(c > bu, 1.0, np.where(c < bl, -1.0, 0.0)))

def _atr_brk(df, w=20, k=1.0):
    c = df['close'].values; a = _atr(df, w)
    pc = np.concatenate([[c[0]], c[:-1]])
    return _ffill(np.where(c > pc + k*a, 1.0, np.where(c < pc - k*a, -1.0, 0.0)))

def _obv_x(df, w=50):
    ob = _obv(df); ma = pd.Series(ob).rolling(w, min_periods=w).mean().values
    return _ffill(np.sign(ob - ma))

def _cmf_s(df, w=21):
    v = _cmf(df, w)
    return _ffill(np.where(v > 0.05, 1.0, np.where(v < -0.05, -1.0, 0.0)))

def _volspike(df, w=20, k=2.0):
    v = pd.Series(df['volume'].values, dtype=float).fillna(0).values
    mv = pd.Series(v).rolling(w, min_periods=w).mean().values
    o = df['open'].values; c = df['close'].values
    sp = v > k * mv
    return _ffill(np.where(sp, np.sign(c - o), 0.0))

def _streak(df, n=3, rev=True):
    o = df['open'].values; c = df['close'].values
    d = np.sign(c - o)
    s = np.zeros(len(c)); run = 0
    for i in range(len(c)):
        if d[i] != 0 and d[i] == (d[i-1] if i > 0 else 0):
            run += 1
        else:
            run = 1 if d[i] != 0 else 0
        if run >= n and d[i] != 0:
            s[i] = -d[i] if rev else d[i]
    return _ffill(s)

def _orb(df, hh=1):
    ts = pd.to_datetime(df['timestamp'].values, unit='ms')
    day = ts.normalize()
    o = df['open'].values; h = df['high'].values; l = df['low'].values; c = df['close'].values
    dser = pd.Series(day)
    grp = dser.ne(dser.shift()).cumsum().values - 1
    n = len(c); s = np.zeros(n)
    hi = np.full(n, np.nan); lo = np.full(n, np.nan)
    for g in range(grp[-1] + 1):
        m = grp == g
        idx = np.where(m)[0]
        if len(idx) <= hh: continue
        hh_ = h[idx[:hh]].max(); ll_ = l[idx[:hh]].min()
        hi[idx[hh:]] = hh_; lo[idx[hh:]] = ll_
    s = np.where(c > hi, 1.0, np.where(c < lo, -1.0, 0.0))
    return _ffill(s)

def _nr(df, w=7):
    h = df['high'].values; l = df['low'].values
    rng = h - l
    mn = pd.Series(rng).rolling(w, min_periods=w).min().values
    narrow = rng <= mn
    o = df['open'].values; c = df['close'].values
    ph = np.concatenate([[h[0]], h[:-1]]); pl = np.concatenate([[l[0]], l[:-1]])
    brk_up = c > ph; brk_dn = c < pl
    s = np.where(narrow & brk_up, 1.0, np.where(narrow & brk_dn, -1.0, 0.0))
    return _ffill(s)

# 注册: name -> (fn, 说明)
SIG = {}
for w in (48, 96, 168):
    SIG[f'vwap_mr{w}'] = (lambda d, w=w: _vwap_mr(d, w), f'VWAP{w}均值回归')
    SIG[f'vwap_tr{w}'] = (lambda d, w=w: _vwap_tr(d, w), f'VWAP{w}趋势')
SIG['engulf'] = (_engulf, '吞没形态')
SIG['hammer'] = (_hammer, '锤子/射击星')
SIG['doji'] = (_doji, '十字星反向')
SIG['harami'] = (_harami, '孕线反向')
SIG['inside'] = (_inside, '内包线突破')
SIG['squeeze'] = (_squeeze, 'TTM布林挤压')
SIG['bb_mr'] = (_bb_mr, '布林均值回归')
SIG['bb_brk'] = (_bb_brk, '布林突破')
SIG['atr_brk'] = (_atr_brk, 'ATR通道突破')
SIG['obv_x'] = (_obv_x, 'OBV穿越均线')
SIG['cmf'] = (_cmf_s, 'CMF资金流')
SIG['volspike'] = (_volspike, '量能突破')
for n in (3, 5):
    SIG[f'streakrev{n}'] = (lambda d, n=n: _streak(d, n, True), f'{n}连反向')
    SIG[f'streakmom{n}'] = (lambda d, n=n: _streak(d, n, False), f'{n}连跟随')
SIG['orb'] = (_orb, '开盘区间突破')
SIG['nr7'] = (_nr, '窄幅整理突破')
SIG['_cheat'] = (lambda d: pd.Series(np.sign(
    np.concatenate([d['close'].values[5:], d['close'].values[-5:]]) / d['close'].values - 1.0)), '负对照:故意前视')

# ================= 扩展引擎: 增加时间出场 =================
def backtest2(df, sig, s=0.05, R=2.0, cost_bp=COST_BP_MAKER, mode='flip',
              hold_max=12, slip_bp=0.0):
    o = df['open'].values; h = df['high'].values; l = df['low'].values
    sg = np.asarray(pd.Series(sig).values, dtype=float)
    n = len(o)
    cost_R = 2.0 * cost_bp / 1e4 / s
    slip = slip_bp / 1e4
    trades = []
    i = 0
    while i < n - 2:
        d = sg[i]
        if d == 0 or not np.isfinite(d):
            i += 1; continue
        entry = o[i+1]
        if not np.isfinite(entry) or entry <= 0:
            i += 1; continue
        stop = entry * (1 - s*d); targ = entry * (1 + R*s*d)
        j = i + 1; etype = None; exit_px = np.nan
        while j < n - 1:
            if mode in ('flip', 'target', 'stop_time'):
                hs = (l[j] <= stop) if d > 0 else (h[j] >= stop)
                if hs:
                    etype = 'stop'; exit_px = stop * (1 - slip*d); break
            if mode in ('target',):
                ht = (h[j] >= targ) if d > 0 else (l[j] <= targ)
                if ht:
                    etype = 'target'; exit_px = targ; break
            if mode in ('time', 'stop_time'):
                if (j - i) >= hold_max:
                    etype = 'time'; exit_px = o[j+1]; break
            if mode == 'flip':
                nd = sg[j]
                if np.isfinite(nd) and nd != 0 and nd != d:
                    etype = 'flip'; exit_px = o[j+1]; break
            j += 1
        if etype is None:
            etype = 'eod'; exit_px = o[-1]; j = n - 1
        ret = (exit_px / entry - 1.0) * d
        trades.append(dict(entry_i=i, exit_i=j, dir=d, entry=entry, exit=exit_px,
                           etype=etype, hold=j-i, gross_R=ret/s, net_R=ret/s - cost_R))
        i = j + 1
    return pd.DataFrame(trades)
