"""新增策略库评估: 全网格回测 -> OLD7排序 -> NEW6(干净样本外)验证 -> 跨品种t检验"""
import numpy as np, pandas as pd, sys, time, json
sys.path.insert(0, '/data/workspace/tb')
from tb_core import load_all
from tb_new import SIG, backtest2

OLD7 = ['DOGE', 'DOT', 'CRV', 'DASH', 'ETH', 'FIL', 'HBAR']   # 曾参与选择
NEW6 = ['TRX', 'UNI', 'XLM', 'XMR', 'XRP', 'ZEC']             # 干净, 从未参与
S, R, HOLD = 0.05, 2.0, 12
MODES = ['flip', 'target', 'time', 'stop_time']
COSTS = [('maker', 2.0), ('taker', 10.0)]

def main():
    data = load_all('1h')
    syms = [s for s in OLD7 + NEW6 if s in data]
    print(f"品种: {syms}\n")
    rows = []
    t0 = time.time()
    tot = len([k for k in SIG if k != '_cheat']) * len(MODES) * len(COSTS) * len(syms)
    cnt = 0
    for nm, (fn, desc) in SIG.items():
        if nm == '_cheat': continue
        for mode in MODES:
            for cname, cbp in COSTS:
                Es, Ns, holds = {}, {}, {}
                for sy in syms:
                    df = data[sy]
                    try:
                        sg = fn(df)
                        t = backtest2(df, sg, S, R, cbp, mode, hold_max=HOLD)
                    except Exception as e:
                        Es[sy] = np.nan; Ns[sy] = 0; holds[sy] = np.nan; continue
                    if len(t) < 20:
                        Es[sy] = np.nan; Ns[sy] = len(t); holds[sy] = np.nan; continue
                    Es[sy] = t.net_R.mean(); Ns[sy] = len(t); holds[sy] = t.hold.mean()
                    cnt += 1
                e_old = np.nanmean([Es[s] for s in OLD7 if s in Es])
                e_new = np.nanmean([Es[s] for s in NEW6 if s in Es])
                npos = int(sum(1 for s in syms if not np.isnan(Es.get(s, np.nan)) and Es[s] > 0))
                v_old = [Es[s] for s in OLD7 if s in Es and not np.isnan(Es[s])]
                v_new = [Es[s] for s in NEW6 if s in Es and not np.isnan(Es[s])]
                # 跨品种 t 检验 (n=13)
                v_all = [Es[s] for s in syms if s in Es and not np.isnan(Es[s])]
                tstat = np.nan
                if len(v_all) >= 5 and np.std(v_all, ddof=1) > 0:
                    tstat = np.mean(v_all)/np.std(v_all, ddof=1)*np.sqrt(len(v_all))
                tpy = np.mean([Ns[s]/(len(data[s])/8760.0) for s in syms if s in Ns and Ns[s] > 0])
                rows.append(dict(signal=nm, desc=desc, mode=mode, cost=cname,
                                 E_old=e_old, E_new=e_new, E_all=np.mean(v_all) if v_all else np.nan,
                                 npos=npos, ntot=len(v_all), t_cross=tstat,
                                 trades_yr=tpy, hold=np.nanmean(list(holds.values())),
                                 N_tot=int(np.nansum(list(Ns.values())))))
        if time.time() - t0 > 60:
            print(f"  ...{nm} done ({cnt}/{tot})", flush=True)
    res = pd.DataFrame(rows)
    res.to_csv('/data/workspace/tb/new_grid.csv', index=False)
    print(f"\n完成 {len(res)} 组合, 耗时 {time.time()-t0:.0f}s\n")

    # ---- 排序: OLD7 选出的 top, 看 NEW6 ----
    print("="*100)
    print("【排序阶段】按 OLD7(参与过选择) 的 E 排序, 看其在 NEW6(干净样本外) 的表现")
    print("="*100)
    for cname in ['maker', 'taker']:
        sub = res[res.cost == cname].sort_values('E_old', ascending=False)
        print(f"\n--- 成本 {cname} ---")
        print(f"{'signal':12s} {'mode':10s} {'E_old':>8s} {'E_new':>8s} {'衰减':>7s} {'正/总':>6s} {'t跨品种':>8s} {'笔/年':>8s}")
        for _, r in sub.head(12).iterrows():
            dec = (r.E_new/r.E_old) if (r.E_old not in (0,) and not np.isnan(r.E_old) and r.E_old != 0) else np.nan
            print(f"{r.signal:12s} {r.mode:10s} {r.E_old:+8.4f} {r.E_new:+8.4f} "
                  f"{(f'{dec*100:6.0f}%' if not np.isnan(dec) else '   NA')} "
                  f"{r.npos:2d}/{r.ntot:<3d} {r.t_cross:+8.2f} {r.trades_yr:8.0f}")

    # ---- 干净样本外独立排序 ----
    print("\n" + "="*100)
    print("【验证阶段】直接在 NEW6(从未参与任何选择) 上排序 —— 这是最干净的口径")
    print("="*100)
    for cname in ['maker', 'taker']:
        sub = res[res.cost == cname].sort_values('E_new', ascending=False)
        print(f"\n--- 成本 {cname} ---")
        print(f"{'signal':12s} {'mode':10s} {'E_new':>8s} {'E_all':>8s} {'正/总':>6s} {'t跨品种':>8s} {'笔/年':>8s} {'持仓':>6s}")
        for _, r in sub.head(12).iterrows():
            print(f"{r.signal:12s} {r.mode:10s} {r.E_new:+8.4f} {r.E_all:+8.4f} "
                  f"{r.npos:2d}/{r.ntot:<3d} {r.t_cross:+8.2f} {r.trades_yr:8.0f} {r.hold:6.1f}")
    return res

if __name__ == '__main__':
    main()
