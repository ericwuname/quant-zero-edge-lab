"""对唯一幸存者 vwap_tr168 做终极检验 + 不复利/盈余公积收割模拟"""
import numpy as np, pandas as pd, sys, time
sys.path.insert(0, '/data/workspace/tb')
from tb_core import load_all
from tb_new import SIG, backtest2

S, R, HOLD, COST = 0.05, 2.0, 12, 2.0   # maker
CAND = [('vwap_tr168','flip'), ('squeeze','flip'), ('vwap_tr96','flip')]
SYMS = ['DOGE','DOT','CRV','DASH','ETH','FIL','HBAR','TRX','UNI','XLM','XMR','XRP','ZEC']

def run_combo(data, nm, mode, syms=SYMS, shift_seed=None):
    fn = SIG[nm][0]; out = {}
    for sy in syms:
        df = data[sy]; sg = fn(df)
        if shift_seed is not None:     # 循环平移: 保留自相关, 破坏与收益的对齐
            k = shift_seed[sy] if isinstance(shift_seed, dict) else shift_seed
            sg = pd.Series(np.roll(np.asarray(sg.values), k))
        t = backtest2(df, sg, S, R, COST, mode, hold_max=HOLD)
        out[sy] = t
    return out

def main():
    data = load_all('1h')
    print("="*100); print("【检验1】候选策略逐品种 + 多空比 + 时间切分 + 暴露匹配买入持有"); print("="*100)
    for nm, mode in CAND:
        res = run_combo(data, nm, mode)
        Es = [res[s].net_R.mean() for s in SYMS if len(res[s]) > 20]
        longs = [ (res[s].dir>0).mean() for s in SYMS if len(res[s])>20]
        N = sum(len(res[s]) for s in SYMS)
        e_all = np.mean(Es); tstat = np.mean(Es)/np.std(Es,ddof=1)*np.sqrt(len(Es))
        # 时间切分
        h1 = np.mean([res[s].iloc[:len(res[s])//2].net_R.mean() for s in SYMS if len(res[s])>20])
        h2 = np.mean([res[s].iloc[len(res[s])//2:].net_R.mean() for s in SYMS if len(res[s])>20])
        # 暴露匹配 BH:  exposure = f/s ; f=0.02 -> e=0.4
        f = 0.02; e = f/S
        strat_ret = f*np.mean([res[s].net_R.sum() for s in SYMS if len(res[s])>20])
        bh = np.mean([(data[s]['close'].iloc[-1]/data[s]['close'].iloc[0]-1) for s in SYMS])*e
        print(f"\n{nm}/{mode}:  E_all={e_all:+.4f}  t跨品种={tstat:+.2f}  正={sum(1 for x in Es if x>0)}/{len(Es)}  N={N}")
        print(f"   多头占比均值={np.mean(longs)*100:.1f}%   前半={h1:+.4f} 后半={h2:+.4f}")
        print(f"   策略总收益(f=2%,s=5%→敞口{e:.0%}) = {strat_ret*100:+.1f}%   同期暴露匹配买入持有 = {bh*100:+.1f}%")

    print("\n"+"="*100); print("【检验2】循环平移置换检验 (vwap_tr168): 保留信号自相关, 破坏与收益对齐"); print("="*100)
    nm, mode = 'vwap_tr168','flip'
    base = run_combo(data, nm, mode)
    real = np.mean([base[s].net_R.mean() for s in SYMS])
    rng = np.random.default_rng(7); null = []
    for b in range(30):
        shifts = {s: int(rng.integers(200, len(data[s])-200)) for s in SYMS}
        r = run_combo(data, nm, mode, shift_seed=shifts)
        null.append(np.mean([r[s].net_R.mean() for s in SYMS]))
    null = np.array(null)
    p = (np.sum(null >= real) + 1)/(len(null)+1)
    print(f"真实 E = {real:+.5f}")
    print(f"零分布: mean={null.mean():+.5f} sd={null.std():.5f} max={null.max():+.5f}")
    print(f"置换 p 值 = {p:.4f}  ->  {'显著' if p<0.05 else '不显著'}")

    print("\n"+"="*100); print("【检验3】不复利 + 盈余公积收割模拟 (vwap_tr168, 13品种并行)"); print("="*100)
    seq = np.concatenate([base[s].net_R.values for s in SYMS if len(base[s])>20])
    seq = seq[np.isfinite(seq)]
    tpy = np.mean([len(base[s])/(len(data[s])/8760.0) for s in SYMS if len(base[s])>20])*len(SYMS)
    print(f"交易序列: N={len(seq)}  E={seq.mean():+.4f}R  sd={seq.std():.3f}  年交易={tpy:.0f}")
    base0 = seq - seq.mean() + 0.0    # 零期望对照(仅去均值, 保留形状)
    print(f"零期望对照: E={base0.mean():+.6f}R (用于分离'几何白送'与'真实edge')\n")

    def harvest(seqx, f, T, years=3, npath=2000, seed=1):
        nmax = int(min(len(seqx), tpy*years))
        rng = np.random.default_rng(seed)
        C0 = 10000.0; BUST = 0.2
        ok = 0; finals = []; busts = 0; times = []
        for _ in range(npath):
            idx = rng.integers(0, len(seqx), size=nmax)
            eq = C0; reserve = 0.0; done_at = None
            for i, r in enumerate(seqx[idx]):
                if eq <= 0: break
                eq += f*C0*r                      # 固定注: 不复利
                if eq <= BUST*C0:                 # 爆仓
                    reserve += max(eq, 0.0); eq = 0.0
                    if reserve >= C0: reserve -= C0; eq = C0   # 公积金开新店
                    else: break
                if eq >= C0*(1+T):                # 收割
                    reserve += eq - C0; eq = C0
                if reserve >= C0 and done_at is None: done_at = i+1
            if done_at is None and reserve >= C0: done_at = nmax
            if reserve >= C0: ok += 1
            if eq <= 0: busts += 1
            finals.append(reserve + eq - C0)
            times.append(done_at if done_at else nmax)
        return ok/npath, np.median(finals), busts/npath, np.median(times)/max(tpy,1)

    print(f"{'仓位f':>6s} {'收割T':>6s} {'P(赚回本金)':>12s} {'盈亏中位':>10s} {'爆仓率':>8s} {'用时(年)':>9s}")
    for f in (0.01, 0.02, 0.03, 0.05):
        for T in (0.5, 1.0):
            p_, m_, b_, tt = harvest(seq, f, T)
            print(f"{f:6.0%} {T:6.0%} {p_:12.1%} {m_:10.0f} {b_:8.1%} {tt:9.2f}")
    print("\n--- 零期望对照 (同样的波动形状, 期望=0) : 分离'几何白送'与'真实edge' ---")
    print(f"{'仓位f':>6s} {'收割T':>6s} {'P(赚回本金)':>12s} {'盈亏中位':>10s} {'爆仓率':>8s}")
    for f in (0.01, 0.02, 0.03, 0.05):
        for T in (0.5, 1.0):
            p_, m_, b_, _ = harvest(base0, f, T)
            print(f"{f:6.0%} {T:6.0%} {p_:12.1%} {m_:10.0f} {b_:8.1%}")
    print("\n--- taker(10bp) 成本下的同一策略 ---")
    seqT = np.concatenate([backtest2(data[s], SIG[nm][0](data[s]), S, R, 10.0, mode, hold_max=HOLD).net_R.values for s in SYMS])
    seqT = seqT[np.isfinite(seqT)]
    print(f"E={seqT.mean():+.4f}R  (maker时为{seq.mean():+.4f})")
    for f in (0.01, 0.02):
        p_, m_, b_, _ = harvest(seqT, f, 1.0)
        print(f"  f={f:.0%} T=100%: P(赚回本金)={p_:6.1%} 盈亏中位={m_:8.0f} 爆仓={b_:6.1%}")

if __name__ == '__main__':
    main()
