"""新引擎与信号库的可信性验证: 零漂移已知答案测试 + canary 前视探测"""
import numpy as np, pandas as pd, glob, sys
sys.path.insert(0, '/data/workspace/tb')
from tb_core import _sig_cheat
from tb_selftest import synth
from tb_new import SIG, backtest2

RES = []
def chk(name, ok, detail=''):
    RES.append((name, bool(ok))); print(f"[{'PASS' if ok else 'FAIL'}] {name}  {detail}")

def main():
    df = pd.read_csv(sorted(glob.glob('/data/inputs/*_1h.csv'))[0]).dropna(
        subset=['open','high','low','close']).reset_index(drop=True).iloc[:20000]
    n = len(df); s, R = 0.05, 2.0

    # --- A. 新引擎在零漂移合成数据上必须无偏 ---
    for mode in ('target', 'time'):
        for k in (1, 2):
            sd = synth(seed=k, n=20000)
            r = np.random.default_rng(11)
            srr = pd.Series(r.choice([-1., 1.], len(sd)))
            tt = backtest2(sd, srr, s, R, 0.0, mode, hold_max=12)
            e = tt.gross_R.mean(); se = tt.gross_R.std()/np.sqrt(len(tt))
            chk(f'A 零漂移 随机 {mode} E≈0 (seed{k})', abs(e/se) < 2.5,
                f"E={e:+.5f} t={e/se:+.2f} N={len(tt)}")

    # --- B. 成交价必须仍是 open[t+1] ---
    sg = pd.Series(np.zeros(n)); sg.iloc[500] = 1
    for mode in ('flip', 'target', 'time', 'stop_time'):
        t = backtest2(df, sg, s, R, 2.0, mode, hold_max=12)
        ok = len(t) > 0 and abs(t.iloc[0]['entry'] - df['open'].iloc[501])/df['open'].iloc[501] < 1e-9
        chk(f'B 成交价=open[t+1] ({mode})', ok, f"entry={t.iloc[0]['entry'] if len(t) else 'NA'}")

    # --- C. canary 必须抓出故意前视 (负对照) ---
    bad, tot = __import__('tb_core').canary_truncate(lambda d: _sig_cheat(d, 5), df, 20, seed=1)
    d2, m2 = __import__('tb_core').canary_shuffle(lambda d: _sig_cheat(d, 5), df, seed=1)
    chk('C 负对照 cheat 被抓(truncate)', bad > 0, f'bad={bad}/{tot}')
    chk('C 负对照 cheat 被抓(shuffle)', d2 > 0, f'diff={d2}/{m2}')

    # --- D. canary 必须放行所有新增干净信号 ---
    print('\n--- canary 逐个信号 ---')
    caught = []
    for nm, (fn, _) in SIG.items():
        if nm == '_cheat':
            continue
        try:
            b, t_ = __import__('tb_core').canary_truncate(fn, df, 12, seed=2)
            d_, m_ = __import__('tb_core').canary_shuffle(fn, df, seed=2)
            ok = (b == 0 and d_ == 0)
            if not ok:
                caught.append(nm)
            print(f"   {'OK ' if ok else 'LEAK'} {nm:12s} trunc={b}/{t_} shuf={d_}/{m_}")
        except Exception as e:
            caught.append(nm); print(f"   ERR {nm:12s} {e}")
    chk('D 所有新信号无前视', len(caught) == 0, f'leaked={caught}')

    # --- E. 信号长度与值域 ---
    bad_len = []
    for nm, (fn, _) in SIG.items():
        if nm == '_cheat': continue
        v = np.asarray(pd.Series(fn(df)).values, dtype=float)
        if len(v) != n or not np.all(np.isfinite(v)):
            bad_len.append(nm)
    chk('E 信号长度/值域合法', len(bad_len) == 0, f'bad={bad_len}')

    ok = all(r[1] for r in RES)
    print(f"\n==== 新引擎/信号库验证 {'ALL PASS' if ok else 'HAS FAILURE'} ({sum(r[1] for r in RES)}/{len(RES)}) ====")
    return ok

if __name__ == '__main__':
    main()
