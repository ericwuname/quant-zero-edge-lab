import numpy as np, pandas as pd, glob, os
import tb_core as T
NEW6=['TRX','UNI','XLM','XMR','XRP','ZEC']
D={}
for f in sorted(glob.glob(T.DATA+'*_1h.csv')):
    nm=os.path.basename(f).split('_')[0].replace('USDT','')
    if nm in NEW6: D[nm]=pd.read_csv(f).dropna(subset=['open','high','low','close']).reset_index(drop=True)

def bench(sig_name, fn, cost_bp, mode='flip'):
    rows=[]
    for s in NEW6:
        df=D[s]; sg=fn(df)
        tb=T.backtest(df,sg,0.05,2.0,cost_bp,mode)
        if len(tb)<20: continue
        o=df['open'].values
        n=len(tb); hold=tb.hold.sum()
        bh=np.exp(np.log(o[1:]/o[:-1]).sum()*hold/len(o))-1   # 同暴露的持有
        rows.append(dict(sym=s,N=n,E=tb.net_R.mean(),
                         equity=np.prod(1+tb.net_R.values*0.01)-1, bh=bh))
    return pd.DataFrame(rows)

def harvest(seqs, f=0.02, C0=10000, n_tr=1500, nsim=400, T_harv=1.0, ruin=0.2, seed=0):
    rng=np.random.default_rng(seed)
    finals=np.zeros(nsim); harv=np.zeros(nsim)
    for k in range(nsim):
        W=C0; got=0.0; alive=True
        for _ in range(n_tr):
            if not alive: break
            W += C0*f*rng.choice(seqs)
            if W >= C0*(1+T_harv): got += W-C0; W = C0
            if W <= C0*ruin: alive=False
        finals[k]=W-C0; harv[k]=got
    return dict(P_recover=float(np.mean(harv>=C0)), med_final=float(np.median(finals)),
                med_harv=float(np.median(harv)), ruin=float(np.mean(finals<=-C0*0.79)))

print('===== brk50 在干净 NEW6 上的终极基准 =====')
for cost,lab in [(2.0,'maker 2bp'),(10.0,'taker 10bp')]:
    for mode in ['flip','target']:
        r=bench('brk50', lambda d:T._sig_brk(d,50), cost, mode)
        if len(r)==0: continue
        eqm=r['equity'].median(); bhm=r.bh.median(); win=int((r['equity']>r.bh).sum())
        print(f'  [{lab} {mode}] N={r.N.sum()} E={r.E.mean():+.4f}R  净值中位={eqm:+.1%}  同暴露持有={bhm:+.1%}  跑赢持有={win}/{len(r)}')

print('\n===== 收割制模拟 (本金1万, 固定注f, 翻倍即收割, 20%爆仓线) =====')
sg=lambda d:T._sig_brk(d,50)
allR=[]
for s in NEW6:
    tb=T.backtest(D[s],sg(D[s]),0.05,2.0,2.0,'flip')
    allR+=list(tb.net_R.values)
allR=np.array(allR); print(f'  池化序列 N={len(allR)} E={allR.mean():+.4f}R sd={allR.std():.3f}')
for f in [0.01,0.02,0.03]:
    h=harvest(allR,f=f)
    print(f'  f={f:.0%}: P(赚回本金)={h["P_recover"]:.1%}  落袋中位={h["med_harv"]:,.0f}  账户终值中位={h["med_final"]:+,.0f}  爆仓={h["ruin"]:.1%}')
# 零期望对照
rng=np.random.default_rng(1); zero=rng.choice(allR,len(allR),replace=False)
z0=allR-allR.mean()
for f in [0.02]:
    h=harvest(z0,f=f)
    print(f'  [零期望对照 f={f:.0%}]: P(赚回本金)={h["P_recover"]:.1%}  落袋中位={h["med_harv"]:,.0f}')
