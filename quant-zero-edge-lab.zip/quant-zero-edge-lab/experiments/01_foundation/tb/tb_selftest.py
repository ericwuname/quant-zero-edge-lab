"""已知答案的单元测试 v2 — 用零漂移合成数据验证引擎无偏性"""
import numpy as np, pandas as pd, glob
from tb_core import *
from tb_core import _sig_mom,_sig_ma,_sig_brk,_sig_xab,_sig_flat,_sig_long,_sig_cheat

def synth(n=30000, sigma=0.012, seed=0, sub=4):
    """零漂移 GBM, 每bar细分sub步生成真实 high/low -> 严格鞅"""
    rng=np.random.default_rng(seed)
    z=rng.standard_normal((n,sub))*sigma/np.sqrt(sub)
    steps=np.exp(-0.5*(sigma/np.sqrt(sub))**2 + z)   # 无漂移
    path=np.ones((n,sub+1))
    c=100.0
    for i in range(n):
        path[i,0]=c
        for k in range(sub):
            c*=steps[i,k]; path[i,k+1]=c
    o=path[:,0]; cl=path[:,-1]; h=path.max(axis=1); l=path.min(axis=1)
    return pd.DataFrame(dict(timestamp=np.arange(n)*3600000,open=o,high=h,low=l,close=cl,volume=np.ones(n)))

RES=[]
def chk(name, ok, detail=''):
    RES.append((name,bool(ok))); print(f"[{'PASS' if ok else 'FAIL'}] {name}  {detail}")

def main():
    df=pd.read_csv(sorted(glob.glob(DATA+'*_1h.csv'))[0]).dropna(subset=['open','high','low','close']).reset_index(drop=True).iloc[:20000]
    n=len(df); s,R=0.05,2.0

    # T1 空仓无交易
    chk('T1 空仓无交易', len(backtest(df,_sig_flat(df),s,R,2.0,'flip'))==0, 'trades=0')

    # T2 成交价必须是 open[t+1]
    sgm=pd.Series(np.zeros(n)); sgm.iloc[500]=1
    t=backtest(df,sgm,s,R,2.0,'flip')
    ok=len(t)>0 and abs(t.iloc[0]['entry']-df['open'].iloc[501])/df['open'].iloc[501]<1e-9
    chk('T2 成交价=open[t+1]', ok, f"entry={t.iloc[0]['entry'] if len(t) else 'NA'} vs {df['open'].iloc[501]}")

    # T3 恒多+不可能触发的止损止盈 -> 单笔 = 买入持有
    t=backtest(df,_sig_long(df),10.0,100.0,2.0,'flip')
    bh=(df['open'].iloc[-1]/df['open'].iloc[1]-1)/10.0; cost=2*2.0/1e4/10.0
    chk('T3 恒多=持有-成本', abs(t['net_R'].mean()-(bh-cost))<1e-6, f"E={t['net_R'].mean():.6f} 期望={bh-cost:.6f} tr={len(t)}")

    # T4a 零漂移 + target模式(纯鞅性) 随机信号 -> E=0   [引擎无偏的决定性检验]
    for k in (1,2,3):
        sd_=synth(seed=k); r=np.random.default_rng(11)
        srr=pd.Series(r.choice([-1.,1.],len(sd_)))
        tt=backtest(sd_,srr,s,R,0.0,'target')
        e=tt.gross_R.mean(); se=tt.gross_R.std()/np.sqrt(len(tt))
        chk(f'T4a 零漂移 随机 target E≈0 (seed{k})', abs(e/se)<2.5, f"E={e:+.5f} t={e/se:+.2f} N={len(tt)}")

    # T4b 零漂移 + flip模式: 干净信号E - 随机信号E ≈ 0  [策略评估真正需要的相对无偏]
    for k in (1,2):
        sd_=synth(seed=k); r=np.random.default_rng(11)
        srr=pd.Series(r.choice([-1.,1.],len(sd_)))
        base=backtest(sd_,srr,s,R,0.0,'flip').gross_R.mean()
        for nm,fn in [('mom20',lambda d:_sig_mom(d,20)),('ma50',lambda d:_sig_ma(d,50))]:
            tt=backtest(sd_,fn(sd_),s,R,0.0,'flip')
            e=tt.gross_R.mean(); se=tt.gross_R.std()/np.sqrt(len(tt))
            chk(f'T4b 零漂移 {nm}-随机 ≈0 (seed{k})', abs((e-base)/se)<2.5,
                f"sig={e:+.5f} rand={base:+.5f} diff={e-base:+.5f} t={(e-base)/se:+.2f}")

    # T5 零漂移合成: 干净信号 -> E=0
    for k in (1,2):
        sd_=synth(seed=k)
        for nm,fn in [('mom20',lambda d:_sig_mom(d,20)),('ma50',lambda d:_sig_ma(d,50))]:
            tt=backtest(sd_,fn(sd_),s,R,0.0,'flip')
            e=tt.gross_R.mean(); se=tt.gross_R.std()/np.sqrt(len(tt))
            chk(f'T5 零漂移 {nm} E≈0 (seed{k})', abs(e/se)<2.0, f"E={e:+.5f} t={e/se:+.2f} N={len(tt)}")

    # T6 canary 必须抓出故意前视
    bad,tot=canary_truncate(lambda d:_sig_cheat(d,5), df, 25, seed=1)
    d2,m2=canary_shuffle(lambda d:_sig_cheat(d,5), df, seed=1)
    chk('T6 canary抓前视(truncate)', bad>0, f'bad={bad}/{tot}')
    chk('T6b canary抓前视(shuffle)', d2>0, f'diff={d2}/{m2}')

    # T7 canary 放行干净信号
    for nm,fn in [('mom20',lambda d:_sig_mom(d,20)),('ma200',lambda d:_sig_ma(d,200)),
                  ('brk20',lambda d:_sig_brk(d,20)),('xab20_100',lambda d:_sig_xab(d,20,100))]:
        bad,tot=canary_truncate(fn, df, 25, seed=2); d2,m2=canary_shuffle(fn, df, seed=2)
        chk(f'T7 canary放行 {nm}', bad==0 and d2==0, f'trunc={bad}/{tot} shuf={d2}/{m2}')

    # T8 成本单调
    sg=_sig_mom(df,20); es=[backtest(df,sg,s,R,c,'flip')['net_R'].mean() for c in [0,2,10,20]]
    chk('T8 成本单调递减', all(es[i]>es[i+1] for i in range(3)), f"E={[round(float(x),4) for x in es]}")

    # T9 同bar双触及 -> 保守止损
    d=pd.DataFrame(dict(timestamp=[0,1,2,3],open=[100.]*4,high=[100.,130.,100.,100.],
                        low=[100.,80.,100.,100.],close=[100.]*4,volume=[1.]*4))
    t=backtest(d,pd.Series([1.,1.,1.,1.]),0.10,2.0,0.0,'target')
    chk('T9 同bar双触及=止损', len(t)>0 and t.iloc[0]['etype']=='stop', f"etype={t.iloc[0]['etype'] if len(t) else 'NA'}")

    # T10 止损单 gross_R ≈ -1
    t=backtest(df,_sig_mom(df,5),s,R,2.0,'flip'); st=t[t.etype=='stop']
    chk('T10 止损单 R≈-1', abs(st['gross_R'].mean()+1)<0.02, f"gross={st['gross_R'].mean():+.4f} n={len(st)}")

    # T11 信号只依赖历史
    half=df.iloc[:n//2].reset_index(drop=True)
    a=_sig_mom(df,20).values[:n//2]; b=_sig_mom(half,20).values
    chk('T11 信号只依赖历史', int(np.nansum(a!=b))==0, f'diff={int(np.nansum(a!=b))}')

    # T12 置换检验零假设可用: 真实信号 vs 打乱符号
    sg=_sig_mom(df,20); t=backtest(df,sg,s,R,2.0,'flip'); e0=t.net_R.mean()
    perm=[]
    rng=np.random.default_rng(3)
    for _ in range(30):
        v=sg.values.copy(); rng.shuffle(v)
        perm.append(backtest(df,pd.Series(v),s,R,2.0,'flip').net_R.mean())
    chk('T12 置换零分布可用', len(perm)==30 and np.std(perm)>0, f"real={e0:+.4f} perm_mean={np.mean(perm):+.4f} perm_sd={np.std(perm):.4f}")

    ok=all(r[1] for r in RES)
    print(f"\n==== 单元测试 {'ALL PASS' if ok else 'HAS FAILURE'} ({sum(r[1] for r in RES)}/{len(RES)}) ====")
    return ok

if __name__=='__main__': main()
