"""读取网格结果, 输出排序/验证报告 (规避属性访问问题)"""
import numpy as np, pandas as pd

OLD7 = ['DOGE','DOT','CRV','DASH','ETH','FIL','HBAR']
NEW6 = ['TRX','UNI','XLM','XMR','XRP','ZEC']
res = pd.read_csv('/data/workspace/tb/new_grid.csv')

def f(x, w=8, d=4):
    try: return f"{float(x):+{w}.{d}f}"
    except Exception: return "NA".rjust(w)

print("="*104)
print("【阶段1】在 OLD7(曾参与选择) 上排序 -> 看 NEW6(干净样本外) 是否守住")
print("="*104)
for cn in ['maker','taker']:
    sub = res[res['cost']==cn].sort_values('E_old', ascending=False)
    print(f"\n--- 成本 {cn} ---")
    print(f"{'signal':12s} {'mode':11s} {'E_old':>9s} {'E_new':>9s} {'保留':>7s} {'正/总':>7s} {'t跨品种':>9s} {'笔/年':>9s}")
    for _, r in sub.head(14).iterrows():
        eo, en = float(r['E_old']), float(r['E_new'])
        keep = f"{en/eo*100:6.0f}%" if abs(eo) > 1e-9 else "    NA"
        print(f"{str(r['signal']):12s} {str(r['mode']):11s} {f(eo,9)} {f(en,9)} {keep:>7s} "
              f"{int(r['npos']):2d}/{int(r['ntot']):<3d} {f(r['t_cross'],9,2)} {float(r['trades_yr']):9.0f}")

print("\n"+"="*104)
print("【阶段2】直接在 NEW6(从未参与任何选择) 上排序 —— 最干净的口径")
print("="*104)
for cn in ['maker','taker']:
    sub = res[res['cost']==cn].sort_values('E_new', ascending=False)
    print(f"\n--- 成本 {cn} ---")
    print(f"{'signal':12s} {'mode':11s} {'E_new':>9s} {'E_all':>9s} {'正/总':>7s} {'t跨品种':>9s} {'笔/年':>9s} {'持仓bar':>8s}")
    for _, r in sub.head(14).iterrows():
        print(f"{str(r['signal']):12s} {str(r['mode']):11s} {f(r['E_new'],9)} {f(r['E_all'],9)} "
              f"{int(r['npos']):2d}/{int(r['ntot']):<3d} {f(r['t_cross'],9,2)} {float(r['trades_yr']):9.0f} {float(r['hold']):8.1f}")

# 显著门槛
print("\n"+"="*104)
print("【阶段3】跨品种 t 检验: |t|>1.96 的组合 (未校正多重检验)")
print("="*104)
sig_rows = res[res['t_cross'].abs() > 1.96].sort_values('t_cross', ascending=False)
if len(sig_rows) == 0:
    print("  无任何组合 |t|>1.96")
else:
    print(f"{'signal':12s} {'mode':11s} {'cost':6s} {'E_all':>9s} {'t':>7s} {'正/总':>7s}")
    for _, r in sig_rows.iterrows():
        print(f"{str(r['signal']):12s} {str(r['mode']):11s} {str(r['cost']):6s} {f(r['E_all'],9)} {f(r['t_cross'],7,2)} {int(r['npos']):2d}/{int(r['ntot']):<3d}")
print(f"\n(|t|>1.96 组合数: {len(sig_rows)} / {len(res)}; 随机期望约 {len(res)*0.05:.1f})")

# 负向: 确定亏钱
print("\n"+"="*104)
print("【阶段4】显著为负的组合 (t < -1.96) —— 确定亏钱规律")
print("="*104)
neg = res[res['t_cross'] < -1.96].sort_values('t_cross')
print(f"{'signal':12s} {'mode':11s} {'cost':6s} {'E_all':>9s} {'t':>7s} {'正/总':>7s}")
for _, r in neg.head(15).iterrows():
    print(f"{str(r['signal']):12s} {str(r['mode']):11s} {str(r['cost']):6s} {f(r['E_all'],9)} {f(r['t_cross'],7,2)} {int(r['npos']):2d}/{int(r['ntot']):<3d}")
print(f"\n(t<-1.96 组合数: {len(neg)} / {len(res)})")
