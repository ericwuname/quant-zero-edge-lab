"""
用户锁死规格的最终扫描
固定项：R=2, 风险1%/笔(以损定量), 趋势信号(当前周期1h), 止损限价必成交(slip=0),
        混合成本 cost_R ∈ {0.05, 0.10}, 爆仓线=亏完(净值<=0), 不复利+收割
扫描项：冷却期 {0,5,20,60} × 止损 {1.5,2,3,4,5}%
"""
import numpy as np, pandas as pd, os, sys, json

SYMS = ['DOGE','DOT','CRV','DASH','ETH','FIL','HBAR','TRX','UNI','XLM','XMR','XRP','ZEC']
OLD7 = ['DOGE','DOT','CRV','DASH','ETH','FIL','HBAR']
NEW6 = ['TRX','UNI','XLM','XMR','XRP','ZEC']
BARS_PER_YEAR = 8760.0


def load(sym):
    df = pd.read_csv(f'/data/inputs/{sym}USDT_1h.csv')
    return (df['open'].values, df['high'].values, df['low'].values,
            df['close'].values, df['quoteVolume'].values)


def mom_signal(c, L):
    """sig[t] 只用 close[0..t-1]，在 open[t] 入场 -> 无前视"""
    n = len(c)
    a = c[:-1]                      # a[j]=c[j]
    num = a[L:n-1]
    den = c[0:n-1-L]
    m = np.full(n, np.nan)
    m[L+1:n] = num / den - 1.0
    s = np.zeros(n)
    ok = ~np.isnan(m)
    s[ok] = np.sign(m[ok])
    return s


def bracket(o, h, l, c, sig, stop_pct, R, cooldown=0):
    """带冷却期的止损止盈括号单。同bar双触及->判止损(保守)。
    平仓后 cooldown 根 bar 内不再入场（修复同bar平仓再入场的bug）。"""
    n = len(o)
    tr, ty, ti = [], [], []
    cur = 0.0; entry = 0.0; stop_px = 0.0; tgt_px = 0.0
    last_exit = -10**9

    def close(px, kind, i):
        tr.append((px - entry) * cur / abs(entry) / stop_pct)
        ty.append(kind); ti.append(i)
        return 0.0

    for i in range(1, n):
        closed = False
        if cur != 0:
            if cur > 0:
                hs, ht = l[i] <= stop_px, h[i] >= tgt_px
            else:
                hs, ht = h[i] >= stop_px, l[i] <= tgt_px
            if hs:
                cur = close(stop_px, 0, i); closed = True; last_exit = i
            elif ht:
                cur = close(tgt_px, 1, i); closed = True; last_exit = i
            elif i == n - 1:
                cur = close(c[i], -1, i); closed = True; last_exit = i
        if cur == 0.0 and not closed and sig[i] != 0 and i < n - 1:
            if i - last_exit >= cooldown:
                cur = float(np.sign(sig[i])); entry = o[i]
                stop_px = entry * (1 - cur * stop_pct)
                tgt_px = entry * (1 + cur * R * stop_pct)
                if cur > 0:
                    hs, ht = l[i] <= stop_px, h[i] >= tgt_px
                else:
                    hs, ht = h[i] >= stop_px, l[i] <= tgt_px
                if hs:
                    cur = close(stop_px, 0, i); last_exit = i
                elif ht:
                    cur = close(tgt_px, 1, i); last_exit = i
    if cur != 0:
        tr.append((c[-1] - entry) * cur / abs(entry) / stop_pct); ty.append(-1); ti.append(n - 1)
    return np.asarray(tr), np.asarray(ty), np.asarray(ti)


CACHE = {}
def get(sym):
    if sym not in CACHE:
        CACHE[sym] = load(sym)
    return CACHE[sym]


def run_one(sym, L, stop_pct, R, cooldown):
    o, h, l, c, qv = get(sym)
    sig = mom_signal(c, L)
    tr, ty, ti = bracket(o, h, l, c, sig, stop_pct, R, cooldown)
    yrs = len(o) / BARS_PER_YEAR
    return dict(sym=sym, N=len(tr), freq=len(tr) / yrs,
                win=float(np.mean(tr > 0)) if len(tr) else np.nan,
                gross=float(np.mean(tr)) if len(tr) else np.nan,
                yrs=yrs, tr=tr)


def cross_t(vals):
    v = np.asarray([x for x in vals if np.isfinite(x)])
    if len(v) < 2: return np.nan, np.nan, len(v)
    m = v.mean(); se = v.std(ddof=1) / np.sqrt(len(v))
    return m, (m / se if se > 0 else np.nan), len(v)


def main():
    R = 2.0
    L = 120
    stops = [0.015, 0.02, 0.03, 0.04, 0.05]
    cds = [0, 5, 20, 60]
    rows = []
    for cd in cds:
        for sp in stops:
            per = {}
            for sym in SYMS:
                per[sym] = run_one(sym, L, sp, R, cd)
            g_all = [per[s]['gross'] for s in SYMS]
            m_all, t_all, _ = cross_t(g_all)
            m_o, t_o, _ = cross_t([per[s]['gross'] for s in OLD7])
            m_n, t_n, _ = cross_t([per[s]['gross'] for s in NEW6])
            N_tot = sum(per[s]['N'] for s in SYMS)
            yrs = np.mean([per[s]['yrs'] for s in SYMS])
            pos_old = sum(1 for s in OLD7 if per[s]['gross'] > 0)
            pos_new = sum(1 for s in NEW6 if per[s]['gross'] > 0)
            rows.append(dict(cd=cd, stop=sp, N=N_tot, freq=N_tot / (yrs * len(SYMS)),
                             gross=m_all, t=t_all, gross_old=m_o, t_old=t_o,
                             gross_new=m_n, t_new=t_n, pos_old=pos_old, pos_new=pos_new,
                             yrs=yrs))
            print(f"cd={cd:3d} stop={sp*100:4.1f}%  N={N_tot:7d} freq={N_tot/(yrs*len(SYMS)):8.1f}/yr "
                  f"gross={m_all:+.4f} t={t_all:+5.2f} | OLD7 {m_o:+.4f}(t{t_o:+5.2f}) "
                  f"NEW6 {m_n:+.4f}(t{t_n:+5.2f}) | pos {pos_old}/7 {pos_new}/6", flush=True)
    df = pd.DataFrame(rows)
    df.to_csv('/data/workspace/final_spec/grid.csv', index=False)
    print("\nsaved grid.csv")


if __name__ == '__main__':
    main()
