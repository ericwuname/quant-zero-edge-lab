"""
成本矩阵：cost_R = 2*cost_bp/(s*1e4)
把「成交方式 × 止损宽度」一起看，因为二者共同决定 cost_R，不是独立假设
"""
import numpy as np, pandas as pd

df = pd.read_csv('/data/workspace/final_spec/robust.csv')

# 各止损宽度下的 gross（跨 L∈{60,120}, cd∈{5,60} 平均，避免挑参数）
sub = df[(df.L.isin([60, 120])) & (df.cd.isin([5, 60]))]
agg = sub.groupby('stop')['gross'].agg(['mean', 'max', 'count'])
print("=" * 92)
print("【A】各止损宽度的毛收益（跨 L=60/120 × cd=5/60 共4个配置的平均，不挑参数）")
print("=" * 92)
print(agg.to_string())

print()
print("=" * 92)
print("【B】成本矩阵：净E = 毛收益 − cost_R")
print("=" * 92)
costs = {'maker 全限价 2bp': 2.0, '混合 5bp': 5.0, 'taker 市价 10bp': 10.0}
stops = [0.02, 0.03, 0.05]
rows = []
for name, bp in costs.items():
    for s in stops:
        cost_R = 2 * bp / (s * 1e4)
        g = agg.loc[s, 'mean']
        net = g - cost_R
        rows.append(dict(成交=name, 止损=f"{s*100:.0f}%", cost_R=round(cost_R, 4),
                         毛收益=round(g, 4), 净E=round(net, 4),
                         判定="✅正" if net > 0 else "❌负"))
m = pd.DataFrame(rows)
print(m.to_string(index=False))

print()
print("=" * 92)
print("【C】你的 cost_R 假设反解：要达到 cost_R=0.05 / 0.10，需要多少止损+成交成本")
print("=" * 92)
for target in [0.05, 0.10]:
    for s in [0.015, 0.02, 0.03, 0.05]:
        bp = target * s * 1e4 / 2
        print(f"  cost_R={target:.2f} + 止损{s*100:4.1f}%  ->  单边成本需 {bp:5.2f} bp "
              f"({'≤maker 2bp' if bp<=2 else ('maker~混合之间' if bp<=5 else ('≈taker' if bp<=10 else '>taker，不现实'))})")

print()
print("=" * 92)
print("【D】结论：唯一可能为正的组合")
print("=" * 92)
best = m[m.净E > 0]
if len(best):
    print(best.to_string(index=False))
    print(f"\n最大净E = {m.净E.max():+.4f} R/笔")
else:
    print("无任何组合净E为正")
print(f"\n全部组合净E范围: {m.净E.min():+.4f} ~ {m.净E.max():+.4f}")
