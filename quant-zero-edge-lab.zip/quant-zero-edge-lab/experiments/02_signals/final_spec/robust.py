"""
1) 成本临界点：净E = gross - cost_R，求使最优配置转负的 cost_R
2) 冷却期稳定性：细扫 cd ∈ {2,5,10,20,40,60,90} × 多信号窗口 L ∈ {60,120,240}
   检验 cd 效应是否单调/连续，还是噪声
"""
import numpy as np, pandas as pd, sys
sys.path.insert(0, '/data/workspace/final_spec')
from spec import SYMS, OLD7, NEW6, mom_signal, bracket, get, BARS_PER_YEAR, cross_t

R = 2.0


def run(sym, L, sp, cd):
    o, h, l, c, qv = get(sym)
    sig = mom_signal(c, L)
    tr, ty, ti = bracket(o, h, l, c, sig, sp, R, cd)
    return tr, len(o) / BARS_PER_YEAR


def grid(L, sp_list, cd_list):
    rows = []
    for cd in cd_list:
        for sp in sp_list:
            per = {}
            for s in SYMS:
                tr, yrs = run(s, L, sp, cd)
                per[s] = (np.mean(tr) if len(tr) else np.nan, len(tr), yrs)
            g = [per[s][0] for s in SYMS]
            m, t, _ = cross_t(g)
            mo, to, _ = cross_t([per[s][0] for s in OLD7])
            mn, tn, _ = cross_t([per[s][0] for s in NEW6])
            N = sum(per[s][1] for s in SYMS)
            yrs = np.mean([per[s][2] for s in SYMS])
            rows.append(dict(L=L, cd=cd, stop=sp, N=N, freq=N / (yrs * len(SYMS)),
                             gross=m, t=t, old=mo, t_old=to, new=mn, t_new=tn,
                             pos_o=sum(1 for s in OLD7 if per[s][0] > 0),
                             pos_n=sum(1 for s in NEW6 if per[s][0] > 0)))
    return pd.DataFrame(rows)


print("=" * 100)
print("【A】冷却期细扫  L=120, stop=2%")
print("=" * 100)
dfA = grid(120, [0.02], [0, 2, 5, 10, 20, 40, 60, 90])
print(dfA[['cd', 'stop', 'N', 'freq', 'gross', 't', 'old', 'new', 'pos_o', 'pos_n']].to_string(index=False))

print()
print("=" * 100)
print("【B】信号窗口稳健性  L ∈ {60,120,240}, cd ∈ {5,20,60}, stop ∈ {2%,3%,5%}")
print("=" * 100)
allb = []
for L in [60, 120, 240]:
    b = grid(L, [0.02, 0.03, 0.05], [5, 20, 60])
    allb.append(b)
    print(f"--- L={L} ---")
    print(b[['cd', 'stop', 'N', 'freq', 'gross', 't', 'old', 'new', 'pos_o', 'pos_n']].to_string(index=False))
    print()
dfB = pd.concat(allb)
dfB.to_csv('/data/workspace/final_spec/robust.csv', index=False)

print("=" * 100)
print("【C】成本临界点：最优 gross 与成本对比")
print("=" * 100)
best = dfB.sort_values('gross', ascending=False).head(8)
print(best[['L', 'cd', 'stop', 'N', 'freq', 'gross', 't', 'old', 'new']].to_string(index=False))
print()
print("净E = gross - cost_R。使净E>0 需要 cost_R < gross。")
for _, r in best.iterrows():
    print(f"L={r.L:.0f} cd={r.cd:.0f} s={r.stop*100:.0f}%  gross={r.gross:+.4f}  "
          f"-> 成本容忍上限 cost_R={r.gross:.4f}  (对应单边bp = {r.gross*r.stop*1e4/2:.2f}bp)")
