"""
收割制模拟：混合成本 + 亏完即爆仓 + 定期结算(每周) + 翻倍结算 + 保持初始资金不变
对照组：零期望（同波动形状，均值归零）
"""
import numpy as np, pandas as pd, sys
sys.path.insert(0, '/data/workspace/final_spec')
from spec import SYMS, OLD7, NEW6, mom_signal, bracket, get, BARS_PER_YEAR, cross_t

R = 2.0
L = 120


def build_seq(cfg_list, cost_R):
    """构建逐笔序列：13品种按入场bar合并（一笔一笔过）"""
    out = {}
    for (cd, sp) in cfg_list:
        all_tr = []
        for sym in SYMS:
            o, h, l, c, qv = get(sym)
            sig = mom_signal(c, L)
            tr, ty, ti = bracket(o, h, l, c, sig, sp, R, cd)
            all_tr.append((ti, tr))
        # 按入场bar排序合并
        bars = np.concatenate([t[0] for t in all_tr])
        rets = np.concatenate([t[1] for t in all_tr])
        order = np.argsort(bars, kind='stable')
        rets = rets[order] - cost_R          # 扣混合成本
        yrs = np.mean([len(get(s)[0]) / BARS_PER_YEAR for s in SYMS])
        out[(cd, sp)] = dict(rets=rets, yrs=yrs, freq=len(rets) / yrs)
    return out


def harvest(rets, f, C0=10000.0, weekly_k=None, nsim=2000, seed=7, scale=1.0):
    """
    不复利 + 收割：
      - 每笔押注固定 f*C0（R单位换算：盈亏 = f*C0 * R_value）
      - 每周结算：W>C0 则提取超额，W重置=C0
      - 翻倍结算：W>=2*C0 则提取超额，W重置=C0
      - 爆仓：W<=0 停止
      - scale: E 衰减系数
    """
    rng = np.random.default_rng(seed)
    base = rets * scale
    n = len(base)
    if weekly_k is None or weekly_k < 1:
        weekly_k = 1
    weekly_k = int(weekly_k)
    P, MED, BUST, TAK = [], [], [], []
    for _ in range(nsim):
        idx = rng.integers(0, n, size=n)
        W = C0; taken = 0.0
        cnt = 0
        for j in range(n):
            r = base[idx[j]]
            W += f * C0 * r
            cnt += 1
            if W <= 0:
                break
            if W >= 2 * C0:                    # 翻倍结算
                taken += W - C0; W = C0; cnt = 0
            elif cnt >= weekly_k:              # 定期结算（每周）
                if W > C0:
                    taken += W - C0; W = C0
                cnt = 0
        if W > C0:
            taken += W - C0
        P.append(1.0 if taken >= C0 else 0.0)
        MED.append(taken - C0)
        BUST.append(1.0 if W <= 0 else 0.0)
        TAK.append(taken)
    return dict(P=float(np.mean(P)), med=float(np.median(MED)),
                bust=float(np.mean(BUST)), tak=float(np.median(TAK)))


def zero_expect(rets):
    """零期望对照：保留波动形状，均值归零"""
    return rets - rets.mean()


def main():
    cfgs = [(5, 0.05), (60, 0.03), (20, 0.02), (5, 0.02), (0, 0.02)]
    rows = []
    for cost_R in [0.05, 0.10]:
        seqs = build_seq(cfgs, cost_R)
        for (cd, sp), d in seqs.items():
            rets = d['rets']
            yrs = d['yrs']
            wk = max(1, int(len(rets) / (yrs * 52)))
            m = rets.mean()
            se = rets.std(ddof=1) / np.sqrt(len(rets))
            for f in [0.01, 0.02]:
                a = harvest(rets, f, weekly_k=wk, nsim=1500, seed=11)
                z = harvest(zero_expect(rets), f, weekly_k=wk, nsim=1500, seed=11)
                rows.append(dict(cost_R=cost_R, cd=cd, stop=sp, f=f,
                                 N=len(rets), freq=d['freq'], mean=m, t=m / se,
                                 P=a['P'], med=a['med'], bust=a['bust'],
                                 P0=z['P'], med0=z['med'], bust0=z['bust']))
                print(f"cost{cost_R:.2f} cd={cd:3d} s={sp*100:.0f}% f={f*100:.0f}% "
                      f"N={len(rets):6d} E={m:+.4f}(t{m/se:+5.2f}) "
                      f"P={a['P']:.3f} med={a['med']:+8.0f} bust={a['bust']:.3f} | "
                      f"零期望 P0={z['P']:.3f} med0={z['med']:+8.0f}", flush=True)
    df = pd.DataFrame(rows)
    df.to_csv('/data/workspace/final_spec/harvest.csv', index=False)
    print("\nsaved harvest.csv")


if __name__ == '__main__':
    main()
