"""
市场中性策略引擎: 配对交易(统计套利) + 横截面动量
严格 point-in-time: formation 只用过去, trading 只用已选参数
"""
import numpy as np, pandas as pd
from itertools import combinations

# ============ 配对交易 ============
def formation_select(pxF, method='dist', npairs=5):
    """
    pxF: DataFrame (F x m) formation 期价格
    method: 'dist'(Gatev归一化距离) | 'corr'(收益率相关) | 'rand'(随机对照)
    返回: list of (a,b)
    """
    cols=list(pxF.columns)
    pairs=list(combinations(cols,2))
    if method=='rand':
        rng=np.random.default_rng(0)
        idx=rng.permutation(len(pairs))[:npairs]
        return [pairs[i] for i in idx]
    scores=[]
    P=pxF.values
    if method=='dist':
        Pn=P/P[0]                      # 归一化价格
        for (a,b) in pairs:
            i,j=cols.index(a),cols.index(b)
            ssd=np.nansum((Pn[:,i]-Pn[:,j])**2)
            scores.append((ssd,a,b))
        scores.sort()                  # SSD 最小 = 最贴近
        return [(a,b) for _,a,b in scores[:npairs]]
    if method=='corr':
        R=np.diff(np.log(P),axis=0)
        R=pd.DataFrame(R,columns=cols)
        C=R.corr().values
        for (a,b) in pairs:
            i,j=cols.index(a),cols.index(b)
            scores.append((-C[i,j],a,b))
        scores.sort()
        return [(a,b) for _,a,b in scores[:npairs]]
    raise ValueError(method)

def spread_series(px, a, b, use_log=True, beta=None):
    """价差序列; beta=None -> 对数价差(无参数)"""
    if use_log:
        return np.log(px[a]) - np.log(px[b])
    return px[a] - beta*px[b]

def trade_pairs(px, F=720, T=360, npairs=5, method='dist',
                z_in=2.0, z_out=0.5, z_stop=4.0, use_log=True,
                cost_bp=2.0, allow_shrink=True):
    """
    滚动 walk-forward: 每 T bar 重新 formation(用过去 F bar), 交易 T bar
    返回 trades DataFrame: 每笔 {entry_i, exit_i, a, b, dir, ret_net, etype}
    dir=+1 -> 多a空b ; dir=-1 -> 空a多b
    """
    n=len(px); cols=list(px.columns)
    cst=2.0*cost_bp/1e4            # 往返成本(相对总名义), 双leg开平各一次
    trades=[]
    start=F
    while start < n-2:
        end=min(start+T, n-1)
        pxF=px.iloc[start-F:start]
        prs=formation_select(pxF, method, npairs)
        # 用 formation 期估计 mu,sigma / beta
        params={}
        for (a,b) in prs:
            sF=spread_series(pxF,a,b,use_log)
            mu=sF.mean(); sd=sF.std()
            if not np.isfinite(sd) or sd<=0: continue
            if not use_log:
                beta=np.polyfit(pxF[b].values, pxF[a].values,1)[0]
            else: beta=None
            params[(a,b)]=(mu,sd,beta)
        # trading 期
        inpos={}
        for t in range(start,end):
            for (a,b),(mu,sd,beta) in params.items():
                if (a,b) in inpos: continue
                st=spread_series(px.iloc[t:t+1],a,b,use_log,beta)
                if len(st)==0: continue
                z=(float(st.iloc[0])-mu)/sd
                if not np.isfinite(z): continue
                if abs(z)>=z_in:
                    inpos[(a,b)]=dict(t=t, dir=(-1 if z>0 else 1), z0=z)
            # 检查平仓
            for k in list(inpos.keys()):
                pos=inpos[k]; a,b=k
                mu,sd,beta=params[k]
                st=spread_series(px.iloc[t:t+1],a,b,use_log,beta)
                if len(st)==0: continue
                z=(float(st.iloc[0])-mu)/sd
                d=pos['dir']
                close=False; etype=None
                if abs(z)>=z_stop: etype='stop'; close=True
                elif abs(z)<=z_out: etype='conv'; close=True
                elif t>=end-1: etype='eod'; close=True
                if close:
                    z0=pos['z0']
                    # 收益: dir=+1(多a空b) 时 spread 上升获利; spread 变动 = (z1-z0)*sd
                    # 近似用价差比例收益
                    ret_gross=(z-z0)*sd*d * (1.0 if use_log else 1.0)
                    trades.append(dict(entry_i=pos['t'], exit_i=t, a=a,b=b,dir=d,
                                       etype=etype, hold=t-pos['t'],
                                       gross=ret_gross, net=ret_gross-cst))
                    del inpos[k]
        start=end
    return pd.DataFrame(trades)

# ============ 横截面动量 ============
def cross_sectional(px, L=240, H=120, k=3, sign=+1, cost_bp=2.0):
    """
    每 H bar 调仓: 按过去 L bar 收益排序
    sign=+1 动量(多强空弱); -1 反转
    返回 每期组合收益序列
    """
    n=len(px)
    rets=[]; times=[]
    t=L
    cst=2.0*cost_bp/1e4
    while t < n-H-1:
        p0=px.iloc[t-L]; p1=px.iloc[t]
        mom=(p1/p0-1.0)
        mom=mom.dropna()
        if len(mom) < 2*k:
            t+=H; continue
        srt=mom.sort_values(ascending=(sign<0))
        longs=list(srt.index[:k]); shorts=list(srt.index[-k:])
        pa=px.iloc[t]; pb=px.iloc[t+H]
        rl=np.mean([pb[a]/pa[a]-1 for a in longs])
        rs=np.mean([pb[b]/pa[b]-1 for b in shorts])
        # dollar neutral: 多空各半仓 -> 组合收益 = 0.5*rl - 0.5*rs
        gross=0.5*(rl-rs)
        # 成本: 每期换手(简化: 全额换手) 2腿开平
        rets.append(gross-cst); times.append(t)
        t+=H
    return pd.Series(rets, index=times)

# ============ 基准: 等权多头 ============
def equal_weight(px, cost_bp=2.0):
    r=np.log(px).diff().dropna()
    return r.mean(axis=1)
