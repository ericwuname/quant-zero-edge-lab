"""canary v2: 严格打乱 t+1 之后(不含t自身) + 大步长衰减检验"""
import pandas as pd, numpy as np, ssd_fast
px=pd.read_pickle('px_1h.pkl'); rng=np.random.default_rng(0)

def shuffle_after(px,t,seed=0):
    """只打乱 t+1 之后的数据 (t 及之前完全保留)"""
    r=np.random.default_rng(seed); d2=px.copy()
    if t+1>=len(px): return d2
    idx=np.arange(t+1,len(px)); perm=r.permutation(idx)
    v=px.values.copy(); v[t+1:]=v[t+1:][perm-(t+1)]
    return pd.DataFrame(v,index=px.index,columns=px.columns)

print("="*95); print("【J2】CANARY v2 — 严格打乱 t+1 之后"); print("="*95)
# 配对
F=720
for m in ['dist','corr','coint']:
    d=0;tot=0
    for t in [F+100,8000,20000,35000,45000]:
        a=ssd_fast.select_fast(px.iloc[t-F:t],m,5)
        b=ssd_fast.select_fast(shuffle_after(px,t,1).iloc[t-F:t],m,5)
        tot+=1; d+=int(set(a)!=set(b))
    print(f"  配对[{m:5s}] 改变 {d}/{tot} -> {'干净' if d==0 else '前视!'}")
# 截面
d=0;tot=0
for t in [8000,20000,35000,45000]:
    a=(px.iloc[t]/px.iloc[t-240]-1).sort_values().index.tolist()
    b=(shuffle_after(px,t,1).iloc[t]/shuffle_after(px,t,1).iloc[t-240]-1).sort_values().index.tolist()
    tot+=1; d+=int(a!=b)
print(f"  截面[L=240] 改变 {d}/{tot} -> {'干净' if d==0 else '前视!'}")
# 负对照(真前视): 用 t -> t+240 的未来收益排序
def cheat(df,t,L=240):
    return (df.iloc[t+L]/df.iloc[t]-1).sort_values().index.tolist()
d=0;tot=0
for t in [20000,30000,40000]:
    a=cheat(px,t); b=cheat(shuffle_after(px,t,1),t)
    tot+=1; d+=int(a!=b)
print(f"  负对照[真前视] 改变 {d}/{tot} -> {'探测器有效' if d>0 else '探测器失效!'}")

print()
print("="*95); print("【K】衰减检验: 排序信息延迟使用 (步长递增)"); print("="*95)
def cs_shift(L,H,k,shift):
    nn=len(px); cst=4e-4; out=[]; t=L+shift
    while t<nn-H-1:
        mom=(px.iloc[t-shift]/px.iloc[t-shift-L]-1.0).dropna()
        srt=mom.sort_values(ascending=False); lo=list(srt.index[:k]); sh=list(srt.index[-k:])
        pa=px.iloc[t]; pb=px.iloc[t+H]
        out.append(0.5*(np.mean([pb[a]/pa[a]-1 for a in lo])-np.mean([pb[b]/pa[b]-1 for b in sh]))-cst); t+=H
    return np.mean(out)*1e4, len(out)
print(f"{'延迟(bar)':>10} {'净收益bp':>10} {'N':>6}")
for s in [0,1,5,20,60,120,240]:
    v,NN=cs_shift(240,120,3,s)
    print(f"{s:>10} {v:>+10.2f} {NN:>6}")
print("\n真信号应随延迟单调衰减; 若不衰减 -> 说明是数据伪影或噪声")
