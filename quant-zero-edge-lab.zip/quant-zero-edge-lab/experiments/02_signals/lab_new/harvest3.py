import numpy as np, pandas as pd, pickle
S=pickle.load(open('seqs.pkl','rb'))

def sim(r,f,C0=10000.0,T=1.0,ruin=0.2,nboot=800,horizon=None,seed=11):
    rng=np.random.default_rng(seed); n=len(r); Hh=horizon or n
    tot=np.empty(nboot); hv=np.empty(nboot); bst=np.zeros(nboot,bool); win=np.zeros(nboot,bool)
    for b in range(nboot):
        W=C0; h=0.0
        for i in rng.integers(0,n,size=Hh):
            W += f*C0*r[i]
            if W>=C0*(1+T): h+=W-C0; W=C0
            elif W<=C0*ruin: bst[b]=True; break
        tot[b]=W+h; hv[b]=h; win[b]= h>=C0
    return dict(P=win.mean(),harv=np.median(hv),tot=np.median(tot),bust=bst.mean(),EV=tot.mean()-C0)

CS=[k for k in S if k.startswith('CS')]
PR=[k for k in S if k.startswith('PAIR')]

print("="*104)
print("【L1】收割制 — 截面动量 (N=399期, 每期5天, 全期约5.5年)")
print("="*104)
print(f"{'策略':<16}{'f':>6}{'P(赚回本金)':>12}{'落袋中位':>11}{'总资产中位':>11}{'爆仓率':>8}{'EV':>9}")
for nm in CS:
    r=S[nm]
    for f in [0.10,0.20,0.40,0.80,1.00]:
        d=sim(r,f)
        print(f"{nm:<16}{f:>6.2f}{d['P']:>12.1%}{d['harv']:>11.0f}{d['tot']:>11.0f}{d['bust']:>8.1%}{d['EV']:>+9.0f}")
    print()
print("="*104)
print("【L2】收割制 — 配对交易 (期望已为负, 只验证必亏程度; horizon=3000笔)")
print("="*104)
print(f"{'策略':<16}{'f':>6}{'P(赚回本金)':>12}{'落袋中位':>11}{'总资产中位':>11}{'爆仓率':>8}{'EV':>9}")
for nm in PR:
    r=S[nm]
    for f in [0.05,0.10,0.20]:
        d=sim(r,f,horizon=3000)
        print(f"{nm:<16}{f:>6.2f}{d['P']:>12.1%}{d['harv']:>11.0f}{d['tot']:>11.0f}{d['bust']:>8.1%}{d['EV']:>+9.0f}")
    print()

print("="*104)
print("【M】零期望对照 (序列中心化) — 判断'几何白送'基线")
print("="*104)
print(f"{'策略':<16}{'f':>6}{'真实P':>9}{'零期望P':>9}{'P差值':>9}{'真实EV':>10}{'零期望EV':>10}")
for nm in CS:
    r=S[nm]; r0=r-r.mean()
    for f in [0.40,0.80,1.00]:
        d=sim(r,f); d0=sim(r0,f)
        print(f"{nm:<16}{f:>6.2f}{d['P']:>9.1%}{d0['P']:>9.1%}{d['P']-d0['P']:>+9.1%}{d['EV']:>+10.0f}{d0['EV']:>+10.0f}")
    print()
