import numpy as np
from itertools import combinations
def select_fast(pxF, method, npairs, seed=0):
    cols=list(pxF.columns); P=pxF.values; pairs=list(combinations(range(len(cols)),2))
    idx=[(i,j) for i,j in pairs]
    if method=='rand':
        rng=np.random.default_rng(seed)
        sel=rng.permutation(len(idx))[:npairs]
        return [(cols[i],cols[j]) for i,j in [idx[s] for s in sel]]
    if method=='dist':
        Pn=P/P[0]; A=(Pn**2).sum(0); M=Pn.T@Pn
        ssd=A[:,None]+A[None,:]-2*M
        v=np.array([ssd[i,j] for i,j in idx]); o=np.argsort(v)[:npairs]
        return [(cols[idx[s][0]],cols[idx[s][1]]) for s in o]
    if method=='corr':
        R=np.diff(np.log(P),axis=0); R=R-R.mean(0)
        sd=R.std(0); sd[sd==0]=1
        C=(R.T@R)/(len(R)-1)/np.outer(sd,sd)
        v=np.array([-C[i,j] for i,j in idx]); o=np.argsort(v)[:npairs]
        return [(cols[idx[s][0]],cols[idx[s][1]]) for s in o]
    if method=='coint':
        Lg=np.log(P); out=[]
        for i,j in idx:
            x=Lg[:,j]; y=Lg[:,i]
            X=np.column_stack([np.ones(len(x)),x])
            b=np.linalg.lstsq(X,y,rcond=None)[0]; r=y-X@b
            rho=np.polyfit(r[:-1],np.diff(r),1)[0] if len(r)>10 else 0.0
            out.append(rho)
        o=np.argsort(out)[:npairs]
        return [(cols[idx[s][0]],cols[idx[s][1]]) for s in o]
    raise ValueError(method)
