"""White's Reality Check: 45个参数组合里挑最强者, 校正多重挑选"""
import numpy as np, pandas as pd, itertools, time
px=pd.read_pickle('px_1h.pkl'); P=px.values; n=len(P)
rng=np.random.default_rng(5)

GRID=[(L,H,k) for L in [60,120,240,480,720] for H in [60,120,240] for k in [2,3,4]]
CST=4e-4   # maker 往返 4bp

def cs_stat(L,H,k,shuffle=False):
    out=[]; t=L
    while t<n-H-1:
        mom=P[t]/P[t-L]-1.; ok=np.isfinite(mom); idx=np.where(ok)[0]
        if len(idx)<2*k: t+=H; continue
        if shuffle:
            pm=list(rng.permutation(idx)); lo=pm[:k]; sh=pm[-k:]
        else:
            o=idx[np.argsort(-mom[idx])]; lo=list(o[:k]); sh=list(o[-k:])
        out.append(0.5*(np.mean(P[t+H][lo]/P[t][lo]-1)-np.mean(P[t+H][sh]/P[t][sh]-1))-CST)
        t+=H
    a=np.array(out)
    if len(a)<30: return np.nan, 0, 0.
    mu=a.mean(); sd=a.std(ddof=1)
    return mu, len(a), (mu/(sd/np.sqrt(len(a))) if sd>0 else 0.)

print("计算 45 个参数组合的真实 t 值...")
real={}
t0=time.time()
for g in GRID:
    mu,N,t=cs_stat(*g); real[g]=(mu,N,t)
R=pd.DataFrame([dict(L=g[0],H=g[1],k=g[2],bp=v[0]*1e4,N=v[1],t=v[2]) for g,v in real.items()])
R=R.sort_values('t',ascending=False)
print(f"用时 {time.time()-t0:.0f}s")
print("\n真实 t 值 Top8:")
print(R.head(8).to_string(index=False,float_format=lambda x:f'{x:+.3f}'))
best=R.iloc[0]
print(f"\n最强组合: L={best.L} H={best.H} k={best.k}  t={best.t:+.3f}  bp={best.bp:+.2f}")
V=best.t

print(f"\n单组合置换 p 值 (未校正):")
# 单组合置换
nl=[]
for _ in range(300):
    mu,N,t=cs_stat(int(best.L),int(best.H),int(best.k),shuffle=True); nl.append(t)
p1=(np.sum(np.array(nl)>=V)+1)/301
print(f"  p={p1:.4f}")

print(f"\nReality Check (校正45组合挑选): 300次置换, 每次取45组合中的最大t")
t0=time.time(); Vb=[]
for b in range(300):
    mx=-9e9
    for g in GRID:
        mu,N,t=cs_stat(*g,shuffle=True)
        if np.isfinite(t) and t>mx: mx=t
    Vb.append(mx)
Vb=np.array(Vb)
p_rc=(np.sum(Vb>=V)+1)/301
print(f"  真实最强 t={V:+.3f}")
print(f"  置换 max-t 分布: 均值={Vb.mean():+.3f} 95分位={np.percentile(Vb,95):+.3f} 99分位={np.percentile(Vb,99):+.3f}")
print(f"  Reality Check p = {p_rc:.4f}  -> {'显著' if p_rc<0.05 else '不显著(多重挑选后塌掉)'}")
print(f"用时 {time.time()-t0:.0f}s")
R.to_pickle('rc_grid.pkl'); np.save('Vb.npy',Vb)
