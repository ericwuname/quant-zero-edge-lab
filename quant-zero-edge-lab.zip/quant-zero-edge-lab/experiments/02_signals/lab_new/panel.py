"""多品种面板对齐 + 诊断"""
import numpy as np, pandas as pd, glob, os
DATA='/data/inputs/'

def load_panel(freq='1h', min_len=20000):
    """返回 dict name->Series(close, index=timestamp)"""
    out={}
    for f in sorted(glob.glob(DATA+f'*_{freq}.csv')):
        nm=os.path.basename(f).split('_')[0].replace('USDT','')
        df=pd.read_csv(f)[['timestamp','open','high','low','close','volume']]
        df=df.dropna().drop_duplicates('timestamp').sort_values('timestamp').reset_index(drop=True)
        if len(df)>=min_len: out[nm]=df.set_index('timestamp')['close']
    return out

def align(series_dict, how='inner'):
    df=pd.DataFrame(series_dict)
    if how=='inner': df=df.dropna()
    return df

if __name__=='__main__':
    sd=load_panel('1h')
    print("品种数:", len(sd), list(sd.keys()))
    px=align(sd,'inner')
    print("对齐后 bar 数:", len(px))
    print("时间范围:", pd.to_datetime(px.index[0],unit='ms'), "->", pd.to_datetime(px.index[-1],unit='ms'))
    print("\n各品种bar数:")
    for k,v in sd.items(): print(f"  {k}: {len(v)}")
    # 相关性
    r=np.log(px).diff().dropna()
    C=r.corr()
    iu=np.triu_indices(len(C),1)
    print(f"\n日(bar)收益相关性: 均值={C.values[iu].mean():.3f} 中位={np.median(C.values[iu]):.3f} min={C.values[iu].min():.3f} max={C.values[iu].max():.3f}")
    # 累计收益
    cum=(px.iloc[-1]/px.iloc[0]-1)*100
    print("\n全期累计收益%:")
    print(cum.sort_values(ascending=False).round(1).to_string())
    px.to_pickle('/data/workspace/lab_new/px_1h.pkl')
    print("\nsaved px_1h.pkl")
