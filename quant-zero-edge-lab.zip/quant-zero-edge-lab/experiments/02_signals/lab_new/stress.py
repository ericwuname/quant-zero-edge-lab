import numpy as np, pandas as pd, pickle
S=pickle.load(open('seqs.pkl','rb'))
def sim(r,f,C0=10000.,T=1.,ruin=.2,nboot=800,hor=None,seed=11):
    rng=np.random.default_rng(seed); n=len(r); H=hor or n
    tot=np.empty(nboot); hv=np.empty(nboot); win=np.zeros(nboot,bool); bs=np.zeros(nboot,bool)
    for b in range(nboot):
        W=C0; h=0.
        for i in rng.integers(0,n,size=H):
            W+=f*C0*r[i]
            if W>=C0*(1+T): h+=W-C0; W=C0
            elif W<=C0*ruin: bs[b]=True; break
        tot[b]=W+h; hv[b]=h; win[b]=h>=C0
    return dict(P=win.mean(),tot=np.median(tot),bust=bs.mean(),EV=tot.mean()-C0)

r=S['CS_L720H240k2']; base=r.mean()
print("="*100); print("【N】E 衰减敏感性 (CS_L720H240k2, f=0.8) — 回测E不显著, 真实E可能更低"); print("="*100)
print(f"{'E缩放':>7}{'等效bp/期':>11}{'P(赚回)':>10}{'总资产中位':>11}{'爆仓率':>9}{'EV':>10}")
for sc in [1.0,.8,.6,.5,.3,.0]:
    rr=(r-base)+base*sc
    d=sim(rr,0.8)
    print(f"{sc:>7.2f}{rr.mean()*1e4:>11.2f}{d['P']:>10.1%}{d['tot']:>11.0f}{d['bust']:>9.1%}{d['EV']:>+10.0f}")

print()
print("="*100); print("【O】成本敏感性 — maker往返4bp vs taker往返20bp"); print("="*100)
# 重算序列: 成本从 2bp单边 提到 10bp单边
import pandas as pd
px=pd.read_pickle('px_1h.pkl'); P=px.values; n=len(P)
def cs_cost(cost_bp):
    Lb,H,k=720,240,2; cst=2.0*cost_bp/1e4; out=[]; t=Lb
    while t<n-H-1:
        mom=P[t]/P[t-Lb]-1.; ok=np.isfinite(mom)
        if ok.sum()<2*k: t+=H; continue
        idx=np.where(ok)[0]; o=idx[np.argsort(-mom[idx])]
        lo=o[:k]; sh=o[-k:]
        out.append(0.5*(np.mean(P[t+H][lo]/P[t][lo]-1)-np.mean(P[t+H][sh]/P[t][sh]-1))-cst); t+=H
    return np.array(out)
for cb,nm in [(0,'零成本'),(2,'maker 2bp'),(5,'5bp'),(10,'taker 10bp'),(20,'20bp')]:
    rr=cs_cost(cb)
    d=sim(rr,0.8)
    print(f"  {nm:<12} 均值={rr.mean()*1e4:+7.2f}bp  P(赚回)={d['P']:>6.1%}  总资产中位={d['tot']:>7.0f}  EV={d['EV']:>+8.0f}")

print()
print("="*100); print("【P】置换检验 + 分年 (CS_L720H240k2)"); print("="*100)
rng=np.random.default_rng(3)
def cs_shuf(shuffle=False):
    Lb,H,k=720,240,2; cst=4e-4; out=[]; t=Lb
    while t<n-H-1:
        mom=P[t]/P[t-Lb]-1.; ok=np.isfinite(mom); idx=np.where(ok)[0]
        if len(idx)<2*k: t+=H; continue
        if shuffle: perm=list(rng.permutation(idx)); lo=perm[:k]; sh=perm[-k:]
        else: o=idx[np.argsort(-mom[idx])]; lo=list(o[:k]); sh=list(o[-k:])
        out.append(0.5*(np.mean(P[t+H][lo]/P[t][lo]-1)-np.mean(P[t+H][sh]/P[t][sh]-1))-cst); t+=H
    return np.array(out)
real=cs_shuf().mean()*1e4
nl=[cs_shuf(True).mean()*1e4 for _ in range(300)]
p=(np.sum(np.array(nl)>=real)+1)/301
print(f"  真实={real:+.2f}bp  随机选股300次: 均值={np.mean(nl):+.2f} 标准差={np.std(nl):.2f} 95分位={np.percentile(nl,95):+.2f}")
print(f"  置换 p={p:.4f} -> {'显著' if p<0.05 else '不显著(与随机选股无差异)'}")
# 分年
out=[];t=720
while t<n-241:
    mom=P[t]/P[t-720]-1.; ok=np.isfinite(mom); idx=np.where(ok)[0]
    o=idx[np.argsort(-mom[idx])]; lo=o[:2]; sh=o[-2:]
    out.append((pd.to_datetime(px.index[t],unit='ms').year,
                0.5*(np.mean(P[t+240][lo]/P[t][lo]-1)-np.mean(P[t+240][sh]/P[t][sh]-1))-4e-4))
    t+=240
D=pd.DataFrame(out,columns=['yr','net'])
g=D.groupby('yr')['net'].agg(['size','mean'])
g['bp']=g['mean']*1e4
print("\n  分年:"); print(g[['size','bp']].round(2).to_string())
print(f"  为正的年: {(g.bp>0).sum()}/{len(g)}")
