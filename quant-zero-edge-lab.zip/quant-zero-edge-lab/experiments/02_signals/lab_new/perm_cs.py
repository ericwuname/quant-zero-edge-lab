import pandas as pd, numpy as np
px=pd.read_pickle('px_1h.pkl')
rng=np.random.default_rng(7)

def cs_full(L,H,k,sign,cost_bp=2.0,shuffle=False):
    nn=len(px); cst=2.0*cost_bp/1e4; rows=[]; t=L
    while t<nn-H-1:
        mom=(px.iloc[t]/px.iloc[t-L]-1.0).dropna()
        if len(mom)<2*k: t+=H; continue
        names=list(mom.index)
        if shuffle:
            perm=list(rng.permutation(names))
            lo=perm[:k]; sh=perm[-k:]
        else:
            srt=mom.sort_values(ascending=(sign<0))
            lo=list(srt.index[:k]); sh=list(srt.index[-k:])
        pa=px.iloc[t]; pb=px.iloc[t+H]
        rl=np.mean([pb[a]/pa[a]-1 for a in lo]); rs=np.mean([pb[b]/pa[b]-1 for b in sh])
        rm=np.mean(pb/pa-1)
        rows.append(dict(t=t,net=0.5*(rl-rs)-cst,rm=rm)); t+=H
    return pd.DataFrame(rows)

print("="*95)
print("【H】分年稳定性 (动量 L=240 H=120 k=3)")
print("="*95)
d=cs_full(240,120,3,1)
d['yr']=pd.to_datetime(d['t'],unit='ms').dt.year  # t是位置不是ms! 修正
# t 是整数位置, 用 px.index[t]
d['yr']=[pd.to_datetime(px.index[i],unit='ms').year for i in d['t']]
g=d.groupby('yr').agg(N=('net','size'),bp=('net',lambda x:x.mean()*1e4),
                      mkt=('rm',lambda x:x.mean()*1e4))
g['t']=d.groupby('yr')['net'].apply(lambda x: x.mean()/(x.std(ddof=1)/np.sqrt(len(x))) if len(x)>2 and x.std(ddof=1)>0 else 0)
print(g.round(2).to_string())
print(f"\n为正的年: {(g.bp>0).sum()}/{len(g)}")

print()
print("="*95)
print("【I】随机选股置换对照 (决定性): 保持时间与数量, 随机选多空腿")
print("="*95)
real=cs_full(240,120,3,1)['net']
print(f"真实动量: N={len(real)} 均值={real.mean()*1e4:+.2f}bp")
nulls=[]
for i in range(400):
    s=cs_full(240,120,3,1,shuffle=True)['net']
    nulls.append(s.mean()*1e4)
nulls=np.array(nulls)
p=(np.sum(nulls>=real.mean()*1e4)+1)/(len(nulls)+1)
print(f"随机选股 400次: 均值={nulls.mean():+.2f}bp  标准差={nulls.std():.2f}bp")
print(f"  95分位={np.percentile(nulls,95):+.2f}bp  99分位={np.percentile(nulls,99):+.2f}bp")
print(f"真实值 {real.mean()*1e4:+.2f}bp 的置换 p 值 = {p:.4f}")
print(f"  -> {'不显著(与随机选股无差异)' if p>0.05 else '显著'}")
