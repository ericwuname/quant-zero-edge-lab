import numpy as np, pandas as pd, pickle
px=pd.read_pickle('px_1h.pkl'); P=px.values; n=len(P)
CST=4e-4
GRID=[(L,H,k) for L in [60,120,240,480,720] for H in [60,120,240] for k in [2,3,4]]
def cs(a,b,L,H,k):
    s=np.arange(a+L,b-H-1,H)
    if len(s)<30: return np.array([])
    T0=P[s];TL=P[s-L];TH=P[s+H]
    M=T0/TL-1.;R=TH/T0-1.
    M=np.where(np.isfinite(M),M,-np.inf)
    o=np.argsort(-M,axis=1);rows=np.arange(len(s))
    return 0.5*(R[rows[:,None],o[:,:k]].mean(1)-R[rows[:,None],o[:,-k:]].mean(1))-CST
half=n//2
print("="*100); print("【Q】时间外推: 前半段选最强参数 -> 后半段验证 (独立验证)"); print("="*100)
res=[]
for g in GRID:
    a=cs(0,half,*g)
    if len(a)<30: continue
    t=a.mean()/(a.std(ddof=1)/np.sqrt(len(a)))
    res.append((g,a.mean()*1e4,t,len(a)))
R=pd.DataFrame(res,columns=['g','bp_in','t_in','N']).sort_values('t_in',ascending=False)
print("前半段 Top5:")
print(R.head(5).to_string(index=False,float_format=lambda x:f'{x:+.3f}'))
bg=R.iloc[0]['g']
print(f"\n选中参数: {bg}")
b=cs(half,n,*bg)
tb=b.mean()/(b.std(ddof=1)/np.sqrt(len(b)))
print(f"  前半段(选): bp={R.iloc[0]['bp_in']:+.2f} t={R.iloc[0]['t_in']:+.3f}")
print(f"  后半段(验): bp={b.mean()*1e4:+.2f} t={tb:+.3f}  N={len(b)}")
print(f"  -> {'样本外成立' if tb>1.96 else '样本外不成立'}")

print()
print("="*100); print("【R】反向: 后半段选 -> 前半段验"); print("="*100)
res=[]
for g in GRID:
    a=cs(half,n,*g)
    if len(a)<30: continue
    t=a.mean()/(a.std(ddof=1)/np.sqrt(len(a)))
    res.append((g,a.mean()*1e4,t))
R2=pd.DataFrame(res,columns=['g','bp','t']).sort_values('t',ascending=False)
bg2=R2.iloc[0]['g']
f=cs(0,half,*bg2); tf=f.mean()/(f.std(ddof=1)/np.sqrt(len(f)))
print(f"  后半段选: {bg2} bp={R2.iloc[0]['bp']:+.2f} t={R2.iloc[0]['t']:+.3f}")
print(f"  前半段验: bp={f.mean()*1e4:+.2f} t={tf:+.3f}")
print(f"  -> {'成立' if tf>1.96 else '不成立'}")
print(f"\n  两次选出的最优参数是否一致: {'一致' if bg==bg2 else f'不一致 ({bg} vs {bg2}) -> 参数不稳定'}")
