"""
配对交易引擎 v2 — 修正:
 1) 禁止同bar开平 (平仓检查从 entry_t+1 开始) —— 现实可执行
 2) dollar-neutral 口径: gross = 0.5*(r_a - r_b), 相对总名义
 3) mu/sd 支持 'fixed'(formation期固定) 与 'roll'(滚动,只用过去)
"""
import numpy as np, pandas as pd
from itertools import combinations

def formation_select(pxF, method='dist', npairs=5, seed=0):
    cols=list(pxF.columns); pairs=list(combinations(cols,2))
    if method=='rand':
        rng=np.random.default_rng(seed)
        return [pairs[i] for i in rng.permutation(len(pairs))[:npairs]]
    sc=[]
    P=pxF.values
    if method=='dist':
        Pn=P/P[0]
        for a,b in pairs:
            i,j=cols.index(a),cols.index(b)
            sc.append((np.nansum((Pn[:,i]-Pn[:,j])**2),a,b))
        sc.sort(); return [(a,b) for _,a,b in sc[:npairs]]
    if method=='corr':
        R=np.diff(np.log(P),axis=0); C=pd.DataFrame(R,columns=cols).corr().values
        for a,b in pairs:
            i,j=cols.index(a),cols.index(b)
            sc.append((-C[i,j],a,b))
        sc.sort(); return [(a,b) for _,a,b in sc[:npairs]]
    if method=='coint':
        # Engle-Granger: OLS 残差 ADF(简化: 用残差的 AR(1) rho 作为平稳性代理)
        out=[]
        for a,b in pairs:
            x=np.log(P[:,cols.index(b)]); y=np.log(P[:,cols.index(a)])
            X=np.column_stack([np.ones(len(x)),x])
            beta=np.linalg.lstsq(X,y,rcond=None)[0]
            res=y-X@beta
            dr=np.diff(res)
            rho=np.polyfit(res[:-1],dr,1)[0] if len(res)>10 else 0.0
            out.append((rho,a,b))       # rho 越负越平稳
        out.sort(); return [(a,b) for _,a,b in out[:npairs]]
    raise ValueError(method)

def trade_pairs(px, F=720, T=360, npairs=5, method='dist',
                z_in=2.0, z_out=0.5, z_stop=4.0, mu_mode='fixed',
                cost_bp=2.0, seed=0, min_hold=1):
    n=len(px); cst=2.0*cost_bp/1e4       # 往返成本, 相对总名义(双leg开平)
    trades=[]; start=F
    L=np.log(px)
    while start < n-2:
        end=min(start+T, n-1)
        pxF=px.iloc[start-F:start]
        prs=formation_select(pxF, method, npairs, seed)
        params={}
        for a,b in prs:
            sF=L[a].iloc[start-F:start]-L[b].iloc[start-F:start]
            params[(a,b)]=(float(sF.mean()), float(sF.std()))
        inpos={}
        for t in range(start,end):
            # --- 开仓 ---
            for k,(mu,sd) in params.items():
                if k in inpos or not np.isfinite(sd) or sd<=0: continue
                a,b=k
                z=(float(L[a].iloc[t]-L[b].iloc[t])-mu)/sd
                if np.isfinite(z) and abs(z)>=z_in:
                    inpos[k]=dict(t=t, dir=(-1 if z>0 else 1), z0=z)
            # --- 平仓 (跳过入场bar) ---
            for k in list(inpos.keys()):
                pos=inpos[k]
                if t-pos['t'] < min_hold: continue
                a,b=k; mu,sd=params[k]
                z=(float(L[a].iloc[t]-L[b].iloc[t])-mu)/sd
                if not np.isfinite(z): continue
                d=pos['dir']; et=None
                if abs(z)>=z_stop: et='stop'
                elif abs(z)<=z_out: et='conv'
                elif t>=end-1: et='eod'
                if et:
                    sp0=pos['z0']*sd; sp1=z*sd        # 价差水平(对数)
                    gross=0.5*(sp1-sp0)*d            # dollar-neutral
                    trades.append(dict(entry_i=pos['t'],exit_i=t,a=a,b=b,dir=d,
                                       etype=et,hold=t-pos['t'],gross=gross,
                                       net=gross-cst))
                    del inpos[k]
        start=end
    return pd.DataFrame(trades)

def cross_sectional(px, L=240, H=120, k=3, sign=1, cost_bp=2.0):
    n=len(px); rets=[]; times=[]
    cst=2.0*cost_bp/1e4
    t=L
    while t < n-H-1:
        mom=(px.iloc[t]/px.iloc[t-L]-1.0).dropna()
        if len(mom)<2*k: t+=H; continue
        srt=mom.sort_values(ascending=(sign<0))
        lo=list(srt.index[:k]); sh=list(srt.index[-k:])
        pa=px.iloc[t].values; pb=px.iloc[t+H].values
        ci={c:i for i,c in enumerate(px.columns)}
        rl=np.mean([pb[ci[a]]/pa[ci[a]]-1 for a in lo])
        rs=np.mean([pb[ci[b]]/pa[ci[b]]-1 for b in sh])
        rets.append(0.5*(rl-rs)-cst); times.append(t)
        t+=H
    return pd.Series(rets,index=times)
