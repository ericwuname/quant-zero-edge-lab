import pandas as pd, numpy as np, ssd_fast, pickle, time
px=pd.read_pickle('px_1h.pkl')
cols=list(px.columns); P=px.values          # (n, m)
L=np.log(P)                                  # (n, m)
n,m=P.shape; ci={c:i for i,c in enumerate(cols)}

def seq_cs(Lb,H,k,sign=1,cost_bp=2.0):
    cst=2.0*cost_bp/1e4; out=[]; t=Lb
    while t<n-H-1:
        mom=P[t]/P[t-Lb]-1.0
        ok=np.isfinite(mom)
        if ok.sum()<2*k: t+=H; continue
        idx=np.where(ok)[0]
        if sign>0: order=idx[np.argsort(-mom[idx])]     # 降序: 强->弱
        else:      order=idx[np.argsort(mom[idx])]
        lo=order[:k]; sh=order[-k:]
        rl=np.mean(P[t+H][lo]/P[t][lo]-1); rs=np.mean(P[t+H][sh]/P[t][sh]-1)
        out.append(0.5*(rl-rs)-cst); t+=H
    return np.array(out)

def seq_pairs(F,T,npairs,method,cost_bp=2.0):
    cst=2.0*cost_bp/1e4; out=[]; start=F
    while start<n-2:
        end=min(start+T,n-1)
        prs=ssd_fast.select_fast(px.iloc[start-F:start],method,npairs)
        par=[]
        for a,b in prs:
            i,j=ci[a],ci[b]
            s=L[start-F:start,i]-L[start-F:start,j]
            sd=s.std()
            if np.isfinite(sd) and sd>0: par.append((i,j,float(s.mean()),float(sd)))
        inp={}
        for t in range(start,end):
            for (i,j,mu,sd) in par:
                if (i,j) in inp: continue
                z=(L[t,i]-L[t,j]-mu)/sd
                if np.isfinite(z) and abs(z)>=2.0: inp[(i,j)]=(t,-1 if z>0 else 1,z)
            for key in list(inp.keys()):
                t0,d,z0=inp[key]
                if t-t0<1: continue
                i,j=key; mu,sd=[(p[2],p[3]) for p in par if (p[0],p[1])==key][0]
                z=(L[t,i]-L[t,j]-mu)/sd
                if not np.isfinite(z): continue
                if abs(z)>=4.0 or abs(z)<=0.5 or t>=end-1:
                    out.append(0.5*(z-z0)*sd*d-cst); del inp[key]
        start=end
    return np.array(out)

S={}
t0=time.time(); S['CS_L240H120k3']=seq_cs(240,120,3); print('CS240',len(S['CS_L240H120k3']),f'{time.time()-t0:.1f}s')
t0=time.time(); S['CS_L720H240k2']=seq_cs(720,240,2); print('CS720',len(S['CS_L720H240k2']),f'{time.time()-t0:.1f}s')
t0=time.time(); S['PAIR_dist']=seq_pairs(720,360,5,'dist'); print('PAIRdist',len(S['PAIR_dist']),f'{time.time()-t0:.1f}s')
t0=time.time(); S['PAIR_corr']=seq_pairs(720,360,5,'corr'); print('PAIRcorr',len(S['PAIR_corr']),f'{time.time()-t0:.1f}s')
t0=time.time(); S['PAIR_coint']=seq_pairs(720,360,5,'coint'); print('PAIRcoint',len(S['PAIR_coint']),f'{time.time()-t0:.1f}s')
pickle.dump(S,open('seqs.pkl','wb'))
print("\n序列统计:")
for k,v in S.items():
    print(f"  {k:<16} N={len(v):6d} 均值={v.mean()*1e4:+8.2f}bp 标准差={v.std()*1e4:7.1f}bp t={v.mean()/(v.std()/np.sqrt(len(v))):+.2f}")
