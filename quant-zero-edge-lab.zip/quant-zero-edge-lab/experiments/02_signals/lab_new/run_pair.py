import pandas as pd, numpy as np, ssd_fast, json, itertools, sys
from itertools import combinations

px=pd.read_pickle('px_1h.pkl'); n=len(px)
L=np.log(px)

def run(F,T,npairs,method,z_in,z_out,z_stop,cost_bp=2.0,seg=None,seed=0):
    """seg=(a,b) 只跑 px.iloc[a:b]"""
    P = px.iloc[seg[0]:seg[1]] if seg else px
    Lg=np.log(P); nn=len(P)
    cst=2.0*cost_bp/1e4; tr=[]; start=F
    while start < nn-2:
        end=min(start+T,nn-1)
        prs=ssd_fast.select_fast(P.iloc[start-F:start],method,npairs,seed)
        params={}
        for a,b in prs:
            s=Lg[a].iloc[start-F:start]-Lg[b].iloc[start-F:start]
            sd=float(s.std())
            if np.isfinite(sd) and sd>0: params[(a,b)]=(float(s.mean()),sd)
        inpos={}
        la={k:Lg[k[0]].values for k in params}; lb={k:Lg[k[1]].values for k in params}
        for t in range(start,end):
            for k,(mu,sd) in params.items():
                if k in inpos: continue
                z=(la[k][t]-lb[k][t]-mu)/sd
                if np.isfinite(z) and abs(z)>=z_in:
                    inpos[k]=dict(t=t,dir=(-1 if z>0 else 1),z0=z)
            for k in list(inpos.keys()):
                p=inpos[k]
                if t-p['t']<1: continue
                mu,sd=params[k]; z=(la[k][t]-lb[k][t]-mu)/sd
                if not np.isfinite(z): continue
                d=p['dir']; et=None
                if abs(z)>=z_stop: et='stop'
                elif abs(z)<=z_out: et='conv'
                elif t>=end-1: et='eod'
                if et:
                    g=0.5*(z-p['z0'])*sd*d
                    tr.append(dict(t=p['t'],a=k[0],b=k[1],d=d,et=et,h=t-p['t'],g=g,net=g-cst))
                    del inpos[k]
        start=end
    return pd.DataFrame(tr)

def stat(df,label):
    if len(df)==0: return dict(label=label,N=0)
    x=df['net'].values; g=df['gross'].values if 'gross' in df else df['g'].values
    t=x.mean()/(x.std(ddof=1)/np.sqrt(len(x))) if x.std(ddof=1)>0 else 0
    return dict(label=label,N=len(x),gross_bp=g.mean()*1e4,net_bp=x.mean()*1e4,t=t,
                conv=int((df['et']=='conv').sum()) if 'et' in df else 0,
                stop=int((df['et']=='stop').sum()) if 'et' in df else 0)

print("="*90)
print("【A】全样本 配对交易  4种选对方法  (F=720 T=360 npairs=5 z_in=2 z_out=0.5 z_stop=4)")
print("="*90)
res=[]
for m in ['dist','corr','coint','rand']:
    d=run(720,360,5,m,2.0,0.5,4.0)
    s=stat(d,m); res.append(s)
    print(f"{m:6s} N={s['N']:6d} 毛={s['gross_bp']:+7.2f}bp 净={s['net_bp']:+7.2f}bp t={s['t']:+6.2f} conv={s['conv']:4d} stop={s['stop']:6d}")
print()
print("随机配对(rand)是对照: 若 dist/corr/coint 不优于 rand, 说明选对方法无价值")
d_best=max(res,key=lambda r:r['net_bp'])
print(f"最优: {d_best['label']}  但 |t|={abs(d_best['t']):.2f} {'<1.96 不显著' if abs(d_best['t'])<1.96 else '显著'}")

print()
print("="*90)
print("【B】参数网格稳健性 (dist 法) — 真实结构应出现成片为正, 孤立尖峰=过拟合")
print("="*90)
grid=[]
for F in [360,720,1440]:
    for T in [180,360,720]:
        for z_in,z_stop in [(1.5,3.0),(2.0,4.0),(2.5,5.0)]:
            d=run(F,T,5,'dist',z_in,0.5,z_stop)
            if len(d)<50: continue
            s=stat(d,f'F{F}_T{T}_z{z_in}/{z_stop}'); grid.append(s)
G=pd.DataFrame(grid)
print(G.to_string(index=False,float_format=lambda x:f'{x:+.3f}'))
print(f"\n净收益为正的组: {(G.net_bp>0).sum()}/{len(G)}   毛收益为正: {(G.gross_bp>0).sum()}/{len(G)}")
print(f"显著(|t|>1.96)的组: {(G.t.abs()>1.96).sum()}/{len(G)}")
G.to_pickle('grid_pair.pkl')
