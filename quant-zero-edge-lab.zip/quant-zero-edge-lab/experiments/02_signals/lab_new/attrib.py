import pandas as pd, numpy as np
px=pd.read_pickle('px_1h.pkl')

def cs_detail(L,H,k,sign,cost_bp=2.0,seg=None):
    P=px.iloc[seg[0]:seg[1]] if seg else px
    nn=len(P); cst=2.0*cost_bp/1e4
    rows=[]; t=L
    while t<nn-H-1:
        mom=(P.iloc[t]/P.iloc[t-L]-1.0).dropna()
        if len(mom)<2*k: t+=H; continue
        srt=mom.sort_values(ascending=(sign<0))
        lo=list(srt.index[:k]); sh=list(srt.index[-k:])
        pa=P.iloc[t].values; pb=P.iloc[t+H].values
        ci={c:i for i,c in enumerate(P.columns)}
        rl=np.mean([pb[ci[a]]/pa[ci[a]]-1 for a in lo])
        rs=np.mean([pb[ci[b]]/pa[ci[b]]-1 for b in sh])
        rm=np.mean(pb/pa-1)                    # 等权市场收益
        rows.append(dict(t=t,rl=rl,rs=rs,rm=rm,net=0.5*(rl-rs)-cst,
                         gross=0.5*(rl-rs)))
        t+=H
    return pd.DataFrame(rows)

def ols(y,x):
    X=np.column_stack([np.ones(len(x)),x])
    b=np.linalg.lstsq(X,y,rcond=None)[0]
    r=y-X@b; s2=r@r/(len(y)-2)
    cov=s2*np.linalg.inv(X.T@X); se=np.sqrt(np.diag(cov))
    return b[0],se[0],b[1],se[1]

print("="*95)
print("【E】截面动量 beta 归因:  cs = alpha + beta * market")
print("  若 beta 显著非零 -> 收益来自市场暴露(不是alpha); 只有 alpha 才是真本事")
print("="*95)
for L,H,k in [(240,120,3),(720,240,2),(480,120,3),(240,240,2)]:
    d=cs_detail(L,H,k,1)
    if len(d)<30: continue
    a,sea,b,seb=ols(d['net'].values, d['rm'].values)
    tb=b/seb; ta=a/sea
    # 市场的方向性
    up=(d['rm']>0).mean()
    print(f"L={L:4d} H={H:3d} k={k}: N={len(d):4d} 净={d['net'].mean()*1e4:+7.2f}bp")
    print(f"   alpha={a*1e4:+7.2f}bp (t={ta:+.2f})   beta={b:+.3f} (t={tb:+.2f})   市场上涨期占比={up:.1%}")
    # 分市场状态
    upm=d[d.rm>0]['net']; dnm=d[d.rm<=0]['net']
    print(f"   市场上涨期净={upm.mean()*1e4:+8.2f}bp (n={len(upm)})   下跌期净={dnm.mean()*1e4:+8.2f}bp (n={len(dnm)})")

print()
print("="*95)
print("【F】时间外推: 前50% vs 后50%  (动量 L=240 H=120 k=3)")
print("="*95)
n=len(px); half=n//2
for nm,seg in [('前半段',(0,half)),('后半段',(half,n))]:
    d=cs_detail(240,120,3,1,seg=seg)
    t=d['net'].mean()/(d['net'].std(ddof=1)/np.sqrt(len(d)))
    print(f"{nm}: N={len(d):4d} 净={d['net'].mean()*1e4:+8.2f}bp t={t:+.2f} 市场={d['rm'].mean()*1e4:+8.2f}bp")
print()
print("【G】市场状态拆分的决定性检验 — 若上涨期也为正, 才可能是真alpha")
d=cs_detail(240,120,3,1)
a,sea,b,seb=ols(d['net'].values,d['rm'].values)
print(f"   全样本 beta={b:+.3f} -> 剔除市场暴露后的 alpha={a*1e4:+.2f}bp/期, t={a/sea:+.2f}")
print(f"   对照: 毛(未扣成本) alpha={ (d['gross'].mean())*1e4:+.2f}bp")
