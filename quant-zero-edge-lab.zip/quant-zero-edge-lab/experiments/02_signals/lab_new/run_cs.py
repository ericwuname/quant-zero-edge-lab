import pandas as pd, numpy as np
px=pd.read_pickle('px_1h.pkl'); n=len(px)

def cs(L,H,k,sign,cost_bp=2.0,seg=None):
    P=px.iloc[seg[0]:seg[1]] if seg else px
    nn=len(P); cst=2.0*cost_bp/1e4
    rets=[];ts=[]; t=L
    while t<nn-H-1:
        mom=(P.iloc[t]/P.iloc[t-L]-1.0).dropna()
        if len(mom)<2*k: t+=H; continue
        srt=mom.sort_values(ascending=(sign<0))
        lo=list(srt.index[:k]); sh=list(srt.index[-k:])
        pa=P.iloc[t].values; pb=P.iloc[t+H].values
        ci={c:i for i,c in enumerate(P.columns)}
        rl=np.mean([pb[ci[a]]/pa[ci[a]]-1 for a in lo])
        rs=np.mean([pb[ci[b]]/pa[ci[b]]-1 for b in sh])
        rets.append(0.5*(rl-rs)-cst); ts.append(t); t+=H
    return pd.Series(rets,index=ts)

def bh(seg=None,H=None):
    P=px.iloc[seg[0]:seg[1]] if seg else px
    r=np.log(P).diff().dropna(); m=r.mean(axis=1)
    if H: m=m.iloc[::H].iloc[:len(m)//H]
    return m

print("="*95)
print("【C】横截面动量/反转  全样本  (L=240 H=120 k=3)")
print("="*95)
for sign,nm in [(1,'动量 多强空弱'),(-1,'反转 多弱空强')]:
    s=cs(240,120,3,sign)
    t=s.mean()/(s.std(ddof=1)/np.sqrt(len(s)))
    b=bh(H=120); tb=b.mean()/(b.std(ddof=1)/np.sqrt(len(b)))
    print(f"{nm}: N={len(s)} 均值={s.mean()*1e4:+8.2f}bp/期 t={t:+6.2f} | 同期等权多头={b.mean()*1e4:+8.2f}bp/期 t={tb:+.2f}")

print()
print("="*95)
print("【D】参数网格 (动量 sign=+1) — 检查参数平原")
print("="*95)
rows=[]
for L in [60,120,240,480,720]:
    for H in [60,120,240]:
        for k in [2,3,4]:
            for sign in [1,-1]:
                s=cs(L,H,k,sign)
                if len(s)<30: continue
                t=s.mean()/(s.std(ddof=1)/np.sqrt(len(s)))
                rows.append(dict(L=L,H=H,k=k,sign=sign,N=len(s),
                                 bp=s.mean()*1e4,t=t))
G=pd.DataFrame(rows)
G.to_pickle('grid_cs.pkl')
piv=G[G.sign==1].pivot_table(index=['L','k'],columns='H',values='bp')
print("\n动量 净收益bp/期:")
print(piv.round(1).to_string())
piv2=G[G.sign==-1].pivot_table(index=['L','k'],columns='H',values='bp')
print("\n反转 净收益bp/期:")
print(piv2.round(1).to_string())
print(f"\n动量: 正={(  (G[G.sign==1].bp>0).sum())}/{len(G[G.sign==1])}  显著|t|>1.96: {(G[G.sign==1].t.abs()>1.96).sum()}")
print(f"反转: 正={((G[G.sign==-1].bp>0).sum())}/{len(G[G.sign==-1])}  显著|t|>1.96: {(G[G.sign==-1].t.abs()>1.96).sum()}")
print("\n最强5组:")
print(G.reindex(G.t.abs().sort_values(ascending=False).index).head(8).to_string(index=False,float_format=lambda x:f'{x:+.3f}'))
