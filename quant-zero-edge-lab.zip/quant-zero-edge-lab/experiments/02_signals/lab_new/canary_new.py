"""对新策略(配对/截面)做前视探测 —— 平台校验"""
import pandas as pd, numpy as np, ssd_fast
px=pd.read_pickle('px_1h.pkl')
rng=np.random.default_rng(0)

print("="*95); print("【J】CANARY 前视探测 (新策略)"); print("="*95)
print("原理: 打乱 t 之后的未来数据, 若 t 时刻的选对/排序结果改变 -> 偷看未来")

# --- 配对: 打乱未来后, formation 选的对是否改变 ---
F=720
for m in ['dist','corr','coint']:
    diffs=0; tot=0
    for t in [F+100, 8000, 20000, 35000, 45000]:
        d2=px.copy()
        idx=np.arange(t,len(px)); perm=rng.permutation(idx)
        v=px.values.copy(); v[t:]=v[t:][perm-t]; d2=pd.DataFrame(v,index=px.index,columns=px.columns)
        a=ssd_fast.select_fast(px.iloc[t-F:t],m,5)
        b=ssd_fast.select_fast(d2.iloc[t-F:t],m,5)
        tot+=1; diffs+= int(set(a)!=set(b))
    print(f"  配对[{m:5s}] 5个时点, 未来打乱后选对改变次数={diffs}/{tot} -> {'干净' if diffs==0 else '前视!'}")

# --- 截面: 打乱未来后, t 时刻排名是否改变 ---
for L in [240]:
    diffs=0; tot=0
    for t in [L+100, 8000, 20000, 35000, 45000]:
        d2=px.copy()
        idx=np.arange(t,len(px)); perm=rng.permutation(idx)
        v=px.values.copy(); v[t:]=v[t:][perm-t]; d2=pd.DataFrame(v,index=px.index,columns=px.columns)
        a=(px.iloc[t]/px.iloc[t-L]-1).sort_values().index.tolist()
        b=(d2.iloc[t]/d2.iloc[t-L]-1).sort_values().index.tolist()
        tot+=1; diffs+= int(a!=b)
    print(f"  截面[L={L}] 5个时点, 未来打乱后排名改变次数={diffs}/{tot} -> {'干净' if diffs==0 else '前视!'}")

# --- 负对照: 故意用未来 L bar 收益排序, 探测器必须报警 ---
print("\n  负对照(故意前视: 用 t..t+L 的未来收益排序):")
diffs=0; tot=0
def cheat_rank(df,t,L):
    return (df.iloc[t+L]/df.iloc[t]-1).sort_values().index.tolist()
for t in [20000,30000]:
    d2=px.copy()
    idx=np.arange(t,len(px)); perm=rng.permutation(idx)
    v=px.values.copy(); v[t:]=v[t:][perm-t]; d2=pd.DataFrame(v,index=px.index,columns=px.columns)
    try:
        a=cheat_rank(px,t,240); b=cheat_rank(d2,t,240); tot+=1; diffs+=int(a!=b)
    except Exception: pass
print(f"    打乱未来后改变={diffs}/{tot} -> {'探测器有效(能抓到)' if diffs>0 else '探测器失效!'}")

# --- 收益口径 sanity: 信号后移1期 ---
print("\n  收益崩塌检验(信号后移1期, 若收益不崩 -> 前视嫌疑):")
def cs_net(L,H,k,shift=0):
    nn=len(px); cst=4e-4; out=[]; t=L+shift
    while t<nn-H-1:
        mom=(px.iloc[t-shift]/px.iloc[t-shift-L]-1.0).dropna()
        srt=mom.sort_values(ascending=False); lo=list(srt.index[:k]); sh=list(srt.index[-k:])
        pa=px.iloc[t]; pb=px.iloc[t+H]
        out.append(0.5*(np.mean([pb[a]/pa[a]-1 for a in lo])-np.mean([pb[b]/pa[b]-1 for b in sh]))-cst); t+=H
    return np.mean(out)*1e4
print(f"    原始排序 -> 下一期持有: {cs_net(240,120,3,0):+.2f}bp")
print(f"    排序后移1期(用过期排名): {cs_net(240,120,3,1):+.2f}bp  (应显著降低)")
