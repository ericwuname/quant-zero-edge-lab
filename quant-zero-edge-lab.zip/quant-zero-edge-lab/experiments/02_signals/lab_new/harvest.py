"""收割制: 不复利(固定注) + 盈余公积提取 + 爆仓线"""
import pandas as pd, numpy as np
px=pd.read_pickle('px_1h.pkl')
rng=np.random.default_rng(11)

# ---------- 生成各策略的"每笔/每期净收益率"序列 ----------
def seq_cs(L,H,k,sign=1,cost_bp=2.0):
    nn=len(px); cst=2.0*cost_bp/1e4; out=[]; t=L
    while t<nn-H-1:
        mom=(px.iloc[t]/px.iloc[t-L]-1.0).dropna()
        srt=mom.sort_values(ascending=(sign<0)); lo=list(srt.index[:k]); sh=list(srt.index[-k:])
        pa=px.iloc[t]; pb=px.iloc[t+H]
        out.append(0.5*(np.mean([pb[a]/pa[a]-1 for a in lo])-np.mean([pb[b]/pa[b]-1 for b in sh]))-cst); t+=H
    return np.array(out)

def seq_pairs(F,T,npairs,method,cost_bp=2.0):
    import ssd_fast
    L=np.log(px); nn=len(px); cst=2.0*cost_bp/1e4; out=[]; start=F
    while start<nn-2:
        end=min(start+T,nn-1)
        prs=ssd_fast.select_fast(px.iloc[start-F:start],method,npairs)
        par={}
        for a,b in prs:
            s=L[a].iloc[start-F:start]-L[b].iloc[start-F:start]; sd=float(s.std())
            if np.isfinite(sd) and sd>0: par[(a,b)]=(float(s.mean()),sd)
        la={k:L[k[0]].values for k in par}; lb={k:L[k[1]].values for k in par}
        inp={}
        for t in range(start,end):
            for k2,(mu,sd) in par.items():
                if k2 in inp: continue
                z=(la[k2][t]-lb[k2][t]-mu)/sd
                if np.isfinite(z) and abs(z)>=2.0: inp[k2]=dict(t=t,d=(-1 if z>0 else 1),z0=z)
            for k2 in list(inp.keys()):
                p=inp[k2]
                if t-p['t']<1: continue
                mu,sd=par[k2]; z=(la[k2][t]-lb[k2][t]-mu)/sd
                if not np.isfinite(z): continue
                if abs(z)>=4.0 or abs(z)<=0.5 or t>=end-1:
                    out.append(0.5*(z-p['z0'])*sd*p['d']-cst); del inp[k2]
        start=end
    return np.array(out)

print("生成序列...")
S={}
S['截面动量 L240H120k3']=seq_cs(240,120,3)
S['截面动量 L720H240k2']=seq_cs(720,240,2)
S['配对 dist']=seq_pairs(720,360,5,'dist')
S['配对 corr']=seq_pairs(720,360,5,'corr')
for k,v in S.items():
    print(f"  {k}: N={len(v)} 均值={v.mean()*1e4:+.2f}bp 标准差={v.std()*1e4:.1f}bp")

# ---------- 收割制模拟 ----------
def harvest_sim(r, f, C0=10000.0, T=1.0, ruin=0.2, nboot=2000, horizon=None, seed=11):
    """f: 每期押注占本金比例(固定注)  T: 收割阈值(净值达 C0*(1+T) 则提取浮盈重置)"""
    rr=np.random.default_rng(seed); n=len(r)
    Hh=horizon if horizon else n
    res=[]
    for b in range(nboot):
        idx=rr.integers(0,n,size=Hh)
        W=C0; harv=0.0; bust=False
        for i in idx:
            W += f*C0*r[i]
            if W>=C0*(1+T): harv += W-C0; W=C0
            elif W<=C0*ruin: bust=True; break
        res.append(dict(total=W+harv, harv=harv, bust=bust,
                        win=harv>=C0, endW=W))
    return pd.DataFrame(res)

print()
print("="*100)
print("【L】收割制 (不复利+盈余公积)  C0=10000  翻倍即收割, 爆仓线20%")
print("="*100)
print(f"{'策略':<22}{'f':>5}{'P(赚回本金)':>12}{'落袋中位':>11}{'总资产中位':>11}{'爆仓率':>9}")
rows=[]
for nm,r in S.items():
    if len(r)<50: continue
    for f in [0.01,0.02,0.05,0.10]:
        d=harvest_sim(r,f)
        rows.append(dict(strategy=nm,f=f,P=d.win.mean(),
                         harv=d.harv.median(),tot=d.total.median(),bust=d.bust.mean()))
        print(f"{nm:<22}{f:>5.2f}{d.win.mean():>12.1%}{d.harv.median():>11.0f}{d.total.median():>11.0f}{d.bust.mean():>9.1%}")
R=pd.DataFrame(rows); R.to_pickle('harvest_res.pkl')

print()
print("="*100)
print("【M】零期望对照 (把序列中心化 -> 剔除edge, 只剩几何) — 判断'白送'基线")
print("="*100)
print(f"{'策略':<22}{'f':>5}{'真实P':>9}{'零期望P':>9}{'差值':>9}{'真实EV':>10}{'零期望EV':>10}")
for nm,r in S.items():
    if len(r)<50: continue
    r0=r-r.mean()
    for f in [0.02,0.05]:
        d=harvest_sim(r,f); d0=harvest_sim(r0,f)
        ev=(d.total-C0 if False else d.total).mean()-C0
        ev0=d0.total.mean()-C0
        print(f"{nm:<22}{f:>5.2f}{d.win.mean():>9.1%}{d0.win.mean():>9.1%}{d.win.mean()-d0.win.mean():>+9.1%}{ev:>+10.0f}{ev0:>+10.0f}")
