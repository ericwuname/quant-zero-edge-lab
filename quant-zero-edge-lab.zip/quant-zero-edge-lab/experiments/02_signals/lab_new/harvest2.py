import numpy as np, pandas as pd, pickle
S=pickle.load(open('seqs.pkl','rb'))

def sim(r,f,C0=10000.0,T=1.0,ruin=0.2,nboot=3000,horizon=None,seed=11):
    rng=np.random.default_rng(seed); n=len(r); Hh=horizon or n
    tot=np.zeros(nboot); hv=np.zeros(nboot); bst=np.zeros(nboot,bool); win=np.zeros(nboot,bool)
    for b in range(nboot):
        W=C0; h=0.0
        for i in rng.integers(0,n,size=Hh):
            W += f*C0*r[i]
            if W>=C0*(1+T): h+=W-C0; W=C0
            elif W<=C0*ruin: bst[b]=True; break
        tot[b]=W+h; hv[b]=h; win[b]= h>=C0
    return dict(P=win.mean(),harv=np.median(hv),tot=np.median(tot),
                bust=bst.mean(),EV=tot.mean()-C0)

print("="*104)
print("【L】收割制  不复利(固定注)+盈余公积  C0=10000  翻倍即收割  爆仓线20%")
print("="*104)
print(f"{'策略':<16}{'N':>7}{'f':>6}{'P(赚回本金)':>12}{'落袋中位':>11}{'总资产中位':>11}{'爆仓率':>8}{'EV':>9}")
out=[]
for nm,r in S.items():
    for f in [0.05,0.10,0.20,0.40,0.80]:
        d=sim(r,f)
        out.append(dict(strategy=nm,N=len(r),f=f,**d))
        print(f"{nm:<16}{len(r):>7}{f:>6.2f}{d['P']:>12.1%}{d['harv']:>11.0f}{d['tot']:>11.0f}{d['bust']:>8.1%}{d['EV']:>+9.0f}")
    print()
pd.DataFrame(out).to_pickle('harv2.pkl')

print("="*104)
print("【M】零期望对照: 序列中心化(剔除edge) -> 测'纯几何白送'基线")
print("="*104)
print(f"{'策略':<16}{'f':>6}{'真实P':>9}{'零期望P':>9}{'P差值':>9}{'真实EV':>10}{'零期望EV':>10}{'EV差':>9}")
for nm,r in S.items():
    r0=r-r.mean()
    for f in [0.20,0.40,0.80]:
        d=sim(r,f); d0=sim(r0,f)
        print(f"{nm:<16}{f:>6.2f}{d['P']:>9.1%}{d0['P']:>9.1%}{d['P']-d0['P']:>+9.1%}{d['EV']:>+10.0f}{d0['EV']:>+10.0f}{d['EV']-d0['EV']:>+9.0f}")
    print()

print("="*104)
print("【N】E衰减敏感性: 截面动量若不显著, 真实E可能远低于回测值")
print("="*104)
r=S['CS_L240H120k3']; base=r.mean()
print(f"{'E缩放':>8}{'等效bp':>9}{'f=0.2 P':>10}{'f=0.4 P':>10}{'f=0.8 P':>10}{'f=0.4 EV':>10}")
for sc in [1.0,0.7,0.5,0.3,0.0]:
    rr=(r-base)+base*sc
    row=f"{sc:>8.2f}{rr.mean()*1e4:>9.2f}"
    for f in [0.2,0.4,0.8]:
        row+=f"{sim(rr,f)['P']:>10.1%}"
    row+=f"{sim(rr,0.4)['EV']:>+10.0f}"
    print(row)
