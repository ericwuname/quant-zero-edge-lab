import numpy as np, pandas as pd, time
px=pd.read_pickle('px_1h.pkl'); P=px.values; n,m=P.shape
rng=np.random.default_rng(5)
CST=4e-4
GRID=[(L,H,k) for L in [60,120,240,480,720] for H in [60,120,240] for k in [2,3,4]]

# 预计算每个 (L,H) 的索引矩阵
IDX={}
for L in [60,120,240,480,720]:
    for H in [60,120,240]:
        s=np.arange(L,n-H-1,H)
        IDX[(L,H)]=s

def cs_fast(L,H,k,shuffle=False):
    s=IDX[(L,H)]
    if len(s)<30: return np.array([])
    T0=P[s]; TL=P[s-L]; TH=P[s+H]
    MOM=T0/TL-1.0; RET=TH/T0-1.0
    bad=~np.isfinite(MOM)
    MOM=np.where(bad,-np.inf,MOM)
    if shuffle:
        # 随机选股: 对每期随机排列品种
        perm=np.argsort(rng.random(MOM.shape),axis=1)
        top=perm[:,:k]; bot=perm[:,-k:]
    else:
        o=np.argsort(-MOM,axis=1); top=o[:,:k]; bot=o[:,-k:]
    rows=np.arange(len(s))
    rl=RET[rows[:,None],top].mean(1); rs=RET[rows[:,None],bot].mean(1)
    return 0.5*(rl-rs)-CST

print("真实 45 组合:")
R=[]
for g in GRID:
    a=cs_fast(*g)
    if len(a)<30: continue
    t=a.mean()/(a.std(ddof=1)/np.sqrt(len(a)))
    R.append(dict(L=g[0],H=g[1],k=g[2],bp=a.mean()*1e4,N=len(a),t=t))
R=pd.DataFrame(R).sort_values('t',ascending=False)
print(R.head(8).to_string(index=False,float_format=lambda x:f'{x:+.3f}'))
best=R.iloc[0]; V=best.t
print(f"\n最强: L={int(best.L)} H={int(best.H)} k={int(best.k)}  t={V:+.3f}  bp={best.bp:+.2f}/期  N={int(best.N)}")

# 单组合置换
nl=[]
for _ in range(500):
    a=cs_fast(int(best.L),int(best.H),int(best.k),shuffle=True)
    nl.append(a.mean()/(a.std(ddof=1)/np.sqrt(len(a))))
p1=(np.sum(np.array(nl)>=V)+1)/501
print(f"\n单组合置换 p = {p1:.4f}  (随机选股500次, 95分位t={np.percentile(nl,95):+.3f})")

# Reality Check: 每次置换取45组合最大t
print("\nReality Check (300次置换, 每次取45组合max-t)...")
t0=time.time(); Vb=[]
for b in range(300):
    mx=-9e9
    for g in GRID:
        a=cs_fast(*g,shuffle=True)
        if len(a)<30: continue
        t=a.mean()/(a.std(ddof=1)/np.sqrt(len(a)))
        if t>mx: mx=t
    Vb.append(mx)
Vb=np.array(Vb); p_rc=(np.sum(Vb>=V)+1)/301
print(f"  真实最强 t      = {V:+.3f}")
print(f"  置换 max-t 均值 = {Vb.mean():+.3f}   95分位={np.percentile(Vb,95):+.3f}   99分位={np.percentile(Vb,99):+.3f}")
print(f"  Reality Check p = {p_rc:.4f} -> {'显著' if p_rc<0.05 else '不显著 (多重挑选后塌掉)'}")
print(f"用时 {time.time()-t0:.0f}s")
R.to_pickle('rc_grid.pkl')
