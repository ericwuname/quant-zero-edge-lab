import numpy as np, pandas as pd, sys
sys.path.insert(0,'.')
from eng import mom_sig, run
from selftest import synth_ohlc

print('--- 1. 合成零漂移 + 随机方向 (最干净) ---')
for sp in [0.015,0.02]:
    Es=[];ps=[]
    for sd in range(8):
        O,H,Lw,C=synth_ohlc(20000,4,0.01,8,seed=sd)
        rng=np.random.default_rng(sd)
        s=rng.choice([-1.0,1.0],C.shape)
        res=run(O,H,Lw,C,s,sp,2.0,5,seed=sd,start=50)
        r=res[res.Rmul.isin([-1.0,2.0])]
        Es.append(r.Rmul.mean()); ps.append((r.Rmul>0).mean())
    Es=np.array(Es);ps=np.array(ps)
    print(f'  stop={sp}: E={Es.mean():+.4f}±{Es.std(ddof=1)/np.sqrt(8):.4f}  胜率={ps.mean():.4f} (理论0.3333)')

print('\n--- 2. 合成零漂移 + 随机方向, 但每bar重新随机 vs 固定 ---')
for sp in [0.02]:
    for cd in [0,5,60]:
        Es=[]
        for sd in range(6):
            O,H,Lw,C=synth_ohlc(20000,4,0.01,8,seed=sd)
            rng=np.random.default_rng(sd)
            s=rng.choice([-1.0,1.0],C.shape)
            res=run(O,H,Lw,C,s,sp,2.0,cd,seed=sd,start=50)
            r=res[res.Rmul.isin([-1.0,2.0])]
            Es.append(r.Rmul.mean())
        Es=np.array(Es)
        print(f'  cd={cd}: E={Es.mean():+.4f}±{Es.std(ddof=1)/np.sqrt(6):.4f}  n={len(r)}')

print('\n--- 3. 检查末尾强平占比 + 持仓时长 ---')
O,H,Lw,C=synth_ohlc(20000,4,0.01,8,seed=0)
rng=np.random.default_rng(0); s=rng.choice([-1.0,1.0],C.shape)
res=run(O,H,Lw,C,s,0.02,2.0,5,seed=0,start=50)
tot=len(res); fin=res[res.Rmul.isin([-1.0,2.0])]
print(f'  总笔={tot} 正常结束={len(fin)} 末尾强平={tot-len(fin)} ({100*(tot-len(fin))/tot:.2f}%)')
b=res.bar.values; hold=np.diff(np.concatenate([[0],b]))
print(f'  持仓bar 中位={np.median(hold):.0f} 均值={hold.mean():.1f} 最大={hold.max()}')
