import numpy as np, pandas as pd

SYMS=['CRV','DASH','DOGE','DOT','ETH','FIL','HBAR','TRX','UNI','XLM','XMR','XRP','ZEC']

def load_all():
    d={}
    for s in SYMS:
        x=pd.read_csv(f'/data/inputs/{s}USDT_1h.csv')
        x['ts']=pd.to_datetime(x['timestamp'],unit='ms')
        d[s]=x.set_index('ts')[['open','high','low','close']].astype(float)
    idx=sorted(set.intersection(*[set(v.index) for v in d.values()]))
    O=pd.DataFrame({s:d[s].loc[idx,'open'].values for s in SYMS},index=idx)
    H=pd.DataFrame({s:d[s].loc[idx,'high'].values for s in SYMS},index=idx)
    L=pd.DataFrame({s:d[s].loc[idx,'low'].values for s in SYMS},index=idx)
    C=pd.DataFrame({s:d[s].loc[idx,'close'].values for s in SYMS},index=idx)
    return O,H,L,C

def mom_sig(C,L):
    # sig[t] = sign(close[t]-close[t-L]); 只用t及之前信息
    return np.sign(C.values - np.vstack([np.full((L,C.shape[1]),np.nan),C.values[:-L]]))

def run(O,H,L,C,sig,stop_pct,R,cd,seed=0,start=0):
    """逐笔、一次一个持仓、平仓后冷却cd根bar、入场价=open[t+1]"""
    o,h,l,c=O.values,H.values,L.values,C.values
    T,N=o.shape
    rng=np.random.default_rng(seed)
    state=None; last_exit=-10**9
    rec=[]
    t=start
    while t<T-1:
        if state is not None:
            i=state['i']; d=state['d']
            # 同bar双触及 -> 保守判止损
            if d>0:
                hs = l[t,i]<=state['stop']; ht = h[t,i]>=state['tgt']
            else:
                hs = h[t,i]>=state['stop']; ht = l[t,i]<=state['tgt']
            if hs:
                rec.append((i,d,-1.0,t)); state=None; last_exit=t; t+=1; continue
            if ht:
                rec.append((i,d,R,t)); state=None; last_exit=t; t+=1; continue
            t+=1; continue
        # 空仓
        if t-last_exit<cd:
            t+=1; continue
        sv=sig[t]
        cand=np.nonzero(~np.isnan(sv)&(sv!=0))[0]
        if len(cand)==0:
            t+=1; continue
        i=int(rng.choice(cand))
        d=float(sv[i])
        ep=o[t+1,i]
        if not np.isfinite(ep) or ep<=0:
            t+=1; continue
        stop=ep*(1-d*stop_pct); tgt=ep*(1+d*R*stop_pct)
        state=dict(i=i,d=d,stop=stop,tgt=tgt,ep=ep,eb=t+1)
        t+=1
    if state is not None:  # 末尾强平
        i=state['i']; d=state['d']
        ret=(c[T-1,i]-state['ep'])/state['ep']*d
        rec.append((i,d,ret/stop_pct,T-1))
    return pd.DataFrame(rec,columns=['sym','dir','Rmul','bar'])

if __name__=='__main__':
    O,H,Lw,C=load_all()
    print('bars',len(C),'syms',len(SYMS),C.index[0],C.index[-1])
    # 自检1: 合成零漂移 -> gross E 应为0
    rng=np.random.default_rng(1); T=20000; N=3
    r=rng.normal(0,0.01,(T,N)); c=100*np.exp(np.cumsum(r,0))
    C2=pd.DataFrame(c); O2=C2.shift(1).fillna(100)
    H2=pd.DataFrame(np.maximum(c,O2.values)*1.001); L2=pd.DataFrame(np.minimum(c,O2.values)*0.999)
    s2=mom_sig(C2,120)
    res=run(O2,H2,L2,C2,s2,0.02,2.0,5,seed=0,start=130)
    print('SYNTH zero-drift gross E =',round(res.Rmul.mean(),4),' n=',len(res))
    # 自检2: bar振幅
    amp=((H.values-Lw.values)/C.values)
    print('bar amplitude median bp =',round(np.nanmedian(amp)*1e4,1),
          ' p90 =',round(np.nanpercentile(amp,90)*1e4,1))
    # 跳空率
    g=np.abs(O.values[1:]-C.values[:-1])/C.values[:-1]
    print('gap median bp =',round(np.nanmedian(g)*1e4,2),' P(gap>1.5%)=',round(float(np.nanmean(g>0.015))*100,5),'%')
