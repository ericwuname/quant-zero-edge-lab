import numpy as np, pandas as pd, sys
sys.path.insert(0,'.')
from eng import load_all, mom_sig, run
SYMS=['CRV','DASH','DOGE','DOT','ETH','FIL','HBAR','TRX','UNI','XLM','XMR','XRP','ZEC']
O,H,Lw,C=load_all()
def ps(res,stop):
    r=res[res.Rmul.isin([-1.0,2.0])]
    return r.groupby('sym').Rmul.mean()
def one(sig,stop,cd,seeds):
    return pd.concat([ps(run(O,H,Lw,C,sig,stop,2.0,cd,seed=sd,start=300),stop) for sd in seeds],axis=1).mean(axis=1)

print('=== A. 凸性分解(真实数据, stop=2%, cd=20) ===')
res={}
for name,sig in [('全多',np.where(np.isnan(C.values),np.nan,1.0)),
                 ('全空',np.where(np.isnan(C.values),np.nan,-1.0)),
                 ('随机',np.where(np.isnan(C.values),np.nan,np.random.default_rng(3).choice([-1.,1.],C.shape))),
                 ('mom120',mom_sig(C,120))]:
    v=one(sig,0.02,20,(0,1,2)); res[name]=v
    print(f'  {name:>6}: E={v.mean():+.4f}')
print(f'  >> 凸性检验 全多-全空 = {res["全多"].mean()-res["全空"].mean():+.4f} '
      f'(合成GBM理论为正; 真实含牛熊漂移)')

print('\n=== B. 混合成本下的真实 cost_R (入场限价2bp, 止盈限价2bp, 止损市价10bp) ===')
# 加权: 胜率p时成本=p*(4bp)+(1-p)*(12bp), 转R单位除以止损
for stop in [0.015,0.02]:
    for p in [0.333]:
        cbp = p*4 + (1-p)*12
        cr = cbp/10000/stop
        print(f'  stop={stop:.3f}: 期望成本={cbp:.2f}bp -> cost_R={cr:.4f}')

print('\n=== C. 净期望 & 盈亏平衡 ===')
E_base=0.0079
print(f'  随机方向基线(真实) E_gross = {E_base:+.4f} R/笔   [alpha≈0, 故信号E≈同值]')
for cr,lab in [(0.020,'全限价maker 止损2%'),(0.0267,'全限价maker 止损1.5%'),
               (0.047,'混合 止损2%(用户口径)'),(0.062,'混合 止损1.5%(用户口径)'),
               (0.008,'全限价maker 止损5%')]:
    print(f'  cost_R={cr:.4f} [{lab:22s}] -> 净E = {E_base-cr:+.4f}  '
          f'{"✓正" if E_base>cr else "✗负"}')
