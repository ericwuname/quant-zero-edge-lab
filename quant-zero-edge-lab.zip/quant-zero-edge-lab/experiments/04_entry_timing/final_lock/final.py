import numpy as np, pandas as pd, sys, time
sys.path.insert(0,'.')
from eng import load_all, mom_sig, run
SYMS=['CRV','DASH','DOGE','DOT','ETH','FIL','HBAR','TRX','UNI','XLM','XMR','XRP','ZEC']
O,H,Lw,C=load_all(); T=len(C)
print('bars',T,'| 各品种对数收益(BH):',', '.join(f'{s}:{np.exp(np.log(C[s].iloc[-1]/C[s].iloc[0]))-1:+.0%}' for s in SYMS[:5]),'...')

def per_sym(res):
    return res.groupby('sym').Rmul.mean()

def one(sig,stop,cd,seeds=(0,1,2)):
    Es=[]
    for sd in seeds:
        r=run(O,H,Lw,C,sig,stop,2.0,cd,seed=sd,start=300)
        r=r[r.Rmul.isin([-1.0,2.0])]
        Es.append(per_sym(r))
    return pd.concat(Es,axis=1).mean(axis=1)

rows=[]
t0=time.time()
for L in [60,120,240]:
    sig=mom_sig(C,L)
    for stop in [0.015,0.020]:
        for cd in [5,20,60]:
            a=one(sig,stop,cd)
            rng=np.random.default_rng(7)
            rs=np.where(np.isnan(C.values),np.nan,rng.choice([-1.0,1.0],C.shape))
            b=one(rs,stop,cd)
            d=(a-b).dropna()
            n=len(d); t=d.mean()/(d.std(ddof=1)/np.sqrt(n)) if n>1 and d.std(ddof=1)>0 else np.nan
            rows.append(dict(L=L,stop=stop,cd=cd,
                E_sig=a.mean(), E_rand=b.mean(), alpha=d.mean(), t_alpha=t,
                wr_sig=None))
            print(f'L={L} stop={stop} cd={cd}: E_sig={a.mean():+.4f} E_rand={b.mean():+.4f} '
                  f'alpha={d.mean():+.4f} t={t:+.2f}  ({time.time()-t0:.0f}s)')
pd.DataFrame(rows).to_csv('final.csv',index=False)
