import numpy as np
np.set_printoptions(suppress=True)

def mc_continuous(P0, s, R, sigma_bar, sub, nbar_max, n, seed):
    """连续步进: 每步检查, 无bar聚合. 返回 (p_tgt, E)"""
    rng=np.random.default_rng(seed)
    step_sigma = sigma_bar/np.sqrt(sub)
    stop = P0*(1-s); tgt = P0*(1+R*s)
    res=np.zeros(n)
    for k in range(n):
        p=P0; out=None
        for b in range(nbar_max):
            for _ in range(sub):
                p *= np.exp(rng.normal(0,step_sigma))
                if p<=stop: out=-1.0; break
                if p>=tgt:  out=R;    break
            if out is not None: break
        res[k]= out if out is not None else 0.0
    ok=res!=0
    return (res[ok]>0).mean(), res[ok].mean()

def mc_bar(P0, s, R, sigma_bar, sub, nbar_max, n, seed, conservative=True):
    """bar聚合: 每bar末用high/low判定, 同bar双触及判止损(保守)"""
    rng=np.random.default_rng(seed)
    step_sigma = sigma_bar/np.sqrt(sub)
    stop = P0*(1-s); tgt = P0*(1+R*s)
    res=np.zeros(n)
    for k in range(n):
        p=P0; out=None
        for b in range(nbar_max):
            hi=p; lo=p
            for _ in range(sub):
                p *= np.exp(rng.normal(0,step_sigma))
                hi=max(hi,p); lo=min(lo,p)
            hs = lo<=stop; ht = hi>=tgt
            if hs: out=-1.0; break
            if ht: out=R; break
        res[k]= out if out is not None else 0.0
    ok=res!=0
    return (res[ok]>0).mean(), res[ok].mean()

R=2.0; sig=0.01; sub=8
print(f"{'止损':>6} {'方式':>10} {'胜率':>8} {'E':>9}   理论p(算术)=0.3333  p(对数修正)")
for s in [0.015,0.02,0.03]:
    a=R*s; b=s
    pl=np.log(1+b)/(np.log(1+a)+np.log(1+b))
    for name,fn in [('连续步进',mc_continuous),('bar聚合',mc_bar)]:
        ps=[];Es=[]
        for sd in range(5):
            p,e=fn(100.0,s,R,sig,sub,2000,400,sd)
            ps.append(p);Es.append(e)
        print(f'{s:>6.3f} {name:>10} {np.mean(ps):>8.4f} {np.mean(Es):>+9.4f}   p_log={pl:.4f}')

print('\n=== 多空分解 (bar聚合, stop=2%) ===')
# 用方向参数模拟空头: 等价于把收益取反
def mc_dir(d, s, R, sigma_bar, sub, nbar_max, n, seed):
    rng=np.random.default_rng(seed); step=sigma_bar/np.sqrt(sub)
    stop=100*(1-d*s); tgt=100*(1+d*R*s); res=np.zeros(n)
    for k in range(n):
        p=100.0; out=None
        for b in range(nbar_max):
            hi=p;lo=p
            for _ in range(sub):
                p*=np.exp(rng.normal(0,step)); hi=max(hi,p); lo=min(lo,p)
            if d>0: hs=lo<=stop; ht=hi>=tgt
            else:   hs=hi>=stop; ht=lo<=tgt
            if hs: out=-1.0;break
            if ht: out=R;break
        res[k]=out if out is not None else 0.0
    ok=res!=0
    return (res[ok]>0).mean(), res[ok].mean()
for d in [1,-1]:
    ps=[];Es=[]
    for sd in range(5):
        p,e=mc_dir(d,0.02,2.0,sig,sub,2000,400,sd); ps.append(p);Es.append(e)
    print(f'  方向={d:+d}: 胜率={np.mean(ps):.4f} E={np.mean(Es):+.4f}')
