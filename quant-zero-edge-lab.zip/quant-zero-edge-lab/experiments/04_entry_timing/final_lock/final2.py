import numpy as np, pandas as pd, sys, time
sys.path.insert(0,'.')
from eng import load_all, mom_sig, run
SYMS=['CRV','DASH','DOGE','DOT','ETH','FIL','HBAR','TRX','UNI','XLM','XMR','XRP','ZEC']
O,H,Lw,C=load_all(); T=len(C)
def ps(res):
    r=res[res.Rmul.isin([-1.0,2.0])]
    return r.groupby('sym').Rmul.mean()
def one(sig,stop,cd,seeds):
    return pd.concat([ps(run(O,H,Lw,C,sig,stop,2.0,cd,seed=sd,start=300)) for sd in seeds],axis=1).mean(axis=1)

NR=12   # 随机方向实现数
rows=[];t0=time.time()
for L in [60,120,240]:
    sig=mom_sig(C,L)
    cache={}
    for stop in [0.015,0.020]:
        for cd in [5,20,60]:
            k=(stop,cd)
            if k not in cache:
                Es=[]
                for j in range(NR):
                    rng=np.random.default_rng(1000+j)
                    rs=np.where(np.isnan(C.values),np.nan,rng.choice([-1.0,1.0],C.shape))
                    Es.append(one(rs,stop,cd,(j%3,)))
                R=pd.concat(Es,axis=1)
                cache[k]=(R.mean(axis=1), R.std(axis=1).mean())
            b,bse=cache[k]
            a=one(sig,stop,cd,(0,1,2))
            d=(a-b).dropna(); n=len(d)
            t=d.mean()/(d.std(ddof=1)/np.sqrt(n))
            rows.append(dict(L=L,stop=stop,cd=cd,E_sig=a.mean(),E_rand=b.mean(),
                             rand_sd_across=bse,alpha=d.mean(),t=t))
            print(f'L={L:3d} stop={stop:.3f} cd={cd:2d}: E_sig={a.mean():+.4f} '
                  f'E_rand={b.mean():+.4f}(±{bse:.3f}) alpha={d.mean():+.4f} t={t:+.2f} [{time.time()-t0:.0f}s]')
df=pd.DataFrame(rows); df.to_csv('final2.csv',index=False)
print('\n=== alpha 汇总 (真方向能力) ===')
print(f'  18配置 alpha均值={df.alpha.mean():+.4f}  |t|>1.96个数={int((df.t.abs()>1.96).sum())} '
      f'(正显著{int((df.t>1.96).sum())} 负显著{int((df.t<-1.96).sum())})')
print(f'  E_rand 均值={df.E_rand.mean():+.4f}  (随机方向基线的"多头凸性+beta")')
print(f'  E_sig  均值={df.E_sig.mean():+.4f}')
