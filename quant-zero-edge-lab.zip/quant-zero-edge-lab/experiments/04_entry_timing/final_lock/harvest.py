import numpy as np, pandas as pd, sys
sys.path.insert(0,'.')
from eng import load_all, mom_sig, run
O,H,Lw,C=load_all()
# 真实R序列 (mom120, stop=2%, cd=20) + 品种bar位置
sig=mom_sig(C,120)
res=pd.concat([run(O,H,Lw,C,sig,0.02,2.0,20,seed=sd,start=300) for sd in (0,1,2,3,4)])
res=res[res.Rmul.isin([-1.0,2.0])].reset_index(drop=True)
print('真实序列: n=%d 胜率=%.4f 毛E=%+.4f'%(len(res),(res.Rmul>0).mean(),res.Rmul.mean()))

def sim(R,cost_R,f=0.01,C0=10000,week=168,npath=3000,seed=0,scale=1.0):
    rng=np.random.default_rng(seed)
    idx=rng.integers(0,len(R),size=(npath,4000))
    seq=(R.values[idx]*scale)-cost_R        # 净R (scale用于E衰减压力测试)
    bars=res.bar.values[idx]
    W=np.full(npath,float(C0)); cum=np.zeros(npath); done=np.zeros(npath,bool)
    last_wk=np.zeros(npath,int)
    for k in range(4000):
        act=~done
        if not act.any(): break
        # 押注: 固定注= f*C0 的风险金额 -> 每笔盈亏(元)= f*C0 * R净
        pnl=np.where(act, f*C0*seq[:,k], 0.0)
        # 不能押超过净值
        pnl=np.maximum(pnl, np.where(act,-W,0.0))   # 亏损不超过净值
        W=np.where(act, W+pnl, W)
        # 翻倍结算
        hit=act&(W>=2*C0)
        cum=np.where(hit, cum+(W-C0), cum); W=np.where(hit,float(C0),W)
        # 周结算 (按bar)
        wk=act&((bars[:,k]-last_wk)>=week)
        up=wk&(W>C0)
        cum=np.where(up, cum+(W-C0), cum); W=np.where(up,float(C0),W)
        last_wk=np.where(wk,bars[:,k],last_wk)
        # 亏完即爆仓
        bust=act&(W<=0); done=done|bust
    win=(cum>=C0)
    return dict(P=win.mean(), med=np.median(cum)-C0, bust=done.mean(),
                med_total=np.median(cum+np.maximum(W,0))-C0)

print('\n=== 收割制终局 (C0=1万, f=1%, 每周+翻倍结算, 亏完即爆仓, 不复利) ===')
print(f"{'cost_R':>7} {'口径':>26} {'P(赚回本金)':>11} {'盈亏中位':>10} {'爆仓率':>8}")
for cr,lab in [(0.020,'全限价maker 止损2%'),(0.047,'混合 止损2% [用户]'),
               (0.062,'混合 止损1.5% [用户]'),(0.008,'全限价maker 止损5%')]:
    r=sim(res.Rmul,cr)
    print(f'{cr:>7.3f} {lab:>26} {r["P"]:>11.3f} {r["med"]:>+10.0f} {r["bust"]:>8.1%}')

print('\n=== 零期望对照 (E强制归零, 保留波动形状) ===')
R0=res.Rmul.values-res.Rmul.values.mean()
for cr,lab in [(0.020,'全限价maker 止损2%'),(0.047,'混合 止损2%')]:
    r=sim(pd.Series(R0),cr)
    print(f'{cr:>7.3f} {lab:>26} {r["P"]:>11.3f} {r["med"]:>+10.0f} {r["bust"]:>8.1%}')

print('\n=== E衰减压力测试 (混合 cost_R=0.047) ===')
for sc,lab in [(1.0,'E=回测值'),(0.7,'E×0.7'),(0.5,'E×0.5'),(0.0,'E=0 (真无edge)')]:
    r=sim(res.Rmul,0.047,scale=sc)
    print(f'  {lab:>12}: P={r["P"]:.3f} 盈亏中位={r["med"]:+.0f} 爆仓={r["bust"]:.1%}')
