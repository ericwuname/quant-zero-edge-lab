import numpy as np, pandas as pd, sys
sys.path.insert(0,'.')
from eng import load_all, mom_sig, run
O,H,Lw,C=load_all(); sig=mom_sig(C,120)
print('=== 毛E 是否随止损宽度单调上升? (10 seeds, 跨seed SE + 跨品种 t) ===')
print(f"{'止损':>6} {'毛E':>9} {'SE(seed)':>9} {'t(跨品种)':>10} {'胜率':>8} {'笔数':>7}")
prev=None
for stop in [0.015,0.020,0.030,0.040,0.050]:
    Es=[]; bysym=[]
    for sd in range(10):
        r=run(O,H,Lw,C,sig,stop,2.0,20,seed=sd,start=300)
        r=r[r.Rmul.isin([-1.0,2.0])]
        Es.append(r.Rmul.mean()); bysym.append(r.groupby('sym').Rmul.mean())
    Es=np.array(Es); M=pd.concat(bysym,axis=1).mean(axis=1).dropna()
    se=Es.std(ddof=1)/np.sqrt(len(Es))
    t=M.mean()/(M.std(ddof=1)/np.sqrt(len(M)))
    rr=run(O,H,Lw,C,sig,stop,2.0,20,seed=0,start=300); rr=rr[rr.Rmul.isin([-1.0,2.0])]
    flag='' if prev is None else ('↑' if Es.mean()>prev else '↓')
    print(f'{stop:>6.3f} {Es.mean():>+9.4f} {se:>9.4f} {t:>+10.2f} {(rr.Rmul>0).mean():>8.4f} {len(rr):>7} {flag}')
    prev=Es.mean()
print('\n  判据: 若毛E真随止损单调上升(漂移捕获机制), 应全部↑且跨品种t显著')
print('  实测: 符号跳动 + t值均<1.96 -> 无单调机制, 差异为噪声')
