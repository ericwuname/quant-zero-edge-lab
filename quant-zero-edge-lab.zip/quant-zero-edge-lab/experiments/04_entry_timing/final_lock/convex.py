import numpy as np, pandas as pd, sys
sys.path.insert(0,'.')
from selftest import synth_ohlc
from eng import load_all

def run_log(O,H,Lw,C,sig,stop_pct,R,cd,seed,start):
    """对数距离版: 止损=ep*exp(-s), 止盈=ep*exp(+R*s)  [对照用]"""
    o,h,l,c=O.values,H.values,Lw.values,C.values
    T,N=o.shape; rng=np.random.default_rng(seed)
    state=None; last_exit=-10**9; rec=[]; t=start
    while t<T-1:
        if state is not None:
            i=state['i']; d=state['d']
            if d>0: hs=l[t,i]<=state['stop']; ht=h[t,i]>=state['tgt']
            else:   hs=h[t,i]>=state['stop']; ht=l[t,i]<=state['tgt']
            if hs: rec.append((i,-1.0)); state=None; last_exit=t; t+=1; continue
            if ht: rec.append((i,float(R))); state=None; last_exit=t; t+=1; continue
            t+=1; continue
        if t-last_exit<cd: t+=1; continue
        sv=sig[t]; cand=np.nonzero(~np.isnan(sv)&(sv!=0))[0]
        if len(cand)==0: t+=1; continue
        i=int(rng.choice(cand)); d=float(sv[i]); ep=o[t+1,i]
        if not np.isfinite(ep) or ep<=0: t+=1; continue
        state=dict(i=i,d=d,stop=ep*np.exp(-d*stop_pct),tgt=ep*np.exp(d*R*stop_pct))
        t+=1
    return pd.DataFrame(rec,columns=['sym','Rmul'])

print('=== 决定性验证: 算术止损 vs 对数止损 (合成GBM, 零对数漂移, 随机方向) ===')
print(f"{'stop':>6} {'模式':>6} {'胜率':>8} {'E':>9} {'理论p':>8}")
for sp in [0.015,0.02,0.03]:
    R=2.0
    for mode in ['arith','log']:
        Es=[];ps=[]
        for sd in range(10):
            O,H,Lw,C=synth_ohlc(20000,4,0.01,8,seed=sd)
            rng=np.random.default_rng(sd); s=rng.choice([-1.0,1.0],C.shape)
            if mode=='arith':
                from eng import run
                res=run(O,H,Lw,C,s,sp,R,5,seed=sd,start=50); col='Rmul'
                r=res[res[col].isin([-1.0,R])]
            else:
                res=run_log(O,H,Lw,C,s,sp,R,5,seed=sd,start=50)
                r=res
            Es.append(r.Rmul.mean()); ps.append((r.Rmul>0).mean())
        # 理论: 算术直觉 p=b/(a+b)=1/3 ; 对数修正 p=log(1+b)/(log(1+a)+log(1+b))
        a=R*sp; b=sp
        p_log=np.log(1+b)/(np.log(1+a)+np.log(1+b))
        print(f'{sp:>6.3f} {mode:>6} {np.mean(ps):>8.4f} {np.mean(Es):>+9.4f} {p_log:>8.4f}')
print('\n  注: 算术模式下理论p应=log修正值(0.338~0.340)而非0.3333; 对数模式理论p=0.3333')

print('\n=== 真实数据 随机方向: 算术 vs 对数 ===')
O,H,Lw,C=load_all()
for sp in [0.015,0.02]:
    for mode in ['arith','log']:
        Es=[]
        for sd in range(6):
            rng=np.random.default_rng(1000+sd)
            s=rng.choice([-1.0,1.0],C.shape)
            if mode=='arith':
                from eng import run
                res=run(O,H,Lw,C,s,sp,2.0,5,seed=sd,start=200)
                r=res[res.Rmul.isin([-1.0,2.0])]
            else:
                r=run_log(O,H,Lw,C,s,sp,2.0,5,seed=sd,start=200)
            Es.append(r.Rmul.mean())
        Es=np.array(Es)
        print(f'  stop={sp:.3f} {mode:>5}: E={Es.mean():+.4f} ±{Es.std(ddof=1)/np.sqrt(6):.4f}')
