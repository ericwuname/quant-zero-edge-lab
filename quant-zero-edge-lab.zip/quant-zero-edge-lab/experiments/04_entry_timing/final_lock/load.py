import pandas as pd, numpy as np, os
SYMS=['CRV','DASH','DOGE','DOT','ETH','FIL','HBAR','TRX','UNI','XLM','XMR','XRP','ZEC']
def load(s):
    d=pd.read_csv(f'/data/inputs/{s}USDT_1h.csv')
    d['ts']=pd.to_datetime(d['timestamp'],unit='ms')
    return d.set_index('ts')[['open','high','low','close','quoteVolume']].astype(float)
if __name__=='__main__':
    rows=[]
    for s in SYMS:
        d=load(s)
        # 最近1年日均成交额 (USDT)
        last=d.iloc[-8760:]
        adv=last['quoteVolume'].sum()/ (len(last)/24)
        adv_all=d['quoteVolume'].sum()/(len(d)/24)
        rows.append(dict(sym=s, bars=len(d), start=str(d.index[0].date()), end=str(d.index[-1].date()),
                         adv_1y=adv, adv_all=adv_all))
    r=pd.DataFrame(rows).sort_values('adv_1y',ascending=False)
    pd.set_option('display.width',200)
    print(r.to_string(index=False,float_format=lambda x:f'{x:,.0f}'))
