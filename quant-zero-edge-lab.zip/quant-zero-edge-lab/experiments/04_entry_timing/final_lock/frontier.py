import numpy as np, pandas as pd, sys
sys.path.insert(0,'.')
from eng import load_all, mom_sig, run
O,H,Lw,C=load_all(); sig=mom_sig(C,120)

def sim(R,bars,cost_R,f=0.01,C0=10000,week=168,npath=3000,seed=0,scale=1.0):
    rng=np.random.default_rng(seed)
    idx=rng.integers(0,len(R),size=(npath,4000))
    seq=(R[idx]*scale)-cost_R
    bb=bars[idx]
    W=np.full(npath,float(C0)); cum=np.zeros(npath); done=np.zeros(npath,bool)
    last_wk=np.zeros(npath,int)
    for k in range(4000):
        act=~done
        if not act.any(): break
        pnl=np.where(act, f*C0*seq[:,k], 0.0)
        pnl=np.maximum(pnl, np.where(act,-W,0.0))
        W=np.where(act, W+pnl, W)
        hit=act&(W>=2*C0)
        cum=np.where(hit,cum+(W-C0),cum); W=np.where(hit,float(C0),W)
        wk=act&((bb[:,k]-last_wk)>=week); up=wk&(W>C0)
        cum=np.where(up,cum+(W-C0),cum); W=np.where(up,float(C0),W)
        last_wk=np.where(wk,bb[:,k],last_wk)
        done=done|(act&(W<=0))
    return dict(P=(cum>=C0).mean(), med=np.median(cum)-C0, bust=done.mean())

print('=== 止损宽度 × 成交方式 (mom120, cd=20, f=1%, C0=1万) ===')
print(f"{'止损':>6} {'方式':>8} {'毛E':>8} {'cost_R':>7} {'净E':>8} {'P(赚回)':>8} {'盈亏中位':>9} {'爆仓':>6}")
for stop in [0.015,0.020,0.030,0.050]:
    rs=pd.concat([run(O,H,Lw,C,sig,stop,2.0,20,seed=sd,start=300) for sd in (0,1,2,3,4)])
    rs=rs[rs.Rmul.isin([-1.0,2.0])].reset_index(drop=True)
    g=rs.Rmul.mean(); p=(rs.Rmul>0).mean()
    for mode,cin,cw,cl in [('maker',2,2,2),('混合',2,2,10)]:
        cr=(cin+p*cw+(1-p)*cl)/10000/stop
        r=sim(rs.Rmul.values,rs.bar.values,cr)
        print(f'{stop:>6.3f} {mode:>8} {g:>+8.4f} {cr:>7.4f} {g-cr:>+8.4f} '
              f'{r["P"]:>8.3f} {r["med"]:>+9.0f} {r["bust"]:>6.1%}')
