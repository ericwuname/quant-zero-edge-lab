import numpy as np, pandas as pd, sys
sys.path.insert(0,'.')
from eng import mom_sig, run

def synth_ohlc(T,N,sigma=0.01,sub=8,seed=0):
    """真实日内路径: 每根bar内sub个子步随机游走 -> 聚合真实OHLC"""
    rng=np.random.default_rng(seed)
    r=rng.normal(0,sigma/np.sqrt(sub),(T*sub,N))
    p=100*np.exp(np.cumsum(r,axis=0))
    p=p.reshape(T,sub,N)
    O=p[:,0,:]; C=p[:,-1,:]
    H=p.max(axis=1); L=p.min(axis=1)
    idx=pd.date_range('2020-01-01',periods=T,freq='h')
    return (pd.DataFrame(O,index=idx),pd.DataFrame(H,index=idx),
            pd.DataFrame(L,index=idx),pd.DataFrame(C,index=idx))

print('=== 自检A: 合成零漂移(真实日内路径) ===')
for L in [60,120]:
    for sp in [0.015,0.02]:
        Es=[]
        for sd in range(6):
            O,H,Lw,C=synth_ohlc(20000,4,0.01,8,seed=sd)
            s=mom_sig(C,L)
            res=run(O,H,Lw,C,s,sp,2.0,5,seed=sd,start=L+10)
            # 剔除末尾强平
            r=res[res.Rmul.isin([-1.0,2.0])]
            Es.append(r.Rmul.mean())
        Es=np.array(Es)
        se=Es.std(ddof=1)/np.sqrt(len(Es))
        print(f'  L={L} stop={sp:.3f}  grossE={Es.mean():+.4f} ±{se:.4f}  '
              f'(期望0, z={Es.mean()/se:+.2f})  n≈{len(r)}')

print('\n=== 自检B: 真实数据 + 随机方向 (零期望对照) ===')
from eng import load_all
O,H,Lw,C=load_all()
T=len(C)
for sp in [0.015,0.02]:
    Es=[]
    for sd in range(6):
        rng=np.random.default_rng(1000+sd)
        s=np.where(np.isnan(C.values),np.nan,rng.choice([-1.0,1.0],C.shape))
        res=run(O,H,Lw,C,s,sp,2.0,5,seed=sd,start=200)
        r=res[res.Rmul.isin([-1.0,2.0])]
        Es.append(r.Rmul.mean())
    Es=np.array(Es); se=Es.std(ddof=1)/np.sqrt(len(Es))
    print(f'  stop={sp:.3f}  grossE={Es.mean():+.4f} ±{se:.4f}  (期望0, z={Es.mean()/se:+.2f})')
