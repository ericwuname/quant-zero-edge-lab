"""
时间框架 vs 止损点数 + 限价止损/黑天鹅止损 检验
================================================
用户命题:
  1. 入场价 100, 止损 1.5%/2% -> 1h 和 4h 的止损价相同 -> 周期不重要
  2. 全部限价, 无滑点; 极端行情由 2R 黑天鹅止损兜底 -> 限价止损基本都能成交

本脚本:
  A. 算术验证(止损价与时间框架无关)
  B. bar 振幅 / 跳空率: 1h vs 4h
  C. P(跳空 > 止损距离): 决定限价止损失效(需黑天鹅)的频率
  D. 全真模拟: 限价止损1R + 黑天鹅2R, 1h vs 4h, 信号用"小时"定义(周期中性)
  E. 成本口径: 全限价 cost_R
"""
import numpy as np
import pandas as pd
import os, json, glob

IN = '/data/inputs'
SYMS = ['CRV','DASH','DOGE','DOT','ETH','FIL','HBAR','TRX','UNI','XLM','XMR','XRP','ZEC']
OLD7 = ['CRV','DASH','DOGE','DOT','ETH','FIL','HBAR']
NEW6 = ['TRX','UNI','XLM','XMR','XRP','ZEC']

def load(sym):
    df = pd.read_csv(f'{IN}/{sym}USDT_1h.csv')
    df['dt'] = pd.to_datetime(df['timestamp'], unit='ms')
    df = df.set_index('dt')[['open','high','low','close','volume']].dropna()
    df = df[df['close'] > 0]
    return df

def resamp(df, hours):
    agg = {'open':'first','high':'max','low':'min','close':'last','volume':'sum'}
    r = df.resample(f'{hours}h').agg(agg).dropna()
    r = r[(r['close'] > 0) & (r['high'] >= r['low'])]
    return r

# ---------- B. bar stats ----------
def bar_stats(df):
    c = df['close'].values
    rng = ((df['high'] - df['low']) / c)
    gap = (df['open'] - df['close'].shift(1)).abs() / df['close'].shift(1)
    return rng.dropna(), gap.dropna()

# ---------- D. simulation ----------
def simulate(df, L_bars, r=0.015, Rtgt=2.0, cost_bp=2.0, swan_bp=10.0):
    """
    L_bars: 信号回看(以该时间框架的bar为单位)
    入场: 信号翻转 -> 下一根bar开盘价入场
    出场:
      S1 = E*(1-r)      限价止损 (1R)
      T  = E*(1+Rtgt*r) 限价止盈 (Rtgt R)
      S2 = E*(1-2*r)    黑天鹅止损 (2R)
    """
    o = df['open'].values; h = df['high'].values
    l = df['low'].values;  c = df['close'].values
    n = len(c)
    if n < L_bars + 50:
        return []
    sig = np.zeros(n)
    sig[L_bars:] = np.sign(c[L_bars:] / np.maximum(c[:-L_bars], 1e-12) - 1.0)

    trades = []
    pos = 0; entrybar = -1; E = 0.0; S1 = 0.0; T = 0.0; S2 = 0.0
    prev = 0.0
    for i in range(L_bars, n - 1):
        s = sig[i]
        if pos == 0:
            if s != 0 and s != prev:          # 信号翻转 -> 入场
                pos = s; E = o[i + 1]; entrybar = i + 1
                if pos > 0:
                    S1 = E * (1 - r); T = E * (1 + Rtgt * r); S2 = E * (1 - 2 * r)
                else:
                    S1 = E * (1 + r); T = E * (1 - Rtgt * r); S2 = E * (1 + 2 * r)
            prev = s
            continue

        # 持仓中: 检查 bar i 的出场
        ex = None; rmult = 0.0; kind = ''
        if i == entrybar:
            # 入场bar: 以开盘价进, 看剩余部分
            if pos > 0:
                if l[i] <= S1: ex, rmult, kind = S1, -1.0, 'stop'
                elif h[i] >= T: ex, rmult, kind = T, Rtgt, 'target'
            else:
                if h[i] >= S1: ex, rmult, kind = S1, -1.0, 'stop'
                elif l[i] <= T: ex, rmult, kind = T, Rtgt, 'target'
        else:
            if pos > 0:
                if o[i] < S1:                       # 跳空跌破限价止损
                    if l[i] <= S2: ex, rmult, kind = S2, -2.0, 'swan'
                    elif h[i] >= S1: ex, rmult, kind = S1, -1.0, 'stop'
                else:
                    if l[i] <= S1: ex, rmult, kind = S1, -1.0, 'stop'
                    elif h[i] >= T: ex, rmult, kind = T, Rtgt, 'target'
            else:
                if o[i] > S1:                       # 跳空涨破限价止损
                    if h[i] >= S2: ex, rmult, kind = S2, -2.0, 'swan'
                    elif l[i] <= S1: ex, rmult, kind = S1, -1.0, 'stop'
                else:
                    if h[i] >= S1: ex, rmult, kind = S1, -1.0, 'stop'
                    elif l[i] <= T: ex, rmult, kind = T, Rtgt, 'target'

        if ex is not None:
            fee = (cost_bp if kind == 'target' else
                   (swan_bp if kind == 'swan' else cost_bp))
            # 往返成本: 入场2bp(maker) + 出场
            cost_R = (cost_bp + fee) / (r * 1e4)
            trades.append({'rmult': rmult, 'kind': kind,
                           'net': rmult - cost_R, 'cost_R': cost_R,
                           'hold': i - entrybar})
            pos = 0; prev = s     # 出场后: 需信号再次翻转才入场(天然冷却)
    return trades


def summarize(trades):
    if not trades:
        return None
    d = pd.DataFrame(trades)
    gross = d['rmult'].mean()
    net = d['net'].mean()
    n = len(d)
    sd = d['rmult'].std()
    t = gross / (sd / np.sqrt(n)) if sd > 0 and n > 1 else 0.0
    kc = d['kind'].value_counts(normalize=True)
    return {'n': n, 'gross': gross, 'net': net, 't': t,
            'target%': kc.get('target', 0), 'stop%': kc.get('stop', 0),
            'swan%': kc.get('swan', 0),
            'hold': d['hold'].mean(),
            'cost_R': d['cost_R'].mean()}


def main():
    out = {}
    print("=" * 78)
    print("A. 算术验证: 止损价是否与时间框架有关")
    print("=" * 78)
    for px in [100.0]:
        print(f"  入场价 {px}:  1.5%止损 -> {px*(1-0.015):.4f}   2%止损 -> {px*(1-0.02):.4f}")
        print(f"  1h 收盘价=100 与 4h 收盘价=100, 止损价完全相同 -> 与时间框架无关")
    out['A'] = {'entry': 100, 'stop1.5': 98.5, 'stop2': 98.0}

    print()
    print("=" * 78)
    print("B. bar 振幅 / 跳空率: 1h vs 4h")
    print("=" * 78)
    rows = []
    for sym in SYMS:
        d1 = load(sym)
        d4 = resamp(d1, 4)
        r1, g1 = bar_stats(d1)
        r4, g4 = bar_stats(d4)
        rows.append({
            'sym': sym,
            'rng1h_med': r1.median() * 1e4, 'rng1h_p90': r1.quantile(.90) * 1e4,
            'rng4h_med': r4.median() * 1e4, 'rng4h_p90': r4.quantile(.90) * 1e4,
            'gap1h_med': g1.median() * 1e4, 'gap1h_p99': g1.quantile(.99) * 1e4,
            'gap4h_med': g4.median() * 1e4, 'gap4h_p99': g4.quantile(.99) * 1e4,
            'P_gap1h>150': (g1 > 0.015).mean(), 'P_gap1h>200': (g1 > 0.020).mean(),
            'P_gap1h>300': (g1 > 0.030).mean(),
            'P_gap4h>150': (g4 > 0.015).mean(), 'P_gap4h>200': (g4 > 0.020).mean(),
            'P_gap4h>300': (g4 > 0.030).mean(),
        })
    B = pd.DataFrame(rows)
    print(B[['sym', 'rng1h_med', 'rng4h_med', 'gap1h_med', 'gap4h_med',
             'P_gap1h>150', 'P_gap4h>150', 'P_gap1h>300', 'P_gap4h>300']].to_string(index=False))
    print()
    print("  [均值]  1h振幅 %.0fbp  4h振幅 %.0fbp  比值 %.2f" % (
        B.rng1h_med.mean(), B.rng4h_med.mean(), B.rng4h_med.mean() / B.rng1h_med.mean()))
    print("  [均值]  1h跳空 %.0fbp  4h跳空 %.0fbp  比值 %.2f" % (
        B.gap1h_med.mean(), B.gap4h_med.mean(), B.gap4h_med.mean() / B.gap1h_med.mean()))
    print("  [均值]  P(跳空>1.5%%): 1h %.4f%%  4h %.4f%%" % (
        B['P_gap1h>150'].mean() * 100, B['P_gap4h>150'].mean() * 100))
    print("  [均值]  P(跳空>3.0%%): 1h %.4f%%  4h %.4f%%" % (
        B['P_gap1h>300'].mean() * 100, B['P_gap4h>300'].mean() * 100))
    out['B'] = B.to_dict('list')

    print()
    print("=" * 78)
    print("C. 全真模拟: 限价止损1R + 黑天鹅2R,  1h vs 4h (信号用小时定义)")
    print("=" * 78)
    allrows = []
    for L_hours in [24, 120, 240]:
        for r in [0.015, 0.02]:
            for tf, hrs in [('1h', 1), ('4h', 4)]:
                L_bars = int(round(L_hours / hrs))
                if L_bars < 3:
                    continue
                agg = []
                for sym in SYMS:
                    d1 = load(sym)
                    dd = d1 if hrs == 1 else resamp(d1, hrs)
                    tr = simulate(dd, L_bars, r=r)
                    s = summarize(tr)
                    if s:
                        s['sym'] = sym; agg.append(s)
                A = pd.DataFrame(agg)
                if len(A) == 0:
                    continue
                pooled_g = A['gross'].mean(); pooled_n = A['net'].mean()
                tcross = pooled_g / (A['gross'].std() / np.sqrt(len(A))) if len(A) > 1 else 0
                row = {'L_h': L_hours, 'r': r, 'tf': tf,
                       'n': int(A['n'].sum()),
                       'gross': pooled_g, 'net': pooled_n,
                       't_cross': tcross,
                       'target%': A['target%'].mean(), 'stop%': A['stop%'].mean(),
                       'swan%': A['swan%'].mean(), 'hold': A['hold'].mean(),
                       'pos%': (A['gross'] > 0).mean()}
                allrows.append(row)
                print(f"  L={L_hours:4d}h r={r:.3f} {tf}: N={row['n']:6d} "
                      f"gross={pooled_g:+.4f} net={pooled_n:+.4f} t={tcross:+5.2f} "
                      f"胜{row['target%']:.3f} 止{row['stop%']:.3f} "
                      f"天鹅{row['swan%']:.4f} hold={row['hold']:.1f}bar 正{row['pos%']:.2f}")
    C = pd.DataFrame(allrows)
    out['C'] = C.to_dict('list')
    print()
    print("  --- 黑天鹅(2R)触发占比 & 1h/4h 差异 ---")
    piv = C.pivot_table(index=['L_h', 'r'], columns='tf',
                        values=['gross', 'swan%', 'n'])
    print(piv.to_string())

    print()
    print("=" * 78)
    print("D. 成本口径: 全限价(无滑点)")
    print("=" * 78)
    for r in [0.015, 0.02]:
        rt = 2 * 2.0                      # 往返 4bp 全 maker
        swan = 2.0 + 10.0                 # 黑天鹅: 入场maker2 + 出场taker10
        print(f"  止损 r={r:.3f} ({r*1e4:.0f}bp):  正常往返 cost_R = {rt/(r*1e4):.4f} R")
        print(f"                          黑天鹅 cost_R = {swan/(r*1e4):.4f} R")
    print("  用户假设 0.05~0.10 R  ->  实际全限价 0.020~0.027 R  (更乐观)")

    print()
    print("=" * 78)
    print("E. 保本胜率 vs 实测胜率  (E=(R+1)*(p - 1/(1+R)) - cost_R)")
    print("=" * 78)
    print(f"  {'止损r':>6} {'cost_R':>8} {'毛保本p*':>9} {'净保本p*':>9} | 实测最好胜率  差距")
    for r in [0.015, 0.02]:
        cr = 4.0 / (r * 1e4)
        p_gross = 1.0 / 3.0
        p_net = (1.0 + cr) / 3.0
        sub = C[(C['r'] == r) & (C['tf'] == '1h')]
        best = sub['target%'].max() if len(sub) else np.nan
        print(f"  {r:6.3f} {cr:8.4f} {p_gross*100:8.2f}% {p_net*100:8.2f}% | "
              f"{best*100:8.2f}%  {(best-p_net)*100:+6.2f}pp")
    print("  注: 实测胜率 = 触发止盈占比(即p); 全部 1h 配置中取最好")

    C.to_csv('/data/workspace/tf_test/sim.csv', index=False)
    B.to_csv('/data/workspace/tf_test/bars.csv', index=False)
    print("\n[saved]")

if __name__ == '__main__':
    main()
