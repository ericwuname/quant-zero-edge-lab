"""
放宽止损扫描: 检验"以损定量 -> 宽止损 -> cost_R下降 -> 净E转正"的临界点
理论: 净保本胜率 p* = (1 + cost_R)/(1+R),  cost_R = 4bp/(r*1e4)
      若实测胜率 p 基本不随 r 变化, 则存在临界 r*:  cost_R < 3p - 1
"""
import numpy as np, pandas as pd
from tf_analysis import load, simulate, summarize, SYMS, OLD7, NEW6

RS = [0.015, 0.02, 0.03, 0.04, 0.05, 0.08, 0.12]
LH = [120, 240]

rows = []
for L_hours in LH:
    for r in RS:
        agg = []
        for sym in SYMS:
            d1 = load(sym)
            tr = simulate(d1, int(L_hours), r=r)
            s = summarize(tr)
            if s:
                s['sym'] = sym; s['grp'] = 'OLD7' if sym in OLD7 else 'NEW6'
                agg.append(s)
        A = pd.DataFrame(agg)
        if len(A) == 0:
            continue
        g = A['gross'].mean(); n_ = A['net'].mean()
        t = g / (A['gross'].std() / np.sqrt(len(A)))
        o = A[A.grp == 'OLD7']; w = A[A.grp == 'NEW6']
        rows.append({
            'L_h': L_hours, 'r': r, 'N': int(A['n'].sum()),
            'gross': g, 'net': n_, 't': t,
            'p_win': A['target%'].mean(), 'p_req': (1 + 4.0 / (r * 1e4)) / 3.0,
            'gap_pp': (A['target%'].mean() - (1 + 4.0 / (r * 1e4)) / 3.0) * 100,
            'OLD7': o['gross'].mean(), 'NEW6': w['gross'].mean(),
            'pos%': (A['gross'] > 0).mean(), 'hold': A['hold'].mean(),
            'swan%': A['swan%'].mean(),
        })

D = pd.DataFrame(rows)
pd.set_option('display.width', 200)
print("=" * 100)
print("放宽止损扫描 (1h, 全限价无滑点, 信号=L小时动量, R=2)")
print("=" * 100)
print(D[['L_h', 'r', 'N', 'gross', 'net', 't', 'p_win', 'p_req', 'gap_pp',
         'OLD7', 'NEW6', 'hold']].to_string(index=False,
      formatters={'gross': '{:+.4f}'.format, 'net': '{:+.4f}'.format,
                  't': '{:+.2f}'.format, 'p_win': '{:.4f}'.format,
                  'p_req': '{:.4f}'.format, 'gap_pp': '{:+.2f}'.format,
                  'OLD7': '{:+.4f}'.format, 'NEW6': '{:+.4f}'.format,
                  'hold': '{:.1f}'.format}))
print()
print("  临界预测: 若 p 不随 r 变, 净E转正需 cost_R < 3p-1")
sub = D[D.L_h == 120]
for _, x in sub.iterrows():
    need = 3 * x['p_win'] - 1
    crit = 4.0 / (need * 1e4) if need > 0 else np.nan
    print(f"    r={x['r']:.3f}: 实测p={x['p_win']*100:.2f}%  允许cost_R={need:.4f}  "
          f"-> 对应临界止损 r*={crit*100 if crit==crit else float('nan'):.2f}%")
print()
print("  [理论] 成本 4bp 往返, 净E>0 需:  r > 4bp / (3p-1)")
print(f"    取 p=33.8% -> r > {0.0004/(3*0.338-1)*100:.2f}%")
print(f"    取 p=33.4% -> r > {0.0004/(3*0.334-1)*100:.2f}%")
print(f"    取 p=33.33%(无edge) -> 永不成立")
D.to_csv('/data/workspace/tf_test/wide.csv', index=False)
print("\n[saved wide.csv]")
