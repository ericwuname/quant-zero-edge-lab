import numpy as np, pandas as pd, sys
sys.path.insert(0,'/data/workspace/grid_v2')
from eng import *
DATA={}
for s in SYMS:
    d=load(s,2); DATA[s]=d
    DATA[s+'_adx']=adx(d['high'].values,d['low'].values,d['close'].values,14)

def sim2(o,h,l,c,capital,fee_bp,N,k=0.25,gtype='geom',util=1.0,
         adx_thr=None,adxser=None,te=None,recenter=False):
    """te/recenter 只在网格活跃时计数 (修复组合bug)"""
    P0=o[0]; fee=fee_bp/1e4; deploy=capital*util
    lv=levels_make(P0,k,N,gtype); m=deploy/float(N)
    inv=0.5*deploy/P0; cash=deploy*0.5; avg=P0
    realized=0.;fees=0.;nfill=0;peak=capital;maxdd=0.
    idle=0; prev=np.concatenate([[o[0]],c[:-1]]); restarts=0
    for t in range(len(c)):
        ax=adxser[t] if adxser is not None else np.nan
        paused = (adx_thr is not None) and (not np.isnan(ax)) and ax>adx_thr
        if not paused:
            a=np.searchsorted(lv,l[t],'left'); b=np.searchsorted(lv,prev[t],'left')
            d=np.searchsorted(lv,prev[t],'right'); e=np.searchsorted(lv,h[t],'right')
            nf0=nfill
            for L in lv[a:b][::-1]:
                u=m/L;cost=m;f=cost*fee
                if cash>=cost+f:
                    cash-=(cost+f);fees+=f;avg=(avg*inv+cost)/(inv+u) if inv>0 else cost
                    inv+=u;nfill+=1
            for L in lv[d:e]:
                u=m/L;proc=m;f=proc*fee
                if inv>=u-1e-12:
                    fees+=f;realized+=(proc-avg*u);cash+=(proc-f);inv-=u;nfill+=1
            idle = 0 if nfill>nf0 else idle+1
            if recenter and (c[t]<lv[0] or c[t]>lv[-1]):
                lv=levels_make(c[t],k,N,gtype); restarts+=1
        eq=cash+inv*c[t]+(capital-deploy)
        peak=max(peak,eq); maxdd=max(maxdd,(peak-eq)/peak if peak>0 else 0)
        if te is not None and idle>=te: break
    final=cash+inv*c[-1]+(capital-deploy); yrs=len(c)/(365*24.)
    ann=(final/capital)**(1/yrs)-1 if final>0 and yrs>0 else -1
    return dict(ann=ann,maxdd=maxdd,nfill=nfill,ret=final/capital-1,restarts=restarts)

def run(**kw):
    out=[]
    for s in SYMS:
        d=DATA[s]
        ax=DATA[s+'_adx'] if kw.get('adx_thr') is not None else None
        r=sim2(d['open'].values,d['high'].values,d['low'].values,d['close'].values,1000,
               N=kw.get('N',20),k=kw.get('k',0.25),gtype=kw.get('gtype','geom'),
               util=kw.get('util',1.0),adx_thr=kw.get('adx_thr'),adxser=ax,
               te=kw.get('te'),recenter=kw.get('recenter',False),fee_bp=kw.get('fee',2))
        bh=d['close'].values[-1]/d['open'].values[0]-1
        out.append(dict(sym=s,bh=bh,**{x:r[x] for x in ['ann','maxdd','nfill','ret','restarts']}))
    return pd.DataFrame(out)

print("=== 修复后: 组合配置对比 ===")
cfgs=[
("1 基线",dict()),
("2 ADX25",dict(adx_thr=25)),
("3 21d退出",dict(te=504)),
("4 ADX25+21d退出[修复]",dict(adx_thr=25,te=504)),
("5 破网移仓重启",dict(recenter=True)),
("6 ADX25+移仓重启",dict(adx_thr=25,recenter=True)),
("7 6+N=40",dict(adx_thr=25,recenter=True,N=40)),
("8 6+±35%",dict(adx_thr=25,recenter=True,k=0.35)),
("9 6+N=40±35%",dict(adx_thr=25,recenter=True,N=40,k=0.35)),
("10 4+移仓重启",dict(adx_thr=25,te=504,recenter=True)),
("11 9+等差",dict(adx_thr=25,recenter=True,N=40,k=0.35,gtype='arith')),
("12 9+taker10bp",dict(adx_thr=25,recenter=True,N=40,k=0.35,fee=10)),
]
res=[]
for n,kw in cfgs:
    df=run(**kw)
    res.append(dict(cfg=n,ann=df['ann'].median(),dd=df['maxdd'].median(),
        calmar=(df['ann']/df['maxdd']).median(),pos=(df['ret']>0).mean(),
        beat_bh=(df['ret']>df['bh']).mean(),nfill=df['nfill'].median(),rest=df['restarts'].median()))
R=pd.DataFrame(res)
print(R.round(3).to_string(index=False))
R.to_csv('/data/workspace/grid_v2/I2.csv',index=False)
