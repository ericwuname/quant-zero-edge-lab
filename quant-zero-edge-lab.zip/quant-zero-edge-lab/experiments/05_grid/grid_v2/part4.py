import numpy as np, pandas as pd, sys
sys.path.insert(0,'/data/workspace/grid_v2')
from eng import *
DATA={}
for s in SYMS:
    d=load(s,2); DATA[s]=d
    DATA[s+'_adx']=adx(d['high'].values,d['low'].values,d['close'].values,14)

def sim3(o,h,l,c,capital,fee_bp,N,k=0.25,gtype='geom',util=1.0,
         adx_thr=None,adxser=None,te=None,recenter=False):
    P0=o[0]; fee=fee_bp/1e4; deploy=capital*util
    lv=levels_make(P0,k,N,gtype); m=deploy/float(N)
    inv=0.5*deploy/P0; cash=deploy*0.5; avg=P0
    fees=0.;nfill=0;peak=capital;maxdd=0.;idle=0;rest=0
    prev=np.concatenate([[o[0]],c[:-1]]); outside=False
    for t in range(len(c)):
        ax=adxser[t] if adxser is not None else np.nan
        paused=(adx_thr is not None) and (not np.isnan(ax)) and ax>adx_thr
        if not paused:
            # 边沿触发移仓: 仅在"由内转外"时重建一次
            isout = c[t]<lv[0] or c[t]>lv[-1]
            if recenter and isout and not outside:
                lv=levels_make(c[t],k,N,gtype); rest+=1; outside=True
            if not isout: outside=False
            a=np.searchsorted(lv,l[t],'left'); b=np.searchsorted(lv,prev[t],'left')
            d=np.searchsorted(lv,prev[t],'right'); e=np.searchsorted(lv,h[t],'right')
            nf0=nfill
            for L in lv[a:b][::-1]:
                u=m/L;cost=m;f=cost*fee
                if cash>=cost+f:
                    cash-=(cost+f);fees+=f;avg=(avg*inv+cost)/(inv+u) if inv>0 else cost;inv+=u;nfill+=1
            for L in lv[d:e]:
                u=m/L;proc=m;f=proc*fee
                if inv>=u-1e-12:
                    fees+=f;realized=(proc-avg*u);cash+=(proc-f);inv-=u;nfill+=1
            idle=0 if nfill>nf0 else idle+1
        eq=cash+inv*c[t]+(capital-deploy)
        peak=max(peak,eq); maxdd=max(maxdd,(peak-eq)/peak if peak>0 else 0)
        if te is not None and idle>=te: break
    final=cash+inv*c[-1]+(capital-deploy); yrs=len(c)/(365*24.)
    ann=(final/capital)**(1/yrs)-1 if final>0 and yrs>0 else -1
    return dict(ann=ann,maxdd=maxdd,nfill=nfill,ret=final/capital-1,rest=rest)

def run(**kw):
    out=[]
    for s in SYMS:
        d=DATA[s]; ax=DATA[s+'_adx'] if kw.get('adx_thr') is not None else None
        r=sim3(d['open'].values,d['high'].values,d['low'].values,d['close'].values,1000,
               fee_bp=kw.get('fee',2),N=kw.get('N',20),k=kw.get('k',0.25),
               gtype=kw.get('gtype','geom'),util=kw.get('util',1.0),
               adx_thr=kw.get('adx_thr'),adxser=ax,te=kw.get('te'),recenter=kw.get('recenter',False))
        out.append(dict(sym=s,bh=d['close'].values[-1]/d['open'].values[0]-1,
                        **{x:r[x] for x in ['ann','maxdd','nfill','ret','rest']}))
    return pd.DataFrame(out)

cfgs=[
("1 基线 不设防",dict()),
("2 ADX25过滤",dict(adx_thr=25)),
("3 21d无成交退出",dict(te=504)),
("4 移仓重启[修复]",dict(recenter=True)),
("5 ADX25+移仓",dict(adx_thr=25,recenter=True)),
("6 5+N40",dict(adx_thr=25,recenter=True,N=40)),
("7 5+±35%",dict(adx_thr=25,recenter=True,k=0.35)),
("8 5+N40±35%",dict(adx_thr=25,recenter=True,N=40,k=0.35)),
("9 8+等差",dict(adx_thr=25,recenter=True,N=40,k=0.35,gtype='arith')),
("10 8+taker10bp",dict(adx_thr=25,recenter=True,N=40,k=0.35,fee=10)),
("11 8+备用金util0.7",dict(adx_thr=25,recenter=True,N=40,k=0.35,util=0.7)),
("12 2+N40±35%不移仓",dict(adx_thr=25,N=40,k=0.35)),
("13 3+N40±35%",dict(te=504,N=40,k=0.35)),
("14 2+3 组合",dict(adx_thr=25,te=504,N=40,k=0.35)),
]
res=[]
for n,kw in cfgs:
    df=run(**kw)
    res.append(dict(cfg=n,ann=df['ann'].median(),dd=df['maxdd'].median(),
      calmar=(df['ann']/df['maxdd']).median(),pos=(df['ret']>0).mean(),
      beat_bh=(df['ret']>df['bh']).mean(),nfill=df['nfill'].median(),rest=df['rest'].median()))
R=pd.DataFrame(res)
print("=== 修复移仓后 组合对比 ===")
print(R.round(3).to_string(index=False))
R.to_csv('/data/workspace/grid_v2/I3.csv',index=False)
