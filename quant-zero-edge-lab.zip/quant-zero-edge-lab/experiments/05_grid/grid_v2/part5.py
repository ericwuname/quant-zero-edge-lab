import numpy as np, pandas as pd, sys
sys.path.insert(0,'/data/workspace/grid_v2')
from eng import *
from part4 import sim3
DATA3={}
for s in SYMS:
    d=load(s,3); DATA3[s]=d
    DATA3[s+'_adx']=adx(d['high'].values,d['low'].values,d['close'].values,14)

def run(years=3,**kw):
    out=[]
    for s in SYMS:
        d=DATA3[s] if years==3 else None
        r=sim3(d['open'].values,d['high'].values,d['low'].values,d['close'].values,1000,
               fee_bp=kw.get('fee',2),N=kw.get('N',40),k=kw.get('k',0.35),
               gtype=kw.get('gtype','geom'),util=kw.get('util',1.0),te=kw.get('te',504))
        out.append(dict(sym=s,bh=d['close'].values[-1]/d['open'].values[0]-1,
                        **{x:r[x] for x in ['ann','maxdd','nfill','ret','rest']}))
    return pd.DataFrame(out)

print("=== K 稳健性: 21d退出下 N × 区间 网格 (3年, maker2bp) ===")
rows=[]
for N in [20,40,60,100]:
    for k in [0.25,0.30,0.35,0.45]:
        df=run(3,N=N,k=k)
        rows.append(dict(N=N,k=k,g_pct=(((1+k)/(1-k))**(1/N)-1)*100,
                         ann=df['ann'].median(),dd=df['maxdd'].median(),
                         calmar=(df['ann']/df['maxdd']).median(),pos=(df['ret']>0).mean(),
                         beat_bh=(df['ret']>df['bh']).mean()))
K=pd.DataFrame(rows); print(K.round(3).to_string(index=False))

print("\n=== L 最优配置 逐品种 (N=40,±35%,21d退出,3年) ===")
best=run(3,N=40,k=0.35)
print(best.round(3).to_string(index=False))

print("\n=== M 成本敏感性 ===")
for fee in [0,2,5,10,20]:
    df=run(3,N=40,k=0.35,fee=fee)
    print(f"  单边{fee:>2}bp: 年化中位={df['ann'].median():>7.1%} 回撤={df['maxdd'].median():.1%} 为正={(df['ret']>0).mean():.0%}")

print("\n=== N 与权威基准对照 ===")
df=run(3,N=40,k=0.35)
print(f"  本方案: 年化中位={df['ann'].median():.1%}  回撤中位={df['maxdd'].median():.1%}  Calmar={(df['ann']/df['maxdd']).median():.2f}")
print(f"  银河期货(股指网格,2015-2024长期): 年化2.78~4.17%, MDD 10~14%")
print(f"  外网实盘基准(保守配置): 月化3-8%, MDD 8-12%  ->  年化36-96%")
print(f"  同期买入持有中位={df['bh'].median():.1%}  跑赢持有={(df['ret']>df['bh']).mean():.0%}")
K.to_csv('/data/workspace/grid_v2/K.csv',index=False)
best.to_csv('/data/workspace/grid_v2/best3.csv',index=False)
