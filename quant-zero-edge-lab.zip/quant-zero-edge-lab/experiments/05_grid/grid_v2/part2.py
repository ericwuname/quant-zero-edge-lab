import numpy as np, pandas as pd, sys
sys.path.insert(0,'/data/workspace/grid_v2')
from eng import *
DATA={}
for s in SYMS:
    d=load(s,2); DATA[s]=d
    DATA[s+'_adx']=adx(d['high'].values,d['low'].values,d['close'].values,14)

def run(cap=1000,fee=2,N=20,k=0.25,gtype='geom',adx_thr=None,te=None,recenter='none',util=1.0):
    out=[]
    for s in SYMS:
        d=DATA[s]; o,h,l,c=d['open'].values,d['high'].values,d['low'].values,d['close'].values
        ax=DATA[s+'_adx'] if adx_thr is not None else None
        r=sim(o,h,l,c,cap,fee,N,k=k,gtype=gtype,util=util,
              use_adx=(adx_thr is not None),adx_thr=adx_thr if adx_thr else 25,
              adxser=ax,time_exit=te,mode='fixed')
        yrs=len(c)/(365*24.)
        bh=c[-1]/o[0]-1
        out.append(dict(sym=s,ann=r['ann'],maxdd=r['maxdd'],nfill=r['nfill'],ret=r['ret'],bh=bh,
                        calmar=r['ann']/r['maxdd'] if r['maxdd']>0 else 0))
    return pd.DataFrame(out)

print("=== G 成本地板: 单格毛利 vs 往返成本 (N使单格间距=g) ===")
rows=[]
for k in [0.10,0.20]:
    for N in [10,20,40,60,100]:
        g=( (1+k)/(1-k) )**(1/N)-1
        for fee in [2,10]:
            df=run(N=N,k=k,fee=fee)
            rows.append(dict(k=k,N=N,g_pct=g*100,fee=fee,
                             ratio=g*1e4/(2*fee),   # 单格毛利/往返成本
                             ann=df['ann'].median(),pos=(df['ret']>0).mean()))
G=pd.DataFrame(rows)
print(G.round(3).to_string(index=False))

print("\n=== H 格数公式校验 N=区间宽度%/(3.5*费率%) ===")
for k in [0.20,0.30]:
    width=2*k*100
    for fee in [2,10]:
        Nopt=width/(3.5*fee/100.)
        print(f"  区间±{k*100:.0f}%(宽{width:.0f}%) 费率{fee/100:.2f}% -> 公式N={Nopt:.0f}")

print("\n=== I 组合对比 (逐项叠加) ===")
cfgs=[
 ("1 基线 geom N20 ±25%",dict()),
 ("2 +破网重启(21d退出)",dict(te=504)),
 ("3 +ADX25过滤",dict(adx_thr=25)),
 ("4 2+3 组合",dict(te=504,adx_thr=25)),
 ("5 4 +宽区间±35%",dict(te=504,adx_thr=25,k=0.35)),
 ("6 4 +N=40",dict(te=504,adx_thr=25,N=40)),
 ("7 4 +等差",dict(te=504,adx_thr=25,gtype='arith')),
 ("8 4 +N=10",dict(te=504,adx_thr=25,N=10)),
 ("9 5 +N=40",dict(te=504,adx_thr=25,k=0.35,N=40)),
]
res=[]
for name,kw in cfgs:
    df=run(**kw)
    res.append(dict(cfg=name,ann_med=df['ann'].median(),dd_med=df['maxdd'].median(),
                    calmar=(df['ann']/df['maxdd']).median(),pos=(df['ret']>0).mean(),
                    beat_bh=(df['ret']>df['bh']).mean(),nfill=df['nfill'].median()))
R=pd.DataFrame(res)
print(R.round(3).to_string(index=False))

print("\n=== J 与权威基准对照 (银河期货:股指网格长期年化2.78~4.17%,MDD10~14%) ===")
best=run(te=504,adx_thr=25,N=40,k=0.35)
print(f"  本方案(加密1h) 年化中位={best['ann'].median():.1%} 回撤中位={best['maxdd'].median():.1%}")
print(f"  同期买入持有中位={best['bh'].median():.1%}")
print(f"  跑赢持有比例={(best['ret']>best['bh']).mean():.0%}")
best.to_csv('/data/workspace/grid_v2/best.csv',index=False)
G.to_csv('/data/workspace/grid_v2/G.csv',index=False)
R.to_csv('/data/workspace/grid_v2/I.csv',index=False)
