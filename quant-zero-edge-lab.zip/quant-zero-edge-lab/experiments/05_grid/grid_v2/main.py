import numpy as np, pandas as pd, sys
sys.path.insert(0,'/data/workspace/grid_v2')
from eng import *
rows=[]
DATA={}
for s in SYMS:
    d=load(s,2); DATA[s]=d
    DATA[s+'_adx']=adx(d['high'].values,d['low'].values,d['close'].values,14)

# A: 等差 vs 等比
for gtype in ['geom','arith']:
    for N in [10,20,40]:
        for k in [0.15,0.25,0.35]:
            for s in SYMS:
                d=DATA[s]
                r=sim(d['open'].values,d['high'].values,d['low'].values,d['close'].values,
                      1000,2,N,k=k,gtype=gtype,mode='fixed')
                rows.append(dict(test='A_gtype',gtype=gtype,N=N,k=k,sym=s,**{x:r[x] for x in ['ann','maxdd','nfill','ret']}))
A=pd.DataFrame([r for r in rows if r['test']=='A_gtype'])
print("=== A 等差 vs 等比 (年化中位/回撤中位) ===")
print(A.groupby(['gtype','N','k'])[['ann','maxdd']].median().round(3).to_string())

rows=[]
# B: 不对称网格 (relative grid, asym=buy_step multiplier)
for asym in [1.0,1.3,1.6,2.0]:
    for s in SYMS:
        d=DATA[s]
        r=sim(d['open'].values,d['high'].values,d['low'].values,d['close'].values,
              1000,2,20,asym=asym,mode='rel')
        rows.append(dict(test='B_asym',asym=asym,sym=s,**{x:r[x] for x in ['ann','maxdd','nfill','ret']}))
B=pd.DataFrame(rows)
print("\n=== B 不对称网格 (买入间距=3%*asym, 卖出间距=3%) ===")
print(B.groupby('asym')[['ann','maxdd','nfill']].median().round(3).to_string())

rows=[]
# C: 资金利用率 (备用金)
for util in [0.5,0.7,0.85,1.0]:
    for s in SYMS:
        d=DATA[s]
        r=sim(d['open'].values,d['high'].values,d['low'].values,d['close'].values,
              1000,2,20,k=0.25,gtype='geom',util=util,mode='fixed')
        rows.append(dict(util=util,sym=s,**{x:r[x] for x in ['ann','maxdd','nfill','ret']}))
C=pd.DataFrame(rows)
print("\n=== C 资金利用率/备用金 (util=投入网格比例) ===")
print(C.groupby('util')[['ann','maxdd','nfill']].median().round(3).to_string())
print("为正比例:", C.groupby('util')['ret'].apply(lambda x:(x>0).mean()).round(2).to_dict())

rows=[]
# D: ADX regime filter
for thr in [999,30,25,20]:
    for s in SYMS:
        d=DATA[s]
        r=sim(d['open'].values,d['high'].values,d['low'].values,d['close'].values,
              1000,2,20,k=0.25,gtype='geom',
              use_adx=(thr<900),adx_thr=thr,adxser=DATA[s+'_adx'],mode='fixed')
        rows.append(dict(thr=thr,sym=s,**{x:r[x] for x in ['ann','maxdd','nfill','ret']}))
D=pd.DataFrame(rows)
print("\n=== D ADX趋势过滤 (thr=999即不过滤) ===")
print(D.groupby('thr')[['ann','maxdd','nfill']].median().round(3).to_string())

rows=[]
# F: 时间退出 (N根bar无成交即离场)
for te in [None,24*21,24*45,24*90]:
    for s in SYMS:
        d=DATA[s]
        r=sim(d['open'].values,d['high'].values,d['low'].values,d['close'].values,
              1000,2,20,k=0.25,gtype='geom',time_exit=te,mode='fixed')
        rows.append(dict(te=str(te),sym=s,**{x:r[x] for x in ['ann','maxdd','nfill','ret']}))
F=pd.DataFrame(rows)
print("\n=== F 时间退出 (无成交天数) ===")
print(F.groupby('te')[['ann','maxdd','nfill']].median().round(3).to_string())

for n,df in [('A',A),('B',B),('C',C),('D',D),('F',F)]:
    df.to_csv(f'/data/workspace/grid_v2/{n}.csv',index=False)
print("\nSAVED")
