import numpy as np, pandas as pd, warnings
warnings.filterwarnings('ignore')
SYMS=['DOGE','ETH','CRV','DASH','DOT','FIL','HBAR','TRX','UNI','XLM','XMR','XRP','ZEC']

def load(sym, years=3):
    df=pd.read_csv(f'/data/inputs/{sym}USDT_1h.csv')
    df=df[['timestamp','open','high','low','close','quoteVolume']].dropna()
    df=df[(df[['open','high','low','close']]>0).all(axis=1)]
    df=df.reset_index(drop=True)
    n=int(365*24*years)
    return df.iloc[-n:].reset_index(drop=True) if len(df)>n else df

def adx(h,l,c,n=14):
    up=np.diff(h,prepend=h[0]); dn=-np.diff(l,prepend=l[0])
    tr=np.maximum(h-l, np.maximum(abs(h-np.roll(c,1)), abs(l-np.roll(c,1))))
    tr[0]=h[0]-l[0]
    pdm=np.where((up>dn)&(up>0),up,0.0); ndm=np.where((dn>up)&(dn>0),dn,0.0)
    def wma(x,p):
        a=np.zeros(len(x)); a[0]=np.nan; prev=np.nan
        for i in range(1,len(x)):
            prev = x[i] if np.isnan(prev) else (prev*(p-1)+x[i])/p
            a[i]=prev
        return a
    atr=wma(tr,n); sp=wma(pdm,n); sn=wma(ndm,n)
    with np.errstate(divide='ignore',invalid='ignore'):
        pdi=100*sp/atr; ndi=100*sn/atr
        dx=100*np.abs(pdi-ndi)/(pdi+ndi)
    out=np.zeros(len(c)); out[:n]=np.nan; prev=np.nan
    for i in range(n,len(c)):
        prev = dx[i] if np.isnan(prev) else (prev*(n-1)+dx[i])/n
        out[i]=prev
    return out

def levels_make(P0, k, N, gtype):
    lo=P0*(1-k); hi=P0*(1+k)
    if gtype=='geom':  return lo*(hi/lo)**(np.arange(N+1)/float(N))
    return np.linspace(lo,hi,N+1)

def sim(o,h,l,c, capital, fee_bp, N, k=0.25, gtype='geom',
        asym=1.0, util=1.0, init_frac=0.5,
        use_adx=False, adx_thr=25, adxser=None,
        trail=False, time_exit=None, mode='fixed'):
    """mode: fixed(levels array) | rel(relative asymmetric grid)"""
    P0=o[0]; fee=fee_bp/1e4
    deploy=capital*util
    if mode=='fixed':
        lv=levels_make(P0,k,N,gtype)
        m=deploy/float(N)
    else:
        gb=0.03*asym; gs=0.03      # buy step wider by asym
        m=deploy/float(N)
    inv=init_frac*deploy/P0; cash=deploy*(1.0-init_frac)
    avg=P0 if inv>0 else 0.0
    realized=0.0; fees=0.0; nfill=0
    peak=capital; maxdd=0.0
    center=P0; last=P0
    lv=levels_make(P0,k,N,gtype) if mode=='fixed' else np.array([P0*(1-0.03*asym),P0,P0*(1+0.03)])
    lbuy=lv[0] if mode=='fixed' else None
    last_cycle=0; T=len(c)
    prev=np.concatenate([[o[0]],c[:-1]])
    for t in range(T):
        if use_adx and adxser is not None and not np.isnan(adxser[t]) and adxser[t]>adx_thr:
            continue                                   # pause in trend
        if mode=='fixed':
            # trailing: recenter if price leaves band
            if trail and (c[t]<lv[0] or c[t]>lv[-1]):
                pass
            a=np.searchsorted(lv,l[t],'left'); b=np.searchsorted(lv,prev[t],'left')
            d=np.searchsorted(lv,prev[t],'right'); e=np.searchsorted(lv,h[t],'right')
            dn=lv[a:b]; up=lv[d:e]
            for L in dn[::-1]:
                u=m/L; cost=m; f=cost*fee
                if cash>=cost+f:
                    cash-=(cost+f); fees+=f
                    avg=(avg*inv+cost)/(inv+u) if inv>0 else cost
                    inv+=u; nfill+=1; last_cycle=t
            for L in up:
                u=m/L; proc=m; f=proc*fee
                if inv>=u-1e-12:
                    fees+=f; realized+=(proc-avg*u); cash+=(proc-f); inv-=u; nfill+=1; last_cycle=t
        else:
            # relative asymmetric: buy at last*(1-gb), sell at last*(1+gs)
            pb=last*(1-gb); ps=last*(1+gs)
            if l[t]<=pb and cash>=m*(1+fee):
                u=m/pb; cost=m; f=cost*fee
                cash-=(cost+f); fees+=f
                avg=(avg*inv+cost)/(inv+u) if inv>0 else cost
                inv+=u; last=pb; nfill+=1; last_cycle=t
            if h[t]>=ps and inv>=m/ps-1e-12:
                u=m/ps; proc=m; f=proc*fee
                fees+=f; realized+=(proc-avg*u); cash+=(proc-f); inv-=u; last=ps; nfill+=1; last_cycle=t
        eq=cash+inv*c[t]+(capital-deploy)
        if eq>peak: peak=eq
        dd=(peak-eq)/peak if peak>0 else 0
        if dd>maxdd: maxdd=dd
        if time_exit is not None and (t-last_cycle)>time_exit:
            break
        if trail and mode=='fixed' and (c[t]<lv[0] or c[t]>lv[-1]):
            lv=levels_make(c[t],k,N,gtype)
            if inv>0: pass
    final=cash+inv*c[-1]+(capital-deploy)
    yrs=T/(365*24.0)
    return dict(final=final, ret=final/capital-1, ann=(final/capital)**(1/yrs)-1 if final>0 and yrs>0 else -1,
                maxdd=maxdd, nfill=nfill, fees=fees, realized=realized)
