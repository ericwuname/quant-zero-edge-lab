"""网格最低价/最高价设定方法对比实验
固定 N=20 格（资金决定），对比不同区间设定方法的表现
"""
import numpy as np, pandas as pd, warnings, itertools, sys
warnings.filterwarnings('ignore')

SYMS = ['DOGE','ETH','CRV','DASH','DOT','FIL','HBAR','TRX','UNI','XLM','XMR','XRP','ZEC']
WARM = 720

def load(sym):
    df = pd.read_csv(f'/data/inputs/{sym}USDT_1h.csv')
    df = df[['timestamp','open','high','low','close']].dropna()
    df = df[(df[['open','high','low','close']] > 0).all(axis=1)]
    return df.reset_index(drop=True)

print('loading...', flush=True)
DATA = {}
for s in SYMS:
    d = load(s)
    d['atr14'] = (pd.concat([d['high'].diff(),
                             (d['high'] - d['close'].shift()),
                             (d['close'].shift() - d['low'])], axis=1)
                  .max(axis=1)).rolling(14).mean()
    d['ma720']  = d['close'].rolling(WARM).mean()
    d['std720'] = d['close'].rolling(WARM).std()
    d['lo720']  = d['low'].rolling(WARM).min()
    d['hi720']  = d['high'].rolling(WARM).max()
    d['lo2160'] = d['low'].rolling(2160).min()
    d['hi2160'] = d['high'].rolling(2160).max()
    d = d.iloc[WARM:].reset_index(drop=True)
    DATA[s] = d
print('loaded', {s: len(DATA[s]) for s in SYMS[:3]}, '...', flush=True)

def grid_seg(o, h, l, c, levels, capital, fee, init_frac):
    """单段网格，返回 (end_equity, realized, nfill, maxdd, exited)"""
    N = len(levels) - 1
    m = capital / float(N)
    P0 = o[0]
    prev = np.concatenate([[o[0]], c[:-1]])
    a = np.searchsorted(levels, l, 'left')
    b = np.searchsorted(levels, prev, 'left')
    dd_ = np.searchsorted(levels, prev, 'right')
    e = np.searchsorted(levels, h, 'right')
    inv = init_frac * capital / P0
    cash = capital * (1.0 - init_frac)
    avg = P0 if inv > 0 else 0.0
    realized = 0.0; nfill = 0
    peak = capital; maxdd = 0.0
    for t in range(len(c)):
        dn = levels[a[t]:b[t]]
        up = levels[dd_[t]:e[t]]
        for L_ in dn[::-1]:
            u = m / L_; cost = m; f = cost * fee
            if cash >= cost + f:
                cash -= (cost + f)
                if inv + u > 0:
                    avg = (avg * inv + cost) / (inv + u) if inv > 0 else cost
                inv += u; nfill += 1
        for L_ in up:
            u = m / L_; proc = m; f = proc * fee
            if inv >= u - 1e-12:
                realized += (proc - avg * u)
                cash += (proc - f); inv -= u; nfill += 1
        eq = cash + inv * c[t]
        if eq > peak: peak = eq
        ddx = (peak - eq) / peak if peak > 0 else 0.0
        if ddx > maxdd: maxdd = ddx
        if c[t] < levels[0] or c[t] > levels[-1]:
            return cash + inv * c[t], realized, nfill, maxdd, t
    return cash + inv * c[-1], realized, nfill, maxdd, None

def sim(df, method, N=20, capital=1000.0, fee_bp=2, init_frac=0.5, update_every=None):
    o = df['open'].values; h = df['high'].values
    l = df['low'].values;  c = df['close'].values
    fee = fee_bp / 1e4
    eq = capital; t0 = 0
    n_restart = 0; n_upd = 0; total_fill = 0
    maxdd_all = 0.0; widths = []
    n = len(c)
    seg_guard = 0
    while t0 < n and seg_guard < 3000:
        seg_guard += 1
        P0 = o[t0]
        L, H = method(df, t0)
        wr = H / L
        if P0 < L: L = P0; H = P0 * wr
        if P0 > H: H = P0; L = P0 / wr
        if not np.isfinite(L) or not np.isfinite(H) or L <= 0 or H <= L:
            L, H = P0 * 0.8, P0 * 1.25
        widths.append((H / L - 1) * 100)
        levels = np.geomspace(L, H, N + 1)
        end = n
        if update_every:
            end = min(n, t0 + update_every)
        eq_seg, realized, nfill, maxdd, brk = grid_seg(
            o[t0:end], h[t0:end], l[t0:end], c[t0:end],
            levels, eq, fee, init_frac)
        total_fill += nfill
        maxdd_all = max(maxdd_all, maxdd)
        eq = eq_seg
        if brk is not None:
            # 破网：平仓，以破网处价格重建（移仓）
            n_restart += 1
            t0 = t0 + brk + 1
        else:
            if update_every and end < n:
                n_upd += 1
            t0 = end
        if eq <= 0: return dict(ann=-1.0, maxdd=1.0, n_restart=n_restart,
                                nfill=total_fill, width=np.mean(widths), blow=True)
    yrs = n / 8760.0
    ret = eq / capital - 1.0
    ann = (max(eq, 1e-9) / capital) ** (1.0 / yrs) - 1.0
    return dict(ann=ann, ret=ret, maxdd=maxdd_all, n_restart=n_restart,
                n_upd=n_upd, nfill=total_fill, width=np.mean(widths), blow=False)

# ---------------- 区间方法工厂 ----------------
def m_fixed(k, center='px'):
    def f(df, t):
        P0 = df['open'].values[t]
        ctr = df['ma720'].values[t] if center == 'ma' else P0
        if not np.isfinite(ctr): ctr = P0
        return ctr * (1 - k), ctr * (1 + k)
    return f

def m_atr(k, center='px'):
    def f(df, t):
        P0 = df['open'].values[t]
        ctr = df['ma720'].values[t] if center == 'ma' else P0
        if not np.isfinite(ctr): ctr = P0
        a = df['atr14'].values[t]
        w = k * a / ctr if np.isfinite(a) else 0.2
        w = min(max(w, 0.02), 3.0)
        return ctr * (1 - w), ctr * (1 + w)
    return f

def m_boll(k, center='px'):
    def f(df, t):
        P0 = df['open'].values[t]
        ctr = df['ma720'].values[t] if center == 'ma' else P0
        s = df['std720'].values[t]
        if not np.isfinite(ctr): ctr = P0
        w = k * s / ctr if np.isfinite(s) else 0.2
        w = min(max(w, 0.02), 3.0)
        return ctr * (1 - w), ctr * (1 + w)
    return f

def m_minmax(win):
    key_lo = f'lo{win}'; key_hi = f'hi{win}'
    def f(df, t):
        P0 = df['open'].values[t]
        lo = df[key_lo].values[t]; hi = df[key_hi].values[t]
        if not np.isfinite(lo) or not np.isfinite(hi) or hi <= lo:
            return P0 * 0.8, P0 * 1.25
        return lo, hi
    return f

CONFIGS = []
for k in [0.10, 0.20, 0.30, 0.40, 0.60]:
    CONFIGS.append((f'fixed±{int(k*100)}%', m_fixed(k, 'px')))
for k in [2, 3, 4]:
    CONFIGS.append((f'ATR{k}', m_atr(k, 'px')))
for k in [1.5, 2.0, 2.5]:
    CONFIGS.append((f'BOLL{k}', m_boll(k, 'px')))
CONFIGS.append(('minmax720', m_minmax(720)))
CONFIGS.append(('minmax2160', m_minmax(2160)))
# 中心对比
for k in [0.20, 0.30]:
    CONFIGS.append((f'fixed±{int(k*100)}%_MActr', m_fixed(k, 'ma')))
CONFIGS.append(('ATR3_MActr', m_atr(3, 'ma')))
CONFIGS.append(('BOLL2_MActr', m_boll(2, 'ma')))

print('\n=== 主对比：N=20, 现货1x, 半仓, maker 2bp, 破网重启移仓 ===', flush=True)
rows = []
for name, fn in CONFIGS:
    res = [sim(DATA[s], fn, N=20) for s in SYMS]
    ann = np.median([r['ann'] for r in res])
    ret = np.median([r['ret'] for r in res])
    dd  = np.median([r['maxdd'] for r in res])
    nrs = np.median([r['n_restart'] for r in res])
    nf  = np.median([r['nfill'] for r in res])
    wd  = np.median([r['width'] for r in res])
    pos = np.mean([r['ann'] > 0 for r in res])
    rows.append(dict(method=name, width_pct=wd, ann=ann, ret=ret,
                     maxdd=dd, calmar=(ann/dd if dd > 0 else np.nan),
                     restarts=nrs, fills=nf, pos_rate=pos))
    print(f'{name:18s} 宽{wd:6.1f}%  年化{ann:7.3f}  收益{ret:8.2f}  回撤{dd:.3f}  '
          f'Calmar{ann/dd if dd>0 else 0:6.2f}  重启{nrs:5.0f}  成交{nf:6.0f}  为正{pos:.0%}', flush=True)

pd.DataFrame(rows).to_csv('/data/workspace/range_methods.csv', index=False)

print('\n=== 更新频率对比（fixed±30%, N=20） ===', flush=True)
rows2 = []
for ue in [None, 168, 24]:
    res = [sim(DATA[s], m_fixed(0.30, 'px'), N=20, update_every=ue) for s in SYMS]
    ann = np.median([r['ann'] for r in res])
    dd = np.median([r['maxdd'] for r in res])
    nr = np.median([r['n_restart'] for r in res])
    nu = np.median([r['n_upd'] for r in res])
    rows2.append(dict(update=('破网才更新' if ue is None else f'每{ue}根'), ann=ann, maxdd=dd,
                      restarts=nr, updates=nu))
    print(f'{("破网才更新" if ue is None else "每"+str(ue)+"根"):12s} 年化{ann:7.3f} 回撤{dd:.3f} '
          f'重启{nr:5.0f} 定期更新{nu:5.0f}', flush=True)
pd.DataFrame(rows2).to_csv('/data/workspace/range_update.csv', index=False)

print('\n=== 区间宽度 × 格数 网格（fixed 中心现价） ===', flush=True)
rows3 = []
for k in [0.10, 0.20, 0.30, 0.40, 0.60]:
    for N in [10, 20, 40]:
        res = [sim(DATA[s], m_fixed(k, 'px'), N=N) for s in SYMS]
        ann = np.median([r['ann'] for r in res])
        dd = np.median([r['maxdd'] for r in res])
        nr = np.median([r['n_restart'] for r in res])
        g = (1 + 2 * k) ** (1.0 / N) - 1 if False else (( (1+k)/(1-k) )**(1.0/N) - 1)
        rows3.append(dict(k=k, N=N, width=2*k*100, g_pct=g*100, ann=ann,
                          maxdd=dd, restarts=nr,
                          pos=np.mean([r['ann'] > 0 for r in res])))
        print(f'±{int(k*100):2d}% N={N:2d} 格距g={g*100:5.2f}%  年化{ann:7.3f}  '
              f'回撤{dd:.3f}  重启{nr:5.0f}  为正{np.mean([r["ann"]>0 for r in res]):.0%}', flush=True)
pd.DataFrame(rows3).to_csv('/data/workspace/range_grid.csv', index=False)
print('\nDONE', flush=True)
