import numpy as np, core
def canary(nm,g=0.01,N=10,t=15000,mode='fixed'):
    d=core.load(nm); o,h,l,c=[d[k].values for k in ('open','high','low','close')]
    def cut(a): return a[:t+1]
    rf=core.grid_sim(o,h,l,c,g,N,2.0,'down',trace=True,center_mode=mode)
    rt=core.grid_sim(cut(o),cut(h),cut(l),cut(c),g,N,2.0,'down',trace=True,center_mode=mode)
    a=[x for x in rf['tr'] if x[0]<=t]; b=rt['tr']
    clean=(len(a)==len(b)) and all(x==y for x,y in zip(a,b))
    out=[clean]
    for ch in ('future','futma'):
        rc=core.grid_sim(o,h,l,c,g,N,2.0,'down',trace=True,center_mode=mode,cheat_center=ch)
        rt2=core.grid_sim(cut(o),cut(h),cut(l),cut(c),g,N,2.0,'down',trace=True,center_mode=mode,cheat_center=ch)
        a2=[x for x in rc['tr'] if x[0]<=t]; b2=rt2['tr']
        out.append(not((len(a2)==len(b2)) and all(x==y for x,y in zip(a2,b2))))
    return tuple(out)
