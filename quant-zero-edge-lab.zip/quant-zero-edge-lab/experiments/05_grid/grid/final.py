import numpy as np, pandas as pd, core, calib, drift
G,N=0.02,10
print('=== A. 零漂移合成：20 seed 期望（判断是否有真实edge）===')
res=[];bh=[]
for s in range(20):
    P,o,h,l,c=drift.gen(ann_mu=0.0,seed=s,n=20000)
    gt=calib.grid_path(P,G,N,2.0); res.append(gt['nav']-10000); bh.append(10000*(c[-1]/c[0]-1))
res=np.array(res);bh=np.array(bh)
print(f"网格净: 均值{res.mean():9.0f} 中位{np.median(res):9.0f} 标准差{res.std():9.0f} t={res.mean()/(res.std()/np.sqrt(20)):6.2f}")
print(f"买入持有: 均值{bh.mean():9.0f}  (零漂移下几何拖累应为负)")
print(f"网格-BH: 均值{(res-bh).mean():9.0f} t={(res-bh).mean()/((res-bh).std()/np.sqrt(20)):6.2f}  为正比例{np.mean(res-bh>0):.2f}")

print('\n=== B. 成本敏感性（真实13品种, g=2%, N=10, down）===')
print(f"{'单边bp':>7}{'cost_R':>8}{'收益中位':>10}{'为正比例':>9}{'手续费中位':>10}{'vsBH中位':>10}")
for cb_ in (2,5,10,20,50):
    r=[];f=[];al=[]
    for nm in core.ALL:
        d=core.load(nm); o,h,l,c=[d[k].values for k in ('open','high','low','close')]
        x=core.grid_sim(o,h,l,c,G,N,float(cb_),'down')
        r.append(x['nav']/10000-1); f.append(x['fee']); al.append(x['nav']/10000-x['bh']/10000)
    print(f"{cb_:7d}{2*cb_/(G*1e4):8.3f}{np.median(r):10.2f}{np.mean(np.array(r)>0):9.2f}{np.median(f):10.0f}{np.median(al):10.2f}")

print('\n=== C. 时间外推（前50% vs 后50%）===')
for nm in core.ALL:
    d=core.load(nm); o,h,l,c=[d[k].values for k in ('open','high','low','close')]
    t=len(o)//2
    a=core.grid_sim(o[:t],h[:t],l[:t],c[:t],G,N,2.0,'down')
    b=core.grid_sim(o[t:],h[t:],l[t:],c[t:],G,N,2.0,'down')
    print(f"{nm:>6} 前半{a['nav']/10000-1:9.2f}(BH{a['bh']/10000-1:8.2f})  后半{b['nav']/10000-1:9.2f}(BH{b['bh']/10000-1:8.2f})")

print('\n=== D. 收割制（不复利，每周结算提取盈余，本金1万）===')
print(f"{'品种':>6}{'总提取':>10}{'赚回本金':>9}{'爆仓':>7}{'最终nav':>10}")
tot=[];win=[];bust=[]
for nm in core.ALL:
    d=core.load(nm); o,h,l,c=[d[k].values for k in ('open','high','low','close')]
    x=core.grid_sim(o,h,l,c,G,N,2.0,'down',harvest=168,maxdd_stop=0.20)
    tot.append(x['withdrawn']); win.append(x['withdrawn']>=10000); bust.append(x['stopped'])
    print(f"{nm:>6}{x['withdrawn']:10.0f}{'是' if x['withdrawn']>=10000 else '否':>9}{'是' if x['stopped'] else '否':>7}{x['nav']:10.0f}")
print(f"赚回本金比例 {np.mean(win):.2f}  爆仓(净值<=20%)比例 {np.mean(bust):.2f}  提取中位 {np.median(tot):.0f}")
