"""网格策略引擎（几何网格，做多：低买高卖）
网格线 level[k] = center*(1+g)^k
配对规则：价格跌到格 k -> 在 level[k] 买入；价格涨到格 j -> 卖出买于格 j-1 的单（成交 level[j]）
  故每格毛利恒为 m*g（m = cap/N 每格名义资金）
关键：网格线跟踪价格（k_now 始终=价格所在格），持仓独立管理；不因某格无持仓而 break
bar 内路径不可知 -> 三口径：down(先跌后涨,乐观)/up(先涨后跌)/close(净移动,保守)
"""
import numpy as np, pandas as pd

DATA='/data/inputs'
OLD7=['CRV','DASH','DOGE','DOT','ETH','FIL','HBAR']
NEW6=['TRX','UNI','XLM','XMR','XRP','ZEC']
ALL=OLD7+NEW6

def load(nm):
    d=pd.read_csv(f'{DATA}/{nm}USDT_1h.csv')
    d=d[['open','high','low','close']].dropna().astype(float)
    d=d[(d>0).all(axis=1)]
    return d.reset_index(drop=True)

def grid_sim(o,h,l,c,g,N,cost_bp,order='down',cap=10000.0,init_pos=0,
             center_mode='fixed',ma_w=500,harvest=0,maxdd_stop=0.20,trace=False,
             cheat_center=None):
    n=len(o)
    if center_mode=='fixed':
        if cheat_center=='future':                 # 负对照：中枢用全样本几何均值(前视)
            center=np.full(n,float(np.exp(np.mean(np.log(c)))))
        elif cheat_center=='futma':                # 负对照：中枢用未来窗口MA(前视)
            center=pd.Series(c)[::-1].rolling(ma_w,min_periods=1).mean()[::-1].bfill().values
        else:
            center=np.full(n,c[0]) if not isinstance(cheat_center,(int,float)) else np.full(n,float(cheat_center))
    else:
        s=pd.Series(c); center=s.rolling(ma_w,min_periods=ma_w).mean().bfill().values
    lg=np.log(1.0+g)
    k_low=np.floor(np.log(l/center)/lg).astype(np.int64)
    k_high=np.floor(np.log(h/center)/lg).astype(np.int64)
    k_cls=np.floor(np.log(c/center)/lg).astype(np.int64)

    m=cap/float(N); cb=cost_bp/1e4
    cash=cap; hold={}
    realized=0.0; fee=0.0; n_buy=0; n_sell=0; max_hold=0
    tr=[]
    withdrawn=0.0; stopped=False
    k_now=int(k_cls[0])
    navs=np.empty(n); navs[0]=cap

    for j in range(init_pos):        # 初始建仓
        kk=-j-1; px=center[0]*(1.0+g)**kk
        if cash>=m: cash-=m*(1+cb); fee+=m*cb; hold[kk]=px; n_buy+=1

    for i in range(1,n):
        kl=int(k_low[i]); kh=int(k_high[i]); kc=int(k_cls[i])
        seq=[kc] if order=='close' else ([kl,kh,kc] if order=='down' else [kh,kl,kc])
        for tgt in seq:
            if tgt<k_now:                                   # 下跌
                for kk in range(k_now-1,tgt-1,-1):
                    if len(hold)>=N or cash<m: break        # 资金/持仓上限
                    px=center[i]*(1.0+g)**kk
                    cash-=m*(1+cb); fee+=m*cb; hold[kk]=px; n_buy+=1
                    if trace: tr.append((i,'B',kk))
                k_now=tgt
            elif tgt>k_now:                                 # 上涨
                for jg in range(k_now+1,tgt+1):
                    bp=hold.get(jg-1)
                    if bp is None: continue
                    px=center[i]*(1.0+g)**jg
                    amt=m*(px/bp); cash+=amt*(1-cb); fee+=amt*cb
                    realized+=amt*(1-cb)-m*(1+cb); del hold[jg-1]; n_sell+=1
                    if trace: tr.append((i,'S',jg-1))
                k_now=tgt
        if len(hold)>max_hold: max_hold=len(hold)
        navs[i]=cash+sum(m*(c[i]/bp) for bp in hold.values())
        if harvest>0 and i%harvest==0 and navs[i]>cap:
            ex=max(0.0,min(navs[i]-cap,cash)); cash-=ex; withdrawn+=ex; navs[i]=navs[i]-ex
        if maxdd_stop>0 and navs[i]<=cap*maxdd_stop and not stopped:
            stopped=True
    unrl=0.0
    for kk in list(hold.keys()):
        bp=hold[kk]; amt=m*(c[-1]/bp); cash+=amt*(1-cb); fee+=amt*cb; unrl+=amt*(1-cb)-m*(1+cb); n_sell+=1
    # 最大回撤
    peak=np.maximum.accumulate(navs); dd=1-navs/peak
    return dict(nav=cash, realized=realized, unrl=unrl, fee=fee, n_buy=n_buy, n_sell=n_sell,
                max_hold=max_hold, bh=cap*(c[-1]/c[0]), withdrawn=withdrawn, navs=navs,
                maxdd=dd.max(), stopped=stopped, cap=cap, m=m, g=g, N=N, tr=tr)
