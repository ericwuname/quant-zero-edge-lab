"""漂移敏感性：网格在不同趋势强度下的表现（合成）+ 真实数据OLD7/NEW6外推"""
import numpy as np, core, calib

def gen(n=30000,ns=8,ann_vol=0.80,ann_mu=0.0,seed=0,p0=100.0):
    rng=np.random.default_rng(seed)
    dt=1.0/8760.0; sd=ann_vol*np.sqrt(dt/ns)
    mu=(ann_mu-0.5*ann_vol**2)*dt/ns
    steps=rng.normal(mu,sd,n*ns)
    logp=np.log(p0)+np.cumsum(steps); p=np.exp(logp); P=p.reshape(n,ns)
    o=np.empty(n);h=np.empty(n);l=np.empty(n);c=np.empty(n); o[0]=p0
    for i in range(n):
        h[i]=P[i].max(); l[i]=P[i].min(); c[i]=P[i][-1]
        if i>0: o[i]=c[i-1]
    return P,o,h,l,c

if __name__=='__main__':
    print('=== 合成：漂移敏感性（g=2%,N=10,cost2bp,本金1万）===')
    print(f"{'年化漂移':>9}{'真实路径净':>11}{'down净':>10}{'买入持有':>10}{'网格-BH':>10}")
    for mu in (-0.5,-0.2,0.0,0.2,0.5,1.0):
        P,o,h,l,c=gen(ann_mu=mu,seed=7)
        gt=calib.grid_path(P,0.02,10,2.0)
        rd=core.grid_sim(o,h,l,c,0.02,10,2.0,'down')
        bh=10000*(c[-1]/c[0]-1)
        print(f"{mu:9.2f}{gt['nav']-10000:11.0f}{rd['nav']-10000:10.0f}{bh:10.0f}{rd['nav']-10000-bh:10.0f}")

    print('\n=== 真实数据：逐品种分解（g=2%,N=10,down,cost2bp）===')
    print(f"{'品种':>6}{'网格净':>10}{'已实现':>10}{'未实现':>10}{'手续费':>8}{'成交格':>8}{'最大回撤':>9}{'BH':>10}")
    for nm in core.ALL:
        d=core.load(nm); o,h,l,c=[d[k].values for k in ('open','high','low','close')]
        r=core.grid_sim(o,h,l,c,0.02,10,2.0,'down')
        print(f"{nm:>6}{r['nav']-10000:10.0f}{r['realized']:10.0f}{r['unrl']:10.0f}{r['fee']:8.0f}{r['n_buy']:8d}{r['maxdd']:9.2f}{r['bh']-10000:10.0f}")

    print('\n=== 真实数据：OLD7 vs NEW6 外推 ===')
    for g,N in ((0.01,10),(0.02,10),(0.03,10)):
        for grp,syms in (('OLD7',core.OLD7),('NEW6',core.NEW6)):
            ret=[];al=[]
            for nm in syms:
                d=core.load(nm); o,h,l,c=[d[k].values for k in ('open','high','low','close')]
                r=core.grid_sim(o,h,l,c,g,N,2.0,'down')
                ret.append(r['nav']/10000-1); al.append(r['nav']/10000-r['bh']/10000)
            print(f"g={g} N={N} {grp}: 收益中位{np.median(ret):8.2f}  vsBH中位{np.median(al):8.2f}  为正比例{np.mean(np.array(al)>0):.2f}")
