"""用合成数据(已知真实bar内路径)校准 down/up/close 三口径的偏差
GBM零漂移，bar内 ns 个子步 -> ground truth 由逐子步成交给出
"""
import numpy as np, core

def gen(n=30000,ns=8,ann_vol=0.80,seed=0,p0=100.0):
    """生成 bar 内真实路径：返回 (子步价格序列, OHLC)"""
    rng=np.random.default_rng(seed)
    dt=1.0/8760.0; sd=ann_vol*np.sqrt(dt/ns)
    steps=rng.normal(0,sd,n*ns)
    logp=np.log(p0)+np.cumsum(steps)
    p=np.exp(logp)
    P=p.reshape(n,ns)                     # 每bar ns个子步价格
    o=np.empty(n);h=np.empty(n);l=np.empty(n);c=np.empty(n)
    o[0]=p0
    for i in range(n):
        h[i]=P[i].max(); l[i]=P[i].min(); c[i]=P[i][-1]
        if i>0: o[i]=c[i-1]
    return P,o,h,l,c

def grid_path(P,g,N,cost_bp,cap=10000.0):
    """ground truth：逐子步成交"""
    n,ns=P.shape; center=P[0,0]; lg=np.log(1.0+g)
    m=cap/float(N); cb=cost_bp/1e4
    cash=cap; hold={}; realized=0.0; fee=0.0; nb=0; ns_=0
    k_now=int(np.floor(np.log(P[0,0]/center)/lg))
    flat=P.reshape(-1)
    kf=np.floor(np.log(flat/center)/lg).astype(np.int64)
    for idx in range(len(flat)):
        tgt=int(kf[idx])
        if tgt<k_now:
            for kk in range(k_now-1,tgt-1,-1):
                if len(hold)>=N or cash<m: break
                px=center*(1.0+g)**kk; cash-=m*(1+cb); fee+=m*cb; hold[kk]=px; nb+=1
            k_now=tgt
        elif tgt>k_now:
            for jg in range(k_now+1,tgt+1):
                bp=hold.get(jg-1)
                if bp is None: continue
                px=center*(1.0+g)**jg; amt=m*(px/bp); cash+=amt*(1-cb); fee+=amt*cb
                realized+=amt*(1-cb)-m*(1+cb); del hold[jg-1]; ns_+=1
            k_now=tgt
    unrl=0.0
    for kk in list(hold.keys()):
        bp=hold[kk]; amt=m*(flat[-1]/bp); cash+=amt*(1-cb); fee+=amt*cb; unrl+=amt*(1-cb)-m*(1+cb)
    return dict(nav=cash,realized=realized,unrl=unrl,fee=fee,n_buy=nb)

if __name__=='__main__':
    print('合成GBM零漂移：ground truth vs 三口径（本金10000）')
    print(f"{'g':>5}{'N':>4} | {'真实路径':>10} {'down':>10} {'up':>10} {'close':>10} | down/真实")
    for g in (0.01,0.02,0.03):
        for N in (10,):
            P,o,h,l,c=gen(seed=42)
            gt=grid_path(P,g,N,2.0)
            rd=core.grid_sim(o,h,l,c,g,N,2.0,'down')
            ru=core.grid_sim(o,h,l,c,g,N,2.0,'up')
            rc=core.grid_sim(o,h,l,c,g,N,2.0,'close')
            f=lambda r:r['nav']-10000
            print(f"{g:5.3f}{N:4d} | {f(gt):10.0f} {f(rd):10.0f} {f(ru):10.0f} {f(rc):10.0f} | {f(rd)/max(abs(f(gt)),1):6.2f}x")
