import numpy as np, pandas as pd, core, time
NAMES=core.ALL
D={nm:core.load(nm) for nm in NAMES}
def arrs(nm):
    d=D[nm]; return [d[k].values for k in ('open','high','low','close')]
HRS={nm:len(D[nm]) for nm in NAMES}

def run(g,N,order,cost_bp,init_pos=0):
    rows=[]
    for nm in NAMES:
        o,h,l,c=arrs(nm)
        r=core.grid_sim(o,h,l,c,g,N,cost_bp,order,cap=10000.0,init_pos=init_pos)
        n=HRS[nm]; yrs=n/8760.0
        net=r['nav']-r['cap']
        per_grid=net/max(r['n_buy'],1)
        R=r['m']*r['g']
        rows.append(dict(sym=nm,grp='OLD7' if nm in core.OLD7 else 'NEW6',
            yrs=yrs, navret=r['nav']/r['cap']-1, ann=(r['nav']/r['cap'])**(1/yrs)-1,
            bhret=r['bh']/r['cap']-1, alpha=r['nav']/r['cap']-r['bh']/r['cap'],
            realized=r['realized'], unrl=r['unrl'], fee=r['fee'],
            n_buy=r['n_buy'], maxhold=r['max_hold'], maxdd=r['maxdd'],
            per_grid=per_grid, per_grid_R=per_grid/R,
            cost_R=2*cost_bp/(g*1e4), turnover=r['n_buy']/yrs))
    return pd.DataFrame(rows)

if __name__=='__main__':
    t0=time.time(); out=[]
    for g in (0.005,0.01,0.02,0.03):
        for N in (5,10,20):
            for order in ('down','close'):
                df=run(g,N,order,2.0)
                df.insert(0,'g',g); df.insert(1,'N',N); df.insert(2,'order',order)
                out.append(df)
    A=pd.concat(out,ignore_index=True)
    A.to_csv('/data/workspace/grid/main.csv',index=False)
    print('secs',round(time.time()-t0,1),'rows',len(A))
    # 汇总：按配置，跨品种中位数
    s=A.groupby(['g','N','order']).agg(
        navret_med=('navret','median'), bhret_med=('bhret','median'),
        alpha_med=('alpha','median'), perR_med=('per_grid_R','median'),
        dd_med=('maxdd','median'), pos_rate=('alpha',lambda x:(x>0).mean()),
        turnover_med=('turnover','median')).reset_index()
    print('\n=== 主扫描（maker 2bp，13品种中位数）===')
    print(s.to_string(index=False,float_format=lambda v:f'{v:.4f}'))
