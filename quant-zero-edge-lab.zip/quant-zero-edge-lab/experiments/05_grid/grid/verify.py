"""可信性验证：canary 前视探测 + 负对照 + 随机方向对照 + 鞅性检查"""
import numpy as np, core

def grid_rand(o,h,l,c,g,N,cost_bp,order='down',cap=10000.0,seed=0):
    """同触发时点、方向随机（零期望对照）：检验网格'低买高卖'方向是否有价值"""
    rng=np.random.default_rng(seed)
    n=len(o); center=np.full(n,c[0]); lg=np.log(1.0+g)
    k_low=np.floor(np.log(l/center)/lg).astype(np.int64)
    k_high=np.floor(np.log(h/center)/lg).astype(np.int64)
    k_cls=np.floor(np.log(c/center)/lg).astype(np.int64)
    m=cap/float(N); cb=cost_bp/1e4
    cash=cap; hold={}; realized=0.0; fee=0.0; ntr=0
    k_now=int(k_cls[0])
    for i in range(1,n):
        kl=int(k_low[i]); kh=int(k_high[i]); kc=int(k_cls[i])
        seq=[kc] if order=='close' else ([kl,kh,kc] if order=='down' else [kh,kl,kc])
        for tgt in seq:
            if tgt<k_now:
                for kk in range(k_now-1,tgt-1,-1):
                    if len(hold)>=N or cash<m: break
                    px=center[i]*(1.0+g)**kk
                    buy=rng.random()<0.5
                    if buy: cash-=m; fee+=m*cb; hold[kk]=px
                    else:   cash-=m; fee+=m*cb; hold[kk]=-px   # 标记为空单(反向)
                    ntr+=1
                k_now=tgt
            elif tgt>k_now:
                for jg in range(k_now+1,tgt+1):
                    bp=hold.get(jg-1)
                    if bp is None: continue
                    px=center[i]*(1.0+g)**jg
                    amt=m*(px/abs(bp)); cash+=amt; fee+=amt*cb
                    realized+=amt-m if bp>0 else (2*m-amt-m)
                    del hold[jg-1]; ntr+=1
                k_now=tgt
    for kk in list(hold.keys()):
        bp=hold[kk]; amt=m*(c[-1]/abs(bp)); cash+=amt; fee+=amt*cb
        realized+= amt-m if bp>0 else (2*m-amt-m)
    return dict(nav=cash,realized=realized,fee=fee,ntr=ntr)

def canary(nm='DOGE',t=20000,g=0.01,N=10):
    """前视探测：打乱 t 之后数据，t 之前的成交应完全不变"""
    d=core.load(nm); o,h,l,c=[d[k].values for k in ('open','high','low','close')]
    r1=core.grid_sim(o,h,l,c,g,N,2.0,'down')
    b1=(r1['n_buy'],r1['realized'])
    rng=np.random.default_rng(1); n=len(o)
    o2,h2,l2,c2=o.copy(),h.copy(),l.copy(),c.copy()
    idx=rng.permutation(n-t)+t
    for a,b in ((o2,'o'),(h2,'h'),(l2,'l'),(c2,'c')):
        a[t:]=({'o':o,'h':h,'l':l,'c':c}[b])[idx]
    r2=core.grid_sim(o2,h2,l2,c2,g,N,2.0,'down')
    return dict(clean=(r2['n_buy']==b1[0] and abs(r2['realized']-b1[1])<1e-6),
                before=(r1['n_buy'],round(r1['realized'],2)),
                after=(r2['n_buy'],round(r2['realized'],2)))
