import numpy as np, core, drift, calib
print('=== H. 格距峰值（寻找最优g，N=10,cost2bp）===')
print(f"{'g':>7}{'收益中位':>9}{'为正':>6}{'回撤中位':>9}{'成交/年':>8}")
for g in (0.08,0.12,0.18,0.25,0.35):
    r=[];dd=[];tv=[]
    for nm in core.ALL:
        d=core.load(nm); o,h,l,c=[d[k].values for k in ('open','high','low','close')]
        x=core.grid_sim(o,h,l,c,g,10,2.0,'down')
        r.append(x['nav']/10000-1); dd.append(x['maxdd']); tv.append(x['n_buy']/(len(o)/8760))
    print(f"{g:7.3f}{np.median(r):9.2f}{np.mean(np.array(r)>0):6.2f}{np.median(dd):9.2f}{np.median(tv):8.0f}")

print('\n=== I. 波动率敏感性（合成零漂移，g=2% N=10；网格收益应∝波动）===')
print(f"{'年化波动':>9}{'网格净':>10}{'BH':>10}{'成交格':>8}")
for v in (0.30,0.50,0.80,1.20):
    P,o,h,l,c=drift.gen(ann_vol=v,ann_mu=0.0,seed=11,n=15000)
    x=core.grid_sim(o,h,l,c,0.02,10,2.0,'down')
    print(f"{v:9.2f}{x['nav']-10000:10.0f}{10000*(c[-1]/c[0]-1):10.0f}{x['n_buy']:8d}")

print('\n=== J. 格数N（资金分批数，g=2%,cost2bp）===')
print(f"{'N':>4}{'收益中位':>9}{'为正':>6}{'回撤中位':>9}{'vsBH':>8}")
for N in (3,5,10,20,40):
    r=[];dd=[];al=[]
    for nm in core.ALL:
        d=core.load(nm); o,h,l,c=[d[k].values for k in ('open','high','low','close')]
        x=core.grid_sim(o,h,l,c,0.02,N,2.0,'down')
        r.append(x['nav']/10000-1); dd.append(x['maxdd']); al.append(x['nav']/10000-x['bh']/10000)
    print(f"{N:4d}{np.median(r):9.2f}{np.mean(np.array(r)>0):6.2f}{np.median(dd):9.2f}{np.median(al):8.2f}")
