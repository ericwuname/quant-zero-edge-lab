import numpy as np, core
print('=== E. 格距g扫描（真实13品种,N=10,down,cost2bp）===')
print(f"{'g':>6}{'cost_R':>8}{'收益中位':>9}{'为正':>6}{'回撤中位':>9}{'成交/年中位':>11}{'vsBH中位':>9}")
for g in (0.005,0.01,0.02,0.03,0.05,0.08):
    r=[];dd=[];tv=[];al=[]
    for nm in core.ALL:
        d=core.load(nm); o,h,l,c=[d[k].values for k in ('open','high','low','close')]
        x=core.grid_sim(o,h,l,c,g,10,2.0,'down')
        r.append(x['nav']/10000-1); dd.append(x['maxdd']); tv.append(x['n_buy']/(len(o)/8760)); al.append(x['nav']/10000-x['bh']/10000)
    print(f"{g:6.3f}{2*2/(g*1e4):8.3f}{np.median(r):9.2f}{np.mean(np.array(r)>0):6.2f}{np.median(dd):9.2f}{np.median(tv):11.0f}{np.median(al):9.2f}")

print('\n=== F. 归零/深跌风险（合成：年化漂移 -100%~-60%，g=2% N=10）===')
import drift,calib
print(f"{'年化漂移':>9}{'网格净':>10}{'最大回撤':>9}{'BH':>10}")
for mu in (-0.6,-0.8,-1.0,-1.5):
    P,o,h,l,c=drift.gen(ann_mu=mu,seed=3,n=15000)
    x=core.grid_sim(o,h,l,c,0.02,10,2.0,'down')
    print(f"{mu:9.2f}{x['nav']-10000:10.0f}{x['maxdd']:9.2f}{10000*(c[-1]/c[0]-1):10.0f}")

print('\n=== G. 收割制（g扫描，每周提取，本金1万，13品种）===')
print(f"{'g':>6}{'赚回本金比例':>12}{'提取中位':>10}{'爆仓比例':>9}")
for g in (0.01,0.02,0.03):
    win=[];wd=[];bs=[]
    for nm in core.ALL:
        d=core.load(nm); o,h,l,c=[d[k].values for k in ('open','high','low','close')]
        x=core.grid_sim(o,h,l,c,g,10,2.0,'down',harvest=168,maxdd_stop=0.20)
        win.append(x['withdrawn']>=10000); wd.append(x['withdrawn']); bs.append(x['stopped'])
    print(f"{g:6.3f}{np.mean(win):12.2f}{np.median(wd):10.0f}{np.mean(bs):9.2f}")
