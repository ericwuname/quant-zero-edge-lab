"""按 g 逐档校准：down口径 vs 真实路径（合成零漂移+真实波动率结构）"""
import numpy as np, core, calib, drift
print('合成GBM零漂移(ann_vol=0.8)：真实路径 vs down/up/close  [本金1万, N=10, cost2bp]')
print(f"{'g':>6}{'真实路径':>10}{'down':>10}{'up':>10}{'close':>10}{'down/真实':>10}{'up/真实':>9}")
for g in (0.01,0.02,0.05,0.08,0.12,0.18,0.25,0.35):
    T=[];D=[];U=[];C=[]
    for s in (0,1,2,3,4):
        P,o,h,l,c=drift.gen(n=15000,ns=8,ann_vol=0.80,ann_mu=0.0,seed=s)
        T.append(calib.grid_path(P,g,10,2.0)['nav']-10000)
        D.append(core.grid_sim(o,h,l,c,g,10,2.0,'down')['nav']-10000)
        U.append(core.grid_sim(o,h,l,c,g,10,2.0,'up')['nav']-10000)
        C.append(core.grid_sim(o,h,l,c,g,10,2.0,'close')['nav']-10000)
    T,D,U,C=map(np.mean,(T,D,U,C))
    print(f"{g:6.3f}{T:10.0f}{D:10.0f}{U:10.0f}{C:10.0f}{D/max(abs(T),1):10.2f}{U/max(abs(T),1):9.2f}")
