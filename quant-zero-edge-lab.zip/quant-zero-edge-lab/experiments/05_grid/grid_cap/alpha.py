"""网格赚的是套利的钱还是beta的钱？—— 对比 网格 vs 买入持有 超额"""
import numpy as np, pandas as pd, sys
sys.path.insert(0,'/data/workspace/grid')
from core import grid_sim, load, ALL
rows=[]
for g in [0.02,0.03,0.05,0.08]:
    for N in [10,20]:
        ex=[];gr=[];bh=[]
        for s in ALL:
            d=load(s); o,h,l,c=d['open'].values,d['high'].values,d['low'].values,d['close'].values
            r=grid_sim(o,h,l,c,g=g,N=N,cost_bp=2,order='down',cap=10000.0,init_pos=0)
            gt=r['nav']/r['cap']-1.0; bt=c[-1]/c[0]-1.0
            gr.append(gt); bh.append(bt); ex.append(gt-bt)
        rows.append({'g':f"{g*100:.0f}%",'N':N,'网格中位':f"{np.median(gr)*100:.0f}%",
            '买入持有中位':f"{np.median(bh)*100:.0f}%",'超额中位':f"{np.median(ex)*100:+.0f}%",
            '跑赢持有比例':f"{(np.array(ex)>0).mean()*100:.0f}%"})
df=pd.DataFrame(rows); print(df.to_string(index=False))
df.to_csv('/data/workspace/grid_cap/Q5_grid_vs_bh.csv',index=False)
print("\n注：超额=网格−持有。超额越大=越靠套利；g越大超额越小/越负=退化成持有、吃beta")
