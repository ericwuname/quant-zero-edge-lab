"""小资金分档方案：按本金规模推荐(g,N)，并算时间成本平衡点"""
import numpy as np, pandas as pd, sys
sys.path.insert(0,'/data/workspace/grid')
from core import grid_sim, load, ALL

def stats(g,N,cost_bp=2):
    tots=[];anns=[];dds=[];yrs=[]
    for s in ALL:
        d=load(s); o,h,l,c=d['open'].values,d['high'].values,d['low'].values,d['close'].values
        r=grid_sim(o,h,l,c,g=g,N=N,cost_bp=cost_bp,order='down',cap=10000.0,init_pos=0)
        y=len(c)/(365*24); tot=r['nav']/r['cap']-1.0
        tots.append(tot); anns.append((1+tot)**(1/y)-1 if tot>-1 else -1); dds.append(r['maxdd']); yrs.append(y)
    return np.median(anns),np.mean(dds),(np.array(tots)>0).mean(),np.mean(yrs)

print("="*80); print("扫描(g,N)：年化中位收益 / 平均回撤 / C_min / 单边覆盖区间"); print("="*80)
rows=[]
for g in [0.02,0.03,0.05,0.08]:
    for N in [5,10,20]:
        a,dd,pos,_=stats(g,N)
        rows.append({'g':f"{g*100:.0f}%",'N':N,'C_min(U)':N*5,
            '年化中位':f"{a*100:.0f}%",'平均回撤':f"{dd*100:.0f}%",'为正比例':f"{pos*100:.0f}%",
            '单边覆盖':f"{(1+g)**N-1:+.0%}"})
df=pd.DataFrame(rows).sort_values('年化中位',ascending=False)
print(df.to_string(index=False)); df.to_csv('/data/workspace/grid_cap/Q4_gn_plan.csv',index=False)

print("\n"+"="*80); print("时间成本平衡点（管理≈0.5h/周=26h/年；机会成本按 5 U/小时）"); print("="*80)
# 选两个候选：A=g3,N20(覆盖大,少重启) B=g5,N10(门槛最低,收益最高)
for tag,(g,N) in [('A 稳健 g=3%,N=20',(0.03,20)),('B 低门槛 g=5%,N=10',(0.05,10))]:
    a,dd,pos,_=stats(g,N); C_min=N*5
    print(f"\n{tag}: 年化{a*100:.0f}%  回撤{dd*100:.0f}%  C_min={C_min}U")
    print(f"{'本金C':>8} {'年化收益':>10} {'时间成本':>10} {'净收益':>10} {'每小时收益':>12} {'建议':>8}")
    for C in [50,100,200,500,1000,2000,5000]:
        if C<C_min: print(f"{C:>8} {'—':>10} {'—':>10} {'—':>10} {'—':>12} {'本金<C_min,降N':>8}"); continue
        gain=C*a; cost=26*5; net=gain-cost
        print(f"{C:>8} {gain:>10.0f} {cost:>10} {net:>10.0f} {gain/26:>12.1f} {'✓值得' if net>0 else '✗不值得':>8}")
