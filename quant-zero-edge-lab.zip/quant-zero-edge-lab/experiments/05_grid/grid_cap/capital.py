"""资金门槛与杠杆代价 —— 针对"没有杠杆，现货买不起"
Q1 现货网格最少多少钱？        -> C_min = N * 最小下单额
Q2 网格是比例收益，小资金能否同样比例赚钱？ -> 收益与C无关，绝对额=C*收益率
Q3 杠杆提高名义敞口的代价      -> 均值为正 vs 中位数归零 的分歧
Q4 资金受限怎么配参数          -> 降N/选低价币
"""
import numpy as np, pandas as pd, sys
sys.path.insert(0,'/data/workspace/grid')
from core import grid_sim, load, ALL

# ---------- Q2 真实收益率(比例)，并年化 ----------
def ret_of(g,N,nm='all',cost_bp=2,init_pos=0):
    out={}
    for s in ALL:
        d=load(s); o,h,l,c=d['open'].values,d['high'].values,d['low'].values,d['close'].values
        r=grid_sim(o,h,l,c,g=g,N=N,cost_bp=cost_bp,order='down',cap=10000.0,init_pos=init_pos)
        yrs=len(c)/(365*24)
        tot=r['nav']/r['cap']-1.0
        out[s]=(tot,(1+tot)**(1/yrs)-1 if tot>-1 else -1.0,yrs,r['maxdd'])
    return out

print("="*78)
print("Q2 网格是【比例收益】—— 收益与你投多少钱无关，只与收益率有关")
print("="*78)
cfg=[(0.02,20),(0.03,20),(0.02,10),(0.05,10),(0.02,5)]
tab=[]
for g,N in cfg:
    o=ret_of(g,N)
    tots=np.array([v[0] for v in o.values()]); anns=np.array([v[1] for v in o.values()])
    yrs=np.mean([v[2] for v in o.values()]); dd=np.mean([v[3] for v in o.values()])
    tab.append({'g':f"{g*100:.0f}%",'N':N,'样本年数':round(yrs,1),
                '全样本中位收益':f"{np.median(tots)*100:.0f}%",
                '年化中位':f"{np.median(anns)*100:.0f}%",
                '为正比例':f"{(tots>0).mean()*100:.0f}%",'平均最大回撤':f"{dd*100:.0f}%"})
df2=pd.DataFrame(tab); print(df2.to_string(index=False))
df2.to_csv('/data/workspace/grid_cap/Q2_proportional.csv',index=False)

# ---------- 各本金档位的绝对年化收益 ----------
print("\n"+"="*78)
print("Q2b 各本金档位的【绝对】年化收益（g=2%,N=20，年化中位收益率代入）")
print("="*78)
o=ret_of(0.02,20); ann_med=np.median([v[1] for v in o.values()])
rows=[]
for C in [100,200,500,1000,2000,5000,10000,50000]:
    rows.append({'本金C(USDT)':C,'年化收益率':f"{ann_med*100:.0f}%",
                 '年化绝对收益':round(C*ann_med,1),
                 '每格金额m':round(C/20,1),
                 '是否满足最小下单额(5U)':'✓' if C/20>=5 else '✗ 需降N'})
df2b=pd.DataFrame(rows); print(df2b.to_string(index=False))
df2b.to_csv('/data/workspace/grid_cap/Q2b_absolute.csv',index=False)

# ---------- Q3 杠杆：均值为正 vs 中位数归零 ----------
print("\n"+"="*78)
print("Q3 杠杆的真实代价：均值骗人，中位数才是你会经历的")
print("="*78)
lev=pd.read_csv('/data/workspace/grid_opt/C_leverage.csv')
print("原始(g=2%,N=20)："); print(lev.to_string(index=False))
rows=[]
for _,r in lev.iterrows():
    L=r['lev']; p=r['liq_rate']; mean=r['ret_mean']; med=r['ret_med']
    # 存活者收益 = (均值 + p) / (1-p)  ，因爆仓贡献 -1
    surv=(mean+p)/(1-p) if p<1 else np.nan
    rows.append({'杠杆':f"{L}x",'名义敞口':f"{L*100:.0f}%本金倍数" if L>1 else "1倍(现货)",
                 '爆仓率':f"{p*100:.1f}%",'均值(含爆仓)':round(mean,2),
                 '中位数':f"{med*100:.0f}%",'存活者收益均值':round(surv,1) if surv==surv else '—',
                 '你会经历的':'✓活着赚' if med>0 else '✗爆仓归零'})
df3=pd.DataFrame(rows); print("\n分解后："); print(df3.to_string(index=False))
df3.to_csv('/data/workspace/grid_cap/Q3_leverage.csv',index=False)
