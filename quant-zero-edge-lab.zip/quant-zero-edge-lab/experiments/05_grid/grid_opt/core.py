import numpy as np, pandas as pd, warnings
warnings.filterwarnings('ignore')
SYMS=['DOGE','ETH','CRV','DASH','DOT','FIL','HBAR','TRX','UNI','XLM','XMR','XRP','ZEC']
def load(sym):
    df=pd.read_csv(f'/data/inputs/{sym}USDT_1h.csv')
    df=df[['timestamp','open','high','low','close','quoteVolume']].dropna()
    df=df[(df[['open','high','low','close']]>0).all(axis=1)]
    return df.reset_index(drop=True)

def grid_sim(o,h,l,c,g,N,capital,fee_bp,init_inv_frac,
             allow_short=False,lev=1.0,maint_pct=0.05,
             exit_on_break=False):
    """init_inv_frac: 0=做多(全现金抄底) .5=中性(半仓) 1=逃顶(全仓卖出网格)"""
    P0=o[0]
    levels=P0*(1.0+g)**(np.arange(N+1)-N/2.0)
    m=capital/float(N); fee=fee_bp/1e4
    prev=np.concatenate([[o[0]],c[:-1]])
    a=np.searchsorted(levels,l,'left');    b=np.searchsorted(levels,prev,'left')
    d=np.searchsorted(levels,prev,'right');e=np.searchsorted(levels,h,'right')
    inv=init_inv_frac*capital/P0; cash=capital*(1.0-init_inv_frac)
    avg=P0 if inv>0 else 0.0
    realized=0.0; fees_paid=0.0; nfill=0
    peak=capital; maxdd=0.0; exited=False
    top=levels[-1]; bot=levels[0]
    for t in range(len(c)):
        dn=levels[a[t]:b[t]]                 # crossed down (ascending)
        up=levels[d[t]:e[t]]                 # crossed up (ascending)
        for L in dn[::-1]:                   # price falling: high level first
            u=m/L; cost=m; f=cost*fee
            if cash>=cost+f or allow_short:
                cash-=(cost+f); fees_paid+=f
                if inv+u>0: avg=(avg*inv+cost)/(inv+u) if inv>0 else cost
                inv+=u; nfill+=1
        for L in up:                         # price rising: low level first
            u=m/L; proc=m; f=proc*fee
            if inv>=u-1e-12 or allow_short:
                fees_paid+=f
                realized += (proc-avg*u) if inv>=u-1e-12 else (proc-c[t]*u)
                cash+=(proc-f); inv-=u; nfill+=1
        eq=cash+inv*c[t]
        if eq>peak: peak=eq
        dd=(peak-eq)/peak if peak>0 else 0.0
        if dd>maxdd: maxdd=dd
        if eq<=0: return dict(final=0.0,blowup=True,maxdd=1.0,nfill=nfill,fees=fees_paid,exited=False)
        if allow_short and lev>1.0:
            notional=abs(inv)*c[t]; margin=notional/lev
            if margin>0 and eq<=maint_pct*margin:
                return dict(final=0.0,blowup=True,maxdd=1.0,nfill=nfill,fees=fees_paid,exited=False)
        if exit_on_break and (c[t]<bot or c[t]>top):
            exited=True; break
    return dict(final=cash+inv*c[-1],blowup=False,maxdd=maxdd,nfill=nfill,fees=fees_paid,exited=exited)

def bhret(o,c,capital): return capital*c[-1]/o[0]
