import numpy as np, pandas as pd, sys, warnings
warnings.filterwarnings('ignore'); sys.path.insert(0,'/data/workspace/grid_opt')
from core import load,SYMS
DATA={s:load(s) for s in SYMS}
def P(*a): print(' '.join(str(x) for x in a))

def grid_seg(o,h,l,c,g,N,cap,fee_bp,init_frac,exit_break):
    P0=o[0]; L=P0*(1+g)**(np.arange(N+1)-N/2.0); m=cap/N; fee=fee_bp/1e4
    prev=np.concatenate([[o[0]],c[:-1]])
    a=np.searchsorted(L,l,'left'); b=np.searchsorted(L,prev,'left')
    d=np.searchsorted(L,prev,'right'); e=np.searchsorted(L,h,'right')
    inv=init_frac*cap/P0; cash=cap*(1-init_frac); avg=P0 if inv>0 else 0.
    bot,top=L[0],L[-1]; brk=None
    for t in range(len(c)):
        for Lv in L[a[t]:b[t]][::-1]:
            u=m/Lv
            if cash>=m*(1+fee): cash-=m*(1+fee); inv+=u; avg=(avg*(inv-u)+m)/inv if inv>0 else m
        for Lv in L[d[t]:e[t]]:
            u=m/Lv
            if inv>=u-1e-12: cash+=m*(1-fee); inv-=u
        if exit_break and (c[t]<bot or c[t]>top): brk=t; break
    end = brk if brk is not None else len(c)-1
    return cash+inv*c[end], (brk is not None), end

def grid_recenter(o,h,l,c,g,N,cap,fee_bp,init_frac=0.5):
    """无限网格: 破网后平仓并以现价为中心重启"""
    eq=cap; i=0; n=0
    while i < len(c)-10 and n<200:
        seg=slice(i,len(c))
        val,brk,end=grid_seg(o[seg],h[seg],l[seg],c[seg],g,N,eq,fee_bp,init_frac,True)
        eq=val; n+=1
        if end<=0: break
        i=i+end+1
    return eq

# ---- H. RE-CENTER vs STOP vs HOLD ----
P("="*74); P("H. 破网后: 重启(移仓) vs 停止 vs 不设防 (现货, 全样本中位收益)")
rows=[]
for g,N in [(0.01,20),(0.02,20),(0.03,20),(0.05,20),(0.02,40)]:
    rc=[];st=[];no=[];dd=[]
    for s,df in DATA.items():
        o=df['open'].values;h=df['high'].values;l=df['low'].values;c=df['close'].values
        rc.append(grid_recenter(o,h,l,c,g,N,10000.,2.0)/1e4-1)
        v,_,_=grid_seg(o,h,l,c,g,N,10000.,2.0,0.5,True);  st.append(v/1e4-1)
        v2,_,_=grid_seg(o,h,l,c,g,N,10000.,2.0,0.5,False); no.append(v2/1e4-1)
    rows.append(dict(g=g,N=N,重启_med=np.median(rc),停止_med=np.median(st),
                     不设防_med=np.median(no),重启_pos=np.mean(np.array(rc)>0)))
RH=pd.DataFrame(rows); P(RH.round(3).to_string(index=False)); RH.to_csv('H_recenter.csv',index=False)

# ---- I. CAPITAL SIZING: worst-case loss fraction ----
P("\n"+"="*74); P("I. 单店最坏亏损比例 → 仓位公式 (现货无杠杆)")
rows=[]
for g,N in [(0.02,20),(0.03,20),(0.05,20),(0.02,40)]:
    for exb in [True,False]:
        rets=[]
        for s,df in DATA.items():
            o=df['open'].values;h=df['high'].values;l=df['low'].values;c=df['close'].values
            v,_,_=grid_seg(o,h,l,c,g,N,10000.,2.0,0.5,exb); rets.append(v/1e4-1)
        rets=np.array(rets)
        rows.append(dict(g=g,N=N,exit=exb,worst_loss=abs(np.min(rets)),
                         p05_loss=abs(np.percentile(rets,5)),median=np.median(rets),
                         loss_rate=np.mean(rets<0)))
RI=pd.DataFrame(rows); P(RI.round(3).to_string(index=False)); RI.to_csv('I_size.csv',index=False)

# ---- J. HARVEST (不复利+盈余公积) ----
P("\n"+"="*74); P("J. 收割制: 每周结算提取超额, 亏80%关店 (重启网格, g=2%,N=20)")
def harvest(o,h,l,c,g,N,C0,fee_bp,period=168,bust=0.2,init_frac=0.5):
    eq=C0; taken=0.; i=0; dead=False
    while i<len(c)-10:
        j=min(i+period,len(c))
        seg=slice(i,j)
        v,brk,end=grid_seg(o[seg],h[seg],l[seg],c[seg],g,N,eq,fee_bp,init_frac,False)
        eq=v
        if eq>C0: taken+=eq-C0; eq=C0
        if eq<=bust*C0: dead=True; break
        i=j
    return taken,eq,dead
rows=[]
for g,N in [(0.02,20),(0.03,20),(0.05,20),(0.02,40)]:
    ts=[];ps=[];ds=[]
    for s,df in DATA.items():
        o=df['open'].values;h=df['high'].values;l=df['low'].values;c=df['close'].values
        t,e,d=harvest(o,h,l,c,g,N,10000.,2.0)
        ts.append(t); ps.append(t>=10000); ds.append(d)
    rows.append(dict(g=g,N=N,提取中位=np.median(ts),P赚回本金=np.mean(ps),关店率=np.mean(ds)))
RJ=pd.DataFrame(rows); P(RJ.round(2).to_string(index=False)); RJ.to_csv('J_harvest.csv',index=False)
