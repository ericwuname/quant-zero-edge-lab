import numpy as np, pandas as pd, sys, warnings
warnings.filterwarnings('ignore'); sys.path.insert(0,'/data/workspace/grid_opt')
from core import load,SYMS
from part5 import grid_recenter
DATA={s:load(s) for s in SYMS}
def P(*a): print(' '.join(str(x) for x in a))
P("="*78); P("K. 重启网格 vs 买入持有 (逐品种, g=2%, N=20, 现货)")
rows=[]
for s,df in DATA.items():
    o=df['open'].values;h=df['high'].values;l=df['low'].values;c=df['close'].values
    g=grid_recenter(o,h,l,c,0.02,20,10000.,2.0)/1e4-1
    b=c[-1]/o[0]-1
    rows.append(dict(sym=s,grid=round(g,2),BH=round(b,2),diff=round(g-b,2),win='Y' if g>b else 'N'))
RK=pd.DataFrame(rows); P(RK.to_string(index=False))
P(f"\n网格胜出品种数: {(RK.win=='Y').sum()}/13   网格中位: {RK.grid.median():.2f}  BH中位: {RK.BH.median():.2f}")
P(f"网格最差: {RK.grid.min():.2f} ({RK.loc[RK.grid.idxmin(),'sym']})   BH最差: {RK.BH.min():.2f}")

# worst case for recenter across configs
P("\n"+"="*78); P("L. 重启网格 最坏情况 (逐品种最差收益)")
for g_,N in [(0.02,20),(0.03,20),(0.05,20),(0.02,40)]:
    r=[grid_recenter(df['open'].values,df['high'].values,df['low'].values,df['close'].values,g_,N,10000.,2.0)/1e4-1 for df in DATA.values()]
    r=np.array(r)
    P(f"g={g_} N={N}: 中位={np.median(r):.2f} 最差={r.min():.2f} 正比例={np.mean(r>0):.2f} 亏损率(<-50%)={np.mean(r<-0.5):.2f}")
