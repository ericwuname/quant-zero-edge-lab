import numpy as np, pandas as pd, sys, warnings
warnings.filterwarnings('ignore'); sys.path.insert(0,'/data/workspace/grid_opt')
from core import load,SYMS
DATA={s:load(s) for s in SYMS}
def P(*a): print(' '.join(str(x) for x in a))

def grid(o,h,l,c,g,N,capital,fee_bp,init_frac=0.5,exit_break=False,lev=0.0,maint=0.05):
    """spot grid; lev>0 => futures margin model w/ liquidation. exit values at EXIT price."""
    P0=o[0]; L=P0*(1+g)**(np.arange(N+1)-N/2.0); m=capital/N; fee=fee_bp/1e4
    prev=np.concatenate([[o[0]],c[:-1]])
    a=np.searchsorted(L,l,'left'); b=np.searchsorted(L,prev,'left')
    d=np.searchsorted(L,prev,'right'); e=np.searchsorted(L,h,'right')
    inv=init_frac*capital/P0; cash=capital*(1-init_frac); avg=P0 if inv>0 else 0.
    fees=0.; peak=capital; maxdd=0.; liq=False; fin=None
    bot,top=L[0],L[-1]
    for t in range(len(c)):
        for Lv in L[a[t]:b[t]][::-1]:
            u=m/Lv; fees+=m*fee
            if lev==0:
                if cash>=m: cash-=m; inv+=u; avg=(avg*(inv-u)+m)/inv if inv>0 else m
            else: inv+=u; avg=(avg*(inv-u)+Lv*u)/inv if inv>0 else Lv
        for Lv in L[d[t]:e[t]]:
            u=m/Lv; fees+=m*fee
            if inv>=u-1e-12:
                if lev==0: cash+=m
                inv-=u
        eq=(cash+inv*c[t]) if lev==0 else (capital+ (inv*(c[t]-avg) if inv!=0 else 0) - fees)
        peak=max(peak,eq); maxdd=max(maxdd,(peak-eq)/peak if peak>0 else 0)
        if lev>0:
            notional=abs(inv)*c[t]; margin=notional/lev
            if margin>0 and eq<=maint*margin: liq=True; break
        if eq<=0: liq=True; break
        if exit_break and (c[t]<bot or c[t]>top):
            fin=(cash+inv*c[t]) if lev==0 else eq; break
    if liq: return dict(final=0.0,maxdd=1.0,liq=True)
    if fin is None: fin=(cash+inv*c[-1]) if lev==0 else (capital+(inv*(c[-1]-avg) if inv!=0 else 0)-fees)
    return dict(final=fin,maxdd=maxdd,liq=False,fees=fees)

# ---- E2. EXIT CONTROL (fixed) ----
P("="*72); P("E2. 破网离场 (修正计价) → 收益 vs 最大回撤")
rows=[]
for g,N in [(0.01,20),(0.02,20),(0.03,20),(0.05,20),(0.02,40),(0.05,40)]:
    rng=((1+g)**(N/2.)-1)*100
    for exb in [False,True]:
        rets=[];dds=[]
        for s,df in DATA.items():
            o=df['open'].values;h=df['high'].values;l=df['low'].values;c=df['close'].values
            r=grid(o,h,l,c,g,N,10000.,2.0,0.5,exit_break=exb)
            rets.append(r['final']/1e4-1); dds.append(r['maxdd'])
        rows.append(dict(g=g,N=N,range_pct=round(rng,0),exit=exb,ret_med=np.median(rets),
                         ret_mean=np.mean(rets),maxdd=np.mean(dds),worstdd=np.max(dds),
                         pos=np.mean(np.array(rets)>0)))
RE=pd.DataFrame(rows); P(RE.round(3).to_string(index=False)); RE.to_csv('E2_exit.csv',index=False)

# ---- F2. synthetic crash/moon (fixed) ----
P("\n-- 合成极端路径 (震荡→单边) 修正后 --")
def synth(kind,n1=2000,n2=3000,seed=0):
    rng=np.random.default_rng(seed); r1=np.cumsum(rng.normal(0,0.01,n1)); p=100*np.exp(r1)
    p2={'crash80':np.linspace(p[-1],p[-1]*0.2,n2),'crash95':np.linspace(p[-1],p[-1]*0.05,n2),
        'moon':np.linspace(p[-1],p[-1]*4.0,n2)}[kind]
    p=np.concatenate([p,p2]); o=np.concatenate([[p[0]],p[:-1]]); c=p
    h=np.maximum(o,c)*(1+0.002); l=np.minimum(o,c)*(1-0.002); return o,h,l,c
rows=[]
for kind in ['crash80','crash95','moon']:
    o,h,l,c=synth(kind)
    for g,N in [(0.02,20),(0.05,20)]:
        for exb in [False,True]:
            r=grid(o,h,l,c,g,N,10000.,2.0,0.5,exit_break=exb)
            rows.append(dict(scene=kind,g=g,N=N,exit=exb,ret=round(r['final']/1e4-1,3),maxdd=round(r['maxdd'],3)))
P(pd.DataFrame(rows).to_string(index=False))

# ---- G2. FUTURES direction (fixed accounting) ----
P("\n"+"="*72); P("G2. 合约网格: 做多 vs 做空 (杠杆3x) → 爆仓率 x 市场环境")
def fut(o,h,l,c,g,N,capital,fee_bp,lev,maint=0.05,side='long'):
    P0=o[0]; L=P0*(1+g)**(np.arange(N+1)-N/2.0); m=capital/N; fee=fee_bp/1e4
    prev=np.concatenate([[o[0]],c[:-1]])
    a=np.searchsorted(L,l,'left'); b=np.searchsorted(L,prev,'left')
    d=np.searchsorted(L,prev,'right'); e=np.searchsorted(L,h,'right')
    inv=0.; avg=0.; realized=0.; fees=0.; liq=False
    for t in range(len(c)):
        if side=='long':
            for Lv in L[a[t]:b[t]][::-1]:
                u=m/Lv; fees+=m*fee; avg=(avg*inv+Lv*u)/(inv+u); inv+=u
            for Lv in L[d[t]:e[t]]:
                u=m/Lv; fees+=m*fee
                if inv>=u-1e-12: realized+=u*(Lv-avg); inv-=u
        else:
            for Lv in L[d[t]:e[t]]:
                u=m/Lv; fees+=m*fee; avg=(avg*abs(inv)+Lv*u)/(abs(inv)+u); inv-=u
            for Lv in L[a[t]:b[t]][::-1]:
                u=m/Lv; fees+=m*fee
                if abs(inv)>=u-1e-12: realized+=u*(avg-Lv); inv+=u
        unreal=inv*(c[t]-avg)
        eq=capital+realized+unreal-fees
        notional=abs(inv)*c[t]; margin=notional/lev
        if margin>0 and eq<=maint*margin: liq=True; break
        if eq<=0: liq=True; break
    return 0.0 if liq else eq
rows=[]
for side in ['long','short']:
    for reg,filt in [('上涨',lambda d:d>0.2),('震荡',lambda d:abs(d)<=0.2),('下跌',lambda d:d<-0.2)]:
        liq=[];rets=[]
        for s,df in DATA.items():
            o=df['open'].values;h=df['high'].values;l=df['low'].values;c=df['close'].values
            for i in range(0,len(c)-3000,3000):
                sl=slice(i,i+3000); dd=np.log(c[sl][-1]/o[sl][0])
                if not filt(dd): continue
                r=fut(o[sl],h[sl],l[sl],c[sl],0.02,20,10000.,2.0,3.0,side=side)
                liq.append(r<=0); rets.append(r/1e4-1)
        rows.append(dict(side=side,reg=reg,n=len(liq),liq_rate=np.mean(liq),ret_med=np.median(rets)))
RG=pd.DataFrame(rows); P(RG.round(3).to_string(index=False)); RG.to_csv('G2_dir.csv',index=False)
