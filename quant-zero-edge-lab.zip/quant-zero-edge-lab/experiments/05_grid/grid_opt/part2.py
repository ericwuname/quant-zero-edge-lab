import numpy as np, pandas as pd, sys, warnings
warnings.filterwarnings('ignore'); sys.path.insert(0,'/data/workspace/grid_opt')
from core import *
DATA={s:load(s) for s in SYMS}
def P(*a): print(' '.join(str(x) for x in a))

# add leverage-liquidation for LONG grid
def grid_lev(o,h,l,c,g,N,capital,fee_bp,init_frac,lev=1.0,maint=0.05,exit_break=False):
    P0=o[0]; levels=P0*(1+g)**(np.arange(N+1)-N/2.0); m=capital/N; fee=fee_bp/1e4
    prev=np.concatenate([[o[0]],c[:-1]])
    a=np.searchsorted(levels,l,'left'); b=np.searchsorted(levels,prev,'left')
    d=np.searchsorted(levels,prev,'right'); e=np.searchsorted(levels,h,'right')
    inv=init_frac*capital/P0; cash=capital*(1-init_frac); avg=P0 if inv>0 else 0.
    peak=capital; maxdd=0.; liq=False; liq_bar=None; exited=False
    bot,top=levels[0],levels[-1]
    for t in range(len(c)):
        for L in levels[a[t]:b[t]][::-1]:
            u=m/L; f=m*fee
            if cash>=m+f or lev>1:
                cash-=(m+f); inv+=u; avg=(avg*(inv-u)+m)/inv if inv>0 else m
        for L in levels[d[t]:e[t]]:
            u=m/L; f=m*fee
            if inv>=u-1e-12:
                cash+=(m-f); inv-=u
        eq=cash+inv*c[t]
        peak=max(peak,eq); maxdd=max(maxdd,(peak-eq)/peak if peak>0 else 0)
        if lev>1.0:
            notional=inv*c[t]; margin=notional/lev
            if margin>0 and eq<=maint*margin:
                liq=True; liq_bar=t; break
        if exit_break and (c[t]<bot or c[t]>top): exited=True; break
    fin = 0.0 if liq else cash+inv*c[-1]
    return dict(final=fin,liq=liq,maxdd=1.0 if liq else maxdd,exited=exited)

# ---------- C. LEVERAGE = blowup ----------
P("="*72); P("C. 杠杆 → 爆仓 (做多网格抄底, g=2%, N=20, 全样本平均)")
rows=[]
for lev in [1,2,3,5,10]:
    liqs=[];rets=[];dds=[]
    for s,df in DATA.items():
        o=df['open'].values;h=df['high'].values;l=df['low'].values;c=df['close'].values
        r=grid_lev(o,h,l,c,0.02,20,10000.,2.0,0.0,lev=lev)
        liqs.append(r['liq']); rets.append(r['final']/1e4-1); dds.append(r['maxdd'])
    rows.append(dict(lev=lev,liq_rate=np.mean(liqs),ret_med=np.median(rets),
                     ret_mean=np.mean(rets),maxdd=np.mean(dds)))
RC=pd.DataFrame(rows); P(RC.round(3).to_string(index=False))
RC.to_csv('C_leverage.csv',index=False)

# ---------- D. GRID RANGE (N*g) -> return vs maxdd frontier ----------
P("\n"+"="*72); P("D. 网格总区间 (N×g) → 收益 vs 最大回撤 前沿 (中性半仓, 现货无杠杆)")
rows=[]
for g in [0.01,0.02,0.03,0.05]:
    for N in [10,20,30,40,60]:
        rng=(1+g)**(N/2.)-1
        rets=[];dds=[];ex=[]
        for s,df in DATA.items():
            o=df['open'].values;h=df['high'].values;l=df['low'].values;c=df['close'].values
            r=grid_sim(o,h,l,c,g,N,10000.,2.0,0.5,exit_on_break=False)
            rets.append(r['final']/1e4-1); dds.append(r['maxdd'])
        rows.append(dict(g=g,N=N,range_pct=round(rng*100,1),ret_med=np.median(rets),
                         maxdd=np.mean(dds),worstdd=np.max(dds)))
RD=pd.DataFrame(rows); P(RD.round(3).to_string(index=False))
RD.to_csv('D_range.csv',index=False)

# ---------- E. EXIT-ON-BREAK risk control ----------
P("\n"+"="*72); P("E. 破网止损 (价格突破网格边界即离场) → 收益 vs 风险")
rows=[]
for g,N in [(0.02,20),(0.03,20),(0.02,40),(0.05,20)]:
    rng=(1+g)**(N/2.)-1
    for exb in [False,True]:
        rets=[];dds=[]
        for s,df in DATA.items():
            o=df['open'].values;h=df['high'].values;l=df['low'].values;c=df['close'].values
            r=grid_sim(o,h,l,c,g,N,10000.,2.0,0.5,exit_on_break=exb)
            rets.append(r['final']/1e4-1); dds.append(r['maxdd'])
        rows.append(dict(g=g,N=N,range_pct=round(rng*100,1),exit=exb,
                         ret_med=np.median(rets),ret_mean=np.mean(rets),
                         maxdd=np.mean(dds),worstdd=np.max(dds)))
RE=pd.DataFrame(rows); P(RE.round(3).to_string(index=False))
RE.to_csv('E_exit.csv',index=False)
