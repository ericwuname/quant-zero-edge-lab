import numpy as np, pandas as pd, sys, warnings, time
warnings.filterwarnings('ignore'); sys.path.insert(0,'/data/workspace/grid_opt')
from core import *
DATA={s:load(s) for s in SYMS}
out=[]
def P(*a):
    s=' '.join(str(x) for x in a); print(s); out.append(s)

# ---------- A. DIRECTION x REGIME ----------
P("="*70); P("A. 网格方向 x 市场环境 (N=20, g=1~3%, capital=1e4, fee=2bp)")
DIRS={'做多(全现金抄底)':0.0,'中性(半仓双向)':0.5,'逃顶(全仓卖出)':1.0}
rows=[]
WIN=3000; STEP=3000
for s,df in DATA.items():
    o=df['open'].values;h=df['high'].values;l=df['low'].values;c=df['close'].values
    for st in range(0,len(c)-WIN,STEP):
        sl=slice(st,st+WIN); oo,hh,ll,cc=o[sl],h[sl],l[sl],c[sl]
        drift=np.log(cc[-1]/oo[0])
        reg='上涨' if drift>0.2 else ('下跌' if drift<-0.2 else '震荡')
        for dn,fr in DIRS.items():
            for g in [0.01,0.02,0.03]:
                r=grid_sim(oo,hh,ll,cc,g,20,10000.,2.0,fr)
                rows.append(dict(sym=s,reg=reg,dir=dn,g=g,ret=r['final']/1e4-1,
                                 bh=bhret(oo,cc,1e4)/1e4-1,maxdd=r['maxdd'],nfill=r['nfill']))
RA=pd.DataFrame(rows); RA.to_csv('A_dir_regime.csv',index=False)
t=RA.groupby(['reg','dir']).agg(n=('ret','size'),ret_mean=('ret','mean'),ret_med=('ret','median'),
    maxdd=('maxdd','mean'),nfill=('nfill','mean'))
t['win_vs_BH']=RA.assign(w=(RA.ret>RA.bh).astype(float)).groupby(['reg','dir'])['w'].mean()
P(t.round(3).to_string())

# ---------- B. g x N SWEEP (full sample) ----------
P("\n"+"="*70); P("B. 网格间距 g x 格数 N (中性半仓, 全样本, fee=2bp)")
rows=[]
for g in [0.005,0.01,0.02,0.03,0.05,0.08]:
    for N in [5,10,20,40]:
        rets=[];dds=[];nfs=[]
        for s,df in DATA.items():
            o=df['open'].values;h=df['high'].values;l=df['low'].values;c=df['close'].values
            r=grid_sim(o,h,l,c,g,N,10000.,2.0,0.5)
            rets.append(r['final']/1e4-1); dds.append(r['maxdd']); nfs.append(r['nfill'])
        rows.append(dict(g=g,N=N,ret_med=np.median(rets),ret_mean=np.mean(rets),
                         maxdd=np.mean(dds),worstdd=np.max(dds),
                         nfill=np.mean(nfs),pos=np.mean(np.array(rets)>0)))
RB=pd.DataFrame(rows); RB.to_csv('B_gn_sweep.csv',index=False)
P(RB.round(3).to_string(index=False))
