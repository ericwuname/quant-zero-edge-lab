import numpy as np, pandas as pd, sys, warnings
warnings.filterwarnings('ignore'); sys.path.insert(0,'/data/workspace/grid_opt')
from core import *
DATA={s:load(s) for s in SYMS}
def P(*a): print(' '.join(str(x) for x in a))

# ---- F. CRASH / MOON stress: worst real windows + synthetic ----
P("="*72); P("F. 极端单边行情压力测试 (现货无杠杆 vs 加杠杆)")
def worst_windows(df,n=3000):
    c=df['close'].values
    dd=[]; 
    for i in range(0,len(c)-n,500):
        w=c[i:i+n]; peak=np.maximum.accumulate(w); dd.append((np.min((w/peak)-1),i))
    dd.sort(); return [i for _,i in dd[:3]]
rows=[]
for g,N in [(0.01,20),(0.02,20),(0.03,20),(0.05,20),(0.02,40)]:
    for exb in [False,True]:
        los=[];dds=[]
        for s,df in DATA.items():
            o=df['open'].values;h=df['high'].values;l=df['low'].values;c=df['close'].values
            for i in worst_windows(df):
                sl=slice(i,i+3000)
                r=grid_sim(o[sl],h[sl],l[sl],c[sl],g,N,10000.,2.0,0.5,exit_on_break=exb)
                los.append(r['final']/1e4-1); dds.append(r['maxdd'])
        rows.append(dict(g=g,N=N,exit=exb,worst_ret=np.min(los),mean_ret=np.mean(los),
                         mean_dd=np.mean(dds),worst_dd=np.max(dds)))
RF=pd.DataFrame(rows); P(RF.round(3).to_string(index=False)); RF.to_csv('F_crash.csv',index=False)

# synthetic: oscillate then crash to -80% / -95%; and moon +300%
P("\n-- 合成极端路径 (震荡2000bar → 单边) --")
def synth(kind,n1=2000,n2=3000,seed=0):
    rng=np.random.default_rng(seed)
    r1=np.cumsum(rng.normal(0,0.01,n1)); p=100*np.exp(r1)
    if kind=='crash80': p2=np.linspace(p[-1],p[-1]*0.2,n2)
    elif kind=='crash95': p2=np.linspace(p[-1],p[-1]*0.05,n2)
    elif kind=='moon': p2=np.linspace(p[-1],p[-1]*4.0,n2)
    p=np.concatenate([p,p2])
    o=np.concatenate([[p[0]],p[:-1]]); c=p
    h=np.maximum(o,c)*(1+0.002); l=np.minimum(o,c)*(1-0.002)
    return o,h,l,c
rows=[]
for kind in ['crash80','crash95','moon']:
    o,h,l,c=synth(kind)
    for g,N in [(0.02,20),(0.05,20)]:
        for exb in [False,True]:
            r=grid_sim(o,h,l,c,g,N,10000.,2.0,0.5,exit_on_break=exb)
            rows.append(dict(scene=kind,g=g,N=N,exit=exb,ret=round(r['final']/1e4-1,3),
                             maxdd=round(r['maxdd'],3)))
P(pd.DataFrame(rows).to_string(index=False))

# ---- G. FUTURES grid DIRECTION: long vs short vs neutral, with leverage ----
P("\n"+"="*72); P("G. 合约网格方向 x 市场环境 (杠杆3x) → 爆仓率")
def fut_grid(o,h,l,c,g,N,capital,fee_bp,lev,maint=0.05,side='long'):
    P0=o[0]; levels=P0*(1+g)**(np.arange(N+1)-N/2.0); m=capital/N; fee=fee_bp/1e4
    prev=np.concatenate([[o[0]],c[:-1]])
    a=np.searchsorted(levels,l,'left'); b=np.searchsorted(levels,prev,'left')
    d=np.searchsorted(levels,prev,'right'); e=np.searchsorted(levels,h,'right')
    inv=0.0; cash=capital; liq=False
    for t in range(len(c)):
        for L in levels[a[t]:b[t]][::-1]:
            if side=='long': u=m/L; cash-=m*fee; inv+=u; cash-=m*(1/lev)*0  # margin
            else: u=m/L; inv-=u; cash+=m*(1/lev)*0
        for L in levels[d[t]:e[t]]:
            if side=='long': u=m/L; inv-=u; cash+=m
            else: u=m/L; inv+=u; cash-=m
        eq=cash+(inv*c[t] if side=='long' else -inv*c[t])
        notional=abs(inv)*c[t]; margin=notional/lev
        if margin>0 and eq<=maint*margin: liq=True; break
        if eq<=0: liq=True; break
    return 0.0 if liq else (cash+(inv*c[-1] if side=='long' else -inv*c[-1]))
rows=[]
for side in ['long','short']:
    for reg,filt in [('上涨',lambda d:d>0.2),('震荡',lambda d:abs(d)<=0.2),('下跌',lambda d:d<-0.2)]:
        liq=[];rets=[]
        for s,df in DATA.items():
            o=df['open'].values;h=df['high'].values;l=df['low'].values;c=df['close'].values
            for i in range(0,len(c)-3000,3000):
                sl=slice(i,i+3000); d=np.log(c[sl][-1]/o[sl][0])
                if not filt(d): continue
                r=fut_grid(o[sl],h[sl],l[sl],c[sl],0.02,20,10000.,2.0,3.0,side=side)
                liq.append(r<=0); rets.append(r/1e4-1)
        rows.append(dict(side=side,reg=reg,n=len(liq),liq_rate=np.mean(liq),ret_med=np.median(rets)))
RG=pd.DataFrame(rows); P(RG.round(3).to_string(index=False)); RG.to_csv('G_dir.csv',index=False)
