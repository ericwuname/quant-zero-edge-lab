"""网格最低价/最高价设定方法对比（加速版：13品种 × 最近3年）"""
import numpy as np, pandas as pd, warnings, time
warnings.filterwarnings('ignore')

SYMS = ['DOGE','ETH','CRV','DASH','DOT','FIL','HBAR','TRX','UNI','XLM','XMR','XRP','ZEC']
WARM = 720
YEARS = 3
NB = YEARS * 8760

def load(sym):
    df = pd.read_csv(f'/data/inputs/{sym}USDT_1h.csv')
    df = df[['timestamp','open','high','low','close']].dropna()
    df = df[(df[['open','high','low','close']] > 0).all(axis=1)]
    df['atr14'] = (pd.concat([df['high'].diff(),
                              (df['high'] - df['close'].shift()),
                              (df['close'].shift() - df['low'])], axis=1)
                   .max(axis=1)).rolling(14).mean()
    df['ma720']  = df['close'].rolling(WARM).mean()
    df['std720'] = df['close'].rolling(WARM).std()
    df['lo720']  = df['low'].rolling(WARM).min()
    df['hi720']  = df['high'].rolling(WARM).max()
    return df.iloc[WARM:].reset_index(drop=True).iloc[-NB:].reset_index(drop=True)

t0_ = time.time()
DATA = {s: load(s) for s in SYMS}
print(f'loaded {len(DATA)} syms, {NB} bars each, {time.time()-t0_:.0f}s', flush=True)

def grid_seg(o, h, l, c, levels, capital, fee, init_frac):
    N = len(levels) - 1
    m = capital / float(N)
    P0 = o[0]
    prev = np.concatenate([[o[0]], c[:-1]])
    a = np.searchsorted(levels, l, 'left')
    b = np.searchsorted(levels, prev, 'left')
    d_ = np.searchsorted(levels, prev, 'right')
    e = np.searchsorted(levels, h, 'right')
    inv = init_frac * capital / P0
    cash = capital * (1.0 - init_frac)
    avg = P0 if inv > 0 else 0.0
    realized = 0.0; nfill = 0
    peak = capital; maxdd = 0.0
    for t in range(len(c)):
        if a[t] < b[t]:
            for L_ in levels[a[t]:b[t]][::-1]:
                u = m / L_; cost = m; f = cost * fee
                if cash >= cost + f:
                    cash -= (cost + f)
                    if inv + u > 0:
                        avg = (avg * inv + cost) / (inv + u) if inv > 0 else cost
                    inv += u; nfill += 1
        if d_[t] < e[t]:
            for L_ in levels[d_[t]:e[t]]:
                u = m / L_; proc = m; f = proc * fee
                if inv >= u - 1e-12:
                    realized += (proc - avg * u)
                    cash += (proc - f); inv -= u; nfill += 1
        eq = cash + inv * c[t]
        if eq > peak: peak = eq
        ddx = (peak - eq) / peak if peak > 0 else 0.0
        if ddx > maxdd: maxdd = ddx
        if c[t] < levels[0] or c[t] > levels[-1]:
            return cash + inv * c[t], realized, nfill, maxdd, t
    return cash + inv * c[-1], realized, nfill, maxdd, None

def sim(df, method, N=20, capital=1000.0, fee_bp=2, init_frac=0.5, update_every=None):
    o = df['open'].values; h = df['high'].values
    l = df['low'].values;  c = df['close'].values
    fee = fee_bp / 1e4
    eq = capital; t0 = 0
    n_rs = 0; n_up = 0; nf = 0; maxdd_all = 0.0; widths = []
    n = len(c); guard = 0
    while t0 < n and guard < 5000:
        guard += 1
        P0 = o[t0]
        L, H = method(df, t0)
        wr = H / L
        if P0 < L: L = P0; H = P0 * wr
        if P0 > H: H = P0; L = P0 / wr
        if not np.isfinite(L) or not np.isfinite(H) or L <= 0 or H <= L:
            L, H = P0 * 0.8, P0 * 1.25
        widths.append((H / L - 1) * 100)
        levels = np.geomspace(L, H, N + 1)
        end = n if update_every is None else min(n, t0 + update_every)
        eq_s, rz, f, mdd, brk = grid_seg(o[t0:end], h[t0:end], l[t0:end], c[t0:end],
                                         levels, eq, fee, init_frac)
        nf += f; maxdd_all = max(maxdd_all, mdd); eq = eq_s
        if brk is not None:
            n_rs += 1; t0 = t0 + brk + 1
        else:
            if update_every and end < n: n_up += 1
            t0 = end
        if eq <= 0:
            return dict(ann=-1.0, ret=-1.0, maxdd=1.0, n_restart=n_rs, nfill=nf,
                        width=np.mean(widths), blow=True)
    yrs = n / 8760.0
    return dict(ann=(max(eq, 1e-9) / capital) ** (1.0 / yrs) - 1.0,
                ret=eq / capital - 1.0, maxdd=maxdd_all, n_restart=n_rs,
                n_upd=n_up, nfill=nf, width=np.mean(widths), blow=False)

def m_fixed(k, center='px'):
    def f(df, t):
        P0 = df['open'].values[t]
        ctr = df['ma720'].values[t] if center == 'ma' else P0
        if not np.isfinite(ctr): ctr = P0
        return ctr * (1 - k), ctr * (1 + k)
    return f

def m_atr(k, center='px'):
    def f(df, t):
        P0 = df['open'].values[t]
        ctr = df['ma720'].values[t] if center == 'ma' else P0
        if not np.isfinite(ctr): ctr = P0
        a = df['atr14'].values[t]
        w = k * a / ctr if np.isfinite(a) else 0.2
        return ctr * (1 - w), ctr * (1 + w)
    return f

def m_boll(k, center='px'):
    def f(df, t):
        P0 = df['open'].values[t]
        ctr = df['ma720'].values[t] if center == 'ma' else P0
        s = df['std720'].values[t]
        if not np.isfinite(ctr): ctr = P0
        w = k * s / ctr if np.isfinite(s) else 0.2
        return ctr * (1 - w), ctr * (1 + w)
    return f

def m_minmax():
    def f(df, t):
        P0 = df['open'].values[t]
        lo = df['lo720'].values[t]; hi = df['hi720'].values[t]
        if not np.isfinite(lo) or not np.isfinite(hi) or hi <= lo:
            return P0 * 0.8, P0 * 1.25
        return lo, hi
    return f

CONFIGS = [('fixed±10%', m_fixed(0.10)), ('fixed±20%', m_fixed(0.20)),
           ('fixed±30%', m_fixed(0.30)), ('fixed±40%', m_fixed(0.40)),
           ('ATR6', m_atr(6)), ('BOLL2', m_boll(2.0)),
           ('minmax720', m_minmax()),
           ('fixed±30%_MA中心', m_fixed(0.30, 'ma')),
           ('BOLL2_MA中心', m_boll(2.0, 'ma'))]

print('\n=== 区间设定方法对比 (N=20, 现货1x, 半仓, maker2bp, 破网重启移仓, 3年) ===', flush=True)
rows = []
for name, fn in CONFIGS:
    ts = time.time()
    res = [sim(DATA[s], fn, N=20) for s in SYMS]
    ann = np.median([r['ann'] for r in res])
    ret = np.median([r['ret'] for r in res])
    dd  = np.median([r['maxdd'] for r in res])
    nrs = np.median([r['n_restart'] for r in res])
    nf  = np.median([r['nfill'] for r in res])
    wd  = np.median([r['width'] for r in res])
    pos = np.mean([r['ann'] > 0 for r in res])
    g   = ((1 + wd / 200) / (1 - wd / 200)) ** (1 / 20) - 1 if wd < 199 else np.nan
    rows.append(dict(method=name, width_pct=wd, g_pct=g * 100, ann=ann, ret=ret,
                     maxdd=dd, calmar=(ann / dd if dd > 0 else np.nan),
                     restarts=nrs, fills=nf, pos_rate=pos))
    print(f'{name:16s} 宽{wd:6.1f}% g={g*100:5.2f}% 年化{ann:7.3f} 收益{ret:7.2f} '
          f'回撤{dd:.3f} Calmar{(ann/dd if dd>0 else 0):6.2f} 重启{nrs:6.0f} '
          f'成交{nf:6.0f} 为正{pos:.0%}  [{time.time()-ts:.0f}s]', flush=True)
pd.DataFrame(rows).to_csv('/data/workspace/range_methods.csv', index=False)

print('\n=== 更新频率 (fixed±30%, N=20) ===', flush=True)
rows2 = []
for ue in [None, 168]:
    ts = time.time()
    res = [sim(DATA[s], m_fixed(0.30), N=20, update_every=ue) for s in SYMS]
    print(f'{("破网才动" if ue is None else f"每{ue}根(周)"):10s} 年化{np.median([r["ann"] for r in res]):7.3f} '
          f'回撤{np.median([r["maxdd"] for r in res]):.3f} 重启{np.median([r["n_restart"] for r in res]):5.0f} '
          f'定期{np.median([r["n_upd"] for r in res]):5.0f} [{time.time()-ts:.0f}s]', flush=True)
    rows2.append(dict(update=('break' if ue is None else ue),
                      ann=np.median([r['ann'] for r in res]),
                      maxdd=np.median([r['maxdd'] for r in res]),
                      restarts=np.median([r['n_restart'] for r in res])))
pd.DataFrame(rows2).to_csv('/data/workspace/range_update.csv', index=False)

print('\n=== 宽度 × 格数 (fixed, 现价中心) ===', flush=True)
rows3 = []
for k in [0.10, 0.20, 0.30, 0.40]:
    for N in [10, 20]:
        ts = time.time()
        res = [sim(DATA[s], m_fixed(k), N=N) for s in SYMS]
        ann = np.median([r['ann'] for r in res]); dd = np.median([r['maxdd'] for r in res])
        g = (((1 + k) / (1 - k)) ** (1.0 / N) - 1) * 100
        print(f'±{int(k*100):2d}% N={N:2d} g={g:5.2f}% 年化{ann:7.3f} 回撤{dd:.3f} '
              f'重启{np.median([r["n_restart"] for r in res]):6.0f} '
              f'为正{np.mean([r["ann"]>0 for r in res]):.0%} [{time.time()-ts:.0f}s]', flush=True)
        rows3.append(dict(k=k, N=N, g_pct=g, ann=ann, maxdd=dd,
                          restarts=np.median([r['n_restart'] for r in res]),
                          pos=np.mean([r['ann'] > 0 for r in res])))
pd.DataFrame(rows3).to_csv('/data/workspace/range_grid.csv', index=False)
print('\nDONE', flush=True)
