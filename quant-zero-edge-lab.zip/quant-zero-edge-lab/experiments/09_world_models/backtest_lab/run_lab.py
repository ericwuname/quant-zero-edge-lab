"""
run_lab.py — 平台入口：先过门禁，再出结论。
任何一道门禁失败 → 拒绝输出策略结论。
"""
import numpy as np, pandas as pd, json, os, sys, time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from lab import (load_all, fingerprint, backtest, backtest_bracket, signal_zoo,
                 invariants, leakage_tests, cross_symbol_t, reality_check,
                 block_bootstrap_p, sig_long, sig_none)

OUT = os.path.dirname(os.path.abspath(__file__))
COST = 2.0          # maker 单边 bp
OLD7 = ['CRVUSDT', 'DASHUSDT', 'DOGEUSDT', 'DOTUSDT', 'ETHUSDT', 'FILUSDT', 'HBARUSDT']
NEW6 = ['TRXUSDT', 'UNIUSDT', 'XLMUSDT', 'XMRUSDT', 'XRPUSDT', 'ZECUSDT']

t0 = time.time()
log = []
def P(s):
    print(s, flush=True); log.append(s)

# ---------------- 1. 载入 ----------------
P('[1/6] 载入数据')
dfs = load_all()
P('  品种(%d): %s' % (len(dfs), ', '.join(dfs)))
P('  样本量: ' + ', '.join('%s=%d' % (k, len(v)) for k, v in dfs.items()))
fp = fingerprint(dfs)
P('  数据指纹: %s' % fp)

# ---------------- 2. 门禁1：不变量 ----------------
P('[2/6] 门禁1 — 引擎不变量（与策略无关，必须恒成立）')
gate1 = True
inv_summary = {}
for k, d in dfs.items():
    C = invariants(d['open'].values, cost_bp=COST)
    inv_summary[k] = C
    bad = [c['name'] for c in C if not c['pass']]
    if bad:
        gate1 = False
        P('  ✗ %s 失败: %s' % (k, bad))
names = [c['name'] for c in inv_summary[list(dfs)[0]]]
for i, nm in enumerate(names):
    ok = all(inv_summary[k][i]['pass'] for k in dfs)
    P('  %s %s' % ('✓' if ok else '✗', nm))
P('  门禁1: %s' % ('PASS' if gate1 else 'FAIL'))
if not gate1:
    P('!! 引擎不变量未通过 → 所有策略结论作废')
    open(os.path.join(OUT, 'REPORT.md'), 'w').write('# 平台中止\n\n门禁1未通过，结论作废。\n')
    sys.exit(1)

# ---------------- 3. 门禁2：泄漏检测 ----------------
P('[3/6] 门禁2 — 泄漏探测器（每个信号 × 每个品种）')
zoo = signal_zoo()
leak = {}
gate2 = True
for nm, fn in zoo.items():
    if nm in ('none', 'long'):
        continue
    tot = fail = 0
    detail = {}
    for k, d in dfs.items():
        T = leakage_tests(d, fn(d), cost_bp=COST, fn=fn)
        for t in T:
            tot += 1
            if not t['pass']:
                fail += 1
                detail.setdefault(t['name'], []).append(k)
    leak[nm] = dict(total=tot, fail=fail, detail={a: len(b) for a, b in detail.items()})
    if fail > tot * 0.10:          # 允许 10% 以内的边界噪声
        gate2 = False
        P('  ✗ %s 泄漏报警 %d/%d %s' % (nm, fail, tot, list(detail)))
P('  门禁2: %s（探测器总数 %d，报警 %d）' % (
    'PASS' if gate2 else 'FAIL',
    sum(v['total'] for v in leak.values()), sum(v['fail'] for v in leak.values())))

# ---------------- 4. 策略评估 ----------------
P('[4/6] 策略评估（净收益口径 bp/bar，maker %.0fbp）' % COST)
res = {}          # sym -> sig -> mean net bp/bar
turn = {}         # sym -> sig -> turnover/bar
for k, d in dfs.items():
    o = d['open'].values
    res[k] = {}; turn[k] = {}
    for nm, fn in zoo.items():
        r = backtest(o, fn(d), COST)
        res[k][nm] = r['net'] / len(o) * 1e4
        turn[k][nm] = r['turnover'] / len(o)

sigs = [s for s in zoo if s not in ('none', 'long')]
syms = list(dfs)
rows = []
for s in sigs:
    v_all = np.array([res[k][s] for k in syms])
    v_old = np.array([res[k][s] for k in OLD7 if k in res])
    v_new = np.array([res[k][s] for k in NEW6 if k in res])
    tv = np.array([turn[k][s] for k in syms])
    t_all, _ = cross_symbol_t(v_all)
    t_new, _ = cross_symbol_t(v_new)
    al = np.array([res[k][s] - res[k]['long'] for k in syms])
    t_a, _ = cross_symbol_t(al)
    rows.append(dict(sig=s, mean=float(v_all.mean()), t=float(t_all),
                     alpha=float(al.mean()), t_alpha=float(t_a),
                     old=float(v_old.mean()), new=float(v_new.mean()), t_new=float(t_new),
                     pos=int((v_all > 0).sum()), n=len(v_all), turn=float(tv.mean())))
rows.sort(key=lambda r: -r['alpha'])
P('  %-11s %8s %7s | %8s %7s | %8s %8s %7s %6s %7s' % (
    '信号', '净收益', 't', 'αvs买持', 't_α', 'OLD7', 'NEW6', 't_new', '正/13', '换手'))
for r in rows:
    P('  %-11s %8.4f %7.2f | %8.4f %7.2f | %8.4f %8.4f %7.2f %6d %7.4f' % (
        r['sig'], r['mean'], r['t'], r['alpha'], r['t_alpha'],
        r['old'], r['new'], r['t_new'], r['pos'], r['turn']))

bh = {k: res[k]['long'] for k in syms}
P('  买入持有基准: 均值 %.4f bp/bar（%d/13 为正）' % (np.mean(list(bh.values())),
                                                  int(np.sum(np.array(list(bh.values())) > 0))))

rc = reality_check({k: {s: v[s] for s in sigs} for k, v in res.items()}, COST, n_boot=2000)
P('  Reality Check(全族最优=%s): stat=%.4f  p=%.3f' % (rc['best'], rc['stat'], rc['p']))

# 时间外推：前50%选，后50%验
P('  --- 时间外推（前50%%选 → 后50%%验）---')
half = {k: len(v) // 2 for k, v in dfs.items()}
res_in, res_out = {}, {}
for k, d in dfs.items():
    o = d['open'].values; hs = half[k]
    res_in[k] = {}; res_out[k] = {}
    for nm, fn in zoo.items():
        if nm == 'none': continue
        s = np.asarray(fn(d), float)
        r1 = backtest(o[:hs], s[:hs], COST); r2 = backtest(o[hs:], s[hs:], COST)
        res_in[k][nm] = r1['net'] / hs * 1e4
        res_out[k][nm] = r2['net'] / (len(o) - hs) * 1e4
best_in = max(sigs, key=lambda s: np.mean([res_in[k][s] for k in syms]))
v_out = np.array([res_out[k][best_in] for k in syms])
t_out, _ = cross_symbol_t(v_out)
P('  样本内最优=%s（%.4f）→ 样本外 %.4f  t=%.2f  正/13=%d' % (
    best_in, np.mean([res_in[k][best_in] for k in syms]), v_out.mean(), t_out,
    int((v_out > 0).sum())))

# ---------------- 5. 校准：检测下限与误报率 ----------------
P('[5/6] 平台校准（注入已知强度的真实 edge，测检测能力）')
def calibrate(strength, n=20000, sigma=0.008, M=120, seed=3):
    rng = np.random.default_rng(seed)
    det = 0; tvals = []
    for m in range(M):
        mu = strength * sigma
        r = mu + sigma * rng.standard_normal(n)
        o = 100 * np.cumprod(1 + r)
        d = pd.DataFrame({'open': o, 'high': o, 'low': o, 'close': o})
        s = sig_mom_ = None
        from lab import sig_mom
        s = sig_mom(d, 20)
        rr = backtest(o, s, COST)
        tvals.append(rr['t_bar'])
        if rr['t_bar'] > 1.96:
            det += 1
    return det / M, float(np.mean(tvals))

from lab import sig_mom
cal = []
for st in (0.0, 0.005, 0.01, 0.02, 0.04, 0.08):
    d_, t_ = calibrate(st)
    cal.append(dict(strength=st, detect=d_, mean_t=t_))
    P('  强度(每bar夏普)=%.3f  检出率=%.1f%%  平均t=%.2f' % (st, d_ * 100, t_))
P('  误报率(强度0) = %.1f%%（理论 5%%）' % (cal[0]['detect'] * 100))

# ---------------- 6. 报告 ----------------
P('[6/6] 生成报告')
md = ['# 可信回测平台 — 验证报告', '',
      '数据指纹 `%s`　样本 %d 品种　成本 maker %.0fbp' % (fp, len(dfs), COST), '',
      '## 一、平台如何保证可信', '',
      '| 机制 | 做法 |', '|---|---|',
      '| P1 物理截断 | 信号在 bar i 只能读到 bar ≤ i-1，未来数据不在内存 |',
      '| P2 执行时点 | sig[i] 一律在 open[i] 成交，收益取 open[i]→open[i+1] |',
      '| P3 成本口径 | cost=Σ|Δpos|×bp，可闭式核对 |',
      '| P4 同bar歧义 | 双向触及保守判止损先触发 |',
      '| P5 确定性 | 同输入同输出，数据哈希入档 |',
      '| P6 门禁 | 不变量+泄漏检测全过，才输出结论 |', '',
      '## 二、门禁1 不变量（%s）' % ('PASS' if gate1 else 'FAIL'), '']
for i, nm in enumerate(names):
    ok = all(inv_summary[k][i]['pass'] for k in dfs)
    md.append('- %s **%s**' % ('✓' if ok else '✗', nm))
md += ['', '## 三、门禁2 泄漏检测（%s）' % ('PASS' if gate2 else 'FAIL'), '',
       '探测器总数 %d，报警 %d。' % (sum(v['total'] for v in leak.values()),
                                 sum(v['fail'] for v in leak.values())), '',
       '四道探测器：', '',
       '- **D0 自检**：注入完美前视信号，引擎必须给出巨额正收益（证明探测器能抓到前视）',
       '- **D1 截断一致性（PIT 强检验）**：随机截断点 m，用前 m 根 bar 重算信号末位，'
       '必须与全样本信号在 m-1 位完全一致。信号一旦偷看未来，截断后必然对不上。',
       '- **D2 时间洗牌**：打乱收益序列后，信号必须失去全部能力',
       '- **D3 前视对照**：真实信号强度须远低于完美前视', '',
       '## 四、策略评估（净收益 bp/bar）', '',
       '| 信号 | 净收益 | t | αvs买持 | t_α | OLD7 | NEW6 | t(NEW6) | 正/13 | 换手/bar |',
       '|---|---|---|---|---|---|---|---|---|---|']
for r in rows:
    md.append('| %s | %.4f | %.2f | %.4f | %.2f | %.4f | %.4f | %.2f | %d | %.4f |' % (
        r['sig'], r['mean'], r['t'], r['alpha'], r['t_alpha'],
        r['old'], r['new'], r['t_new'], r['pos'], r['turn']))
md += ['', '买入持有基准均值 **%.4f** bp/bar（%d/13 为正）' % (
    np.mean(list(bh.values())), int(np.sum(np.array(list(bh.values())) > 0))), '',
       'Reality Check（全族最优=%s）：stat=%.4f，**p=%.3f**' % (rc['best'], rc['stat'], rc['p']), '',
       '时间外推：样本内最优 %s → 样本外 %.4f bp/bar，t=%.2f，正/13=%d' % (
           best_in, v_out.mean(), t_out, int((v_out > 0).sum())), '',
       '## 五、平台校准：我能发现多强的 edge？', '',
       '| 注入强度(每bar夏普) | 检出率 | 平均 t |', '|---|---|---|']
for c in cal:
    md.append('| %.3f | %.1f%% | %.2f |' % (c['strength'], c['detect'] * 100, c['mean_t']))
md += ['', '误报率 = **%.1f%%**（理论 5%%）→ 平台无系统性正向偏误。' % (cal[0]['detect'] * 100), '']

# 判定
strongest = rows[0]
if gate1 and gate2:
    verd = ('结论可信度：**高**（门禁全过）。\n\n'
            '在该口径下，%d 个信号中最强者为 `%s`，全样本 %.4f bp/bar，'
            '跨品种 t=%.2f，Reality Check p=%.3f。'
            % (len(sigs), strongest['sig'], strongest['mean'], strongest['t'], rc['p']))
else:
    verd = '结论可信度：**低**（门禁未过），上方数据仅供参考，不可用于决策。'
md += ['## 六、判定', '', verd, '',
       '---', '', '耗时 %.1fs' % (time.time() - t0)]

open(os.path.join(OUT, 'REPORT.md'), 'w').write('\n'.join(md))
json.dump(dict(fp=fp, gate1=gate1, gate2=gate2, rows=rows, rc=rc, cal=cal,
               leak=leak, bh={k: float(v) for k, v in bh.items()}),
          open(os.path.join(OUT, 'results.json'), 'w'), indent=1)
P('  完成，耗时 %.1fs' % (time.time() - t0))
