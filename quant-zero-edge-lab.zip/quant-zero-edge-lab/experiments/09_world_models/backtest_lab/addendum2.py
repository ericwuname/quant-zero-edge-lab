"""
addendum2.py — 关键追问：
  Q1 止损/止盈引擎里那个正的 E，是 alpha 还是 beta？（多空分解）
  Q2 收割制的成功率里，有多少是"障碍几何"白送的？（真·零均值对照）
"""
import numpy as np, os, sys, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from lab import load_all, backtest_bracket, signal_zoo

OUT = os.path.dirname(os.path.abspath(__file__))
COST_BP, STOP, R_MULT = 2.0, 0.05, 2.0
COST_R = 2 * COST_BP / 1e4 / STOP

t0 = time.time()
dfs = load_all(); zoo = signal_zoo()
use = ['xab20_100', 'brk60', 'mom240']


def harvest(trades, f=0.01, n_max=2500, T=1.0, ruin=0.2, n_path=2000, seed=0):
    rng = np.random.default_rng(seed)
    base = np.asarray(trades, float) - COST_R
    idx = rng.integers(0, len(base), size=(n_path, n_max))   # 预生成，快
    sample = base[idx]
    C0 = 10000.0; bet = f * C0
    pocket = np.zeros(n_path); bust = np.zeros(n_path, bool)
    W = np.full(n_path, C0)
    alive = np.ones(n_path, bool)
    for j in range(n_max):
        W = np.where(alive, W + np.minimum(bet, W) * sample[:, j], W)
        hit = alive & (W >= (1 + T) * C0)
        pocket += np.where(hit, W - C0, 0.0)
        W = np.where(hit, C0, W)
        dead = alive & (W <= ruin * C0)
        bust |= dead
        alive &= ~dead
    pocket += W - C0
    return dict(P=float((pocket >= C0).mean()), med=float(np.median(pocket)),
                bust=float(bust.mean()))


lines = ['', '## 八、关键追问：那个正的 E 是 alpha 还是 beta？', '',
         '### 8.1 多空分解（剥离市场方向漂移）', '',
         '若 E>0 只是因为样本期是牛市（多头天然占优），那么多头 E 会远高于空头 E，',
         '而"多头 − 空头"接近 0 说明没有方向能力。', '',
         '| 信号 | 多头笔数 | 多头E(R) | 空头笔数 | 空头E(R) | 多空差 | 多空差 t |',
         '|---|---|---|---|---|---|---|']
print('[addendum2] 多空分解 + 真零均值对照')
pool = {}
for nm in use:
    tr_l, td_l = [], []
    for k, d in dfs.items():
        r = backtest_bracket(d, zoo[nm](d), stop_pct=STOP, R=R_MULT, cost_bp=COST_BP)
        tr_l.append(r['trades']); td_l.append(r['dirs'])
    tr = np.concatenate(tr_l); td = np.concatenate(td_l)
    pool[nm] = (tr, td)
    lng, sht = tr[td > 0], tr[td < 0]
    el, es = lng.mean() - COST_R, sht.mean() - COST_R
    diff = el - es
    se = np.sqrt(lng.var(ddof=1) / len(lng) + sht.var(ddof=1) / len(sht))
    t = diff / se if se > 0 else 0.0
    print('  %-10s 多头N=%5d E=%+.4fR | 空头N=%5d E=%+.4fR | 差=%+.4fR t=%+.2f'
          % (nm, len(lng), el, len(sht), es, diff, t))
    lines.append('| %s | %d | %+.4f | %d | %+.4f | %+.4f | %+.2f |'
                 % (nm, len(lng), el, len(sht), es, diff, t))

lines += ['', '### 8.2 真·零均值对照（把 E 平移到 0，只保留分布形状）', '',
          '| 信号 | 原始 E(R) | 原始 P(落袋≥本金) | **零均值后 P** | 差值(真能力贡献) |',
          '|---|---|---|---|---|']
for nm in use:
    tr, td = pool[nm]
    h0 = harvest(tr)
    tr0 = tr - tr.mean()                       # 平移到零均值
    h1 = harvest(tr0)
    print('  %-10s E=%.4fR → P=%.1f%% | 零均值 → P=%.1f%% | 真能力贡献=%.1f pp'
          % (nm, tr.mean() - COST_R, h0['P'] * 100, h1['P'] * 100,
             (h0['P'] - h1['P']) * 100))
    lines.append('| %s | %.4f | %.1f%% | **%.1f%%** | %.1f pp |'
                 % (nm, tr.mean() - COST_R, h0['P'] * 100, h1['P'] * 100,
                    (h0['P'] - h1['P']) * 100))

lines += ['', '读法：零均值后的 P 是"纯靠分布形状 + 障碍几何"白送的成功率；',
          '原始 P 与它的差，才是真正的 edge 贡献。', '',
          '耗时 %.1fs' % (time.time() - t0)]
with open(os.path.join(OUT, 'REPORT.md'), 'a') as f:
    f.write('\n'.join(lines) + '\n')
print('  已追加，耗时 %.1fs' % (time.time() - t0))
