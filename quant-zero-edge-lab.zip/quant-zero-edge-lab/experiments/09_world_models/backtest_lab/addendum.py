"""
addendum.py — 在同一可信引擎上补跑：
  (a) 止损/止盈（盈亏比）引擎
  (b) 收割制（不复利，翻倍即提取）
两步都复用 lab.py 的信号与门禁，不另起口径。
"""
import numpy as np, pandas as pd, os, sys, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from lab import load_all, backtest_bracket, signal_zoo

OUT = os.path.dirname(os.path.abspath(__file__))
COST_BP = 2.0
STOP = 0.05
R_MULT = 2.0
COST_R = 2 * COST_BP / 1e4 / STOP      # 单笔往返成本，R 单位 = 0.008R

t0 = time.time()
dfs = load_all()
zoo = signal_zoo()
use = ['xab20_100', 'brk60', 'mom240', 'rev5']


def harvest(trades, f=0.01, n_max=3000, T=1.0, ruin=0.2, n_path=3000, seed=0):
    """固定注 + 翻倍收割 + 爆仓线。返回 P(落袋>=本金)、落袋中位、爆仓率。"""
    rng = np.random.default_rng(seed)
    base = np.asarray(trades, float) - COST_R
    C0 = 10000.0
    pocket, bust, ever = [], 0, 0
    for _ in range(n_path):
        W = C0; pk = 0.0; b = False; hit = False
        for _ in range(n_max):
            if W <= ruin * C0:
                b = True; break
            bet = min(f * C0, W)
            W += bet * float(rng.choice(base))
            if W >= (1 + T) * C0:
                pk += W - C0; W = C0; hit = True
        pocket.append(pk + (W - C0))
        bust += b; ever += hit
    pocket = np.array(pocket)
    return dict(P=float((pocket >= C0).mean()), med=float(np.median(pocket)),
                bust=float(bust / n_path), ever=float(ever / n_path))


lines = ['', '## 七、追加：止损/止盈 与 收割制（同一引擎）', '',
         f'规格：止损 5%，止盈 R=2，maker 2bp → 单笔往返成本 {COST_R:.3f}R（已含在 E 中）。', '',
         '| 信号 | 交易数 | 实际胜率 | p* | 每笔 E(R) | t | 收割 P(落袋≥本金) | 落袋中位 | 爆仓率 |',
         '|---|---|---|---|---|---|---|---|---|']

print('[addendum] 止损/止盈 + 收割制')
all_tr = {}
for nm in use:
    tr_all = []
    for k, d in dfs.items():
        sig = zoo[nm](d)
        r = backtest_bracket(d, sig, stop_pct=STOP, R=R_MULT, cost_bp=COST_BP)
        tr_all.append(r['trades'])
    tr = np.concatenate(tr_all)
    all_tr[nm] = tr
    n = len(tr)
    win = float((tr > 0).mean())
    pstar = 1.0 / (1 + R_MULT)
    e = float(tr.mean() - COST_R)
    t = float(tr.mean() / tr.std(ddof=1) * np.sqrt(n)) if tr.std(ddof=1) > 0 else 0.0
    hs = harvest(tr)
    print('  %-10s N=%5d 胜率=%.1f%% (p*=%.1f%%) E=%.4fR t=%.2f | P=%.1f%% 中位=%.0f 爆仓=%.1f%%'
          % (nm, n, win * 100, pstar * 100, e, t, hs['P'] * 100, hs['med'], hs['bust'] * 100))
    lines.append('| %s | %d | %.1f%% | %.1f%% | %.4f | %.2f | %.1f%% | %.0f | %.1f%% |'
                 % (nm, n, win * 100, pstar * 100, e, t, hs['P'] * 100, hs['med'], hs['bust'] * 100))

# 零期望对照：把交易序列洗牌（破坏时序，但保留分布）
rng = np.random.default_rng(5)
lines += ['', '**零期望对照**（把最优信号的交易序列洗牌，破坏任何时序结构）：']
for nm in ['xab20_100']:
    tr = all_tr[nm].copy(); rng.shuffle(tr)
    hs = harvest(tr)
    print('  [对照] %s 洗牌后 P=%.1f%% 中位=%.0f 爆仓=%.1f%%'
          % (nm, hs['P'] * 100, hs['med'], hs['bust'] * 100))
    lines.append('- `%s` 洗牌后：P=%.1f%%，落袋中位=%.0f，爆仓率=%.1f%%'
                 % (nm, hs['P'] * 100, hs['med'], hs['bust'] * 100))

lines += ['', '几何对照：无漂移随机游走在 [0.2C, 2C] 双障碍间，先到 2C 的概率 = 0.8/1.8 = **44.4%**。',
          '上表 P 若只是接近该值，则"成功"由障碍几何白送，与信号能力无关。', '',
          '耗时 %.1fs' % (time.time() - t0)]

with open(os.path.join(OUT, 'REPORT.md'), 'a') as f:
    f.write('\n'.join(lines) + '\n')
print('  已追加到 REPORT.md，耗时 %.1fs' % (time.time() - t0))
