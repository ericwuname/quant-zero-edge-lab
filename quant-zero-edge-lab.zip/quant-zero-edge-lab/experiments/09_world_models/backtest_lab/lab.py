"""
lab.py — 可信回测平台（Point-in-Time by Construction）

设计原则（任一被违反，结果自动作废）：
  P1 物理截断：信号在 bar i 只能读到 bar 0..i-1。未来 bar 不在内存里。
  P2 执行时点：信号 sig[i] 一律在 open[i] 成交，收益取 open[i] -> open[i+1]。
  P3 成本按换手计费：cost = |Δpos| * cost_bp（唯一成本口径，可闭式核对）。
  P4 同 bar 双向触及 → 保守判止损先触发。
  P5 确定性：同输入 → 同输出（可哈希）。
  P6 门禁：不变量 + 泄漏检测全部通过，才允许输出策略结论。
"""
import numpy as np
import pandas as pd
import glob, os, hashlib, json

# ============================== 数据载入 ==============================

def load_all(data_dir='/data/inputs', suffix='_1h.csv', min_bars=5000):
    out = {}
    for p in sorted(glob.glob(os.path.join(data_dir, '*' + suffix))):
        name = os.path.basename(p).replace(suffix, '')
        try:
            df = pd.read_csv(p)
        except Exception:
            continue
        cols = {c.lower(): c for c in df.columns}
        if not all(k in cols for k in ('open', 'high', 'low', 'close')):
            continue
        d = df[[cols[k] for k in ('open', 'high', 'low', 'close')]].copy()
        d.columns = ['open', 'high', 'low', 'close']
        d = d.dropna().astype(float)
        d = d[(d['open'] > 0) & (d['high'] > 0) & (d['low'] > 0) & (d['close'] > 0)]
        if len(d) < min_bars:
            continue
        out[name] = d.reset_index(drop=True)
    return out


def fingerprint(dfs):
    h = hashlib.sha256()
    for k in sorted(dfs):
        d = dfs[k]
        h.update(k.encode())
        h.update(np.ascontiguousarray(d['open'].values).tobytes())
        h.update(np.ascontiguousarray(d['close'].values).tobytes())
    return h.hexdigest()[:16]


# ============================== P1: 安全历史视图 ==============================

class LookAheadError(Exception):
    pass


class Hist:
    """只读历史视图，物理截断到 bar t（含）。索引 > t 的数据不存在。"""
    __slots__ = ('o', 'h', 'l', 'c', 't')

    def __init__(self, o, h, l, c, t):
        self.o = o[:t + 1]   # numpy 视图，O(1)
        self.h = h[:t + 1]
        self.l = l[:t + 1]
        self.c = c[:t + 1]
        self.t = t

    def __len__(self):
        return self.t + 1


# ============================== 回测引擎（唯一口径） ==============================

def backtest(o, sig, cost_bp=2.0, size=1.0):
    """open-to-open 引擎。sig[i] 在 open[i] 建立，持有到 open[i+1]。"""
    o = np.asarray(o, float)
    sig = np.asarray(sig, float) * float(size)
    n = len(o)
    ret = np.zeros(n)
    ret[:-1] = o[1:] / o[:-1] - 1.0        # ret[i]: open[i] -> open[i+1]
    pnl = sig * ret
    prev = np.concatenate(([0.0], sig[:-1]))
    turn = np.abs(sig - prev)
    cost = turn * (cost_bp / 1e4)
    net = pnl - cost
    sd = net.std(ddof=1)
    return dict(
        gross=float(pnl.sum()), cost_total=float(cost.sum()), net=float(net.sum()),
        turnover=float(turn.sum()), n_flips=int((turn > 1e-12).sum()),
        n_bars=n, exposure=float(np.mean(np.abs(sig))),
        t_bar=float(net.mean() / sd * np.sqrt(n)) if sd > 0 else 0.0,
        pnl=pnl, cost_bar=cost, net_bar=net,
    )


def backtest_bracket(df, sig, stop_pct=0.05, R=2.0, cost_bp=2.0, slip_bp=0.0,
                     start=0, end=None):
    """止损/止盈引擎。P4: 同 bar 双向触及 -> 止损先触发。
    sig[i] 用 bar<=i-1 的信息，在 open[i] 建仓。返回每笔 R 倍数与方向。
    """
    o = df['open'].values.astype(float)
    h = df['high'].values.astype(float)
    l = df['low'].values.astype(float)
    sig = np.asarray(sig, float)
    n = len(o)
    end = n if end is None else end
    trades, tdirs, net_bar = [], [], np.zeros(n)
    cur, entry, stop_px, tgt_px = 0.0, 0.0, 0.0, 0.0
    for i in range(max(1, start), end):
        if cur != 0 and i < n - 1:
            if cur > 0:
                hit_stop = l[i] <= stop_px; hit_tgt = h[i] >= tgt_px
            else:
                hit_stop = h[i] >= stop_px; hit_tgt = l[i] <= tgt_px
            if hit_stop:
                px = stop_px * (1 - np.sign(cur) * slip_bp / 1e4)
                trades.append((px - entry) * cur / abs(entry) / stop_pct)
                tdirs.append(np.sign(cur)); cur = 0.0
            elif hit_tgt:
                trades.append((tgt_px - entry) * cur / abs(entry) / stop_pct)
                tdirs.append(np.sign(cur)); cur = 0.0
        if cur == 0.0 and sig[i] != 0:
            cur = float(np.sign(sig[i])); entry = o[i]
            stop_px = entry * (1 - cur * stop_pct)
            tgt_px = entry * (1 + cur * R * stop_pct)
            net_bar[i] -= cost_bp / 1e4
            if i < n - 1:
                if cur > 0:
                    hs, ht = l[i] <= stop_px, h[i] >= tgt_px
                else:
                    hs, ht = h[i] >= stop_px, l[i] <= tgt_px
                if hs:
                    px = stop_px * (1 - cur * slip_bp / 1e4)
                    trades.append((px - entry) * cur / abs(entry) / stop_pct)
                    tdirs.append(np.sign(cur)); cur = 0.0
                elif ht:
                    trades.append((tgt_px - entry) * cur / abs(entry) / stop_pct)
                    tdirs.append(np.sign(cur)); cur = 0.0
        if cur != 0 and i < n - 1:
            net_bar[i] += cur * (o[i + 1] / o[i] - 1.0) / stop_pct
    tr = np.asarray(trades) if trades else np.zeros(0)
    td = np.asarray(tdirs) if tdirs else np.zeros(0)
    return dict(trades=tr, dirs=td, n=len(tr), net_bar=net_bar)


# ============================== 信号库（全部点-in-time） ==============================
# 约定：sig[i] 只能依赖 bar <= i-1 的数据，一律用 shift(1) 起手。

def sig_none(df):
    return np.zeros(len(df))

def sig_long(df):
    return np.ones(len(df))

def sig_mom(df, k):
    c = df['close']
    return np.sign(c.shift(1) / c.shift(1 + k) - 1.0).fillna(0).values

def sig_rev(df, k):
    return -sig_mom(df, k)

def sig_ma(df, k):
    c = df['close']
    m = c.shift(1).rolling(k).mean()
    return np.sign(c.shift(1) - m).fillna(0).values

def sig_xab(df, a, b):
    c = df['close']
    ma = c.shift(1).rolling(a).mean()
    mb = c.shift(1).rolling(b).mean()
    return np.sign(ma - mb).fillna(0).values

def sig_brk(df, k):
    """突破后保持方向，直到反向突破。
    向量化实现：事件序列 forward-fill，等价于状态机，且天然只用 <= i-1 的数据。
    """
    h = df['high'].shift(2).rolling(k).max()
    lo = df['low'].shift(2).rolling(k).min()
    c = df['close'].shift(1)
    ev = pd.Series(np.where(c > h, 1.0, np.where(c < lo, -1.0, np.nan)), index=df.index)
    return ev.ffill().fillna(0.0).values

def sig_rsi(df, k, lo=30.0, hi=70.0):
    c = df['close'].shift(1)
    d = c.diff()
    up = d.clip(lower=0).ewm(alpha=1.0 / k, adjust=False).mean()
    dn = (-d.clip(upper=0)).ewm(alpha=1.0 / k, adjust=False).mean()
    rsi = 100 - 100 / (1 + up / dn.replace(0, np.nan))
    s = np.where(rsi < lo, 1.0, np.where(rsi > hi, -1.0, 0.0))
    return np.nan_to_num(s)

def sig_canary_leak(df):
    """故意前视的信号（完美预知下一根 bar）。仅用于检验引擎是否会奖励前视。"""
    o = df['open'].values
    s = np.zeros(len(o))
    s[:-1] = np.sign(o[1:] / o[:-1] - 1.0)
    return s


def signal_zoo():
    z = {'none': lambda d: sig_none(d), 'long': lambda d: sig_long(d)}
    for k in (5, 10, 20, 60, 240):
        z[f'mom{k}'] = lambda d, k=k: sig_mom(d, k)
        z[f'rev{k}'] = lambda d, k=k: sig_rev(d, k)
        z[f'ma{k}'] = lambda d, k=k: sig_ma(d, k)
        z[f'brk{k}'] = lambda d, k=k: sig_brk(d, k)
    for a, b in ((20, 100), (50, 200)):
        z[f'xab{a}_{b}'] = lambda d, a=a, b=b: sig_xab(d, a, b)
    for k in (14, 48):
        z[f'rsi{k}'] = lambda d, k=k: sig_rsi(d, k)
    return z


# ============================== 门禁 1：不变量 ==============================

def invariants(o, cost_bp=2.0, rng_seed=0):
    """无论策略怎么变，这些恒等式必须成立。任一 False → 结果作废。"""
    rng = np.random.default_rng(rng_seed)
    n = len(o)
    C = []

    def add(name, ok, info=''):
        C.append({'name': name, 'pass': bool(ok), 'info': str(info)})

    ret = np.zeros(n)
    ret[:-1] = o[1:] / o[:-1] - 1.0

    # 1 空仓 → 零交易、零成本、零损益
    r = backtest(o, np.zeros(n), cost_bp)
    add('空仓零损益', abs(r['gross']) < 1e-12 and r['turnover'] < 1e-12
        and abs(r['net']) < 1e-12, "gross=%.2e" % r['gross'])

    # 2 收益构造：对数望远镜（专抓 off-by-one / 错位）
    lhs = float(np.log1p(ret[:-1]).sum())
    rhs = float(np.log(o[-1] / o[0]))
    add('收益构造对数望远镜', abs(lhs - rhs) < 1e-9, "%.10f vs %.10f" % (lhs, rhs))

    # 3 口径自洽：固定名义敞口买持 == Σ 逐bar算术收益
    r = backtest(o, np.ones(n), 0.0)
    add('固定名义买持=Σ逐bar收益', abs(r['gross'] - ret.sum()) < 1e-12,
        "%.10f vs %.10f" % (r['gross'], ret.sum()))

    # 4 口径差量化（几何 vs 算术，方差拖累）——只报告不断言
    geo = o[-1] / o[0] - 1.0
    add('口径差已量化', True, "几何=%.4f 算术=%.4f 差=%.4f" % (geo, ret.sum(), geo - ret.sum()))

    # 5 成本恒等式
    sg = sig_mom(pd.DataFrame({'close': o, 'open': o, 'high': o, 'low': o}), 20)
    r = backtest(o, sg, cost_bp)
    add('成本=换手×费率', abs(r['cost_total'] - r['turnover'] * cost_bp / 1e4) < 1e-10,
        "cost=%.8f" % r['cost_total'])

    # 6 净 = 毛 - 成本（相对容差，防浮点累加误差）
    add('净=毛-成本', abs(r['net'] - (r['gross'] - r['cost_total'])) <= 1e-9 * max(1.0, abs(r['gross'])))

    # 7 零换手 → 零成本
    add('零换手零成本', abs(backtest(o, np.zeros(n), cost_bp)['cost_total']) < 1e-15)

    # 8 规模线性（毛）
    r2 = backtest(o, sg * 2.0, cost_bp)
    add('规模线性(毛)', abs(r2['gross'] - 2 * r['gross']) < 1e-9)

    # 9 成本单调性
    e0 = backtest(o, sg, 0.0)['net']
    e1 = backtest(o, sg, 10.0)['net']
    e2 = backtest(o, sg, 50.0)['net']
    add('成本单调性', e0 >= e1 >= e2, "%.4f >= %.4f >= %.4f" % (e0, e1, e2))

    # 10 随机信号无 Alpha
    rs = rng.choice([-1.0, 0.0, 1.0], size=n)
    rr = backtest(o, rs, cost_bp)
    se = rr['pnl'].std(ddof=1) * np.sqrt(n)
    add('随机信号无Alpha', abs(rr['gross']) < 4 * se, "gross=%.4f 4SE=%.4f" % (rr['gross'], 4 * se))

    # 11 确定性
    a = backtest(o, sg, cost_bp)['net']
    b = backtest(o, sg, cost_bp)['net']
    add('确定性可复现', a == b)

    return C


# ============================== 门禁 2：泄漏检测 ==============================

def leakage_tests(df, sig, cost_bp=2.0, rng_seed=1, fn=None):
    """三道探测器。任一报警 → 该信号结论作废。"""
    o = df['open'].values.astype(float)
    n = len(o)
    rng = np.random.default_rng(rng_seed)
    T = []

    def add(name, ok, info=''):
        T.append({'name': name, 'pass': bool(ok), 'info': str(info)})

    e0 = backtest(o, sig, cost_bp)['gross']

    # D1 引擎是否会奖励前视？（探测器自检：必须报警）
    cn = backtest(o, sig_canary_leak(df), cost_bp)['gross']
    add('D0 前视探测器自检', cn > 0.5 * np.abs(o[1:] / o[:-1] - 1).sum(),
        f"完美前视 gross={cn:.3f}（应远大于0）")

    # D1 截断一致性（点-in-time 强检验）：
    # 对任意 m，用前 m 根 bar 重算信号的最后一位，必须等于全样本信号在 m-1 位的值。
    # 若信号偷看未来，截断后重算必然对不上。
    if fn is not None:
        rng2 = np.random.default_rng(rng_seed + 100)
        ms = rng2.choice(range(500, n - 1), size=min(6, n - 501), replace=False)
        diffs = 0
        for m in ms:
            a = float(np.asarray(fn(df.iloc[:int(m)]), float)[-1])
            b = float(np.asarray(sig, float)[int(m) - 1])
            if abs(a - b) > 1e-12:
                diffs += 1
        add('D1 截断一致性(PIT)', diffs == 0, f"{len(ms)} 个截断点，不一致 {diffs}")

    # D1b 滞后崩塌（仅提示，不算门禁）：真实 1bar 预测力也会崩塌，不可作硬判据
    lag = np.concatenate(([0.0], np.asarray(sig, float)[:-1]))
    e1 = backtest(o, lag, cost_bp)['gross']
    collapsed = (abs(e0) - abs(e1)) / (abs(e0) + 1e-12)
    add('D1b 滞后崩塌(提示)', True, f"原={e0:.4f} 滞后={e1:.4f} 衰减={collapsed:.1%}")

    # D2 时间结构洗牌：打乱收益序列，真实信号应失去全部能力
    r = np.zeros(n); r[:-1] = o[1:] / o[:-1] - 1.0
    idx = rng.permutation(n - 1)
    rs = r.copy(); rs[:-1] = r[:-1][idx]
    o2 = o[0] * np.cumprod(1 + rs)
    e2 = backtest(o2, sig, cost_bp)['gross']
    se2 = (np.asarray(sig, float) * rs).std(ddof=1) * np.sqrt(n)
    add('D2 洗牌后无能力', abs(e2) < 4 * se2,
        f"洗牌 gross={e2:.4f}, 4SE={4*se2:.4f}")

    # D3 完美前视对照：真实信号不应接近它
    add('D3 远弱于完美前视', abs(e0) < 0.05 * abs(cn),
        f"|真实|={abs(e0):.4f} vs 5%×完美前视={0.05*abs(cn):.4f}")

    return T


# ============================== 统计层 ==============================

def cross_symbol_t(res):
    """跨品种 t 值（每个品种一个观测，避免 bar 自相关高估显著性）。"""
    v = np.asarray([r for r in res if np.isfinite(r)], float)
    if len(v) < 2: return 0.0, len(v)
    sd = v.std(ddof=1)
    if sd < 1e-15: return 0.0, len(v)
    return float(v.mean() / sd * np.sqrt(len(v))), len(v)


def reality_check(sym_results, cost_bp, n_boot=2000, seed=7):
    """White's Reality Check：在信号族里挑最优后的多重检验校正。"""
    rng = np.random.default_rng(seed)
    syms = list(sym_results.keys())
    sigs = list(sym_results[syms[0]].keys())
    M = {s: np.array([sym_results[y][s] for y in syms]) for s in sigs}
    best = max(sigs, key=lambda s: M[s].mean())
    stat = M[best].mean()
    # 零分布：对每个品种的收益序列做符号翻转（保持截面结构）
    cnt = 0
    for _ in range(n_boot):
        flips = rng.choice([-1.0, 1.0], size=len(syms))
        m = {s: M[s] * flips for s in sigs}
        if max(sigs, key=lambda s: m[s].mean()) and \
           max(m[s].mean() for s in sigs) >= stat:
            cnt += 1
    return dict(best=best, stat=float(stat), p=float((cnt + 1) / (n_boot + 1)))


def block_bootstrap_p(net_bar, block=720, n_boot=2000, seed=11):
    """分块自助（保留自相关），检验 net 是否显著 ≠ 0。"""
    x = np.asarray(net_bar, float)
    n = len(x)
    nb = int(np.ceil(n / block))
    rng = np.random.default_rng(seed)
    obs = x.mean()
    dev = np.empty(n_boot)
    for b in range(n_boot):
        st = rng.integers(0, max(1, n - block), size=nb)
        s = np.concatenate([x[i:i + block] for i in st])[:n]
        dev[b] = s.mean() - obs           # 中心化后的重抽样偏差
    # 单侧 p：重抽样中"至少和观测一样极端（同方向）"的比例
    if obs >= 0:
        p = float((np.sum(dev >= obs) + 1) / (n_boot + 1))
    else:
        p = float((np.sum(dev <= obs) + 1) / (n_boot + 1))
    return p
