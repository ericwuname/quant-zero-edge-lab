#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
================================================================================
真实市场矛盾强度检验器 (单文件自包含版)
Real-Market Contradiction Strength Tester
================================================================================

用途
----
测量【真实市场数据】中"趋势 vs 反转"这一矛盾的力量对比强度 rho,
并与【成本决定的临界值 rho_crit】比较, 判定:
    - 该市场是否存在"可抓的矛盾"(即正期望机会)
    - 若存在, 能否在有限样本内被检测出来

核心原理 (纯数学, 不依赖任何模拟数据)
--------------------------------------
1. 矛盾强度 = 收益率序列的 lag-1 自相关 rho
   rho > 0 : 趋势主导(动量)
   rho < 0 : 反转主导(震荡)

2. 1:1 盈亏比下, 盈亏平衡胜率:
   p* = (1 + c) / 2,   其中 c = 2 * 单边成本 / 砖块幅度A

3. 结构强度 rho 转化为胜率:
   p(rho) = Phi( rho * A / (sigma * sqrt(T)) ),  T = (A/sigma)^2

4. 正期望条件: p(rho) > p*
   解出临界强度 rho_crit(A)  [二分法求解]

5. 第二道门 —— 可检测性:
   确认 rho 所需样本量 N_req = ((1.96 + 0.84) / |rho|)^2
   必须 N_req < 可得样本数, 否则"存在但不可知"

6. 随机对照: 打乱收益率破坏时间结构, 得到零矛盾基线, 扣除伪影

判定逻辑
--------
仅当同时满足以下三条, 才判定"存在可抓的矛盾":
   (a) |rho| > rho_crit(A)          矛盾强度跨过成本门槛
   (b) N_req(rho) < 可得样本数        样本足够确认该矛盾
   (c) 滚动 rho 方向稳定(正负比例不接近50%)  矛盾不会随机翻转

用法
----
  # 下载数据 (三选一)
  python3 market_test.py download --source binance --symbol BTCUSDT --interval 1h --days 365
  python3 market_test.py download --source stooq  --symbol btcusd
  python3 market_test.py download --source yfinance --symbol AAPL --interval 1h

  # 分析 (可一次传多个文件)
  python3 market_test.py analyze data/BTCUSDT_1h.csv data/AAPL_1h.csv

  # 自定义成本 (按你的真实手续费, 默认万分之一)
  python3 market_test.py analyze data.csv --cost 0.0005

  # 输出 JSON 结果
  python3 market_test.py analyze data.csv --json result.json

依赖: numpy, scipy  (pip install numpy scipy)
     下载 yfinance 源需额外: pip install yfinance
================================================================================
"""

import os
import sys
import csv
import json
import argparse
import numpy as np

try:
    from scipy.stats import norm
except ImportError:
    sys.exit("需要 scipy:  pip install scipy")

# ============================================================================
# 默认参数
# ============================================================================
DEFAULT_COST = 0.0001      # 单边手续费率(按名义价值)。请按你的实际费率调整
A_MULT_LIST = [3, 5, 8, 12, 20, 30, 50, 80, 120, 200]   # 砖块大小(单位: 单步波动的倍数)


# ============================================================================
# 一、数据下载
# ============================================================================
def dl_binance(symbol="BTCUSDT", interval="1h", days=365, out="data"):
    """Binance K线。无需 API key。interval: 1m 5m 15m 1h 4h 1d"""
    import urllib.request
    os.makedirs(out, exist_ok=True)
    # interval 毫秒
    ims = {"1m": 60000, "5m": 300000, "15m": 900000, "1h": 3600000,
           "4h": 14400000, "1d": 86400000}
    step = ims.get(interval, 3600000)
    end = int(np.datetime64('now', 'ms').astype(np.int64))
    start = end - days * 86400000
    rows, cur = [], start
    print(f"  下载 {symbol} {interval} ...", end="", flush=True)
    while cur < end:
        url = (f"https://api.binance.com/api/v3/klines?symbol={symbol}"
               f"&interval={interval}&startTime={cur}&limit=1000")
        try:
            with urllib.request.urlopen(url, timeout=30) as r:
                d = json.loads(r.read().decode())
        except Exception as e:
            print(f"\n  [!] 请求失败: {e}")
            break
        if not d:
            break
        rows.extend(d)
        cur = d[-1][0] + step
        print(".", end="", flush=True)
        if len(d) < 1000:
            break
    print(f" 共 {len(rows)} 根")
    if not rows:
        return None
    path = os.path.join(out, f"{symbol}_{interval}.csv")
    with open(path, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["timestamp", "open", "high", "low", "close", "volume"])
        for k in rows:
            w.writerow([k[0], k[1], k[2], k[3], k[4], k[5]])
    return path


def dl_stooq(symbol="btcusd", out="data"):
    """Stooq 日线。symbol 例: btcusd, aapl.us, spy.us, ^spx"""
    import urllib.request
    os.makedirs(out, exist_ok=True)
    url = f"https://stooq.com/q/d/l/?s={symbol}&i=d"
    print(f"  下载 stooq {symbol} ...", end="", flush=True)
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
        with urllib.request.urlopen(req, timeout=30) as r:
            txt = r.read().decode("utf-8-sig")
    except Exception as e:
        print(f"\n  [!] 失败: {e}")
        return None
    lines = [l for l in txt.strip().split("\n") if l]
    print(f" 共 {max(0, len(lines)-1)} 行")
    if len(lines) < 10:
        return None
    path = os.path.join(out, f"{symbol}_d.csv")
    with open(path, "w", newline="") as f:
        f.write("\n".join(lines))
    return path


def dl_yfinance(symbol="AAPL", interval="1h", period="730d", out="data"):
    """Yahoo Finance。需 pip install yfinance"""
    try:
        import yfinance as yf
    except ImportError:
        print("  需要: pip install yfinance")
        return None
    os.makedirs(out, exist_ok=True)
    print(f"  下载 yfinance {symbol} {interval} ...", end="", flush=True)
    try:
        df = yf.download(symbol, interval=interval, period=period,
                         progress=False, auto_adjust=False)
    except Exception as e:
        print(f"\n  [!] 失败: {e}")
        return None
    if df is None or len(df) < 100:
        print("  数据不足")
        return None
    print(f" 共 {len(df)} 根")
    path = os.path.join(out, f"{symbol}_{interval}.csv".replace("^", ""))
    df.to_csv(path)
    return path


# ============================================================================
# 二、数据读取 (自动识别多种 CSV 格式)
# ============================================================================
def load_prices(path):
    """返回 (价格数组, 说明)。自动识别 close/price/adj close 列"""
    with open(path, "r", encoding="utf-8-sig", errors="ignore") as f:
        rows = [r for r in csv.reader(f) if r]
    if not rows:
        raise ValueError("空文件")

    head = rows[0]
    low = [h.strip().lower() for h in head]

    def is_num(s):
        try:
            float(s)
            return True
        except Exception:
            return False

    has_header = not all(is_num(x) for x in head if x != "")
    data = rows[1:] if has_header else rows

    idx = None
    if has_header:
        for name in ["close", "adj close", "adj_close", "price", "last", "close/last"]:
            if name in low:
                idx = low.index(name)
                break
    if idx is None:
        # 无表头或未匹配: 选数值列中"看起来像价格"的那一列(取最后一列数值列)
        for j in range(len(head) - 1, -1, -1):
            vals = []
            ok = True
            for r in data[:50]:
                if len(r) <= j:
                    ok = False
                    break
                try:
                    vals.append(float(r[j]))
                except Exception:
                    ok = False
                    break
            if ok and len(vals) > 10 and all(v > 0 for v in vals):
                idx = j
                break
    if idx is None:
        idx = len(head) - 1

    px = []
    for r in data:
        if len(r) <= idx:
            continue
        try:
            v = float(r[idx])
        except Exception:
            continue
        if np.isfinite(v) and v > 0:
            px.append(v)
    px = np.asarray(px, dtype=float)
    if len(px) < 200:
        raise ValueError(f"有效价格太少({len(px)}), 至少需要 200")
    return px, (f"列[{head[idx] if has_header else idx}]" if has_header else f"第{idx}列")


# ============================================================================
# 三、核心测量
# ============================================================================
def measure_rho(px, lags=(1, 2, 3, 5, 10, 20, 50, 100)):
    """多尺度自相关"""
    r = np.diff(np.log(px))
    r = r - r.mean()
    n = len(r)
    out = {}
    for L in lags:
        if n <= L + 50:
            continue
        ac = float(np.corrcoef(r[:-L], r[L:])[0, 1])
        se = 1.0 / np.sqrt(n)
        out[L] = dict(rho=ac, se=se, z=ac / se)
    return out, r


def rolling_rho(px, W=2000, lag=1):
    """滚动自相关, 检验矛盾是否稳定/会转化"""
    r = np.diff(np.log(px))
    n = len(r)
    if n <= W + lag + 10:
        W = max(100, n // 5)
    acf = np.full(n, np.nan)
    for i in range(W + lag, n):
        seg = r[i - W:i]
        a, b = seg[:-lag], seg[lag:]
        if a.std() > 0 and b.std() > 0:
            acf[i] = np.corrcoef(a, b)[0, 1]
    return acf


def shuffle_null(px, n_boot=30, lag=1, seed=0):
    """打乱收益率 -> 零矛盾基线(扣伪影)"""
    rng = np.random.default_rng(seed)
    r = np.diff(np.log(px))
    if len(r) <= lag + 10:
        return 0.0, 0.0
    vals = []
    for _ in range(n_boot):
        rb = rng.permutation(r)
        vals.append(np.corrcoef(rb[:-lag], rb[lag:])[0, 1])
    return float(np.mean(vals)), float(np.std(vals))


def win_rate_from_rho(rho, A, sigma):
    """结构强度 -> 砖块延续胜率"""
    if abs(rho) < 1e-12:
        return 0.5
    T = (A / max(sigma, 1e-15)) ** 2
    mu = rho * A
    noise = sigma * np.sqrt(max(T, 1.0))
    return float(norm.cdf(mu / max(noise, 1e-15)))


def rho_crit_of(A, sigma, cost):
    """解出临界矛盾强度: p(rho) = p* 的 rho"""
    c = 2.0 * cost / A
    pstar = (1.0 + c) / 2.0
    if win_rate_from_rho(0.0, A, sigma) >= pstar:
        return 0.0, pstar
    lo, hi = 0.0, 1.0
    for _ in range(100):
        mid = 0.5 * (lo + hi)
        if win_rate_from_rho(mid, A, sigma) < pstar:
            lo = mid
        else:
            hi = mid
        if hi - lo < 1e-12:
            break
    return 0.5 * (lo + hi), pstar


def n_required(rho, alpha=0.05, power=0.80):
    """确认 rho 所需样本量"""
    if abs(rho) < 1e-9:
        return float("inf")
    za, zb = norm.ppf(1 - alpha / 2), norm.ppf(power)
    return ((za + zb) / abs(rho)) ** 2


# ============================================================================
# 四、主分析
# ============================================================================
def analyze_file(path, cost=DEFAULT_COST, a_mults=None, verbose=True):
    a_mults = a_mults or A_MULT_LIST
    px, colinfo = load_prices(path)
    n = len(px)
    name = os.path.basename(path)

    res = dict(file=path, name=name, n=n, cost=cost, col=colinfo,
               px_min=float(px.min()), px_max=float(px.max()),
               total_return=float(px[-1] / px[0] - 1))

    # --- 1. 矛盾强度 ---
    rho_res, r = measure_rho(px)
    sigma = float(np.std(r))
    rho1 = rho_res[1]["rho"]
    null_m, null_s = shuffle_null(px)
    rho_net = rho1 - null_m
    res.update(sigma=sigma, rho1=rho1, rho_se=rho_res[1]["se"],
               rho_z=rho_res[1]["z"], null_rho=null_m, null_sd=null_s,
               rho_net=rho_net, rho_multi=dict(
                   {str(k): v["rho"] for k, v in rho_res.items()}))

    # --- 2. 临界值表 ---
    table = []
    for am in a_mults:
        A = am * sigma
        rc, pstar = rho_crit_of(A, sigma, cost)
        nd = n_required(rho_net)
        n_bricks = n * sigma / A
        table.append(dict(
            A_mult=am, A_bp=A * 1e4, cost_ratio=2 * cost / A,
            pstar=pstar, rho_crit=rc,
            passes_strength=abs(rho_net) > rc,
            n_required=nd, n_bricks=n_bricks,
            passes_detect=nd < n_bricks,
        ))
    res["table"] = table

    feasible = [t for t in table if t["passes_strength"] and t["passes_detect"]]
    res["feasible"] = feasible
    res["has_feasible"] = len(feasible) > 0
    if feasible:
        b = min(feasible, key=lambda t: t["rho_crit"])
        res["best"] = b
    else:
        # 找最接近的
        cand = [t for t in table if t["passes_detect"]]
        res["best"] = min(cand, key=lambda t: t["rho_crit"]) if cand else None

    # --- 3. 稳定性 ---
    acf = rolling_rho(px, W=min(2000, max(200, n // 5)))
    v = acf[~np.isnan(acf)]
    if len(v) > 20:
        pos_ratio = float((v > 0).mean())
        res.update(roll_mean=float(np.mean(v)), roll_sd=float(np.std(v)),
                   pos_ratio=pos_ratio,
                   stable=bool(pos_ratio >= 0.8 or pos_ratio <= 0.2))
    else:
        res.update(roll_mean=None, roll_sd=None, pos_ratio=None, stable=False)

    # --- 4. 最终判定 ---
    ok = res["has_feasible"] and res.get("stable", False)
    res["verdict"] = "EXISTS" if ok else "NOT_FOUND"
    return res, px


def print_report(res):
    n = res["n"]
    print("=" * 88)
    print(f"文件: {res['name']}   (读取列: {res['col']})")
    print("=" * 88)
    print(f"  样本数   : {n}")
    print(f"  价格范围 : {res['px_min']:.4f} ~ {res['px_max']:.4f}")
    print(f"  区间总收益: {res['total_return']*100:+.2f}%")
    print(f"  单步波动 σ: {res['sigma']*1e4:.3f} bp")

    print("\n【1】矛盾强度 rho (自相关)")
    print("-" * 88)
    print(f"  lag-1 实测 rho : {res['rho1']:+.6f}   (标准误 {res['rho_se']:.6f}, "
          f"z = {res['rho_z']:+.2f})")
    print(f"  随机对照基线   : {res['null_rho']:+.6f} ± {res['null_sd']:.6f}")
    print(f"  扣除伪影后 rho : {res['rho_net']:+.6f}   <-- 真实矛盾强度")
    if abs(res["rho_z"]) < 1.96:
        print("  判定: 与零无显著差异 -> 矛盾未分化")
    elif res["rho_net"] > 0:
        print("  判定: 趋势(动量)主导")
    else:
        print("  判定: 反转(震荡)主导")

    print("\n【2】临界值 rho_crit —— 矛盾必须强过它才可能正期望")
    print("-" * 88)
    print(f"  {'砖块A':>9}{'成本占比':>10}{'p*':>9}{'临界ρ':>11}"
          f"{'实测|ρ|':>11}{'强度够?':>9}{'需样本':>10}{'可得砖':>9}{'可检测?':>9}")
    for t in res["table"]:
        print(f"  {t['A_bp']:>8.1f}bp{t['cost_ratio']:>10.4f}{t['pstar']:>9.4f}"
              f"{t['rho_crit']:>11.5f}{abs(res['rho_net']):>11.5f}"
              f"{'YES' if t['passes_strength'] else 'no':>9}"
              f"{t['n_required']:>10.0f}{t['n_bricks']:>9.0f}"
              f"{'OK' if t['passes_detect'] else '不够':>9}")

    print("\n【3】矛盾稳定性 (主要矛盾会不会转化?)")
    print("-" * 88)
    if res["pos_ratio"] is not None:
        print(f"  滚动 rho 均值  : {res['roll_mean']:+.6f}")
        print(f"  滚动 rho 标准差: {res['roll_sd']:.6f}")
        print(f"  为正的比例    : {res['pos_ratio']*100:.1f}%   "
              f"{'方向稳定' if res['stable'] else '方向会翻转(不稳定)'}")
    else:
        print("  样本不足以做滚动估计")

    print("\n" + "=" * 88)
    print("【最终判定】")
    print("=" * 88)
    if res["verdict"] == "EXISTS":
        b = res["best"]
        print(f"  存在可抓的矛盾")
        print(f"    砖块 A ≈ {b['A_bp']:.1f} bp")
        print(f"    实测 |rho| = {abs(res['rho_net']):.6f} > 临界 {b['rho_crit']:.6f}")
        print(f"    需样本 {b['n_required']:.0f} < 可得 {b['n_bricks']:.0f}")
        print(f"  含义: 该市场存在统计上可确认的正期望机会")
    else:
        b = res["best"]
        print(f"  未找到可抓的矛盾")
        print(f"    实测 |rho| = {abs(res['rho_net']):.6f}")
        if b:
            print(f"    最接近的砖块 A={b['A_bp']:.1f}bp 需要 |rho| > {b['rho_crit']:.6f}")
            print(f"    差距: 实测值仅为临界值的 "
                  f"{abs(res['rho_net'])/max(b['rho_crit'],1e-12)*100:.1f}%")
        if not res.get("stable", False) and res["pos_ratio"] is not None:
            print(f"    (且矛盾方向不稳定, 为正比例 {res['pos_ratio']*100:.0f}%)")
        print(f"  含义: 在这份数据下, 扣成本后未发现正期望机会")


# ============================================================================
# 五、CLI
# ============================================================================
def main():
    ap = argparse.ArgumentParser(description="真实市场矛盾强度检验器")
    sub = ap.add_subparsers(dest="cmd", required=True)

    d = sub.add_parser("download", help="下载数据")
    d.add_argument("--source", choices=["binance", "stooq", "yfinance"], required=True)
    d.add_argument("--symbol", default="BTCUSDT")
    d.add_argument("--interval", default="1h")
    d.add_argument("--days", type=int, default=365)
    d.add_argument("--period", default="730d")
    d.add_argument("--out", default="data")

    a = sub.add_parser("analyze", help="分析数据")
    a.add_argument("files", nargs="+")
    a.add_argument("--cost", type=float, default=DEFAULT_COST,
                   help="单边手续费率(默认 0.0001 = 万分之一)")
    a.add_argument("--json", default=None, help="输出 JSON 结果")

    args = ap.parse_args()

    if args.cmd == "download":
        print(f"数据源: {args.source}")
        if args.source == "binance":
            p = dl_binance(args.symbol, args.interval, args.days, args.out)
        elif args.source == "stooq":
            p = dl_stooq(args.symbol, args.out)
        else:
            p = dl_yfinance(args.symbol, args.interval, args.period, args.out)
        print(f"\n保存到: {p}" if p else "\n下载失败")
        return

    all_res = []
    for f in args.files:
        try:
            res, _ = analyze_file(f, cost=args.cost)
        except Exception as e:
            print(f"\n[!] 无法分析 {f}: {e}\n")
            continue
        print_report(res)
        print()
        all_res.append(res)

    if len(all_res) > 1:
        print("=" * 88)
        print("汇总")
        print("=" * 88)
        print(f"  {'文件':<28}{'|rho|':>11}{'临界(最小)':>12}{'判定':>12}")
        for r in all_res:
            b = r["best"]
            crit = f"{b['rho_crit']:.5f}" if b else "—"
            v = "存在" if r["verdict"] == "EXISTS" else "未发现"
            print(f"  {r['name'][:26]:<28}{abs(r['rho_net']):>11.6f}{crit:>12}{v:>12}")

    if args.json and all_res:
        with open(args.json, "w", encoding="utf-8") as f:
            json.dump(all_res, f, ensure_ascii=False, indent=2, default=str)
        print(f"\nJSON 已保存: {args.json}")


if __name__ == "__main__":
    main()
