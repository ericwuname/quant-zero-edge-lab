import sys
sys.path.insert(0, "/data/skills/docx/scripts")

from docxlib import (
    open_docx, save_docx, ensure_yuanbao_defaults,
    add_heading, add_paragraph, add_page_break,
    add_table_double_width, add_footer_page_number,
    set_page_size,
)

doc = open_docx()
ensure_yuanbao_defaults(doc)
set_page_size(doc.sections[0], 11906, 16838)  # A4

# ============ 封面标题 ============
add_heading(doc, "个人交易决策系统 v1.0", level=1)
add_paragraph(doc, "防守型框架 · 基于数十轮回测验证的可执行规格", style="Normal")
add_paragraph(doc, "核心定位：不追求预测方向（已验证不可测），只做「测量可信 + 亏损有界 + 赚到即落袋」。", style="Normal")

# ============ 一、核心判据 ============
add_heading(doc, "一、核心判据（10 秒判生死）", level=1)
add_paragraph(doc, "拿到任何一个策略，先过这五条。任何一条不过，不进入下一步。", style="Normal")

add_table_double_width(
    doc,
    headers=["判据", "公式 / 内容", "用法"],
    rows=[
        ["期望分解", "E = (R+1) × (p − 1/(1+R))", "别看夏普回撤，只看「实测胜率 − 保本胜率」"],
        ["净保本胜率", "p* = (1 + cost_R) / (1 + R)", "R=2、cost_R=0.05 → p*=35.0%（不是 33.3%）"],
        ["成本锁定", "cost_R = 2 × 成本bp ÷ (止损% × 10⁴)", "止损宽度与 cost_R 是同一式两端，不能各自设"],
        ["障碍几何", "P = (1−b) / (1−b+u)", "亏80%赚100% → 44.4% 是白送的，与能力无关"],
        ["零期望对照", "同波动、期望归零的对照", "没有它，P 和 t 值都无法解释"],
    ],
    column_widths_dxa=[1600, 4000, 3760],
    header_shading="D5E8F0",
)

add_paragraph(doc, "验证记录：brk50 R=2 时 Δp=+1.09pp，公式预测 E=+0.0327，实测 +0.0321，误差 0.0006。", style="Normal")

# ============ 二、已验证的市场事实 ============
add_heading(doc, "二、已验证的市场事实", level=1)
add_paragraph(doc, "以下均由真实数据回测得出，可直接引用，不必重复验证。", style="Normal")

add_table_double_width(
    doc,
    headers=["事实", "数值", "含义"],
    rows=[
        ["方向能力 alpha", "−0.0003", "信号 vs 随机方向，与零不可区分"],
        ["方向可预测性", "IC=+0.0009, t=+0.20", "等于抛硬币，不可测"],
        ["波动可预测性", "IC=+0.700, t=+44.55", "13/13 全正，这是唯一强信号"],
        ["有效市场数", "N_eff 上限 = 2.0", "crypto ρ=0.497，加品种无用"],
        ["换手率效应", "Q1 +0.0283 / Q5 −0.0093", "单调负相关，无一例外"],
        ["幸存者偏差", "−3.7% → −54.9%", "加回 53.2% 归零者后的真实值"],
        ["检测门槛", "夏普 0.673", "实测最优 0.097，仅门槛的 14%"],
    ],
    column_widths_dxa=[2200, 2800, 4360],
    header_shading="D5E8F0",
)

add_paragraph(doc, "关键推论：能测量风险（σ），但测不出风险值多少钱（μ）。这正是「卖保险」无法转正的根因——你有精算表，但没有定价表。", style="Normal")

# ============ 三、禁区 ============
add_page_break(doc)
add_heading(doc, "三、禁区（负面清单，优先级最高）", level=1)
add_paragraph(doc, "以下每一条都有实测数据支撑，且多数来自真实亏损教训。违反任一条，其余规格全部作废。", style="Normal")

add_table_double_width(
    doc,
    headers=["禁区", "实测证据", "后果"],
    rows=[
        ["加杠杆", "2x 爆仓率 92.3%（3年样本）／约 46%（1年滚动）", "均值正、中位归零；存活者赚 18 倍"],
        ["合约网格", "做多死在跌 42%、做空死在涨 36.6%", "方向不可测，两端都会死"],
        ["猜方向 / 择时", "alpha = −0.0003，方向 t=0.20", "长期与抛硬币无异"],
        ["逆势判断", "rev20 vs 随机 t=−2.20（OLD7 −2.75）", "显著有害，唯一确证的负面规律"],
        ["用 ATR 定网格区间", "62% 为正，Calmar 0.31（最差方法）", "ATR 是单根 K 线波动，用于区间会太窄"],
        ["破网后移仓重启", "年化 0.025 vs 不设防 0.095", "每次移仓 = 浮亏变实亏，死亡螺旋"],
        ["ADX 过滤 + 时间退出并用", "年化掉到 0.018", "两个开关互相打架，只能二选一"],
    ],
    column_widths_dxa=[2600, 3600, 3160],
    header_shading="F2D5D5",
)

# ============ 四、主方案：现货网格规格 ============
add_heading(doc, "四、主方案 · 现货网格执行规格", level=1)
add_paragraph(doc, "网格是「卖保险」结构：震荡收保费，单边赔付。它的正确定位是震荡市收租工具，不是万能策略。", style="Normal")

add_heading(doc, "4.1 区间设定公式（等比网格）", level=2)
add_paragraph(doc, "最低价 = 中心价 × (1 − k)", style="Normal")
add_paragraph(doc, "最高价 = 中心价 × (1 + k)", style="Normal")
add_paragraph(doc, "格距 g = [(1+k)/(1−k)]^(1/N) − 1   （等比，非等差）", style="Normal")
add_paragraph(doc, "示例：现价 P=100，k=25%，N=10 → 最低 75，最高 125，格距 5.24%", style="Normal")

add_heading(doc, "4.2 参数规格表", level=2)
add_table_double_width(
    doc,
    headers=["参数", "取值", "依据"],
    rows=[
        ["网格类型", "等比（区间 >30% 时）", "±35% 时等比 0.194 vs 等差 0.093"],
        ["区间宽度 k", "±25% ~ ±30%", "±10% 太窄（重启204次），±40% 太宽"],
        ["格数 N", "10（资金<200U）／20（≥500U）／100（≥1000U）", "每格金额 ≥ 5 USDT 为硬下限"],
        ["中心价", "建仓时现价", "MA 中心会让重启次数暴增 6 倍"],
        ["更新频率", "每 168 根 bar（约一周）重挂", "年化 +3.6pp，回撤 −9pp"],
        ["初始仓位", "半仓 0.5", "现货方向差异 <5%，半仓最稳"],
        ["离场条件", "21 天无成交即平仓", "最大回撤 0.563 → 0.167"],
        ["杠杆", "1x 现货", "2x 爆仓率 92.3%"],
    ],
    column_widths_dxa=[2000, 3600, 3760],
    header_shading="D5E8F0",
)

# ============ 五、资金管理 ============
add_page_break(doc)
add_heading(doc, "五、资金管理 · 以损定量 + 收割制", level=1)

add_heading(doc, "5.1 单点投入金额", level=2)
add_paragraph(doc, "单店资金 C = 可承受全损金额 ÷ 0.18（0.18 为实测最坏亏损比例）", style="Normal")
add_paragraph(doc, "每格金额 m = C ÷ N", style="Normal")
add_paragraph(doc, "硬下限：C_min = N × 5 USDT（交易所最小下单额）", style="Normal")
add_paragraph(doc, "示例：可承受亏损 1000 元 → C ≈ 5500 元；N=20 → 每格约 275 元", style="Normal")

add_heading(doc, "5.2 收割规则（不复利）", level=2)
add_table_double_width(
    doc,
    headers=["规则", "设定", "作用"],
    rows=[
        ["结算频率", "每周一次", "定期把运气兑现成现金"],
        ["提取规则", "净值超出本金部分全部提取", "让「赚到」变成「落袋」"],
        ["净值重置", "提取后回到初始本金继续跑", "保持风险敞口恒定"],
        ["达标结算", "翻倍时额外结算一次", "大额兑现，防回吐"],
        ["关店线", "亏 80% 关店，剩余入公积金", "单店风险封顶"],
        ["复利", "不复利，固定注", "净值涨了不加注"],
    ],
    column_widths_dxa=[2200, 3400, 3760],
    header_shading="D5E8F0",
)

add_paragraph(doc, "重要区分：网格收割提取的是「已实现价差」，不是浮盈。震荡市可稳定提取，单边市几乎无可提取——这恰好在应收手时自动收手。", style="Normal")

# ============ 六、方法纪律 ============
add_heading(doc, "六、方法纪律 · 防 bug 检查清单", level=1)
add_paragraph(doc, "核心规律：漂亮结果 = bug。以下 8 个 bug 全部出现在「最漂亮的结果」上，无一例外。", style="Normal")

add_table_double_width(
    doc,
    headers=["#", "Bug 类型", "制造出的假结果"],
    rows=[
        ["1", "收盘价代替 bar 内路径", "收益虚高"],
        ["2", "scale 未检查止损", "t = 19.46"],
        ["3", "flip 让盈亏比失效", "语义矛盾"],
        ["4", "off-by-one 前视", "E = +0.78, t = 134"],
        ["5", "信号用 close 却在 open 建仓", "brk50 / mom240 全塌"],
        ["6", "时段效应时间泄漏", "t = 9.856"],
        ["7", "同 bar 平仓后再入场", "t = 9.41"],
        ["8", "唐奇安写成「全做空」", "Δp +4.02, RC p = 0.003"],
    ],
    column_widths_dxa=[700, 4200, 4460],
    header_shading="F2D5D5",
)

add_heading(doc, "6.1 任何新策略必过的四道检查", level=2)
add_paragraph(doc, "① 三重外推：时间切分 + 品种切分 + 参数切分（选中→验证平均衰减 54%~63%）", style="List Bullet")
add_paragraph(doc, "② 零期望对照：45 个随机信号挑最强，平均 t=+1.963——比真实数据最强 t=+1.529 还高", style="List Bullet")
add_paragraph(doc, "③ 配对检验剥离 beta：alpha = E(信号) − E(随机方向)", style="List Bullet")
add_paragraph(doc, "④ 先看代码再看结果：越漂亮越可疑", style="List Bullet")

# ============ 七、预期与边界 ============
add_page_break(doc)
add_heading(doc, "七、预期与边界（10,000 元本金，一年）", level=1)

add_table_double_width(
    doc,
    headers=["情形", "年化", "一年后", "盈亏"],
    rows=[
        ["悲观（25分位）", "+8.7%", "10,870 元", "+870 元"],
        ["中位（最可能）", "+12.9%", "11,290 元", "+1,290 元"],
        ["乐观（75分位）", "+44.5%", "14,450 元", "+4,450 元"],
        ["最差（FIL 式单边阴跌）", "−37.7%", "6,230 元", "−3,770 元"],
        ["最好（ZEC 式暴涨）", "+176.8%", "27,680 元", "+17,680 元"],
    ],
    column_widths_dxa=[3000, 1800, 2200, 2360],
    header_shading="D5E8F0",
)

add_paragraph(doc, "过程中会见到：最大回撤中位 20.3% → 账户一度跌到约 7,970 元。能否扛住而不中途停止，决定能否拿到那 1,290 元。", style="Normal")

add_heading(doc, "7.1 三条必说的边界", level=2)
add_paragraph(doc, "① 均值 26.5% 是假的——ZEC 一个 +176.76% 把均值拉高，剔除后中位几乎不变（12.91% → 12.79%）。只看中位数。", style="List Bullet")
add_paragraph(doc, "② 幸存者偏差——13 个品种全部活到今天，真正归零的币不在样本里，而它们正是网格最致命的场景。", style="List Bullet")
add_paragraph(doc, "③ 只有 38% 跑赢买入持有——它是「在失败者身上赢、在赢家身上输」，中位好看但右尾被削。", style="List Bullet")

# ============ 八、Agent 定位 ============
add_heading(doc, "八、Agent 的正确定位", level=1)
add_paragraph(doc, "测试结果：Agent 判断交易时机，无法把胜率拉向好的方向。", style="Normal")

add_table_double_width(
    doc,
    headers=["用法", "实测结果", "结论"],
    rows=[
        ["开关网格（12 变体）", "最高分位 0.54，无一达 95 分位", "11/12 无效"],
        ["离场判断（ADX）", "真实超额 +0.042 vs 随机挑最强 +0.211", "0/13 胜随机"],
        ["纪律执行", "硬编码：仓位上限、禁杠杆、到点收割", "最有效，推荐"],
        ["扩大扫描（增 N）", "7×24 监控多品种", "有效，是「多开店」不是提高胜率"],
        ["执行优化降成本", "挂单时机、减少不必要成交", "唯一 100% 有效的动作"],
    ],
    column_widths_dxa=[2600, 3800, 2960],
    header_shading="D5E8F0",
)

add_paragraph(doc, "根因：Agent 能看见风暴（波动可测 t=44），但不知道风暴何时结束（方向不可测 t=0.20）。「躲」的代价永远大于「扛」。", style="Normal")

# ============ 九、核心认知 ============
add_heading(doc, "九、核心认知（整套系统的地基）", level=1)
add_paragraph(doc, "确定侧管形状，不确定侧管期望。", style="Normal")
add_paragraph(doc, "形状 = 你愿意承担什么风险；期望 = 谁为这个承担付你钱。", style="Normal")
add_paragraph(doc, "在价格数据里搜，是在找「承担」，不是在找「付款人」。付款人只有一个：需要你服务的那个人。", style="Normal")
add_paragraph(doc, "你控制不了单次结果（是运气），但能控制：站在哪个分布里、坏运气来时亏多少、好运气来时能否真的拿走。", style="Normal")
add_paragraph(doc, "最终落点：赚到就落袋，让运气变成已兑现的现金，不留在桌上等下一次。", style="Normal")

add_footer_page_number(doc.sections[0], prefix="第 ", suffix=" 页")
save_docx(doc, "/data/workspace/方案交付/个人交易决策系统方案.docx")
print("OK")
